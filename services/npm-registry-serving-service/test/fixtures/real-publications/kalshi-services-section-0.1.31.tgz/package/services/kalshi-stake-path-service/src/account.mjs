/**
 * The Kalshi account as the venue states it, never as a ledger remembers it. Shared by the desk app
 * and the desk review.
 */
import { collateralCents } from './desk-plan.mjs';

const cents = (dollars) => Math.round(Number(dollars) * 100);
const eventOf = (ticker) => ticker.slice(0, ticker.lastIndexOf('-'));
const seriesOf = (ticker) => ticker.slice(0, ticker.indexOf('-'));

/** Settled positions the desk held on the losing side: NO held on a market that settled yes, or YES on one that settled no. */
export const deskLosses = (outcomes) => outcomes.filter(row => row.completeOrderFills === true && row.standaloneRealized === true && row.won === false).length;

/** The account as the venue states it: cash, equity, every position and every resting order, both sides, and thirty days of settlements. */
export async function readAccount(client, now = Date.now(), { deskOutcomes = null, includeSettlements = true } = {}) {
  const balance = await client.getBalance();
  const positionsPayload = await client.getPositions({ count_filter: 'position', subaccount: 0 });
  const orders = await client.getOrders({ status: 'resting', subaccount: 0 });
  // Placement needs current capital and exposure. Settlement history belongs
  // to the existing review operation, rather than another read every cycle.
  const settlements = includeSettlements ? await client.getSettlements({ min_ts: Math.floor(now / 1000) - 30 * 86400, subaccount: 0 }) : [];
  const positions = (positionsPayload.market_positions ?? [])
    .filter((row) => Number(row.position_fp) !== 0)
    .map((row) => ({ ticker: row.ticker, eventTicker: eventOf(row.ticker), seriesTicker: seriesOf(row.ticker), side: Number(row.position_fp) < 0 ? 'no' : 'yes', contracts: Math.abs(Number(row.position_fp)), costCents: cents(row.market_exposure_dollars) }));
  const resting = orders.map((order) => ({
    orderId: order.order_id, ticker: order.ticker, eventTicker: eventOf(order.ticker),
    createdAt: order.created_time ?? null,
    bookSide: order.book_side ?? ((order.side === 'yes' && order.action === 'sell') || (order.side === 'no' && order.action === 'buy') ? 'ask' : 'bid'),
    priceCents: cents(order.yes_price_dollars), count: Number(order.remaining_count_fp), expiration: order.expiration_time ?? null,
    // Exact counts for an amend, whose count is the order's total fillable: filled plus what should rest.
    filledCount: Number(order.fill_count_fp ?? 0), remainingCount: Number(order.remaining_count_fp ?? 0),
    // The desk's own orders carry its kd- client ids; anything else was placed by hand and is never the desk's to manage.
    clientOrderId: order.client_order_id ?? null, own: String(order.client_order_id ?? '').startsWith('kd-'),
  }));
  const queueObservation = await readDeskQueues(client, resting);
  // Kalshi's balance does not set aside a resting order's collateral (seen 2026-10-03: $25.00 with
  // $16.66 resting), so equity is cash plus positions, and only cash beyond resting collateral is free.
  // balance_dollars carries the account's $0.0001 grid; the integer `balance` truncates it to the cent.
  const cashCents = balance.balance_dollars !== undefined ? Math.round(Number(balance.balance_dollars) * 1e4) / 100 : balance.balance;
  const restingCollateralCents = resting.reduce((sum, order) => sum + collateralCents(order), 0);
  // Account holdings and settlements remain complete for capital/exposure.
  // Desk performance uses previously qualified kd outcomes, never ticker membership.
  const deskSettlements = (deskOutcomes ?? []).filter(row => row.completeOrderFills === true && row.standaloneRealized === true && Date.parse(row.settledAt) >= now - 30 * 86400_000 && Date.parse(row.settledAt) <= now);
  const deskEvidenceStatus = deskOutcomes === null ? 'unavailable' : 'qualified-order-outcomes';
  return { cashCents, freeCashCents: cashCents - restingCollateralCents, portfolioCents: balance.portfolio_value, equityCents: cashCents + balance.portfolio_value, restingCollateralCents, positions, resting, queueObservation, losses30d: deskOutcomes === null ? null : deskLosses(deskSettlements), settlements, settlementsRead: includeSettlements, deskSettlements, deskEvidenceStatus };
}


/** One bounded batch uses the venue's real price-time priority. An unavailable
 * optional observation cannot block account reads, surveys or execution. */
async function readDeskQueues(client, resting) {
  const own = resting.filter(order => order.own);
  if (!own.length) return { status: 'not-needed', requestedOrders: 0, observedOrders: 0 };
  if (typeof client.getQueuePositions !== 'function') return { status: 'unavailable', requestedOrders: own.length, observedOrders: 0, reason: 'native queue reader unavailable' };
  const tickers = [...new Set(own.map(order => order.ticker))], selected = tickers.slice(0, 100);
  try {
    const packet = await client.getQueuePositions({ market_tickers: selected.join(','), subaccount: 0 });
    const receivedAt = new Date().toISOString(), positions = new Map();
    if (!Array.isArray(packet?.queue_positions)) throw new TypeError('queue position array required');
    for (const row of packet.queue_positions) {
      if (!own.some(order => order.orderId === row.order_id && order.ticker === row.market_ticker)) continue;
      if (typeof row.queue_position_fp !== 'string' || !/^\d{1,18}(?:\.\d{1,2})?$/u.test(row.queue_position_fp)) throw new TypeError('exact nonnegative queue position required');
      if (positions.has(row.order_id) && positions.get(row.order_id) !== row.queue_position_fp) throw new TypeError('contradictory queue position');
      positions.set(row.order_id, row.queue_position_fp);
    }
    for (const order of own) { order.queuePositionFp = positions.get(order.orderId) ?? null; order.queueReceivedAt = positions.has(order.orderId) ? receivedAt : null; }
    return { status: positions.size === own.length ? 'observed' : 'partial', receivedAt, requestedOrders: own.length, observedOrders: positions.size, tickerLimit: 100 };
  } catch (error) {
    return { status: 'unavailable', requestedOrders: own.length, observedOrders: 0, reason: error.code ?? error.message };
  }
}

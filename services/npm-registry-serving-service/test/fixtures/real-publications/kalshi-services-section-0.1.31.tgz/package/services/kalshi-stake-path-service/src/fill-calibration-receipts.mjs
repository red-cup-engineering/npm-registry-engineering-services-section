/**
 * Read-only Kalshi venue -> shared binary fill-calibration evidence adapter.
 *
 * Inputs are already received, custody-held exchange orders, fills and final
 * markets plus the desk's ORIGINAL placement records. Never invent no-fills
 * from missing fill rows, resting orders, expired orders, partial orders or
 * missing historical pagination. This module DOES NOT query/write the venue,
 * train a model, place an order, or create another persistent store.
 *
 * A one-lot resting order is eligible only with:
 * - original desk placement and exact venue order/client ID matching;
 * - a final, terminal venue order record with timestamp and exact size;
 * - complete fill query coverage for the order's life, even for no-fill;
 * - unambiguous $1 binary settlement, actual market-side/source/date receipt;
 * - a market/event/settlement population and quote regime named by the
 *   caller's source-scoped research cohort.
 *
 * For a no-fill, the order must have remained live for the declared
 * observation window. An early cancellation cannot be a Bernoulli no-fill.
 */
import {eventDate} from '@red-cup-engineering/kalshi-services-section/market-facts';
import {deskIntentProvenance} from './desk-book-provenance.mjs';
import {bookSideOfVenueOrder} from './book.mjs';
const clock=x=>typeof x==='string'&&Number.isFinite(Date.parse(x));
const label=x=>typeof x==='string'&&x.trim().length>0;
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const qty=x=>x===null||x===undefined?null:Number(x);
const terminal=new Set(['executed','canceled','cancelled','expired']);
const reason=(id,why)=>({orderId:id??null,reason:why});
export function joinKalshiFillCalibrationReceipts({
 ledgerEntries=[],orders=[],fills=[],markets=[],at,
 familyScope,quoteRegime,side,observationHorizonMs,
 fillCoverage,settlementCoverage,
}={}){
 if(!clock(at)||!label(familyScope)||!label(quoteRegime)||
    !['yes','no'].includes(side)||!Number.isSafeInteger(observationHorizonMs)||
    observationHorizonMs<1000||observationHorizonMs>24*3600_000||
    !Array.isArray(ledgerEntries)||!Array.isArray(orders)||
    !Array.isArray(fills)||!Array.isArray(markets)||
    [ledgerEntries,orders,fills,markets].some(a=>a.length>100000))
   throw new TypeError('bounded, fully named venue receipt join required');
 // The collector, not this pure join, must show its full query range.
 if(!fillCoverage||!clock(fillCoverage.from)||!clock(fillCoverage.through)||
    !settlementCoverage||!clock(settlementCoverage.from)||!clock(settlementCoverage.through)||
    Date.parse(fillCoverage.from)>Date.parse(fillCoverage.through)||
    Date.parse(settlementCoverage.from)>Date.parse(settlementCoverage.through)||
    Date.parse(fillCoverage.through)>Date.parse(at)||
    Date.parse(settlementCoverage.through)>Date.parse(at)||
    fillCoverage.complete!==true||settlementCoverage.complete!==true)
   throw new TypeError('complete bounded fill and settlement pagination receipts required');
 const orderMap=new Map(),marketMap=new Map(),fillMap=new Map();
 for(const o of orders){
   if(!label(o?.order_id)||orderMap.has(o.order_id))throw new TypeError('duplicate/missing venue order ID');
   orderMap.set(o.order_id,o);
 }
 for(const m of markets){
   if(!label(m?.ticker)||marketMap.has(m.ticker))throw new TypeError('duplicate/missing market source');
   marketMap.set(m.ticker,m);
 }
 for(const f of fills){
   if(!label(f?.order_id)||!label(f?.trade_id)||!clock(f.created_time))
     throw new TypeError('fill requires venue order, trade ID and exchange time');
   const group=fillMap.get(f.order_id)??[];
   if(group.some(x=>x.trade_id===f.trade_id))throw new TypeError('duplicate venue fill trade');
   group.push(f);fillMap.set(f.order_id,group);
 }
 // Read the BOOK SOURCE PAYLOAD from the desk's existing ledger.
 // A pretty 'sha256:' string in a place record is NOT itself evidence that
 // the book really existed or that the scope was observed.
 const originalBooks=ledgerEntries.filter(x=>x?.kind==='book-evidence');
 const rows=[],withheld=[],seen=new Set();
 for(const place of ledgerEntries.filter(x=>x?.kind==='place')){
   const id=place.orderId;
   if(!label(id)||seen.has(id)){withheld.push(reason(id,'missing-or-duplicated-desk-placement-identity'));continue}
   seen.add(id);
   const o=orderMap.get(id),m=marketMap.get(place.ticker);
   if(!o||!m||!label(place.clientOrderId)||!label(o.client_order_id)||
      o.client_order_id!==place.clientOrderId||o.ticker!==place.ticker){
    withheld.push(reason(id,'missing-or-mismatched-venue-order-and-market'));continue;
   }
   const purchasedSide=place.bookSide==='bid'?'yes':place.bookSide==='ask'?'no':null;
   const venueBookSide=bookSideOfVenueOrder(o);
   const orderSide=venueBookSide==='bid'?'yes':venueBookSide==='ask'?'no':null;
   if(purchasedSide!==side||orderSide!==side||
      place.execution?.mode==='taker'||o.post_only!==true){
    withheld.push(reason(id,'not-a-matching-post-only-maker-one-lot'));continue;
   }
   const count=qty(o.initial_count_fp??o.count_fp??o.count),
     filled=qty(o.fill_count_fp??o.fill_count),
     remaining=qty(o.remaining_count_fp??o.remaining_count);
   if(count!==1||filled===null||remaining===null||
      ![filled,remaining].every(finite)||filled<0||filled>1||
      remaining<0||remaining>1||Math.abs(filled+remaining-1)>1e-8||
      !clock(place.at)||!clock(place.orderIntentAt)||
      !clock(o.created_time)||!clock(o.updated_time)||
      !terminal.has(o.status)){
    withheld.push(reason(id,'missing-terminal-exact-one-lot-order-state'));continue;
   }
   const born=Date.parse(o.created_time),end=Date.parse(o.updated_time);
   if(born<Date.parse(place.orderIntentAt)-60_000||
      born>Date.parse(o.updated_time)||
      Date.parse(place.bookReceivedAt)>Date.parse(place.orderIntentAt)||
      Date.parse(place.orderIntentAt)-Date.parse(place.bookReceivedAt)>60_000||
      !clock(m.settlement_ts)||!clock(m.settlementAvailableAt)||
      !['yes','no'].includes(m.result)||m.is_provisional!==false||
      m.status!=='finalized'||m.ticker!==o.ticker||
      !eventDate(m.event_ticker)||!label(m.settlementReceiptId)||
      m.familyScope!==familyScope||m.quoteRegime!==quoteRegime||
      !clock(place.bookReceivedAt)||!label(place.bookReceiptId)){
    withheld.push(reason(id,'incomplete-market-source-or-original-book-provenance'));continue;
   }
   const day=eventDate(m.event_ticker);
   const fillsHere=fillMap.get(id)??[];
   const summed=fillsHere.reduce((n,f)=>n+Number(f.count_fp??NaN),0);
   if(!clock(place.bookReceivedAt)||!label(place.bookReceiptId)||
      !label(place.originalQuoteRegime)||place.originalQuoteRegime!==quoteRegime||
      !label(place.originalFamilyScope)||place.originalFamilyScope!==familyScope){
     withheld.push(reason(id,'original-book-scope-and-quote-regime-unverified'));continue;
   }
   // Original book and rules are one immutable DATA receipt (the earlier
   // book-evidence ledger entry) tied to this specific order intent. A
   // source address supplied without bytes, or a later rule substitution,
   // cannot supply the original fill/queue research cohort.
   const matches=originalBooks.filter(e=>
      e.bookReceiptId===place.bookReceiptId&&
      e.orderIntentAt===place.orderIntentAt&&
      e.lane===place.lane&&e.ticker===place.ticker&&
      e.priceCents===place.priceCents&&e.bookSide===place.bookSide);
   if(matches.length!==1){
     withheld.push(reason(id,'missing-or-ambiguous-original-book-evidence-payload'));continue;
   }
   const original=matches[0];
   try{
     const bound=deskIntentProvenance({
       order:{lane:place.lane,ticker:place.ticker,bookSide:place.bookSide,
         priceCents:place.priceCents,eventTicker:place.eventTicker,
         seriesTicker:place.seriesTicker,targetDate:place.targetDate},
       bookObservation:{lane:original.lane,ticker:original.ticker,
         receivedAt:original.bookReceivedAt,book:original.book,
         bookReceiptId:original.bookReceiptId},
       marketObservation:original.marketEvidence,
       intentAt:place.orderIntentAt,ttlMinutes:place.originalTtlMinutes,
     });
     if(bound.provenanceStatus!=='source-bound-book'||
        bound.bookReceiptId!==place.bookReceiptId||
        bound.bookReceivedAt!==place.bookReceivedAt||
        bound.marketRulesReceiptId!==place.marketRulesReceiptId||
        bound.originalFamilyScope!==familyScope||
        bound.originalQuoteRegime!==quoteRegime||
        original.originalFamilyScope!==familyScope||
        original.originalQuoteRegime!==quoteRegime||
        original.originalTtlMinutes!==place.originalTtlMinutes||
        original.bookReceivedAt!==place.bookReceivedAt||
        original.marketRulesReceiptId!==place.marketRulesReceiptId||
        place.provenanceStatus!=='source-bound-book'||
        !label(m.rules_primary)||
        m.rules_primary!==bound.marketEvidence?.market?.rulesPrimary||
        (m.rules_secondary??null)!==(bound.marketEvidence?.market?.rulesSecondary??null)||
        place.targetDate!==day||place.eventTicker!==m.event_ticker){
       withheld.push(reason(id,'original-source-and-order-intent-do-not-reconcile'));continue;
     }
   }catch{
     withheld.push(reason(id,'original-book-or-market-source-digest-invalid'));continue;
   }
   if(fillsHere.some(f=>!finite(Number(f.count_fp))||Number(f.count_fp)<=0||
        Date.parse(f.created_time)<born||Date.parse(f.created_time)>end)||
      Math.abs(summed-filled)>1e-8||
      (filled!==0&&filled!==1)||
      (filled===0&&o.status==='executed')||
      (filled===1&&o.status!=='executed')||
      (filled===0&&end-born<observationHorizonMs)||
      Date.parse(fillCoverage.from)>born||
      Date.parse(fillCoverage.through)<end||
      Date.parse(settlementCoverage.from)>Date.parse(m.settlement_ts)||
      Date.parse(settlementCoverage.through)<Date.parse(m.settlementAvailableAt)||
      Date.parse(m.settlementAvailableAt)>Date.parse(at)||
      end>=Date.parse(m.settlement_ts)){
    withheld.push(reason(id,'incomplete-fill-horizon-or-custody-reconciliation'));continue;
   }
   // Require actual terminal, final publication and source receipts,
   // not the market's retrospective 'as of' time for availability.
   rows.push({
      venueOrderId:id,executionReceiptId:'kalshi:order:'+id+':terminal:'+o.updated_time,
      settlementReceiptId:m.settlementReceiptId,
      familyScope,quoteRegime,side,eventId:m.event_ticker,marketId:m.ticker,
      targetDate:day,settlementSide:m.result,settlementStatus:'finalized',
      attemptedContracts:1,filledContracts:filled,filled:filled===1,
      bookReceivedAt:place.bookReceivedAt,placedAt:o.created_time,
      terminalAt:o.updated_time,settledAt:m.settlement_ts,
      settlementAvailableAt:m.settlementAvailableAt,
      ...(filled===1?{fillReceivedAt:fillsHere.map(f=>f.created_time)
        .sort((a,b)=>Date.parse(b)-Date.parse(a))[0]}:{}),
      evidenceIds:[place.bookReceiptId,place.marketRulesReceiptId,'kalshi:order:'+id,
        ...fillsHere.map(f=>'kalshi:fill:'+f.trade_id),m.settlementReceiptId],
   });
 }
 return {kind:'kalshi-one-lot-fill-join-v1',asOf:at,rows,
   withheld,considered:seen.size,eligible:rows.length,
   caveats:['source coverage, original post-only venue order and book timestamps must be independently received',
    'mixed or partially filled orders and early cancellations are not reliable Bernoulli no-fills',
    'output is research input, not independently authenticated venue truth or trade admission'],
   tradeEligible:false,orderEffect:false};
}

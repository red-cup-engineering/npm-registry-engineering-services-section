/**
 * The desk's one import of the venue-neutral sizer
 * (@red-cup-engineering/mandate-portfolio-allocation-service), and the desk's portfolio sizing in front of it.
 *
 * `sizing.method: 'portfolio-joint'` sizes every opportunity of the cycle TOGETHER, as one log-optimal portfolio
 * over their joint outcomes (position-sizing-service jointKellyForScenarioReturns), instead of giving each its own
 * Kelly fraction as if it were the only bet. Per-bet Kelly over-commits whenever bets are simultaneous: on
 * 2026-10-11 three bets settling 2026-10-12 (LA and Atlanta high tails at 3c, Pittsburgh rain at 8c) asked for
 * 47% + 47% + 76% = 169% of equity, which only the cash and per-event caps held back.
 *
 * The joint outcome model:
 *   - Opportunities are grouped by lane and by `sizing.groupBy[lane]`: 'date' (its correlation.date: everything the
 *     lane holds settling that day) or 'event' (its correlation.event). The evidence decides the level: the tail
 *     lane's record counts its trials by settlement day (forecasting data/records/2026-10-10-temperature-tail-days),
 *     so its bets on one date are one trial.
 *   - Inside a group the bets fail TOGETHER: one shared shock U ~ Uniform(0,1), and bet i loses iff U < q_i, where
 *     q_i = 1 - winProbability_i. Each bet keeps its own loss probability exactly; their dependence is the largest
 *     any marginals allow (comonotone), which is what counting a day as one trial assumes. For brackets of one
 *     ladder, whose losses are in truth exclusive, this overstates joint loss: the sizing errs small, never large.
 *   - Groups are independent of one another. No cross-lane common failure is assumed: the record does not measure
 *     one, and an unmeasured parameter does not size real money.
 *   - Firm positions contribute gross settlement payouts, including positions on candidates and in groups
 *     with no new candidate. Their current, same-instrument prediction supplies their probability. Unread
 *     positions contribute the explicit payout lower bound zero; a candidate never lends its odds to another
 *     instrument. Cash plus these payouts is terminal wealth, divided by current marked equity for units.
 *   - Retained candidate orders are contingent purchases. The variable sizes their desired TOTAL collateral;
 *     the venue allocator subtracts just that retained collateral. Firm positions remain fixed and count
 *     against exposure limits, but are never subtracted again from an incremental recommendation.
 *   - Other retained orders are modeled conditional on full fill at their quoted collateral, with a zero-payout
 *     lower bound when their prediction is unread. No fill probability is invented.
 * The Kelly multiple and capital evidence weight shrink the proposed purchases once. The orders carry
 * their true win probabilities; an equivalent probability is only the venue allocator's fraction interface.
 * The reported lower bound is conditional on the stated joint model and full fills, not a profit forecast
 * for unknown holdings or an estimate of maker fill selection.
 *
 * A cycle whose joint outcomes would exceed the optimizer's bounds (64 opportunities, 20000 scenarios) sizes each
 * group on its own and scales the fractions so that together they stake at most the whole budget.
 */
import { allocateOpportunities as allocateVenueNeutral } from '@red-cup-engineering/mandate-portfolio-allocation-service/allocate-opportunities';
import { jointKellyForScenarioReturns } from '@red-cup-engineering/position-sizing-service';

const MAX_INSTRUMENTS = 64;
const MAX_SCENARIOS = 20000;

/** The win probability at which single-bet Kelly, (b p - (1 - p)) / b, equals `fraction` for payoff ratio b. */
export const kellyEquivalentWinProbability = (fraction, payoffRatio) => (fraction * payoffRatio + 1) / (payoffRatio + 1);

/** Group key of an opportunity: its lane and its correlation date or event, as `groupBy` names for that lane. */
const groupKey = (opportunity, groupBy) => `${opportunity.lane}\u0000${(groupBy?.[opportunity.lane] ?? 'date') === 'event' ? opportunity.correlation.event : opportunity.correlation.date}`;

/**
 * One group's joint outcomes under a shared shock: bet i loses iff U < q_i. Sorted by q, the distinct thresholds
 * cut [0, 1] into intervals; in each, the bets whose q lies above the interval lose. Returns
 * [{probability, loses: Set<index>}] with probabilities summing to 1.
 */
export function sharedShockScenarios(members) {
  const qs = members.map((m) => 1 - m.winProbability);
  const cuts = [...new Set([0, ...qs, 1])].sort((a, b) => a - b);
  const scenarios = [];
  for (let k = 0; k + 1 < cuts.length; k += 1) {
    const probability = cuts[k + 1] - cuts[k];
    if (!(probability > 0)) continue;
    const loses = new Set(members.map((_, i) => i).filter((i) => qs[i] >= cuts[k + 1]));
    scenarios.push({ probability, loses });
  }
  return scenarios;
}

/**
 * The additional purchase fraction of current account equity for every opportunity, sized jointly. Returns
 * { fractions: Map<id, number>, groups: [{key, ids}], scenarios, expectedLogGrowth, fallback? }.
 */
export function portfolioFractions(opportunities, { groupBy = {}, budget = 1, held = [], equityCents = null, cashCents = null, kellyMultiple = 1 } = {}) {
  if (held.length && (!(equityCents > 0) || !Number.isFinite(cashCents))) throw new TypeError('held settlement sizing requires actual cash and marked equity');
  const scale = equityCents > 0 ? equityCents : 1;
  const candidateBy = new Map(opportunities.map(o => [o.id, o]));
  const qualifiedByInstrument = new Map();
  for (const h of held) if (Number.isFinite(h.winProbability) && h.winProbability >= 0 && h.winProbability <= 1 && h.lane && h.correlation) {
    const key = `${h.ticker}\u0000${h.side}`;
    if (!qualifiedByInstrument.has(key)) qualifiedByInstrument.set(key, h);
  }
  const candidateProbabilityBindings = [], capitalWeights = new Map();
  const groups = new Map();
  opportunities.forEach((o, index) => {
    // One instrument has one settlement outcome. If its firm/retained holding
    // carries the stronger source chosen by the planner, use that law for both
    // payouts and proposed purchases; never draw independent lane shocks for it.
    const supplier = qualifiedByInstrument.get(`${o.id}\u0000${o.side}`);
    const modeled = supplier ? { ...o, lane: supplier.lane, correlation: supplier.correlation, winProbability: supplier.winProbability, capitalWeight: supplier.capitalWeight ?? 1 } : o;
    capitalWeights.set(o.id, modeled.capitalWeight ?? 1);
    if (supplier) candidateProbabilityBindings.push({ ticker: o.id, side: o.side, pricingLane: o.lane, pricingWinProbability: o.winProbability, pricingCapitalWeight: o.capitalWeight ?? 1, pricingProbabilityEvidence: o.probabilityEvidence ?? null,
      sizingLane: supplier.lane, sizingWinProbability: supplier.winProbability, sizingCapitalWeight: supplier.capitalWeight ?? 1, probabilityEvidence: supplier.probabilityEvidence });
    const key = groupKey(modeled, groupBy);
    groups.set(key, [...(groups.get(key) ?? []), { ...modeled, index }]);
  });
  const fixedBy = new Map(), contingentRisk = new Map(), unknown = [], robustHeld = [];
  let fixedCollateral = 0;
  for (const h of held) {
    const candidate = candidateBy.get(h.ticker);
    if (h.kind === 'resting' && h.adjustable && candidate?.side === h.side) {
      contingentRisk.set(h.ticker, (contingentRisk.get(h.ticker) ?? 0) + h.riskCents);
      continue;
    }
    if (h.kind === 'resting') fixedCollateral += h.riskCents;
    // A one-sided conservative probability is not a probability for the opposite side.
    const prediction = h.winProbability;
    if (!Number.isFinite(prediction) || prediction < 0 || prediction > 1 || !h.correlation || !h.lane) {
      unknown.push({ ticker: h.ticker, side: h.side, kind: h.kind, riskCents: h.riskCents, grossPayoutCents: h.grossPayoutCents, exposureLane: h.exposureLane, payoutLowerBoundCents: 0 });
      if (h.exposureLane && h.exposureCorrelation) robustHeld.push(h);
      continue;
    }
    const key = groupKey(h, groupBy);
    fixedBy.set(key, [...(fixedBy.get(key) ?? []), { ...h, winProbability: prediction }]);
  }
  const cashBaseline = (cashCents === null ? scale : cashCents) / scale;
  const base = cashBaseline - fixedCollateral / scale;
  const settlementModel = {
    basis: 'cash-plus-qualified-gross-settlement-payouts', cashCents, equityCents,
    fixedRestingCollateralCents: fixedCollateral, unknownHoldings: unknown, candidateProbabilityBindings,
    qualifiedHoldings: [...fixedBy.values()].flat().map(h => ({ ticker: h.ticker, side: h.side, kind: h.kind, grossPayoutCents: h.grossPayoutCents, winProbability: h.winProbability, capitalWeight: h.capitalWeight ?? 1, lane: h.lane, exposureLane: h.exposureLane, probabilityEvidence: h.probabilityEvidence })),
    lowerBound: unknown.length > 0, unknownRestingFees: held.filter(h => h.kind === 'resting' && !h.feeKnown).map(h => h.ticker), restingFillBasis: 'conditional-on-full-fill; no fill probability',
  };
  const solve = (members, cap, includeAllFixed = true, fixedMap = fixedBy) => {
    const keys = new Set([...members.keys(), ...(includeAllFixed ? fixedMap.keys() : [])]);
    const perGroup = [...keys].map(key => {
      const group = members.get(key) ?? [], fixed = fixedMap.get(key) ?? [];
      return { group, fixed, scenarios: sharedShockScenarios([...group, ...fixed]) };
    });
    const flat = [...members.values()].flat();
    const position = new Map(flat.map((o, i) => [o.index, i]));
    let joint = [{ probability: 1, returns: flat.map(() => 0), baseline: base }];
    for (const { group, fixed, scenarios } of perGroup) {
      const next = [];
      for (const row of joint) for (const s of scenarios) {
        const returns = row.returns.slice();
        group.forEach((o, i) => { returns[position.get(o.index)] = s.loses.has(i) ? -1 : o.payoffCents / o.priceCents; });
        const baseline = fixed.reduce((w, h, j) => w + (s.loses.has(group.length + j) ? 0 : h.grossPayoutCents / scale), row.baseline);
        next.push({ probability: row.probability * s.probability, returns, baseline });
      }
      joint = next;
    }
    if (joint.some(row => !(row.baseline > 0))) return { fractions: new Map(flat.map(o => [o.id, 0])), scenarios: joint.length, expectedLogGrowth: null, settlementFloorExhausted: true };
    const result = jointKellyForScenarioReturns({ scenarios: joint.map(({ probability, returns }) => ({ probability, returns })), baselineWealth: joint.map(row => row.baseline), budget: cap, tolerance: 1e-10 });
    return { fractions: new Map(flat.map((o, i) => [o.id, Math.max(0, result.fractions[i])])), scenarios: joint.length, expectedLogGrowth: result.expectedLogGrowth };
  };
  const keys = new Set([...groups.keys(), ...fixedBy.keys()]);
  const scenarioCount = [...keys].reduce((n, key) => n * sharedShockScenarios([...(groups.get(key) ?? []), ...(fixedBy.get(key) ?? [])]).length, 1);
  const described = [...groups.entries()].map(([key, members]) => ({ key: key.replace('\u0000', ' '), ids: members.map(o => o.id) }));
  const common = { groups: described, contingentRisk, settlementModel, capitalWeights };
  if (opportunities.length === 0) return { ...common, fractions: new Map(), scenarios: 0, expectedLogGrowth: null };
  // An unread holding claims no payout, but it still fails with its group. A candidate sharing its group is also
  // sized as if the holding failed together with the group at the group's highest certified win probability, and
  // gets the smaller stake: odds here only bound new risk downward, never justify it (distributionally robust Kelly
  // over the two plausible laws).
  const robustBy = new Map();
  for (const h of robustHeld) {
    const key = groupKey({ lane: h.exposureLane, correlation: h.exposureCorrelation }, groupBy), members = groups.get(key);
    if (!members?.length) continue;
    robustBy.set(key, [...(robustBy.get(key) ?? []), { ...h, lane: h.exposureLane, correlation: h.exposureCorrelation, winProbability: Math.max(...members.map(o => o.winProbability)) }]);
  }
  // Fractional Kelly scales each group's TOTAL position, held included: the new stake is k x (increment + held) - held,
  // never k x the increment alone, which would let a fractional desk exceed its fractional stake beside its holdings.
  const finish = (result, robust = true) => {
    let fractions = result.fractions;
    if (robust && robustBy.size && !result.settlementFloorExhausted) {
      const fixedAlt = new Map(fixedBy);
      for (const [key, rows] of robustBy) fixedAlt.set(key, [...(fixedAlt.get(key) ?? []), ...rows]);
      const alt = solve(groups, budget, true, fixedAlt).fractions;
      fractions = new Map([...fractions].map(([id, f]) => [id, Math.min(f, alt.get(id) ?? f)]));
    }
    if (kellyMultiple !== 1) {
      const next = new Map();
      for (const [key, members] of groups) {
        const increment = members.reduce((sum, o) => sum + (fractions.get(o.id) ?? 0), 0);
        const heldShare = [...(fixedBy.get(key) ?? []), ...(robustBy.get(key) ?? [])].reduce((sum, h) => sum + h.riskCents / scale, 0);
        const available = Math.max(0, kellyMultiple * (increment + heldShare) - heldShare);
        for (const o of members) next.set(o.id, increment > 0 ? (fractions.get(o.id) ?? 0) * available / increment : 0);
      }
      fractions = next;
    }
    return { ...result, fractions, ...(robustBy.size ? { robustUnreadGroups: [...robustBy.keys()].map(k => k.replace('\u0000', ' ')) } : {}) };
  };
  if (opportunities.length <= MAX_INSTRUMENTS && scenarioCount <= MAX_SCENARIOS) return { ...finish(solve(groups, budget)), ...common };
  // Omitted fixed groups contribute their zero-payout lower bound in each bounded solve.
  const fractions = new Map();
  for (const [key, members] of groups) for (const [id, f] of solve(new Map([[key, members]]), budget, false).fractions) fractions.set(id, f);
  const total = [...fractions.values()].reduce((s, f) => s + f, 0);
  if (total > budget) for (const [id, f] of fractions) fractions.set(id, f * budget / total);
  return { ...common, ...finish({ fractions }, false), scenarios: scenarioCount, expectedLogGrowth: null, fallback: 'per-group settlement lower bound, scaled to the budget', settlementModel: { ...settlementModel, lowerBound: true, omittedFixedGroups: true } };
}

/** The desk's sizing: the venue-neutral allocator, with 'portfolio-joint' fractions in front of it when the policy names them. */
export function allocateOpportunities(input) {
  const kellyMultiple = input.sizing.kellyMultiple ?? 1;
  const weight = opportunity => {
    const value = opportunity.capitalWeight ?? 1;
    if (!Number.isFinite(value) || value < 0 || value > 1) throw new TypeError('capital evidence weight must be in [0,1]');
    return value;
  };
  if (input.sizing?.method !== 'portfolio-joint') {
    const byId = new Map(input.opportunities.map(o => [o.id, o]));
    const handed = input.opportunities.map(o => {
      const b = o.payoffCents / o.priceCents;
      const fraction = Math.max(0, (b * o.winProbability - (1 - o.winProbability)) / b);
      return { ...o, winProbability: kellyEquivalentWinProbability(Math.min(1 - 1e-9, fraction * kellyMultiple * weight(o)), b) };
    });
    const result = allocateVenueNeutral({ ...input, opportunities: handed, sizing: { ...input.sizing, kellyMultiple: 1 } });
    return { ...result, orders: result.orders.map(order => ({ ...order, winProbability: byId.get(order.id).winProbability, capitalWeight: weight(byId.get(order.id)) })) };
  }
  const portfolio = portfolioFractions(input.opportunities, { groupBy: input.sizing.groupBy, held: input.held ?? [], equityCents: input.venues?.reduce((s, v) => s + v.equityCents, 0) ?? null, cashCents: input.cashCents ?? null, kellyMultiple });
  const byId = new Map(input.opportunities.map((o) => [o.id, o]));
  // Apply the selected sizing law's uncertainty once. Pricing and sizing may
  // use different source laws; their confidence factors are never multiplied.
  const sizingWeight = opportunity => weight({ ...opportunity, capitalWeight: portfolio.capitalWeights.get(opportunity.id) });
  for (const opportunity of input.opportunities) portfolio.fractions.set(opportunity.id, (portfolio.fractions.get(opportunity.id) ?? 0) * sizingWeight(opportunity));
  const shrunk = kellyMultiple !== 1 || input.opportunities.some(opportunity => sizingWeight(opportunity) !== 1);
  // The shared optimizer's variable is NEW capital / account equity. The
  // venue interface is desired contingent capital / lane capital. Convert the
  // units once; lane/cash/exposure caps remain in the shared allocator.
  const equity = input.venues.reduce((sum, venue) => sum + venue.equityCents, 0);
  const stake = o => {
    const capital = Math.floor(equity * (input.lanes[o.lane]?.fraction ?? 0));
    // The Kelly multiple is already applied to each group's total in portfolioFractions.
    return capital > 0 ? Math.min(1 - 1e-9, Math.max(0, (portfolio.fractions.get(o.id) ?? 0) * equity / capital)) : 0;
  };
  const handed = input.opportunities.map((o) => ({ ...o, heldRiskCents: portfolio.contingentRisk.get(o.id) ?? 0, winProbability: kellyEquivalentWinProbability(stake(o), o.payoffCents / o.priceCents) }));
  const result = allocateVenueNeutral({ ...input, opportunities: handed, sizing: { kellyMultiple: 1 } });
  return {
    ...result,
    orders: result.orders.map((order) => ({ ...order, winProbability: byId.get(order.id).winProbability, kellyFraction: portfolio.fractions.get(order.id), capitalWeight: sizingWeight(byId.get(order.id)), sizing: 'portfolio-joint' })),
    skips: result.skips.map(skip => {
      const o = byId.get(skip.id);
      const reason = /^no Kelly edge/u.test(skip.reason)
        ? portfolio.settlementFloorExhausted
          ? 'settlement payout lower bound has no positive wealth in a modeled outcome; positive marginal edge may remain, but whole-account Kelly is unidentified'
          : portfolio.settlementModel.lowerBound
            ? 'no additional stake under the reported settlement payout lower bound; unknown holdings prevent an exact whole-account Kelly claim'
            : 'no additional stake beside fixed holdings in the joint settlement model'
        : skip.reason === 'already holds its Kelly stake'
          ? 'desired contingent stake is below one additional contract after retained orders'
          : skip.reason;
      return { ...skip, reason, sizingBasis: portfolio.settlementModel.lowerBound ? 'settlement-payout-lower-bound' : 'qualified-joint-settlement-model',
        winProbability: o.winProbability, marginalEdgeUnits: o.winProbability * (o.priceCents + o.payoffCents) - o.priceCents };
    }),
    portfolio: { settlementModel: { ...portfolio.settlementModel, ...(portfolio.settlementFloorExhausted ? { settlementFloorExhausted: true } : {}) }, desiredContingentRiskCents: Object.fromEntries(input.opportunities.map(o => [o.id, stake(o) * result.laneCapital[o.lane]])), contingentRiskCents: Object.fromEntries(portfolio.contingentRisk), sizingCapitalWeights: Object.fromEntries(portfolio.capitalWeights), fractions: Object.fromEntries(portfolio.fractions), groups: portfolio.groups, scenarios: portfolio.scenarios, expectedLogGrowth: shrunk ? null : portfolio.expectedLogGrowth, ...(shrunk ? { unshrunkModelExpectedLogGrowth: portfolio.expectedLogGrowth, stakeShrunk: true } : {}), ...(portfolio.fallback ? { fallback: portfolio.fallback } : {}) },
  };
}

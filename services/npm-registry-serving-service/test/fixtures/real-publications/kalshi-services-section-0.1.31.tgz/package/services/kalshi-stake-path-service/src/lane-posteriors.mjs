/** Actual payout outcomes update scoped belief. Shadow execution/P&L never
 * becomes realized money; repeated orders and observations are not new trials. */
import {binaryLossPosterior,positiveEdgeWeight} from '@red-cup-engineering/forecasting/outcome-calibration';
import {temperatureSeries} from '@red-cup-engineering/forecasting/temperature-market-model';
const weather=new Set(['forecast-edge','weather-tail-premium','daily-rain']);
const date=x=>typeof x==='string'&&/^\d{4}-\d{2}-\d{2}$/u.test(x)&&Number.isFinite(Date.parse(x+'T00:00:00Z'))&&new Date(x+'T00:00:00Z').toISOString().slice(0,10)===x;
const clock=x=>typeof x==='string'&&Number.isFinite(Date.parse(x));

export function cohortOfTarget(lane,target) {
  const declared=target.opportunity?.cohort??target.cohort;
  if(typeof declared==='string'&&declared&&!['tail-premium','rain-tail','rain-favourite','structural','forecast'].includes(declared))return declared;
  if(lane==='weather-tail-premium')return target.detail?.priced?.kind??temperatureSeries(target.seriesTicker??target.ticker?.split('-')[0])?.kind??null;
  if(lane==='daily-rain')return target.opportunity?.kind==='rain-tail'?'tail':target.opportunity?.kind==='rain-favourite'?'favourite':target.detail?.side??(target.bookSide==='ask'?'tail':target.bookSide==='bid'?'favourite':null);
  if(lane==='published-series-favorites')return target.detail?.band??target.opportunity?.kind??(target.bookSide==='bid'?'favorite':target.bookSide==='ask'?'mirror':null);
  if(lane==='forecast-edge'){
    const surface=target.detail?.surface??target.surface;
    if(surface?.structural?.length)return target.adapter==='temperature'||target.detail?.adapter==='temperature'||target.detail?.source==='observation-sweep'||target.source==='observation-sweep'?'structural-temperature':null;
    const models=surface?.admitted,source=target.settlementSource??target.detail?.settlementSource,rule=target.ruleKey??target.detail?.ruleKey;
    return models?.length&&source&&rule?'forecast:'+source+'/'+rule+'/'+models.slice().sort().join(','):null;
  }
  return null;
}

export function deriveLanePosteriors({liveOutcomes=[],shadowOutcomes=[],expectations,now=Date.now()}={}) {
  const groups=new Map(),unknown=[],duplicates=[],sources={live:0,shadow:0};
  const priors=expectations?.lanes??{};
  for(const [lane,evidence] of Object.entries(priors))for(const [cohort,prior] of Object.entries(evidence.posteriors??{}))groups.set(lane+'|'+cohort,{lane,cohort,prior,opportunities:new Map()});
  for(const [kind,rows] of [['live',liveOutcomes],['shadow',shadowOutcomes]])for(const row of rows){
    const cohort=cohortOfTarget(row.lane,row)??(row.lane==='forecast-edge'?'legacy-unclassified':null),key=row.lane+'|'+cohort,id=row.ticker+'|'+row.bookSide;
    const fail=reason=>unknown.push({lane:row.lane??null,ticker:row.ticker??null,cohort:cohort??null,source:kind,reason});
    if(!cohort||!['bid','ask'].includes(row.bookSide)||!['yes','no'].includes(row.result)||!row.eventTicker||!date(row.targetDate)||row.verified!==true||!Array.isArray(row.sourceIds)||!row.sourceIds.length||row.sourceIds.some(s=>typeof s!=='string'||!s)){fail('original scoped binary outcome or source witness is unqualified');continue;}
    if(!clock(row.issuedAt)||!clock(row.closeTime)||!clock(row.settledAt)||!(Date.parse(row.issuedAt)<Date.parse(row.closeTime)&&Date.parse(row.issuedAt)<Date.parse(row.settledAt)&&Date.parse(row.settledAt)<=now)){fail('original issuance and definitive outcome clocks are unqualified');continue;}
    if(kind==='live'&&(!/^kd-/u.test(row.clientOrderId??'')||!row.orderId||row.completeOrderFills!==true)){fail('original kd order ownership is unqualified');continue;}
    let g=groups.get(key);if(!g){g={lane:row.lane,cohort,prior:null,opportunities:new Map()};groups.set(key,g);}
    if(g.prior?.throughDate&&row.targetDate<=g.prior.throughDate){duplicates.push({lane:row.lane,ticker:row.ticker,cohort,reason:'within aggregate historical prior scope; original retained'});continue;}
    const prior=g.opportunities.get(id);
    if(prior){
      duplicates.push({lane:row.lane,ticker:row.ticker,cohort,source:kind,reason:'same original payout opportunity, not an additional trial'});
      if(prior.result!==row.result||prior.eventTicker!==row.eventTicker||prior.targetDate!==row.targetDate){prior.conflicted=true;fail('contradictory original payout witnesses');}
      continue;
    }
    g.opportunities.set(id,{...row,source:kind});sources[kind]++;
  }
  const lanes={};
  for(const g of groups.values()){
    const events=new Map();let live=0,shadow=0;
    for(const row of g.opportunities.values()){
      if(row.conflicted)continue;
      row.source==='live'?live++:shadow++;
      const key=row.eventTicker+'|'+row.bookSide,e=events.get(key)??{date:row.targetDate,n:0,losses:0,quotes:[]};
      e.n++;e.losses+=row.bookSide==='bid'?Number(row.result==='no'):Number(row.result==='yes');
      if(Number.isFinite(row.riskCostCents)&&Number.isFinite(row.feePerContractCents))e.quotes.push({riskCostCents:row.riskCostCents,feePerContractCents:row.feePerContractCents});
      events.set(key,e);
    }
    const clusters=new Map();
    for(const [event,e] of events){
      const key=weather.has(g.lane)?e.date:event,c=clusters.get(key)??{n:0,losses:0,anyLoss:false,quotes:[]};
      c.n++;c.losses+=e.losses/e.n;c.anyLoss||=e.losses>0;c.quotes.push(...e.quotes);clusters.set(key,c);
    }
    const losses=[...clusters.values()].reduce((s,c)=>s+(g.prior?.objective==='any-loss-day'?Number(c.anyLoss):c.losses/c.n),0);
    const posterior=binaryLossPosterior({losses,clusters:clusters.size,prior:g.prior});
    const decisions=[...clusters.values()].flatMap(c=>c.quotes).map(q=>positiveEdgeWeight(posterior,q)).filter(Boolean);
    const informative=Boolean(g.prior)||clusters.size>0;
    const evidenceWeight=decisions.length?Math.max(...decisions.map(d=>d.weight)):null;
    (lanes[g.lane]??={})[g.cohort]={...posterior,informative,prior:g.prior??null,unit:weather.has(g.lane)?'target settlement date':'event and held side',objective:g.prior?.objective??'average per-target loss',rawLiveOpportunities:live,rawShadowOpportunities:shadow,events:events.size,dates:clusters.size,evidenceWeight,probabilityEvidence:'actual binary payout outcomes; shadow has no realized capital or fill authority'};
  }
  return {type:'KalshiLanePosteriors',version:1,at:new Date(now).toISOString(),lanes,sources,unknown,duplicates,orderEffect:false};
}

export const posteriorForTarget=(config,cohort)=>config?.posteriors?.[cohort]?.informative?config.posteriors[cohort]:null;

export function calibratedTargetRisk({posterior,winProbability,riskCostCents,feePerContractCents,conditional=false}) {
  // A separately graded conditional model is not replaced by a lane average.
  const compatible=conditional?null:posterior;
  const probability=compatible?Math.min(winProbability??1,compatible.winMean):winProbability;
  const evidence=positiveEdgeWeight(compatible,{riskCostCents,feePerContractCents});
  return {winProbability:probability,capitalWeight:evidence?.weight??1,posterior:posterior??null,posteriorEdge:evidence?.expectedEdgeCents??null,calibrationUse:conditional?'source-graded conditional forecast unchanged':'compatible scoped empirical payout mean'};
}

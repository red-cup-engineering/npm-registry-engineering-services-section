/**
 * Kalshi's Liquidity Incentive Program (LIP), read-only.
 *
 * What the help article (help.kalshi.com/en/articles/13823851) states, and no
 * more:
 *   - the order book is snapshotted once a second at a random moment inside
 *     the second;
 *   - the Reference Price on a side is found by walking down from the best bid
 *     to the first level where cumulative resting size reaches one fifth of
 *     the program's Target Size;
 *   - resting orders must meet the Target Size on both the yes side and the no
 *     side for a snapshot to count (Target Size is between 100 and 20,000);
 *   - an order priced at or better than the Reference Price scores 1.0x;
 *     priced below it, Discount Factor ^ (ticks away) (Discount Factor is up
 *     to 1.00);
 *   - raw score of an order = size x distance multiplier; your score for a
 *     time period = your total snapshot scores / all participants' total
 *     snapshot scores; reward = that share x the period's reward x
 *     (non-excluded snapshots / total snapshots), rounded down to the cent;
 *   - payouts: $1-$1,000 a market a day, $1.00 minimum, periods up to 31 days
 *     that may overlap.
 * The two-sided Target Size is whole-book resting size, not a minimum
 * for any one participant. A participant's share depends on competing
 * quotes and on actual randomly sampled book snapshots, and cannot be
 * obtained by dividing their own size by the Target Size.
 * This module can now compute CONDITIONAL one-snapshot score bounds, but
 * cannot infer a credited payout from one observed book. GET /incentive_programs has no ticker filter, so all active
 * liquidity programs are fetched once and filtered here.
 *
 * `period_reward` is in hundredths of a cent (1_000_000 = $100).
 */

/** Active liquidity programs, paged. @param {{call: Function}} client a createKalshiClient instance (public read, unsigned). */
export async function fetchActiveLiquidityPrograms(client, { maxPages = 5, deadlineAt = Infinity } = {}) {
  const programs = [];
  let cursor;
  for (let page = 0; page < maxPages; page += 1) {
    const payload = await client.call('GET', '/incentive_programs', { query: { status: 'active', type: 'liquidity', limit: 10000, cursor }, signed: false, deadlineAt });
    programs.push(...(payload.incentive_programs ?? []));
    cursor = payload.next_cursor;
    if (!cursor || !(payload.incentive_programs ?? []).length) break;
  }
  return programs;
}

/**
 * The terms in force for each ticker: reward per hour of its period in dollars,
 * target size, discount factor and when it ends. A ticker with several
 * overlapping programs lists them all.
 * @param {object[]} programs
 * @param {string[]} tickers
 * @returns {Map<string, {programId: string, rewardUsdPerHour: number, periodRewardUsd: number, targetSize: number|null, discountFactor: number|null, endsAt: string, hoursLeft: number}[]>}
 */
export function incentiveTerms(programs, tickers, now = Date.now()) {
  const wanted = new Set(tickers);
  const terms = new Map();
  for (const program of programs) {
    if (!wanted.has(program.market_ticker) || program.incentive_type !== 'liquidity') continue;
    const start = Date.parse(program.start_date), end = Date.parse(program.end_date);
    if (!(end > now) || !(end > start)) continue;
    const periodRewardUsd = Number(program.period_reward) / 10000;
    const row = {
      programId: program.id, rewardUsdPerHour: periodRewardUsd / ((end - start) / 3600_000), periodRewardUsd,
      targetSize: program.target_size_fp === undefined || program.target_size_fp === null ? null : Number(program.target_size_fp),
      discountFactor: program.discount_factor_bps === undefined || program.discount_factor_bps === null ? null : Number(program.discount_factor_bps) / 10000,
      endsAt: program.end_date, hoursLeft: Math.max(0, (end - Math.max(now, start)) / 3600_000),
    };
    terms.set(program.market_ticker, [...(terms.get(program.market_ticker) ?? []), row]);
  }
  return terms;
}

/** Convenience: fetch and filter. Returns an empty Map when there is nothing to quote. */
export async function incentivesFor({ client, tickers, now = Date.now(), deadlineAt = Infinity }) {
  if (tickers.length === 0) return new Map();
  return incentiveTerms(await fetchActiveLiquidityPrograms(client, { deadlineAt }), tickers, now);
}

/**
 * The documented Reference Price on one side: from the best bid down, the
 * first level where cumulative size reaches a fifth of the Target Size.
 * @param {[number, number][]} levels [priceCents, size] bids on that leg
 * @returns {number|null}
 */
export function referencePriceCents(levels, targetSize) {
  let cumulative = 0;
  for (const [price, size] of [...levels].sort((a, b) => b[0] - a[0])) {
    cumulative += size;
    if (cumulative >= targetSize / 5) return price;
  }
  return null;
}

/** The documented raw score of one resting order in one snapshot: size x discountFactor^ticksBelowReference (1.0x at or better than it). */
export function rawSnapshotScore({ size, priceCents, referenceCents, discountFactor, tickSizeCents=1 }) {
  const f=discountFactor??1;
  if(![size,priceCents,referenceCents,tickSizeCents,f].every(Number.isFinite)||
    size<0||priceCents<0||referenceCents<0||tickSizeCents<=0||f<=0||f>1)
    throw new TypeError('size, price, tick and discount must be finite and valid');
  const ticksBelow=Math.max(0,(referenceCents-priceCents)/tickSizeCents);
  if(Math.abs(ticksBelow-Math.round(ticksBelow))>1e-8)
    throw new RangeError('book and reference prices must use the same tick grid');
  return size * f ** Math.round(ticksBelow);
}


const numeric=x=>typeof x==='number'&&Number.isFinite(x);
function levelsOf(levels,label){
 if(!Array.isArray(levels))throw new TypeError(label+' levels must be an array');
 const index=new Map();
 for(const row of levels){
  if(!Array.isArray(row)||row.length!==2||!numeric(row[0])||
    !numeric(row[1])||row[0]<=0||row[0]>=100||row[1]<0)
    throw new TypeError(label+' levels require positive prices and nonnegative quantities');
  index.set(row[0],(index.get(row[0])??0)+row[1]);
 }
 return [...index].filter(([,size])=>size>0).sort((a,b)=>b[0]-a[0]);
}
function snapshotSide(book,ours,{targetSize,discountFactor,tickSizeCents}){
 const levels=levelsOf(book,'book'),ourLevels=levelsOf(ours,'owned');
 const owned=new Map(ourLevels),total=levels.reduce((a,b)=>a+b[1],0);
 const available=new Map(levels);
 for(const [price,count] of owned){
  if(count>(available.get(price)??0)+1e-8)
    throw new RangeError('own qualifying order quantity is not present in this book snapshot');
 }
 if(total+1e-8<targetSize)
  return {qualifies:false,bookSize:total,referenceCents:null,
    ownedScore:{low:0,high:0},bookScore:0,
    share:{low:0,high:0}};
 const referenceCents=referencePriceCents(levels,targetSize);
 if(referenceCents===null)throw new RangeError('qualifying book has no computable reference');
 let used=0,bookScore=0,ownLow=0,ownHigh=0;
 for(const [price,size] of levels){
  if(used>=targetSize-1e-8)break;
  const count=Math.min(size,targetSize-used),my=owned.get(price)??0;
  const factor=rawSnapshotScore({size:1,priceCents:price,
    referenceCents,discountFactor,tickSizeCents});
  bookScore+=count*factor;
  // At a partially included price level the ordering of other users'
  // orders ahead of ours is not available from an aggregate book.
  const mineLow=Math.max(0,count-(size-my)),mineHigh=Math.min(my,count);
  ownLow+=mineLow*factor;ownHigh+=mineHigh*factor;used+=count;
 }
 if(!(bookScore>0))throw new RangeError('invalid weighted liquidity snapshot');
 return {qualifies:true,bookSize:total,referenceCents,
   ownedScore:{low:ownLow,high:ownHigh},bookScore,
   share:{low:ownLow/bookScore,high:ownHigh/bookScore}};
}

/**
 * A CONDITIONAL one-snapshot Kalshi LIP competition reading.
 * Each input leg is an independent BID ladder in cents: 'yesBids' and
 * 'noBids' (NOT YES asks), including all participant orders. The owned
 * ladders are our quantities as a subset of each total level. This is
 * a read-only hypothetical score at the supplied point-in-time book.
 *
 * Both legs must independently reach program Target Size or the snapshot
 * is EXCLUDED. The reference price is depth-weighted, and priority of our
 * orders at a partially qualifying level is unknown; sharp bounds reflect
 * all possible placements within that price level. Side shares are
 * independently normalized, so full snapshot score is in [0,2].
 *
 * No source freshness, member eligibility, random snapshot timing,
 * period-wide competition, payments, or signed trade authority is asserted.
 */
export function liquiditySnapshotShareBounds({
 yesBids,noBids,ourYesBids=[],ourNoBids=[],
 targetSize,discountFactor,tickSizeCents=1,
}={}){
 if(!numeric(targetSize)||targetSize<=0||!numeric(discountFactor)||
    discountFactor<=0||discountFactor>1||!numeric(tickSizeCents)||tickSizeCents<=0)
  throw new TypeError('positive target size, discount and tick size required');
 const options={targetSize,discountFactor,tickSizeCents};
 const yes=snapshotSide(yesBids,ourYesBids,options);
 const no=snapshotSide(noBids,ourNoBids,options);
 const eligible=yes.qualifies&&no.qualifies;
 return {kind:'kalshi-lip-book-snapshot-conditional-v1',eligible,
   yes,no,targetSize,discountFactor,tickSizeCents,
   normalizedSnapshotScore:eligible?{
    low:yes.share.low+no.share.low,high:yes.share.high+no.share.high,
   }:{low:0,high:0},
   interpretation:'observed book snapshot share only; not the random Kalshi scoring sample or period reward',
   rewardUsd:null,tradeEligible:false,orderEffect:false};
}

/** What the ledger records beside a resting order: the terms only, since the share depends on competitors this desk cannot see. */
export function ledgerIncentive(termsForTicker, { count }) {
  if (!termsForTicker?.length) return null;
  return termsForTicker.map((row) => ({ ...row, orderSizeVsTarget: row.targetSize ? count / row.targetSize : null }));
}

import {marketSettlementTiming} from '@red-cup-engineering/kalshi-services-section/market-facts';
import {posteriorForTarget} from '../lane-posteriors.mjs';
import {positiveEdgeWeight} from '@red-cup-engineering/forecasting/outcome-calibration';
/**
 * Lane `weather-tail-premium`: sell YES (hold NO) on the overpriced far tails of Kalshi's daily temperature
 * brackets.
 *
 * The weather is the forecasting service's (temperature-tail-prediction predictTemperatureTail): whether a
 * bracket is a far tail the fitted NBM model is measured to certify -- model probability under its threshold,
 * inside the measured decision window, no NWS temperature hazard on its side -- and the per-settlement-day
 * loss rate a bet against it is sized on (forecasting-service content/config/temperature-markets.json
 * `tails`; data/records/2026-10-03-kalshi-temperature-tail-backtest: out of sample, 0 of 272 high and 0 of
 * 195 low certified tails settled yes, resting sells +2.7c and +3.6c a contract, taking +1.1c to +1.2c).
 *
 * The bet is this lane's: a market inside the backtest's selection (its own best ask at most 5c: a tail the
 * market asks more for is one the backtest never measured), on a whole-cent market, and an edge after
 * Kalshi's fee on the series' own schedule (src/fees.mjs) over the loss rate -- at the ask it
 * would rest at (the maker fee) or, with no ask to rest beside, the bid it would take (the taker fee).
 * Sizing, batching and the exact fee of each order are the desk's (src/desk-plan.mjs).
 *
 * What the lane could not read this cycle is never evidence: a station's NWS hazards, a market's book, or a series'
 * listing left unread gives an `unread` target, which certifies nothing and leaves an order of ours resting on it
 * alone (the planner withdraws it only on evidence). The exception is a same-day bracket whose observations so far
 * are unread: the day's readings are what bound it, so it is never priced from the forecast alone, and an order
 * resting on it is withdrawn.
 */
import { guidanceDirectory } from '../desk-layout.mjs';
import { TEMPERATURE_MARKETS, eventDate, temperatureSeries } from '@red-cup-engineering/forecasting/temperature-market-model';
import { predictTemperatureTail, inDecisionWindow } from '@red-cup-engineering/forecasting/temperature-tail-prediction';
import { latestStationGuidance } from '@red-cup-engineering/forecasting/nbm-station-guidance';
import { climateDate, activeTemperatureHazards, observedExtremes } from '@red-cup-engineering/forecasting/station-observations';
import { feePerContract } from '@red-cup-engineering/forecasting/fees';
import { competingBook, restingAskCents } from '../book.mjs';
import { feeScheduleOf, wholeCentMarket } from '../fees.mjs';

export const id = 'weather-tail-premium';

const seriesOf = (ticker) => ticker.slice(0, ticker.indexOf('-'));
const eventOf = (ticker) => ticker.slice(0, ticker.lastIndexOf('-'));
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const ownsTicker = (ticker) => Boolean(temperatureSeries(seriesOf(ticker)));
export const correlationOf = (ticker) => { const event = eventOf(ticker); return { event, date: eventDate(event) }; };

/**
 * The lane's betting rules from policy.lanes[id].config: the backtest's market selection (the competing YES ask at
 * most maxAskCents), the least premium worth selling, the minimum edge after the fee, guidance age, and the falsifier.
 */
export function laneConfig(policy) {
  const raw = policy.lanes?.[id]?.config ?? {};
  return {
    pricing: { minYesPriceCents: 1, maxAskCents: 5, minEdgeCents: 0, ...raw.pricing },
    maxGuidanceAgeHours:raw.maxGuidanceAgeHours??8,
    posteriors:raw.posteriors??{},
  };
}

/** Temperature NO positions that settled yes in the venue's thirty days of settlements: the lane's falsifier. */
export const tailLosses = (settlements) => settlements.filter((row) => row.market_result === 'yes' && Number(row.no_count_fp) > 0 && ownsTicker(row.ticker)).length;

/**
 * Expected edge in cents per contract of selling YES at `priceCents` against a tail that settles yes with `lossRate`,
 * after the fee per contract (large-batch limit; the desk charges each order's exact whole-cent fee when it sizes).
 */
export const sellEdgeCents = ({ priceCents, lossRate, schedule, maker }) => priceCents - lossRate * 100
  - 100 * feePerContract(priceCents / 100, { multiplier: schedule.multiplier, feeType: schedule.feeType, maker });

/** The lane's verdict for one predicted bracket against its book: the price it sells at and the edge after the fee there. */
export function targetOf(candidate, resting, config) {
  const book = competingBook(candidate.orderbook, resting.filter((order) => order.ticker === candidate.ticker));
  const makerPriceCents = restingAskCents(book);
  const takerPriceCents = book.bestBidCents > 0 ? book.bestBidCents : null;
  const base = { ticker: candidate.ticker, eventTicker: candidate.eventTicker, seriesTicker: candidate.seriesTicker, targetDate: candidate.targetDate, closeTime: candidate.closeTime, expectedExpirationTime:candidate.expectedExpirationTime??null,latestExpirationTime:candidate.latestExpirationTime??null,settlementTimerSeconds:candidate.settlementTimerSeconds??null, fee: candidate.fee, wholeCents: candidate.wholeCents };
  const {prediction}=candidate,cohort=prediction.priced?.kind??null,posterior=posteriorForTarget(config,cohort);
  const retained={...base,bookSide:'ask',priceCents:makerPriceCents??takerPriceCents,takerPriceCents,opportunity:{kind:'tail-premium',cohort,winProbability:Number.isFinite(prediction.lossRate)?1-prediction.lossRate:null},detail:{cohort,priced:prediction.priced??null,probability:prediction.probability??null,lossRate:prediction.lossRate??null,posterior,competingBidCents:book.bestBidCents,competingAskCents:book.bestAskCents}};
  let scopeEligible=false;const fail=reason=>({...retained,predictionEligible:scopeEligible,verdict:{ok:false,reason}});
  if (!candidate.active) return fail('market not active');
  if (!prediction.eligible) return fail(prediction.reason);
  const { minYesPriceCents, maxAskCents, minEdgeCents } = config.pricing;
  // The backtest's selection is the market's own best ask; a tail the market asks more for is outside the measured set.
  if (book.bestAskCents === null) return fail('no competing ask: outside the measured selection');
  if (book.bestAskCents > maxAskCents) return fail(`market asks ${book.bestAskCents}c, above the measured ${maxAskCents}c`);
  const maker = makerPriceCents !== null;
  const priceCents = maker ? makerPriceCents : takerPriceCents;
  if (priceCents === null) return fail('no price to sell at');
  if (priceCents < minYesPriceCents) return fail(`premium ${priceCents}c below ${minYesPriceCents}c`);
  scopeEligible=true;
  const edgeCents = sellEdgeCents({ priceCents, lossRate: prediction.lossRate, schedule: candidate.fee, maker });
  retained.detail.edgeCents=edgeCents;
  if (!(edgeCents > Math.max(0,minEdgeCents??0))) return fail(`edge ${edgeCents.toFixed(2)}c after the ${maker ? 'maker' : 'taker'} fee at ${priceCents}c is under ${minEdgeCents}c (loss rate ${prediction.lossRate.toFixed(4)})`);
  return {
    ...base, verdict: { ok: true, edge: edgeCents / 100 }, bookSide: 'ask', priceCents, takerPriceCents,
    opportunity:{...retained.opportunity,capitalWeight:positiveEdgeWeight(posterior,{riskCostCents:100-priceCents,feePerContractCents:priceCents-prediction.lossRate*100-edgeCents})?.weight??1},
    detail:{...retained.detail,priced:prediction.priced, probability: prediction.probability, lossRate: prediction.lossRate, side: prediction.side, edgeCents, label: `tail sell p=${prediction.probability.toFixed(4)} loss ${prediction.lossRate.toFixed(3)} edge ${edgeCents.toFixed(2)}c after fee` },
  };
}

export function createLane({ policy, sources = { latestStationGuidance, activeTemperatureHazards, observedExtremes } }) {
  const config = laneConfig(policy);
  return {
    id, ownsTicker, correlationOf,
    async survey({ client, account, dir, ledger, at, now }) {
      // Every open bracket of a declared series whose event is today or tomorrow at its station, cheap enough to be a tail.
      const markets = [];
      const unlisted = new Set(); // series whose listing failed this cycle
      for (const series of TEMPERATURE_MARKETS.series) {
        const dates = new Set([climateDate(series.timeZone, now), climateDate(series.timeZone, now + 86400_000)]);
        let rows;
        try { rows = await client.getMarkets({ series_ticker: series.seriesTicker, status: 'open' }); } catch (error) {
          ledger(dir, { at, lane: id, kind: 'error', step: 'markets', series: series.seriesTicker, code: error.code, detail: error.detail ?? error.message });
          unlisted.add(series.seriesTicker);
          continue;
        }
        for (const row of rows) {
          const targetDate = eventDate(row.event_ticker);
          if (!dates.has(targetDate)) continue;
          const ask = Math.round(Number(row.yes_ask_dollars) * 100);
          if (!(ask > 0 && ask <= config.pricing.maxAskCents + 1)) continue;
          // Outside the measured decision window there is nothing to predict: no guidance, hazard or observation read.
          if (!inDecisionWindow({ kind: series.kind, targetDate, timeZone: series.timeZone }, undefined, now)) continue;
          markets.push({ row, series, targetDate });
        }
      }
      // Our orders resting on a series the cycle could not list stay: nothing read says they are wrong.
      const keptUnlisted = (account?.resting ?? []).filter((order) => order.own && unlisted.has(seriesOf(order.ticker)))
        .map((order) => ({ ticker: order.ticker, eventTicker: eventOf(order.ticker), seriesTicker: seriesOf(order.ticker), unread: true, verdict: { ok: false, reason: 'series listing unread this cycle' } }));
      if (!markets.length) return { targets: keptUnlisted, candidates: 0, guidanceRun: null };
      const stations = [...new Set(TEMPERATURE_MARKETS.series.map((row) => row.station))];
      const guidance = await sources.latestStationGuidance({ stations, now, cacheDir: guidanceDirectory(dir, 'nbm') });
      const hazards = new Map();
      await Promise.all([...new Set(markets.map(({ series }) => series.station))].map(async (station) => {
        hazards.set(station, await sources.activeTemperatureHazards({ station }).catch((error) => { ledger(dir, { at, lane: id, kind: 'error', step: 'hazards', station, detail: error.message }); return null; }));
      }));
      // The day's readings so far, for brackets settling today, read for every station-day at once.
      const observed = new Map();
      const sameDay = [...new Map(markets.filter(({ series, targetDate }) => targetDate === climateDate(series.timeZone, now))
        .map(({ series, targetDate }) => [`${series.station}/${targetDate}`, { series, targetDate }])).entries()];
      await Promise.all(sameDay.map(async ([key, { series, targetDate }]) => {
        observed.set(key, await sources.observedExtremes({ station: series.station, date: targetDate, timeZone: series.timeZone, now }).catch((error) => {
          ledger(dir, { at, lane: id, kind: 'error', step: 'observations', station: series.station, detail: error.message });
          return null;
        }));
      }));
      const targets = [];
      for (const { row, series, targetDate } of markets) {
        const base = { ticker: row.ticker, eventTicker: row.event_ticker, seriesTicker: series.seriesTicker, targetDate, closeTime: row.close_time, ...marketSettlementTiming(row) };
        const key = `${series.station}/${targetDate}`;
        // A same-day bracket is bounded by the day's readings so far: unread, it is not priced from the forecast alone.
        if (observed.has(key) && observed.get(key) === null) {
          targets.push({ ...base, verdict: { ok: false, reason: "today's observations unread at the station: a same-day bracket is never priced from the forecast alone" } });
          continue;
        }
        const obs = observed.get(key) ?? null;
        const market = { seriesTicker: series.seriesTicker, eventTicker: row.event_ticker, strikeType: row.strike_type, floorStrike: row.floor_strike, capStrike: row.cap_strike };
        const prediction = predictTemperatureTail(market, { guidance, observed: obs, hazards: hazards.get(series.station), timeZone: series.timeZone, now, maxGuidanceAgeHours:config.maxGuidanceAgeHours,posteriors:config.posteriors });
        if (!prediction.eligible) { targets.push({ ...base, ...(prediction.unread ? { unread: true } : {}), verdict: { ok: false, reason: prediction.reason } }); continue; }
        let orderbook;
        try { orderbook = await client.getOrderbook(row.ticker, 10); } catch (error) {
          ledger(dir, { at, lane: id, kind: 'error', step: 'orderbook', ticker: row.ticker, code: error.code });
          targets.push({ ...base, unread: true, verdict: { ok: false, reason: 'order book unread this cycle' } });
          continue;
        }
        await pause(40);
        const fee = await feeScheduleOf(client, series.seriesTicker);
        targets.push(targetOf({ ticker: row.ticker, eventTicker: row.event_ticker, seriesTicker: series.seriesTicker, targetDate, closeTime: row.close_time, ...marketSettlementTiming(row), active: row.status === 'active', orderbook, prediction, fee, wholeCents: wholeCentMarket(row) }, account.resting.filter((order) => order.own), config));
      }
      return { targets: [...targets, ...keptUnlisted], candidates: targets.length, guidanceRun: guidance.runtime };
    },
  };
}

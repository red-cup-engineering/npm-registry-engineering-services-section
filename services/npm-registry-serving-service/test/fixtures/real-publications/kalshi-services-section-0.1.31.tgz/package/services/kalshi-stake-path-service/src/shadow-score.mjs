/**
 * Scoring the shadow book (src/shadow-book.mjs) after settlement, from public
 * market data only (market result and candlesticks).
 *
 * Per opportunity (the first cycle that certified it -- the earliest decision
 * the desk could have made; later cycles repeat it):
 *   taker  taking at the then best opposite price in a batch of `batch`
 *          contracts: gross P&L less Kalshi's fee for that batch, per contract.
 *   maker  resting at the maker price from the first sighting until the last
 *          sighting plus one cycle (or the close): filled iff a later trade
 *          printed THROUGH the price (a sell fills if a trade printed above it,
 *          a buy if below; `touch` also counts a print at the price), less
 *          the maker fee for that batch.
 * Fees are charged on the series' own schedule, which the desk writes on each
 * shadow row (`feeSchedule`); a row written before it did is scored as it was
 * then (plain taker multiplier, no maker fee) and counted as `feeAssumed`.
 *
 * Each lane's `paired` totals are the opportunities scored both ways, so taking
 * and resting are compared on the same opportunities; desk-review judges which
 * pays (executionChoice).
 *
 * SHADOW IS NOT LIVE. These are hypothetical fills with no queue, no market
 * impact and no capital; desk-review reports them as a separate, labelled
 * source. Their separately authenticated binary outcomes can update a lane's
 * payout belief; candle scenarios cannot establish live execution or profit.
 */
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { readFinalBinaryMarket } from '@red-cup-engineering/kalshi-services-section/settlement-accounting';
import { shadowScorePath } from './desk-layout.mjs';
import { makerFeeCents, takerFeeCents } from './execution.mjs';
import { readShadow } from './shadow-book.mjs';

const seriesOf = (ticker) => ticker.slice(0, ticker.indexOf('-'));
const cents = (dollars) => (dollars === undefined || dollars === null || dollars === '' ? null : Math.round(Number(dollars) * 100));
export const opportunityKey = (row) => `${row.lane}|${row.ticker}|${row.bookSide}`;

/** First and last sighting per opportunity, in time order. */
export function sightings(rows) {
  const map = new Map();
  for (const row of [...rows].sort((a, b) => a.at.localeCompare(b.at))) {
    const key = opportunityKey(row);
    const seen = map.get(key);
    if (!seen) map.set(key, { key, first: row, lastAt: row.at, cycles: 1, acted: row.action === 'take' || row.action === 'rest' || row.action === 'kept-resting' });
    else { seen.lastAt = row.at; seen.cycles += 1; seen.acted ||= row.action === 'take' || row.action === 'rest' || row.action === 'kept-resting'; }
  }
  return [...map.values()];
}

const heldWon = (bookSide, result) => (bookSide === 'ask' ? result === 'no' : result === 'yes');

/** Hypothetical taking P&L per contract, in cents. null when there was no takeable price. */
export function scoreTaker({ first }, result, batch = 10) {
  const tp = first.takerPriceCents;
  if (!Number.isInteger(tp) || tp < 1 || tp > 99) return null;
  const cost = first.bookSide === 'ask' ? 100 - tp : tp;
  const gain = 100 - cost;
  const won = heldWon(first.bookSide, result);
  const fee = takerFeeCents(batch, tp, first.feeSchedule) / batch;
  return { priceCents: tp, won, grossCents: won ? gain : -cost, feePerContractCents: fee, pnlCents: (won ? gain : -cost) - fee };
}

/**
 * Hypothetical resting fill and P&L per contract. `candles` are public
 * candlesticks ({end_period_ts, price: {high_dollars, low_dollars}}) of
 * `periodSeconds`; only candles wholly inside the resting window count, so a
 * print before the order existed never fills it.
 */
export function scoreMaker({ first, lastAt }, result, candles, { periodSeconds = 60, cycleMs = 600_000, batch = 10 } = {}) {
  const p = first.makerPriceCents;
  const start = Date.parse(first.at);
  const close = first.closeTime ? Date.parse(first.closeTime) : Infinity;
  const end = Math.min(Date.parse(lastAt) + cycleMs, close);
  let through = false, touch = false;
  for (const candle of candles ?? []) {
    const endMs = candle.end_period_ts * 1000;
    if (endMs - periodSeconds * 1000 < start || endMs > end + periodSeconds * 1000) continue;
    const high = cents(candle.price?.high_dollars), low = cents(candle.price?.low_dollars);
    if (first.bookSide === 'ask') { if (high !== null && high > p) through = true; if (high !== null && high >= p) touch = true; }
    else { if (low !== null && low < p) through = true; if (low !== null && low <= p) touch = true; }
  }
  const won = heldWon(first.bookSide, result);
  const gross = first.bookSide === 'ask' ? (won ? p : p - 100) : (won ? 100 - p : -p);
  const fee = first.feeSchedule ? makerFeeCents(batch, p, first.feeSchedule) / batch : 0;
  return { priceCents: p, filled: through, filledTouch: touch, won, feePerContractCents: fee, pnlCents: through ? gross - fee : 0, pnlIfTouchCents: touch ? gross - fee : 0 };
}

/** Score settled opportunities; `outcomes` maps key -> { result, candles }. */
export function scoreOpportunities(sights, outcomes, options = {}) {
  const scored = [];
  for (const sight of sights) {
    if (sight.first.capitalEligible === false) continue;
    const outcome = outcomes.get(sight.key);
    if (!outcome || (outcome.result !== 'yes' && outcome.result !== 'no')) continue;
    scored.push({ key: sight.key, lane: sight.first.lane, ticker: sight.first.ticker, bookSide: sight.first.bookSide, firstAt: sight.first.at, targetDate: sight.first.targetDate ?? null, result: outcome.result, acted: sight.acted, feeAssumed: !sight.first.feeSchedule,
      taker: scoreTaker(sight, outcome.result, options.batch), maker: scoreMaker(sight, outcome.result, outcome.candles, options) });
  }
  return scored;
}

/** Real binary outcomes of original prospective shadow decisions. Candlestick
 * fill scenarios and hypothetical profits never enter the outcome posterior. */
export function qualifiedShadowOutcomes(sights, outcomes, at) {
  const rows = [], unknown = [];
  for (const sight of sights) {
    const first = sight.first, source = outcomes.get(sight.key)?.marketSource;
    try {
      const reading = { originalBytes: Buffer.from(source?.bodyBase64 ?? '', 'base64'), originalSha256: source?.sha256, originalUrl: source?.url, receivedAt: source?.receivedAt };
      const market = readFinalBinaryMarket({ reading, ticker: first.ticker, at });
      if (!['ask', 'bid'].includes(first.bookSide)) throw new TypeError('original decision side required');
      const originalClose = first.closeTime ?? market.close_time;
      const issued = Date.parse(first.at), close = Date.parse(originalClose), settled = Date.parse(market.settlement_ts);
      // Rain can settle YES early. Its original prospective deadline stays
      // intact; requiring settlement after that deadline would discard wins.
      if (!Number.isFinite(issued) || !Number.isFinite(close) || !Number.isFinite(settled) || issued >= close || issued >= settled || settled > Date.parse(source.receivedAt) || first.eventTicker && first.eventTicker !== market.event_ticker || !/^\d{4}-\d{2}-\d{2}$/u.test(first.targetDate ?? '') || !/^sha256:[a-f0-9]{64}$/u.test(first.originalShadowSha256 ?? '')) throw new TypeError('original pre-close decision and event/date scope required');
      rows.push({ lane: first.lane, ticker: first.ticker, eventTicker: market.event_ticker, bookSide: first.bookSide, targetDate: first.targetDate, result: market.result, issuedAt: first.at, closeTime: originalClose, finalVenueCloseTime: market.close_time, settledAt: market.settlement_ts, cohort: first.cohort ?? first.detail?.cohort ?? null, detail: first.detail, seriesTicker: first.seriesTicker, verified: true, source: 'shadow-final-outcome', sourceIds: [first.originalShadowSha256, source.sha256], riskCostCents: first.bookSide === 'ask' ? 100 - first.makerPriceCents : first.makerPriceCents, feePerContractCents: first.feeSchedule ? makerFeeCents(1, first.makerPriceCents, first.feeSchedule) : null });
    } catch (error) { unknown.push({ lane: first.lane, ticker: first.ticker, reason: error.message }); }
  }
  return { rows, unknown };
}

/** Per-lane totals of scored opportunities. */
export function summarizeShadow(scored, { pending = {} } = {}) {
  const lanes = {}, days = {}, lossDays = {};
  for (const row of scored) {
    const lane = (lanes[row.lane] ??= { source: 'shadow', note: 'hypothetical: no capital, no queue, no impact; not live evidence', settled: 0, taker: { n: 0, wrong: 0, pnlCents: 0, evPerContractCents: null, lossRate: null }, maker: { n: 0, filled: 0, filledTouch: 0, wrongFilled: 0, pnlCents: 0, fillRate: null, evPerFilledContractCents: null }, paired: { n: 0, takerWrong: 0, takerPnlCents: 0, makerFilled: 0, makerWrongFilled: 0, makerPnlCents: 0 }, feeAssumed: 0 });
    lane.settled += 1;
    if (row.taker) {
      lane.taker.n += 1; if (!row.taker.won) lane.taker.wrong += 1; lane.taker.pnlCents += row.taker.pnlCents;
      // Settlement days: one day's opportunities share their weather, so the independent sample is the days.
      if (row.targetDate) { (days[row.lane] ??= new Set()).add(row.targetDate); if (!row.taker.won) (lossDays[row.lane] ??= new Set()).add(row.targetDate); }
    }
    lane.maker.n += 1;
    if (row.maker.filled) { lane.maker.filled += 1; lane.maker.pnlCents += row.maker.pnlCents; if (!row.maker.won) lane.maker.wrongFilled += 1; }
    if (row.maker.filledTouch) lane.maker.filledTouch += 1;
    if (row.feeAssumed) lane.feeAssumed += 1;
    if (row.taker) {
      const p = lane.paired;
      p.n += 1; p.takerPnlCents += row.taker.pnlCents; if (!row.taker.won) p.takerWrong += 1;
      if (row.maker.filled) { p.makerFilled += 1; p.makerPnlCents += row.maker.pnlCents; if (!row.maker.won) p.makerWrongFilled += 1; }
    }
  }
  for (const [id, lane] of Object.entries(lanes)) {
    lane.taker.evPerContractCents = lane.taker.n ? lane.taker.pnlCents / lane.taker.n : null;
    lane.taker.lossRate = lane.taker.n ? lane.taker.wrong / lane.taker.n : null;
    lane.taker.days = days[id]?.size ?? 0;
    lane.taker.daysWithLoss = lossDays[id]?.size ?? 0;
    lane.maker.fillRate = lane.maker.n ? lane.maker.filled / lane.maker.n : null;
    lane.maker.evPerFilledContractCents = lane.maker.filled ? lane.maker.pnlCents / lane.maker.filled : null;
    lane.unsettled = pending[id] ?? 0;
  }
  return lanes;
}

const atomic = (path, text) => { writeFileSync(`${path}.tmp`, text, { mode: 0o600 }); renameSync(`${path}.tmp`, path); };
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export function readScores(dir) {
  try { return JSON.parse(readFileSync(shadowScorePath(dir, 'scores.json'), 'utf8')); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}

/**
 * Score the shadow book against the public market data. Settled opportunities
 * are cached in <dir>/data/state/shadow-score-state/scored.json so a market is fetched once.
 * @param {{dir: string, client: {getMarket: Function, getCandlesticks: Function}, now?: number, days?: number, batch?: number, maxMarkets?: number, pauseMs?: number}} input
 */
export async function scoreShadow({ dir, client, now = Date.now(), days = 30, batch = 10, maxMarkets = 400, pauseMs = 60, cycleMs = 600_000 }) {
  const day = new Date(now).toISOString().slice(0, 10);
  const from = new Date(Date.parse(`${day}T00:00:00Z`) - days * 86400000).toISOString().slice(0, 10);
  const sights = sightings(readShadow(dir, from, day));
  let cache = {};
  try { cache = JSON.parse(readFileSync(shadowScorePath(dir, 'scored.json'), 'utf8')); } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const outcomes = new Map();
  const errors = [];
  let fetched = 0;
  const pending = {};
  const markets = new Map();
  for (const sight of sights) {
    if (cache[sight.key]?.marketSource) { outcomes.set(sight.key, cache[sight.key]); continue; }
    if (fetched >= maxMarkets && !markets.has(sight.first.ticker)) { pending[sight.first.lane] = (pending[sight.first.lane] ?? 0) + 1; continue; }
    const closeMs = sight.first.closeTime ? Date.parse(sight.first.closeTime) : null;
    const canSettleEarly = (sight.first.seriesTicker ?? seriesOf(sight.first.ticker)) === 'KXRAIN';
    if (closeMs !== null && closeMs > now && !canSettleEarly) { pending[sight.first.lane] = (pending[sight.first.lane] ?? 0) + 1; continue; }
    try {
      if (!markets.has(sight.first.ticker)) { fetched += 1; markets.set(sight.first.ticker, client.call('GET', '/markets/' + sight.first.ticker, { signed: false, retainOriginal: true })); }
      const reading = await markets.get(sight.first.ticker), market = reading.market;
      await pause(pauseMs);
      if (!['settled', 'finalized'].includes(market.status) || !['yes', 'no'].includes(market.result)) { pending[sight.first.lane] = (pending[sight.first.lane] ?? 0) + 1; continue; }
      const startTs = Math.floor(Date.parse(sight.first.at) / 1000);
      const endTs = Math.floor(Math.min(Date.parse(sight.lastAt) + cycleMs, closeMs ?? Infinity) / 1000);
      const candles = sight.first.capitalEligible === false ? [] : await client.getCandlesticks(seriesOf(sight.first.ticker), sight.first.ticker, { start_ts: startTs, end_ts: endTs + 60, period_interval: 1 });
      await pause(pauseMs);
      cache[sight.key] = { result: market.result, marketSource: { url: reading.originalUrl, receivedAt: reading.receivedAt, sha256: reading.originalSha256, bodyBase64: Buffer.from(reading.originalBytes).toString('base64') }, candles: candles.map((c) => ({ end_period_ts: c.end_period_ts, price: { high_dollars: c.price?.high_dollars ?? null, low_dollars: c.price?.low_dollars ?? null } })) };
      outcomes.set(sight.key, cache[sight.key]);
    } catch (error) { errors.push({ ticker: sight.first.ticker, detail: error.detail ?? error.message }); }
  }
  const scored = scoreOpportunities(sights, outcomes, { batch, cycleMs });
  const lanes = summarizeShadow(scored, { pending });
  const generatedAt = new Date().toISOString(), qualified = qualifiedShadowOutcomes(sights, outcomes, generatedAt);
  const record = { type: 'KalshiShadowScores', source: 'shadow', note: 'Fill scoring is hypothetical; separately qualified prospective binary outcomes calibrate probability, never realized profit.', generatedAt, windowDays: days, batch, opportunities: sights.length, settled: scored.length, lanes, errors, shadowOutcomes: qualified.rows, outcomeUnknown: qualified.unknown };
  mkdirSync(dirname(shadowScorePath(dir, 'scored.json')), { recursive: true, mode: 0o700 });
  atomic(shadowScorePath(dir, 'scored.json'), `${JSON.stringify(cache)}\n`);
  atomic(shadowScorePath(dir, 'scores.json'), `${JSON.stringify(record, null, 2)}\n`);
  return record;
}

#!/usr/bin/env node
/**
 * Daily review of the Kalshi desk (reads only; writes only under the state dir).
 *
 *   node apps/kalshi-desk-review.mjs [--date=YYYY-MM-DD] [--days=30] [--offline]
 *
 * Reads the desk ledger (data/logs/desk-ledger-logs/*.jsonl), the venue's fills and
 * settlements (signed reads), measures every lane against its backtest
 * expectation (content/config/kalshi-lane-expectations.json), grades each
 * shadow lane against its forward test, derives the next period's lane
 * fractions from the policy now in force, and writes to <data root>/data/records/desk-review-records/:
 *   YYYY-MM-DD.json      the record
 *   YYYY-MM-DD.md        the digest
 *   judgments.json       the judgments in force: the desk trades them from its next cycle
 * The repository's policy file is never written; it is the base the judgments stand on.
 */
import { mkdirSync, readFileSync, readdirSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createKalshiClient } from '@red-cup-engineering/kalshi-services-section/client';
import { deskDataRoot, inForcePolicy, normalizedLiveOutcomes } from './kalshi-desk.mjs';
import { collectDeskAccountingContext, serializeDeskAccountingContext } from '../src/desk-accounting-context.mjs';
import { deriveLanePosteriors } from '../src/lane-posteriors.mjs';
import { LEDGER_FEED, reviewDirectory } from '../src/desk-layout.mjs';
import { logDays } from '@red-cup-engineering/kalshi-services-section/seavt-log';
import { readLog } from '@red-cup-engineering/semiotic-eavt-services-section/store';
import { readScores } from '../src/shadow-score.mjs';
import { measureLanes, deriveJudgments, renderDigest } from '../src/desk-review.mjs';
import { readBooks, renderBooks } from '../src/books.mjs';

const load = (rel) => JSON.parse(readFileSync(new URL(rel, import.meta.url), 'utf8'));
const atomic = (path, text) => { writeFileSync(`${path}.tmp`, text, { mode: 0o600 }); renameSync(`${path}.tmp`, path); };

export function readLedger(dir, fromDate, toDate) {
  const entries = [], retained = new Set(['place', 'place-acknowledged', 'place-recovered', 'order-intent', 'refused-size']);
  // The Data owner's iterator streams the existing immutable ledger. Full
  // cycle/source/error payloads have no role in accounting or refusal totals
  // and must not occupy the review's heap for its entire evidence window.
  for (const day of logDays(dir, LEDGER_FEED).filter(day => day >= fromDate && day <= toDate)) {
    for (const { line } of readLog(dir, LEDGER_FEED, day)) if (retained.has(line?.kind)) entries.push(line);
  }
  return entries;
}

export async function review({ date, days = 30, env = process.env, client = createKalshiClient({env}), now = Date.now(), offline = false } = {}) {
  const dir = deskDataRoot(env);
  const policy = inForcePolicy(dir, undefined, env);
  const expectationsFile = load('../content/config/kalshi-lane-expectations.json');
  const day = date ?? new Date(now).toISOString().slice(0, 10);
  const from = new Date(Date.parse(`${day}T00:00:00Z`) - days * 86400000).toISOString().slice(0, 10);
  const ledgerEntries = readLedger(dir, from, day);
  const minTs = Math.floor(Date.parse(`${from}T00:00:00Z`) / 1000);
  let fills = [], settlements = [], account = null, books = null, accounting = null;
  if (!offline) {
    const allFills = await client.getFills({ min_ts: 0, subaccount: 0 });
    const allSettlements = await client.getSettlements({ min_ts: 0, subaccount: 0 });
    fills = allFills.filter(row => Date.parse(row.created_time) >= minTs * 1000);
    settlements = allSettlements.filter(row => Date.parse(row.settled_time) >= minTs * 1000);
    const balance = await client.getBalance();
    const cashCents = balance.balance_dollars !== undefined ? Math.round(Number(balance.balance_dollars) * 1e4) / 100 : balance.balance;
    account = { cashCents, equityCents: cashCents + balance.portfolio_value };
    accounting = await collectDeskAccountingContext({ client, ledgerEntries, account: { ...account, settlements: allSettlements }, fills: allFills, maxTickers: 64, includeTerminalUnfilled: true });
    fills = accounting.fills;
    // The books over the account's whole history, reconciled with Kalshi's balance (src/books.mjs).
    try { books = await readBooks(client, { fills: allFills, settlements: allSettlements, balance }); } catch (error) { books = { error: error.message }; }
  }
  const scores = readScores(dir);
  const posteriors = deriveLanePosteriors({ liveOutcomes: accounting ? normalizedLiveOutcomes(accounting) : [], shadowOutcomes: scores?.shadowOutcomes ?? [], expectations: expectationsFile, now: accounting ? Date.parse(accounting.at) : Date.now() });
  const measurements = measureLanes({ ledgerEntries, placements: accounting?.placements, fills, settlements, accountingReadings: accounting?.accountingReadings ?? [], marketReadings: accounting?.marketReadings ?? [], at: accounting?.at ?? new Date().toISOString(), day, laneIds: Object.keys(policy.lanes), expectations: expectationsFile.lanes, significance: expectationsFile.judgment.significance, shadowScores: scores, modes: Object.fromEntries(Object.entries(policy.lanes).map(([id, lane]) => [id, lane.execution?.mode ?? null])) });
  const admissions = {};
  const judgments = deriveJudgments({ measurements, policy, expectationsFile, date: day, admissions, posteriors });
  const inForce = { type: 'KalshiDeskJudgments', judgedOn: day, policyVersion: policy.version, lanes: judgments };
  const record = { type: 'KalshiDeskReview', date: day, generatedAt: new Date().toISOString(), windowDays: days, ledgerEntries: ledgerEntries.length, fills: fills.length, settlements: settlements.length, account, books, measurements, admissions, judgments, posteriors, accountingSource: accounting ? serializeDeskAccountingContext(accounting) : null, accountingCoverage: accounting?.coverage ?? null, accountingUnknown: accounting?.unknown ?? [] };
  const out = reviewDirectory(dir);
  mkdirSync(out, { recursive: true, mode: 0o700 });
  atomic(join(out, `${day}.json`), `${JSON.stringify(record, null, 2)}\n`);
  const booksLines = books && !books.error ? renderBooks(books) : books?.error ? ['## Books', `- Unread: ${books.error}`, ''] : [];
  atomic(join(out, `${day}.md`), `${renderDigest({ date: day, measurements, judgments, account })}${booksLines.length ? `\n${booksLines.join('\n')}` : ''}`);
  atomic(join(out, 'judgments.json'), `${JSON.stringify(inForce, null, 2)}\n`);
  return { ...record, wrote: [`${day}.json`, `${day}.md`, 'judgments.json'].map((f) => join(out, f)) };
}

if (import.meta.main) {
  const arg = (name) => process.argv.find((a) => a.startsWith(`--${name}=`))?.split('=')[1];
  review({ date: arg('date'), days: arg('days') ? Number(arg('days')) : 30, offline: process.argv.includes('--offline') }).then(
    (r) => process.stdout.write(`${JSON.stringify({ date: r.date, wrote: r.wrote, judgments: Object.fromEntries(Object.entries(r.judgments).map(([k, j]) => [k, `${j.previousFraction} -> ${j.fraction}: ${j.rationale}`])) }, null, 2)}\n`),
    (error) => { process.stderr.write(`${error.stack ?? error.message}\n`); process.exitCode = 1; },
  );
}

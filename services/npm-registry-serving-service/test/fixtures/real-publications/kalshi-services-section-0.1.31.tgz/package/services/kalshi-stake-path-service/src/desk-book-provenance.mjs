/**
 * Pure source-evidence projection for the EXISTING Kalshi desk survey.
 *
 * A quote cannot become a real maker-fill training example merely because
 * an order later settled. Preserve the book actually priced by its lane,
 * the market/rule snapshot received in that lane, and the timestamp at
 * which the order intent was recorded.
 *
 * Storage is the EXISTING durable desk ledger; this module has no IO,
 * no extra data source, no new order path, and no market-making strategy.
 */
import {createHash} from 'node:crypto';
import {eventDate} from '@red-cup-engineering/kalshi-services-section/market-facts';
import {aaaGasScopeOf} from '@red-cup-engineering/forecasting/aaa-gas-market-game';

const validTime=x=>typeof x==='string'&&Number.isFinite(Date.parse(x));
const string=x=>typeof x==='string'&&x.trim().length>0;
const number=x=>typeof x==='number'&&Number.isFinite(x);
const centsOf=x=>Math.round(Number(x)*100);
const sha256=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');

/**
 * Only actual response completion qualifies as book receipt time.
 * Called inside surveyLanes's transparent client, which returns the
 * original source object unchanged.
 */
export function receivedDeskBook({lane,ticker,book,receivedAt}={}){
 if(!string(lane)||!string(ticker)||!validTime(receivedAt)||
    !book||typeof book!=='object'||Array.isArray(book)||
    !Array.isArray(book.yes_dollars)||!Array.isArray(book.no_dollars))
   throw new TypeError('source-owned lane, market, time, and complete YES/NO bid ladders required');
 const sides=['yes_dollars','no_dollars'];
 if(sides.some(side=>book[side].length>128))
  throw new RangeError('venue book exceeds bounded source receipt depth');
 for(const side of sides)for(const row of book[side]){
  if((Array.isArray(row)&&row.some(x=>String(x).length>40)))
   throw new RangeError('venue book receipt cell is unbounded');
  if(!Array.isArray(row)||row.length!==2||!number(Number(row[0]))||
     !number(Number(row[1]))||Number(row[0])<=0||Number(row[0])>=1||
     Number(row[1])<0)throw new TypeError('bounded numeric venue book levels required');
 }
 const received={lane,ticker,receivedAt,book:{
  yes_dollars:book.yes_dollars.map(x=>[String(x[0]),String(x[1])]),
  no_dollars:book.no_dollars.map(x=>[String(x[0]),String(x[1])]),
 }};
 return {...received,bookReceiptId:'sha256:'+sha256(received)};
}

/** A market-listing snapshot, not the later settlement revision. */
export function receivedDeskMarket({lane,market,receivedAt}={}){
 if(!string(lane)||!string(market?.ticker)||!validTime(receivedAt))
  throw new TypeError('market listing needs lane, ticker and receipt clock');
 const declared={
  ticker:market.ticker,seriesTicker:market.series_ticker??market.ticker.split('-')[0],
  eventTicker:market.event_ticker??null,
  rulesPrimary:market.rules_primary??null,rulesSecondary:market.rules_secondary??null,
  status:market.status??null,closeTime:market.close_time??null,
  strikeType:market.strike_type??null,
  floorStrike:market.floor_strike??null,capStrike:market.cap_strike??null,
 };
 return {lane,receivedAt,market:declared,
  marketRulesReceiptId:'sha256:'+sha256({lane,receivedAt,market:declared})};
}

/**
 * The original book and market are retained even if the source family
 * cannot yet be certified. Research eligibility only when independently
 * source-scoped. In particular, an arbitrary market title is NOT a
 * source population or venue settlement methodology.
 *
 * The quote regime is a descriptive observation cohort, not a promise
 * of queue position. Snapshot size at the exact limit includes orders
 * ahead that can cancel; it is NOT an authenticated queue priority.
 */
export function deskIntentProvenance({
 order,bookObservation,marketObservation,intentAt,ttlMinutes,
}={}){
 if(!string(order?.lane)||!string(order?.ticker)||!validTime(intentAt)||
    !number(ttlMinutes)||ttlMinutes<=0||
    !Number.isInteger(order.priceCents)||order.priceCents<1||
    order.priceCents>99||!['bid','ask'].includes(order.bookSide))
  throw new TypeError('complete desk limit, lane and intent clock required');
 const result={provenanceStatus:'unavailable',bookReceiptId:null,
  bookReceivedAt:null,bookEvidence:null,marketRulesReceiptId:null,
  marketReceivedAt:null,marketEvidence:null,originalFamilyScope:null,originalQuoteRegime:null};
 if(!bookObservation||bookObservation.ticker!==order.ticker||
    bookObservation.lane!==order.lane||!validTime(bookObservation.receivedAt)||
    Date.parse(bookObservation.receivedAt)>Date.parse(intentAt))
  return result;
 const book=receivedDeskBook(bookObservation);
 if(book.bookReceiptId!==bookObservation.bookReceiptId)
  throw new RangeError('observed book digest differs from selected lane book');
 const evidence={...result,provenanceStatus:'book-received',
  bookReceiptId:book.bookReceiptId,bookReceivedAt:book.receivedAt,
  bookEvidence:book};
 if(!marketObservation||marketObservation.lane!==order.lane||
    marketObservation.market?.ticker!==order.ticker||
    !validTime(marketObservation.receivedAt)||
    Date.parse(marketObservation.receivedAt)>Date.parse(book.receivedAt))
  return evidence;
 const observed=receivedDeskMarket({lane:order.lane,
  market:{
   ticker:marketObservation.market.ticker,
   series_ticker:marketObservation.market.seriesTicker,
   event_ticker:marketObservation.market.eventTicker,
   rules_primary:marketObservation.market.rulesPrimary,
   rules_secondary:marketObservation.market.rulesSecondary,
   status:marketObservation.market.status,
   close_time:marketObservation.market.closeTime,
   strike_type:marketObservation.market.strikeType,
   floor_strike:marketObservation.market.floorStrike,
   cap_strike:marketObservation.market.capStrike,
  },receivedAt:marketObservation.receivedAt});
 if(observed.marketRulesReceiptId!==marketObservation.marketRulesReceiptId)
  throw new RangeError('observed rules digest differs from selected market listing');
 evidence.marketRulesReceiptId=observed.marketRulesReceiptId;
 evidence.marketReceivedAt=observed.receivedAt;
 evidence.marketEvidence=observed;
 const m=observed.market;
 if(m.eventTicker!==order.eventTicker||m.seriesTicker!==order.seriesTicker||
    eventDate(m.eventTicker)!==order.targetDate||
    m.status!=='active'||!validTime(m.closeTime)||
    Date.parse(m.closeTime)<=Date.parse(intentAt))
  return evidence;
 // Reuse existing gas science's source/rule/population interpretation.
 // Other market families retain their original RULES, not a made-up scope.
 const population=aaaGasScopeOf({rules_primary:m.rulesPrimary});
 if(!population||!/^KXAAAGAS(?:D|W|M)(?:[A-Z]{2})?$/u.test(m.seriesTicker))
  return evidence;
 // The market returns two BID books; our YES ask at 96c means an
 // equivalent NO bid at 4c. The source layer is NEVER a YES ask ladder.
 const side=order.bookSide==='bid'?'yes_dollars':'no_dollars';
 const ownLegPrice=order.bookSide==='bid'?order.priceCents:100-order.priceCents;
 const standing=book.book[side].filter(([d])=>centsOf(d)===ownLegPrice)
  .reduce((n,x)=>n+Number(x[1]),0);
 const sizeBand=standing===0?'0':standing<=10?'1-10':standing<=100?'11-100':'101+';
 const purchasedSide=order.bookSide==='bid'?'yes':'no';
 // Group by the observed venue book, NOT claim complete authenticated
 // actual FIFO queue rank. A later rules-version comparison remains required.
 evidence.originalFamilyScope=m.seriesTicker+'|AAA:regular-gasoline|'+population;
 evidence.originalQuoteRegime='maker:'+purchasedSide+
  '|limit:'+order.priceCents+'c|displayed-depth:'+sizeBand+
  '|ttl:'+ttlMinutes+'min';
 evidence.provenanceStatus='source-bound-book';
 return evidence;
}


/**
 * The one existing ledger's source-receipt row and the identical reference
 * fields to attach to intent/place records. Construction is pure; the desk
 * remains responsible for fsync BEFORE dispatch and for error accounting.
 */
export function deskBookIntentPacket({
 order,bookObservation,marketObservation,intentAt,ttlMinutes,
}={}){
 const observed=deskIntentProvenance({
   order,bookObservation,marketObservation,intentAt,ttlMinutes});
 const {bookEvidence,marketEvidence,...fields}=observed;
 const sourceFacts={...fields,originalTtlMinutes:ttlMinutes};
 const bookRecord=bookEvidence?{
   at:intentAt,kind:'book-evidence',
   bookReceiptId:fields.bookReceiptId,
   bookReceivedAt:fields.bookReceivedAt,
   lane:order.lane,ticker:order.ticker,
   eventTicker:order.eventTicker,seriesTicker:order.seriesTicker,
   targetDate:order.targetDate,priceCents:order.priceCents,
   bookSide:order.bookSide,originalTtlMinutes:ttlMinutes,
   orderIntentAt:intentAt,book:bookEvidence.book,
   marketEvidence:marketEvidence??null,
   marketRulesReceiptId:fields.marketRulesReceiptId,
   originalFamilyScope:fields.originalFamilyScope,
   originalQuoteRegime:fields.originalQuoteRegime,
   provenanceStatus:fields.provenanceStatus,
 }:null;
 return {sourceFacts,bookRecord};
}

/**
 * Admission of a strategy to capital by the founder's rules for a good strategy, not by anyone's sign-off.
 *
 * The rules (content/config/kalshi-strategy-criteria.json, from the economics note of 2026-09-01): public
 * information only, no liability beyond the stake, risk capital only, an edge measured out of sample and
 * positive after the fee, and a named falsifier. A lane's evidence is its entry in
 * kalshi-lane-expectations.json, whose `strategy` block states each of these. A lane that meets every rule
 * trades at its policy fraction; one that does not is surveyed in shadow at fraction 0 until it does. A lane
 * the review has falsified stays out: refutation, not a missing signature, is what keeps a strategy from
 * capital. Pure.
 */

/**
 * The rules a lane's evidence fails, empty when it meets them all.
 * @param {object|null|undefined} evidence a lane's kalshi-lane-expectations.json entry
 * @param {{rules: object}} criteria kalshi-strategy-criteria.json
 * @returns {string[]}
 */
export function unmetCriteria(evidence, criteria) {
  const rules = criteria.rules;
  const s = evidence?.strategy;
  if (!s) return ['no strategy evidence declared'];
  const unmet = [];
  if (rules.publicInformationOnly && s.publicInformationOnly !== true) unmet.push('not shown to use public information only');
  if (rules.noLiabilityBeyondStake && s.noLiabilityBeyondStake !== true) unmet.push('can owe beyond its stake');
  if (rules.riskCapitalOnly && s.riskCapitalOnly !== true) unmet.push('not confined to the walled risk stake');
  if (rules.falsifierRequired && !(typeof s.falsifier === 'string' && s.falsifier.trim())) unmet.push('names no falsifier');
  const oos = s.outOfSample;
  if (!oos) unmet.push('no out-of-sample measurement');
  else {
    const ev = oos.evPerContractCents;
    if (oos.perOrderEdge !== true && !(Number.isFinite(ev) && ev > rules.outOfSample.minEvPerContractCents)) unmet.push(`out-of-sample EV ${Number.isFinite(ev) ? `${ev}c` : 'unmeasured'} after the fee is not above ${rules.outOfSample.minEvPerContractCents}c`);
  }
  return unmet;
}

/**
 * The policy with every lane's admission applied: an admitted lane keeps its fraction (the policy's, or the
 * review's judgment of it), and a lane reopened from shadow takes the base policy's fraction; an unadmitted
 * lane goes to shadow at 0. Falsified and paused lanes are left as the review and the lane's own
 * falsifier have them.
 * @param {object} policy the policy in force (base policy with the review's judgments applied)
 * @param {{lanes: Record<string, object>}} expectations kalshi-lane-expectations.json
 * @param {object} criteria kalshi-strategy-criteria.json
 * @param {object} [base] the repository policy, whose fraction a lane takes when it is admitted from 0
 */
export function admitByCriteria(policy, expectations, criteria, base = policy, posteriors = null) {
  const next = JSON.parse(JSON.stringify(policy));
  for (const [id, lane] of Object.entries(next.lanes ?? {})) {
    lane.config={...lane.config,posteriors:posteriors?.lanes?.[id]??{}};
    const unmet = unmetCriteria(expectations.lanes?.[id], criteria);
    if (unmet.length) {
      lane.admission = { admitted: false, unmet };
      lane.fraction = 0;
      lane.status = 'shadow';
      continue;
    }
    lane.admission = { admitted: true, criteria: `kalshi-strategy-criteria-v${criteria.version}` };
    if (!(lane.fraction > 0)) lane.fraction = base.lanes?.[id]?.baseFraction ?? base.lanes?.[id]?.fraction ?? 0;
    lane.status = 'live';
  }
  return next;
}

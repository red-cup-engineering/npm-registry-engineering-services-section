/**
 * The desk's cycle played as the market game (mandate-portfolio-allocation-service market-game), in process, in
 * SHADOW: the decision the game would make from this cycle's certified targets is recorded beside the policy's own
 * plan, and nothing here places, cancels or sizes an order. When the shadow record shows the game covers the
 * policy's placements (same market and side, size inside the policy's caps, over 30 or more cycles), the order path
 * switches to the game's decision; until then this is evidence only.
 *
 * The translation, move by move:
 *   account    the venue reading the cycle already made (equity, free cash), under the policy's principal;
 *   observe    one counted loss record per lane, counted by code from the desk's witnessed shadow scores (every
 *              certified opportunity graded against Kalshi's settled result, src/shadow-score.mjs), citing a sha256 of
 *              that scores record. One day's opportunities share their weather, so the effective sample is the lane's
 *              distinct settlement days: trials = days, losses = the per-opportunity loss rate on that sample, rounded
 *              up (a design effect: the mean kept, the sample shrunk to what is independent); and
 *              the desk's calibration record (method 'binary-loss-rate': the game funds a quote only if it earns
 *              after its fee at its lane's 95% upper loss rate), carrying a payoff scope per quote;
 *   quote      each certified target as a binary contract on the side the desk holds (selling YES is holding NO), at
 *              the price its lane's execution mode trades, with the series' fee as its transition cost;
 *   strategy   each lane, naming its loss record;
 *   forecast   one per close time (the game prices a common horizon): every target's market settles for the held
 *              side except at most one loss in its group (exclusive losses), at the lane's win probability.
 * Policy v11's limits become the game's: maxOpenFraction its deploy budget, perEventFraction its instrument cap and
 * per-event factor cap, perSettlementDateFraction a per-date factor cap, and its Kelly multiple.
 *
 * Known gaps the shadow record will show, recorded rather than papered over: each close time is decided on the whole
 * equity separately (the game has one horizon per decision), held positions enter as zero P&L, and displayed depth is
 * not read, so a quote's available units are the policy's own count for it or, unplaced, a nominal 1000.
 */
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { marketGame, planMarket } from '@red-cup-engineering/mandate-portfolio-allocation-service/market-game';
import { executionConfig, makerFeeCents, takerFeeCents } from './execution.mjs';

const NOMINAL_UNITS = 1000;
const quoteId = (lane, ticker, bookSide) => `${lane}|${ticker}|${bookSide}`;

/** The price (cents, on the YES book) and fee per contract (cents) a target trades at under its lane's execution mode. */
function tradedAt(target, mode) {
  const taking = mode === 'taker' && Number.isInteger(target.takerPriceCents);
  const priceCents = taking ? target.takerPriceCents : target.priceCents;
  if (!Number.isInteger(priceCents) || priceCents < 1 || priceCents > 99) return null;
  const fee = (taking ? takerFeeCents : makerFeeCents)(10, priceCents, target.fee) / 10;
  return { priceCents, feeCents: fee, taking };
}

/**
 * The moves of one cycle and the game's decision(s), or its refusal per horizon. Pure apart from reading the lane
 * expectations; throws nothing (a translation failure is returned as a refusal).
 */
/** Each lane's counted loss record from a shadow scores record (scoreShadow), with its provenance; null when none. */
export function lossRecordsFrom(scores) {
  if (!scores?.lanes) return {};
  const digest = createHash('sha256').update(JSON.stringify(scores)).digest('hex');
  // Scores written before they counted settlement days carry no `days`: such a lane has no record, never one on opportunities.
  return Object.fromEntries(Object.entries(scores.lanes).filter(([, lane]) => Number.isSafeInteger(lane?.taker?.n) && lane.taker.n > 0 && Number.isSafeInteger(lane.taker.days) && lane.taker.days > 0).map(([id, lane]) => [id, {
    kind: 'binary-loss-rate', trials: lane.taker.days, losses: Math.max(0, Math.ceil(lane.taker.days * lane.taker.wrong / lane.taker.n - 1e-12)),
    opportunities: lane.taker.n, opportunityLosses: lane.taker.wrong, daysWithLoss: lane.taker.daysWithLoss ?? null,
    method: 'design effect: trials = distinct settlement days, losses = ceil(opportunity loss rate x days)',
    counted: { by: 'kalshi-stake-path-service src/shadow-score.mjs', digest, generatedAt: scores.generatedAt ?? null, windowDays: scores.windowDays ?? null },
  }]));
}

export function deskGameShadow({ surveyed, account, policy, places = [], at, scores = null, rain = readRainMidRecord() }) {
  const records = lossRecordsFrom(scores);
  const principal = policy.principal?.actorId ?? 'emsenn';
  const out = { type: 'KalshiDeskGameShadow', at, principal, decisions: [], refusals: [], gaps: ['one-decision-per-horizon-on-whole-equity', 'held-positions-zero-pnl', 'depth-unread'] };
  try {
    const placed = new Map(places.map((order) => [quoteId(order.lane, order.ticker, order.bookSide), order]));
    const groups = new Map(); // closeTime -> [{ lane, target, quote, winProbability, correlation }]
    for (const lane of surveyed) {
      if (lane.failed || lane.paused) continue;
      const record = records[lane.id];
      const mode = executionConfig(policy, lane.id).mode;
      for (const target of lane.targets ?? []) {
        if (!target.verdict?.ok || !target.opportunity || !target.closeTime) continue;
        const traded = tradedAt(target, mode);
        if (!traded || !record) { out.refusals.push({ ticker: target.ticker, lane: lane.id, reason: !record ? 'lane has no counted loss record in the shadow scores' : 'no tradable whole-cent price' }); continue; }
        const holdsNo = target.bookSide === 'ask';
        const entryPrice = holdsNo ? (100 - traded.priceCents) / 100 : traded.priceCents / 100;
        const correlation = lane.correlationOf?.(target.ticker) ?? { event: target.eventTicker, date: target.targetDate };
        const id = quoteId(lane.id, target.ticker, target.bookSide);
        const quote = {
          id, venue: 'kalshi', instrument: target.ticker, carrier: 'binary', side: holdsNo ? 'no' : 'yes', entryPrice,
          availableUnits: placed.get(id)?.count ?? NOMINAL_UNITS, unitStep: 1, observedAt: at, horizon: new Date(target.closeTime).toISOString(),
          transitionCostFraction: traded.feeCents / 100 / entryPrice, carryCostFraction: 0,
          factors: { [`event:${correlation.event}`]: 1, [`date:${correlation.date}`]: 1 },
        };
        const key = quote.horizon;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push({ lane: lane.id, record, quote, winProbability: target.opportunity.winProbability });
      }
    }
    const limits = policy.limits ?? {};
    const gamePolicy = {
      principal, maxObservationAgeMs: 600_000, minCalibrationSamples: 30, kellyMultiple: Math.min(1, policy.sizing?.kellyMultiple ?? 1),
      maxDeployFraction: limits.maxOpenFraction ?? 1, maxInstrumentFraction: limits.perEventFraction ?? 1, maxScenarioLossFraction: 1,
    };
    for (const [horizon, members] of groups) {
      if (members.length > 511) { out.refusals.push({ horizon, reason: `${members.length} quotes exceed the game's 512 scenarios` }); continue; }
      const lossMass = members.reduce((sum, m) => sum + (1 - m.winProbability), 0);
      if (!(lossMass < 1)) { out.refusals.push({ horizon, reason: 'exclusive losses need total loss probability under one' }); continue; }
      let s = marketGame.initialPosition();
      const play = (intent) => { s = marketGame.extend(s, intent).state; };
      const observe = (id, value) => play({ kind: 'observe', observation: { id, source: 'urn:kalshi-desk', value, availableAt: at, observedAt: at } });
      const lanes = [...new Set(members.map((m) => m.lane))];
      for (const lane of lanes) observe(`loss-record:${lane}`, members.find((m) => m.lane === lane).record);
      const horizonMs = Date.parse(horizon) - Date.parse(at);
      observe('calibration', { kind: 'calibration', method: 'binary-loss-rate', windowEnd: at, roundTripCostFraction: 1, liveUseLimitations: [],
        basis: 'policy v11 admits a quote on its edge after the fee; its cost budget is that per-quote check, not a separate fraction',
        payoffScopes: members.map((m) => ({ target: { venue: 'kalshi', instrument: m.quote.instrument, carrier: 'binary', side: m.quote.side, fundingInstrument: null }, minHoldingPeriodMs: 1, maxHoldingPeriodMs: Math.max(1, horizonMs) })) });
      play({ kind: 'account', account: { venue: 'kalshi', principal, observedAt: at, equityCents: Math.max(0, Math.round(account.equityCents)), freeCashCents: Math.max(0, Math.min(Math.round(account.cashCents), Math.round(account.equityCents))) } });
      for (const m of members) play({ kind: 'quote', quote: m.quote });
      for (const lane of lanes) play({ kind: 'strategy', strategy: { id: lane, observedAt: at, quoteIds: members.filter((m) => m.lane === lane).map((m) => m.quote.id), evidenceIds: [`loss-record:${lane}`], lossRateEvidence: `loss-record:${lane}`, thesis: `${lane} certified targets`, falsifier: 'the lane falsifier and the daily review' } });
      const settle = (loser) => Object.fromEntries(members.map((m) => [m.quote.id, (m === loser) === (m.quote.side === 'no') ? 1 : 0]));
      play({ kind: 'forecast', forecast: { id: `forecast:${horizon}`, observedAt: at, horizon, evidenceIds: ['calibration'], calibration: { method: 'binary-loss-rate', record: 'calibration', windowEnd: at },
        scenarios: [{ id: 'all-held-win', probability: 1 - lossMass, values: settle(null), heldPnlCentsByVenue: { kalshi: 0 } },
          ...members.map((m, i) => ({ id: `loss-${i}`, probability: 1 - m.winProbability, values: settle(m), heldPnlCentsByVenue: { kalshi: 0 } }))] } });
      const factorCaps = {};
      for (const m of members) for (const factor of Object.keys(m.quote.factors)) factorCaps[factor] = factor.startsWith('date:') ? (limits.perSettlementDateFraction ?? 1) : (limits.perEventFraction ?? 1);
      try {
        const decision = planMarket(s, { ...gamePolicy, factorCaps }, at);
        out.decisions.push({ id: decision.id, horizon, orders: decision.orders.map((o) => ({ id: o.id, instrument: o.instrument, side: o.side, units: o.units, capitalCents: o.capitalCents, lossRate: o.lossRate ?? null })), skips: decision.skips });
      } catch (error) { out.refusals.push({ horizon, reason: error.message }); }
    }
  } catch (error) { out.refusals.push({ reason: `translation failed: ${error.message}` }); }
  out.coverage = coverageOf(out, places);
  const marketOnly = surveyed.flatMap((lane) => lane.marketOnly ?? []);
  if (marketOnly.length) out.marketOnly = marketOnlyShadow({ candidates: marketOnly, account, policy, at, rain });
  return out;
}

/** The KXRAIN mid-bin record (forecasting-service data/records/2026-10-10-rain-mid-bin-returns), with its digest; null if unreadable. */
export function readRainMidRecord(url = new URL('../../forecasting-service/data/records/2026-10-10-rain-mid-bin-returns/results/mid-bin-returns.json', import.meta.url)) {
  try { const text = readFileSync(url, 'utf8'); return { record: JSON.parse(text), digest: createHash('sha256').update(text).digest('hex') }; } catch { return null; }
}

/**
 * The market-only rain strategy, played in shadow: no weather model, only the market's own price read through the
 * measured long-shot bias. For each daily-rain market inside its decision window, and each side, one single-market
 * game: the forecast is the record's base rate over the market's settlement (scenarios yes and no); the market's mid
 * is observed and conditions it through the record's scenario-likelihood-model for that side (P(bin | yes), P(bin | no),
 * each bin's scored gross return on its distinct dates); the side's counted loss record for the mid's bin (trials =
 * distinct dates) is the strategy's evidence, cited by the record's digest. The game funds the side only if the bin's
 * scored return beats the quote's fee and the quote earns at the loss record's 95% upper rate; otherwise its refusal
 * is recorded verbatim. Depth is unread: a funded size is uncapped by displayed size until it is.
 */
export function marketOnlyShadow({ candidates = [], account, policy, at, rain = readRainMidRecord() }) {
  const out = { strategy: 'kxrain-market-only', decisions: [], refusals: [], gaps: ['depth-unread'] };
  if (!rain) { out.refusals.push({ reason: 'the KXRAIN mid-bin record is unreadable' }); return out; }
  const { record, digest } = rain;
  out.record = { digest, dateRange: record.provenance?.dateRange ?? null };
  const principal = policy.principal?.actorId ?? 'emsenn';
  const base = record.all.settledYes / record.all.rows;
  for (const c of candidates) {
    const mid = (c.bidCents + c.askCents) / 200;
    for (const side of ['no', 'yes']) {
      const spec0 = record.gameModels?.[side === 'yes' ? 'takeYes' : 'takeNo'];
      if (!spec0) { out.refusals.push({ ticker: c.ticker, side, reason: 'record has no model for this side' }); continue; }
      const binIndex = spec0.bins.findIndex((b) => mid >= b.lower && mid < b.upper);
      if (binIndex < 0) { out.refusals.push({ ticker: c.ticker, side, mid, reason: 'mid outside the record\'s bins' }); continue; }
      const priceCents = side === 'yes' ? c.askCents : 100 - c.bidCents;
      const entryPrice = priceCents / 100;
      const feeCents = takerFeeCents(10, side === 'yes' ? c.askCents : c.bidCents, c.fee ?? undefined) / 10;
      const quoteId = `market-only|${c.ticker}|${side}`;
      const quote = { id: quoteId, venue: 'kalshi', instrument: c.ticker, carrier: 'binary', side, entryPrice, availableUnits: NOMINAL_UNITS, unitStep: 1,
        observedAt: at, horizon: new Date(c.closeTime).toISOString(), transitionCostFraction: feeCents / 100 / entryPrice, carryCostFraction: 0 };
      // The base forecast is observed a millisecond before the conditioning: the game adopts a forecast only when it is
      // newer, so a conditioned forecast at the same instant would lose to the base on a hash tie about half the time.
      const before = new Date(Date.parse(at) - 1).toISOString();
      const calibration = { method: 'binary-loss-rate', record: 'calibration', windowEnd: before };
      const spec = { source: spec0.source, path: spec0.path, calibration, prior: { yes: base, no: 1 - base },
        bins: spec0.bins.map((b) => ({ lower: b.lower, upper: b.upper, likelihoods: b.likelihoods })),
        expectedReturns: spec0.expectedReturns.map((r) => ({ trainingSamples: r.trainingSamples, gross: r.gross })) };
      const loss = spec0.lossRecords?.[binIndex];
      try {
        let s = marketGame.initialPosition();
        const play = (intent) => { s = marketGame.extend(s, intent).state; };
        const observe = (id, value, source = 'urn:kalshi-desk') => play({ kind: 'observe', observation: { id, source, value, availableAt: at, observedAt: at } });
        const horizonMs = Date.parse(quote.horizon) - Date.parse(at);
        observe('calibration', { kind: 'calibration', method: 'binary-loss-rate', windowEnd: before, roundTripCostFraction: quote.transitionCostFraction, liveUseLimitations: [],
          payoffScopes: [{ target: { venue: 'kalshi', instrument: c.ticker, carrier: 'binary', side, fundingInstrument: null }, minHoldingPeriodMs: 1, maxHoldingPeriodMs: Math.max(1, horizonMs) }] });
        observe('rain-mid-model', { kind: 'scenario-likelihood-model', model: spec, record: digest });
        observe('loss-record', { kind: 'binary-loss-rate', trials: loss?.trials ?? 0, losses: loss?.losses ?? 0, counted: { by: record.provenance?.countedBy ?? 'unknown', digest } });
        observe(`mid:${c.ticker}`, { mid }, spec.source);
        play({ kind: 'account', account: { venue: 'kalshi', principal, observedAt: at, equityCents: Math.max(0, Math.round(account.equityCents)), freeCashCents: Math.max(0, Math.min(Math.round(account.cashCents), Math.round(account.equityCents))) } });
        play({ kind: 'quote', quote });
        play({ kind: 'strategy', strategy: { id: 'kxrain-market-only', observedAt: at, quoteIds: [quoteId], evidenceIds: ['loss-record', 'rain-mid-model'], lossRateEvidence: 'loss-record', thesis: `the market's long-shot bias at mid ${mid}`, falsifier: 'the record\'s bin return turning negative on new settled dates' } });
        play({ kind: 'forecast', forecast: { id: `forecast:${c.ticker}`, observedAt: before, horizon: quote.horizon, evidenceIds: ['calibration'], calibration,
          scenarios: [{ id: 'yes', probability: base, values: { [quoteId]: 1 }, heldPnlCentsByVenue: { kalshi: 0 } }, { id: 'no', probability: 1 - base, values: { [quoteId]: 0 }, heldPnlCentsByVenue: { kalshi: 0 } }] } });
        play({ kind: 'condition', observationId: `mid:${c.ticker}`, model: { evidenceId: 'rain-mid-model', specification: spec }, at });
        if (!s.forecast.conditioning) throw new RangeError('the forecast was not conditioned on the market\'s mid');
        const limits = policy.limits ?? {};
        const decision = planMarket(s, { principal, maxObservationAgeMs: 600_000, minCalibrationSamples: 30, kellyMultiple: Math.min(1, policy.sizing?.kellyMultiple ?? 1),
          maxDeployFraction: limits.maxOpenFraction ?? 1, maxInstrumentFraction: limits.perEventFraction ?? 1, maxScenarioLossFraction: 1 }, at);
        const order = decision.orders[0];
        if (order) out.decisions.push({ id: decision.id, ticker: c.ticker, side, mid, bin: binIndex, units: order.units, capitalCents: order.capitalCents, lossRate: order.lossRate ?? null });
        else out.refusals.push({ ticker: c.ticker, side, mid, bin: binIndex, reason: decision.skips.map((k) => k.reason).join('; ') || 'no funded edge' });
      } catch (error) { out.refusals.push({ ticker: c.ticker, side, mid, bin: binIndex, reason: error.message }); }
    }
  }
  return out;
}

/** Whether the game's orders cover the policy's placements this cycle: same market and held side, any size the game funds. */
export function coverageOf(shadow, places) {
  const funded = new Map();
  for (const d of shadow.decisions) for (const o of d.orders) funded.set(`${o.instrument}|${o.side}`, o);
  const rows = places.map((order) => {
    const side = order.bookSide === 'ask' ? 'no' : 'yes';
    const o = funded.get(`${order.ticker}|${side}`);
    return { lane: order.lane, ticker: order.ticker, side, policyCount: order.count, gameUnits: o?.units ?? 0, covered: Boolean(o && o.units >= 1) };
  });
  return { placements: rows.length, covered: rows.filter((r) => r.covered).length, rows };
}

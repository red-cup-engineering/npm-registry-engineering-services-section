/**
 * The desk's authority to place orders: the principal's policy (content/config/kalshi-desk-policy.json:
 * bankroll, limits, halts, order expiry) and the principal's arming of the desk. Nothing else.
 *
 * The founder, 2026-10-08: "We need to be using Kalshi AGGRESSIVELY as soon as we are confident a
 * prediction will cash out", and of the earlier grant, which bound the desk to post-only sells of
 * temperature tails in one lane: "That's a stupid requirement that I never wanted." That grant record
 * was never present on the host, so the earlier check refused every order. The admission below checks
 * only what keeps an order well-formed and inside the policy; what to trade is the lanes' certification
 * and how much is the allocator's.
 */
import { readDeskPolicy } from '../../../src/desk-policy.mjs';
import { kalshiAccount } from '../../../src/accounts.mjs';

/** The authority in force: the policy the desk trades under. `root` is accepted for callers of the earlier signature and ignored. */
export function readDeskAuthority({ policy, env = process.env, at = new Date().toISOString() } = {}) {
  try {
    const account = kalshiAccount(env);
    policy ??= readDeskPolicy(env);
    if (policy.principal?.actorId !== account.id) throw new TypeError('desk-policy-account-mismatch');
    if (!(policy?.orders?.ttlMinutes > 0) || !Number.isFinite(policy?.bankrollUsd)) throw new TypeError('desk-policy-incomplete');
    return { allowed: true, grant: `kalshi-desk-policy-v${policy.version}${account.id === 'emsenn' ? '' : ':' + account.id}`, principal: account.id, strategySourcePrincipal: account.strategyAccountId, maxOrderTtlMinutes: policy.orders.ttlMinutes, observedAt: at };
  } catch (error) { return { allowed: false, reason: error.message, observedAt: at }; }
}

/** A placement the policy admits: a well-formed order on a Kalshi market, resting no longer than the policy's expiry. */
export function admitDeskOrder({ authority, order, params, at = new Date().toISOString() } = {}) {
  if (authority?.allowed !== true) throw new TypeError(`desk-authority-refused:${authority?.reason ?? 'absent'}`);
  if (typeof order?.ticker !== 'string' || !/^[A-Z0-9][A-Z0-9.-]*$/u.test(order.ticker)) throw new TypeError('order-ticker-invalid');
  if (!['bid', 'ask'].includes(params?.side) || params.side !== order.bookSide) throw new TypeError('order-side-invalid');
  if (!Number.isSafeInteger(params.count) || params.count < 1 || !(params.price > 0 && params.price < 1)) throw new TypeError('order-size-or-price-invalid');
  if (params.postOnly && !(params.expirationTime > Date.parse(at) / 1000 && params.expirationTime <= Date.parse(at) / 1000 + authority.maxOrderTtlMinutes * 60)) throw new TypeError('order-expiry-outside-policy');
  return { grant: authority.grant, principal: authority.principal };
}

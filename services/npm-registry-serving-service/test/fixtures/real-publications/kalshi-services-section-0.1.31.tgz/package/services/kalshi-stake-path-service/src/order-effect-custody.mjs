import {mkdirSync,openSync,writeFileSync,fsyncSync,closeSync,readFileSync,renameSync} from 'node:fs';
import {dirname} from 'node:path';
import {deskStatePath} from './desk-layout.mjs';

// The desk holds its process lock around this custody. Unknown writes reserve
// the account: a later pulse must find the original order before placing more.
const pathOf=dir=>deskStatePath(dir,'pending-order-effect.json');
function durable(dir,value){
 const path=pathOf(dir),state=dirname(path),temporary=path+'.tmp';mkdirSync(state,{recursive:true,mode:0o700});
 const fd=openSync(temporary,'w',0o600);try{writeFileSync(fd,JSON.stringify(value)+'\n');fsyncSync(fd);}finally{closeSync(fd);}
 renameSync(temporary,path);const directory=openSync(state,'r');try{fsyncSync(directory);}finally{closeSync(directory);}
}
export function readPendingOrderEffect(dir){
 let value;try{value=JSON.parse(readFileSync(pathOf(dir),'utf8'));}catch(error){if(error.code==='ENOENT')return null;throw error;}
 if(value===null)return null;
 if(value.type!=='KalshiPendingOrderEffect'||typeof value.params?.clientOrderId!=='string'||typeof value.params?.ticker!=='string')throw new TypeError('invalid-pending-kalshi-order-effect');
 return value;
}
export async function recoverPendingOrderEffect({dir,client,record,absentAfterMs=120000,now=Date.now()}){
 const pending=readPendingOrderEffect(dir);if(!pending)return {blocked:false};
 const orders=await client.getOrders({ticker:pending.params.ticker});
 const matches=orders.filter(order=>order.client_order_id===pending.params.clientOrderId);
 // Kalshi lists an account's orders in every status, so an order that reached the venue is findable by its client id.
 // None found once the venue has had time to record it means the write never happened: release the reservation.
 if(matches.length===0&&now-Date.parse(pending.at)>=absentAfterMs){
  record({at:new Date(now).toISOString(),kind:'place-absent',clientOrderId:pending.params.clientOrderId,ticker:pending.params.ticker,pendingAt:pending.at});
  durable(dir,null);return {blocked:false,absent:true};
 }
 if(matches.length!==1||matches[0].ticker!==pending.params.ticker||typeof matches[0].order_id!=='string')return {blocked:true,pending};
 record({at:new Date(now).toISOString(),kind:'place-recovered',clientOrderId:pending.params.clientOrderId,orderId:matches[0].order_id,ticker:pending.params.ticker,order:matches[0]});
 durable(dir,null);return {blocked:false,recovered:true};
}
export async function placeOrderWithCustody({dir,client,params,at,record}){
 if(readPendingOrderEffect(dir))throw new Error('unresolved-kalshi-order-effect');
 durable(dir,{type:'KalshiPendingOrderEffect',at,params});
 let ack;
 try{ack=await client.createOrder(params);}catch(error){
  // Clear only explicit venue rejections. Transport/parse/application errors
  // after dispatch retain custody even when they lack a venueWrite marker. A 409
  // is ambiguous (a duplicate client id means the order exists; "trading is
  // paused" means it never will), so it keeps custody and recovery decides by
  // looking the client id up.
  if(Number.isInteger(error.status)&&error.status>=400&&error.status<500&&error.status!==408&&error.status!==409)durable(dir,null);
  throw error;
 }
 if(typeof ack?.order_id!=='string'||!ack.order_id)throw new Error('kalshi-order-acknowledgement-uncertain');
 record(ack);durable(dir,null);return ack;
}

/**
 * How a lane's certified opportunity is executed: resting (`maker`), taking
 * (`taker`: an IOC order at the best opposite price), or resting for a few
 * cycles and then taking if it is still certified (`maker-then-taker`).
 *
 * Pure. Kalshi's taker fee is 0.07 x C x P x (1 - P) dollars for an order of C
 * contracts at price P, rounded UP to the cent once PER ORDER, so contracts
 * are batched per order and the fee per contract falls with the batch. Every
 * fee here is the series' own (src/fees.mjs: fee_type and fee_multiplier), and
 * a maker pays the series' maker fee where it has one.
 *
 * Sides are the YES book's: bookSide `ask` sells YES (holds NO: risk
 * 100 - price, gain price), `bid` buys YES (risk price, gain 100 - price).
 */
import { orderFee, orderFeeOfFills } from './fees.mjs';
export const MODES = ['maker', 'taker', 'maker-then-taker'];

const PLAIN = Object.freeze({ feeType: 'quadratic', multiplier: 1 });
/** A schedule from a schedule object or, as callers before schedules passed it, a bare multiplier. */
const scheduleFrom = (schedule) => (typeof schedule === 'number' ? { ...PLAIN, multiplier: schedule } : schedule ?? PLAIN);

/** Taker fee in cents for ONE order of `count` contracts at `priceCents` (integer cents), on the series' schedule and the account's balance grid. */
export const takerFeeCents = (count, priceCents, schedule) => orderFee({ count, priceCents, schedule: scheduleFrom(schedule) });
/** Maker fee in cents for ONE resting order of `count` contracts at `priceCents` when it fills: 0 on a plain quadratic series. */
export const makerFeeCents = (count, priceCents, schedule) => orderFee({ count, priceCents, schedule: scheduleFrom(schedule), maker: true });
/** Taker fee in cents for ONE order that fills at several levels: Kalshi rounds the order's summed fee once. */
export const takerFeeCentsOfLevels = (levels, schedule) => orderFeeOfFills({ fills: levels, schedule: scheduleFrom(schedule) });

/** A lane's execution settings from policy.lanes[laneId].execution; a lane without them is maker-only (as before). */
export function executionConfig(policy, laneId) {
  const raw = policy.lanes?.[laneId]?.execution ?? {};
  const mode = raw.mode ?? 'maker';
  if (!MODES.includes(mode)) throw new RangeError(`lane ${laneId}: execution mode ${mode} is not one of ${MODES.join(', ')}`);
  return { mode, makerCycles: raw.makerCycles ?? 2, minTakerEdgeCents: raw.minTakerEdgeCents ?? 0, maxGapMinutes: raw.maxGapMinutes ?? 25 };
}

/**
 * Taking `count` contracts at the best opposite price: gross cost and gain per
 * contract, the order's fee, and the expected edge per contract after the fee.
 * @param {{bookSide: "bid"|"ask", takerPriceCents: number, count: number, winProbability: number}} input
 */
export function takerEconomics({ bookSide, takerPriceCents, count, winProbability, schedule }) {
  const costCents = bookSide === 'ask' ? 100 - takerPriceCents : takerPriceCents;
  const gainCents = 100 - costCents;
  const feeCents = takerFeeCents(count, takerPriceCents, schedule);
  const feePerContractCents = feeCents / count;
  const edgeCents = winProbability * gainCents - (1 - winProbability) * costCents - feePerContractCents;
  return { costCents, gainCents, feeCents, feePerContractCents, edgeCents };
}

export const canTakeAt = (priceCents) => Number.isInteger(priceCents) && priceCents >= 1 && priceCents <= 99;

/** Admission of a taking order: a takeable price, a gain left after the fee, and edge after the fee at least the lane's minimum. */
export function admitTaker({ bookSide, takerPriceCents, count, winProbability, minTakerEdgeCents, schedule }) {
  if (!canTakeAt(takerPriceCents)) return { ok: false, reason: 'no takeable price on the opposite side' };
  const economics = takerEconomics({ bookSide, takerPriceCents, count, winProbability, schedule });
  if (economics.gainCents - economics.feePerContractCents <= 0) return { ok: false, reason: 'fee consumes the whole gain', economics };
  if (!(economics.edgeCents > 0 && economics.edgeCents >= (minTakerEdgeCents ?? 0))) return { ok: false, reason: `taker edge ${economics.edgeCents.toFixed(2)}c after the ${economics.feeCents}c fee on ${count} is under ${minTakerEdgeCents ?? 0}c or not positive`, economics };
  return { ok: true, economics };
}

/**
 * Taking `count` contracts down a ladder of levels (src/book.mjs takerLadder, best first): the levels used, the
 * limit price (the worst level used: an IOC limit there fills the better levels first), the order's whole cost
 * and gain in cents, and its fee: the levels' model fees summed and rounded up to the account's grid once, as
 * Kalshi charges one order however many levels it fills at.
 * @param {{bookSide: "bid"|"ask", levels: {priceCents: number, count: number}[], count: number, schedule?: object}} input the series' fee schedule (src/fees.mjs)
 */
export function walkLadder({ bookSide, levels, count, schedule }) {
  const used = [];
  let left = count, costCents = 0, gainCents = 0;
  for (const level of levels) {
    if (left <= 0) break;
    const n = Math.min(left, level.count);
    const cost = bookSide === 'ask' ? 100 - level.priceCents : level.priceCents;
    used.push({ priceCents: level.priceCents, count: n });
    costCents += cost * n; gainCents += (100 - cost) * n;
    left -= n;
  }
  const feeCents = takerFeeCentsOfLevels(used, schedule);
  return { levels: used, count: count - Math.max(left, 0), limitPriceCents: used.at(-1)?.priceCents ?? null, costCents, gainCents, feeCents };
}

/**
 * Admission of a taking order that walks the book: each level used must clear the lane's minimum edge on its own,
 * with its own fee, so a deeper level is never taken at a loss the better ones pay for. The order is cut back to
 * the levels that clear; it fails only when the best level does not. Economics are per contract over the walk.
 */
export function admitWalk({ bookSide, levels, count, winProbability, minTakerEdgeCents, schedule }) {
  const kept = [];
  for (const level of walkLadder({ bookSide, levels, count, schedule }).levels) {
    const admitted = admitTaker({ bookSide, takerPriceCents: level.priceCents, count: level.count, winProbability, minTakerEdgeCents, schedule });
    if (!admitted.ok) { if (!kept.length) return admitted; break; }
    kept.push(level);
  }
  const walk = walkLadder({ bookSide, levels: kept, count: kept.reduce((sum, level) => sum + level.count, 0), schedule });
  const n = walk.count;
  const edgeCents = (winProbability * walk.gainCents - (1 - winProbability) * walk.costCents - walk.feeCents) / n;
  return { ok: true, walk, economics: { costCents: walk.costCents / n, gainCents: walk.gainCents / n, feeCents: walk.feeCents, feePerContractCents: walk.feeCents / n, edgeCents } };
}

/** The most optimistic admission: the fee unrounded and batched into a very large order. Used before sizing to decide which mode a target even gets. */
export const admitTakerOptimistic = (input) => admitTaker({ ...input, count: 100_000 });

/**
 * A resting order of `count` at `priceCents` if it fills: cost and gain per contract, the maker fee the series
 * charges on the fill (0 on plain quadratic series), and the expected edge per contract after it.
 */
export function makerEconomics({ bookSide, priceCents, count, winProbability, schedule }) {
  const costCents = bookSide === 'ask' ? 100 - priceCents : priceCents;
  const gainCents = 100 - costCents;
  const feeCents = makerFeeCents(count, priceCents, schedule);
  const feePerContractCents = feeCents / count;
  const edgeCents = winProbability * gainCents - (1 - winProbability) * costCents - feePerContractCents;
  return { costCents, gainCents, feeCents, feePerContractCents, edgeCents };
}

/** Admission of a resting order: a gain left after the maker fee and a positive expected edge after it. */
export function admitMaker({ bookSide, priceCents, count, winProbability, schedule }) {
  if (!canTakeAt(priceCents)) return { ok: false, reason: 'no price to rest at' };
  const economics = makerEconomics({ bookSide, priceCents, count, winProbability, schedule });
  if (economics.gainCents - economics.feePerContractCents <= 0) return { ok: false, reason: 'maker fee consumes the whole gain', economics };
  if (!(economics.edgeCents > 0)) return { ok: false, reason: `maker edge ${economics.edgeCents.toFixed(2)}c after the ${economics.feeCents}c fee on ${count} is not positive`, economics };
  return { ok: true, economics };
}

/** The IOC order for a taking placement: no post-only, no resting remainder. */
export function takerOrderParams({ ticker, bookSide, count, takerPriceCents, clientOrderId }) {
  return { ticker, side: bookSide, count, price: takerPriceCents / 100, timeInForce: 'immediate_or_cancel', postOnly: false, clientOrderId };
}

export const restKey = (lane, ticker, bookSide) => `${lane}|${ticker}|${bookSide}`;

/** Cycles each certified opportunity has already rested, from the saved state; entries not seen within the gap have lapsed. */
export function restCyclesFrom(state, now, gapMs) {
  const cycles = new Map();
  for (const [key, row] of Object.entries(state ?? {})) if (now - Date.parse(row.lastAt) <= gapMs) cycles.set(key, row.cycles);
  return cycles;
}

/**
 * The state after a cycle. `seen` lists every certified opportunity this
 * cycle as { key, resting } (resting: a maker order rested or was placed).
 * A resting one gains a cycle (restarting at 1 after a gap); a certified one
 * that did not rest keeps its count; one not certified is forgotten.
 */
export function advanceRestState(state, seen, now, gapMs) {
  const next = {};
  const at = new Date(now).toISOString();
  for (const { key, resting } of seen) {
    const old = state?.[key];
    const live = old && now - Date.parse(old.lastAt) <= gapMs;
    if (resting) next[key] = { firstAt: live ? old.firstAt : at, lastAt: at, cycles: (live ? old.cycles : 0) + 1 };
    else if (live) next[key] = { ...old, lastAt: at };
  }
  return next;
}

/**
 * The desk's records in the one log: records of the semiotic-eavt store at the node's MetroPlat settlement root
 * (METROPLAT_DATA_ROOT), one store type for each category (`kalshi-decision`, `kalshi-fill`, ...). A sibling write beside the desk's
 * JSONL ledger, which stays as it is: nothing here places, sizes or blocks an order, and a write that fails is a
 * ledger error, never a failed cycle.
 *
 * Two families of types, so the books never read a shadow as cash:
 *   kalshi-decision, kalshi-order-intent, kalshi-order-acknowledged, kalshi-fill, kalshi-refusal
 *                               one chain per order, each record citing the one before it in `causes`:
 *                                 decision -> order-intent -> order-acknowledged -> fill
 *                               plus `refusal` (refused-size, error, cancel, halt), caused by the cycle's decision.
 *                               The decision in force is policy v11's plan for the cycle (the market game decides in
 *                               shadow until the desk switches to it; then the MarketGameDecision is the root).
 *   kalshi-game-shadow          the market game's shadow decision for the cycle.
 * Money fields follow the monetary-event-observation schema: amountAtomic as an integer string in cents (unit USD,
 * unitDecimals 2), economicEventAt beside observedAt, sourceRefs (the venue order id) and boundary (provider kalshi;
 * no credential ever).
 *
 * The actor is the micro-enterprise seated over the desk's section in the agency (organizing `partyOf` over the
 * seated territories at METROPLAT_AGENCY_ROOT); with none seated, or the agency unreadable here, it is
 * `unallocated`, and the reason travels with every record (`actorSource`).
 */
import { put } from '@red-cup-engineering/semiotic-eavt-services-section/store';
import { kalshiAccount } from '../../../src/accounts.mjs';

/** The store type of a category of the desk's records. */
export const deskRecordType = (category) => `kalshi-${category}`;
/** The desk's section in the house (bare-cedar-fog), and the office the desk acts as. */
export const DESK_SECTION = 'lib/emsenn/services/561-group/services/engineering-services-section/services/computer-engineering-services-section/services/computer-systems-engineering-services-section/services/computer-web-engineering-services-section/services/web-platform-services-section/services/web3-platform-services-section/web3-gambling-platform-services-section/services/kalshi-services-section';
export const DESK_PLAYER = `${DESK_SECTION}#kalshi-desk`;
const UNALLOCATED = 'unallocated';

/** The enterprise seated over the desk, read from the agency; `unallocated` with the reason when it cannot be. */
export async function resolveDeskActor(env = process.env, { load = (specifier) => import(specifier) } = {}) {
  if (!env.METROPLAT_AGENCY_ROOT) return { actor: UNALLOCATED, actorSource: 'METROPLAT_AGENCY_ROOT unset' };
  try {
    const [{ agencyAt }, { territoriesOf, partyOf }] = await Promise.all([load('@red-cup-engineering/organizing/agency/held'), load('@red-cup-engineering/organizing/enterprise')]);
    const party = partyOf(DESK_PLAYER, territoriesOf([...agencyAt(env.METROPLAT_AGENCY_ROOT).enterprises.values()]));
    return party.enterprise ? { actor: party.enterprise, actorSource: 'seated' } : { actor: UNALLOCATED, actorSource: 'no enterprise seated over the desk section' };
  } catch (error) { return { actor: UNALLOCATED, actorSource: `agency unreadable: ${error.message}` }; }
}

/** Cents as the schema's exact amount. */
export const money = (cents) => ({ amountAtomic: String(Math.round(cents)), unit: 'USD', unitDecimals: 2 });

/**
 * The one log for one cycle, or null when the node names no settlement root. `record({category, recordedAt, record, causes})`
 * returns the address the next record in the chain cites; a cause is cited as `{type, id}`, the type of the record it names.
 */
export function openDeskOneLog({ env = process.env, actor, actorSource, root = env.METROPLAT_DATA_ROOT } = {}) {
  if (!root) return null;
  const account = kalshiAccount(env);
  const typeOfAddress = new Map();
  return Object.freeze({
    actor, actorSource,
    record({ category, recordedAt, record, causes = [] }) {
      const type = deskRecordType(category);
      const cited = causes.filter(Boolean).map((id) => ({ type: typeOfAddress.get(id) ?? type, id }));
      const body = { ...record, actor, actorSource, boundary: { ...(record.boundary ?? {}), provider: 'kalshi', accountId: account.id, principal: account.principal }, at: recordedAt, causes: cited };
      const address = put(root, type, body);
      typeOfAddress.set(address, type);
      return address;
    },
  });
}

/** The cost in cents of `count` contracts held on `bookSide` at `priceCents` (selling YES at P is buying NO at 100 - P). */
export const costCents = ({ bookSide, priceCents, count }) => (bookSide === 'ask' ? 100 - priceCents : priceCents) * count;

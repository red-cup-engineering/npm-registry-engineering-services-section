import {reconcileKalshiDeskOrderOutcomes,reconcileKalshiDeskUnfilledOrders} from '@red-cup-engineering/kalshi-services-section/settlement-accounting';
/**
 * The measuring half of the desk's improvement loop (pure; no clock, no I/O).
 *
 * measureLanes: ledger + venue fills + venue settlements -> per-lane measurements
 *   against the lane's backtest expectation (exact binomial / Wilson).
 * deriveJudgments: measurements -> lane capital fractions for the next period.
 *   Each judgment carries the measurement it rests on and a revisit date; anyone
 *   who does the work may re-judge. Silence (no evidence) keeps the current
 *   fraction and never blocks. A shadow lane earns its first capital only by
 *   passing its own pre-registered forward test (an admission).
 * A falsified lane stays at 0 (status `falsified`) until its base policy is changed.
 * policyInForce: the policy with the latest judgments' fractions and statuses. The desk trades
 *   it and the next review judges from it, so the loop closes without a hand.
 * renderDigest: a short markdown account a person or Koios can read.
 */

const cents = (dollars) => Math.round(Number(dollars) * 100);
const num = (v) => (v === undefined || v === null || v === '' ? 0 : Number(v));

/** Wilson score interval for k of n at ~95% (z = 1.96). */
export function wilson(k, n, z = 1.959964) {
  if (!n) return { low: null, high: null };
  const p = k / n, z2 = z * z, d = 1 + z2 / n;
  const centre = (p + z2 / (2 * n)) / d;
  const half = (z * Math.sqrt((p * (1 - p)) / n + z2 / (4 * n * n))) / d;
  return { low: Math.max(0, centre - half), high: Math.min(1, centre + half) };
}

function pmfs(n, p) {
  const out = new Array(n + 1);
  if (p <= 0) { out.fill(0); out[0] = 1; return out; }
  if (p >= 1) { out.fill(0); out[n] = 1; return out; }
  let logp = n * Math.log(1 - p);
  out[0] = Math.exp(logp);
  for (let k = 1; k <= n; k += 1) { logp += Math.log((n - k + 1) / k) + Math.log(p / (1 - p)); out[k] = Math.exp(logp); }
  return out;
}
/** P(X >= k), X ~ Binomial(n, p). */
export function binomUpperTail(k, n, p) {
  if (k <= 0) return 1;
  if (k > n) return 0;
  return Math.min(1, pmfs(n, p).slice(k).reduce((a, b) => a + b, 0));
}
/** Two-sided exact binomial p (sum of outcomes no likelier than the observed). */
export function binomTwoSided(k, n, p) {
  if (!n) return null;
  const mass = pmfs(n, p), observed = mass[k];
  return Math.min(1, mass.reduce((sum, m) => (m <= observed * (1 + 1e-9) ? sum + m : sum), 0));
}

const heldSideLost = (row) => (num(row.yes_count_fp) > 0 && row.market_result === 'no') || (num(row.no_count_fp) > 0 && row.market_result === 'yes');
const dayOf = (iso) => String(iso ?? '').slice(0, 10);

/** Realized P&L of one settlement row in cents: revenue less cost less fee. null when the row lacks its cost. */
export function settlementPnlCents(row) {
  const hasCost = row.yes_total_cost_dollars !== undefined || row.no_total_cost_dollars !== undefined || row.yes_total_cost !== undefined || row.no_total_cost !== undefined;
  if (!hasCost) return null;
  const cost = row.yes_total_cost_dollars !== undefined || row.no_total_cost_dollars !== undefined
    ? cents(row.yes_total_cost_dollars ?? 0) + cents(row.no_total_cost_dollars ?? 0)
    : num(row.yes_total_cost) + num(row.no_total_cost);
  const fee = row.fee_cost !== undefined ? cents(row.fee_cost) : 0;
  return num(row.revenue) - cost - fee;
}

/**
 * SHADOW evidence for one lane, from src/shadow-score.mjs: hypothetical taking P&L and resting fills on every
 * certified opportunity, scored after settlement from public data. It is a separate source from the live
 * measurement above -- no capital stood behind it, so it is labelled and kept apart, never added to live counts.
 * Its loss rate is the model's own (an opportunity the lane certified that settled against the held side),
 * tested against the same backtest rate; that test may only reduce a lane's capital, never raise it.
 */
/**
 * Which execution pays on a lane's certified opportunities, from shadow pairs (src/shadow-score.mjs `paired`: each
 * opportunity scored both by taking at the then opposite price and by resting at the maker price, each after the
 * series' fee). Per opportunity, taking earns T = takerPnl / n; resting earns f x M, where f is the fill rate and M the
 * P&L per filled contract. Resting pays when f > T / M, the break-even fill rate; the choice is made only when the
 * Wilson 95% interval of f lies wholly on one side of it, on at least `minTrials` pairs. Adverse selection is the
 * loss rate of the opportunities that would have filled against that of all of them: a resting order fills more
 * often when the price is moving against it, which M already carries. Shadow fills have no queue, so f is an upper
 * bound and the choice is evidence for the policy's execution mode, never a change to it.
 */
export function executionChoice(paired, { minTrials = 30, mode = null } = {}) {
  if (!paired?.n) return null;
  const { n, makerFilled } = paired;
  const takerEvCents = paired.takerPnlCents / n;
  const makerEvPerFilledCents = makerFilled ? paired.makerPnlCents / makerFilled : null;
  const fill = wilson(makerFilled, n);
  const breakEvenFillRate = makerEvPerFilledCents > 0 && takerEvCents > 0 ? takerEvCents / makerEvPerFilledCents : null;
  let better, reason;
  if (n < minTrials) { better = 'undecided'; reason = `${n} paired opportunities, need ${minTrials}`; }
  else if (makerEvPerFilledCents === null) { better = takerEvCents > 0 ? 'taker' : 'neither'; reason = 'no resting order would have filled'; }
  else if (takerEvCents <= 0 && makerEvPerFilledCents <= 0) { better = 'neither'; reason = 'both lose after the fee'; }
  else if (makerEvPerFilledCents <= 0) { better = 'taker'; reason = 'a filled resting order loses after the fee'; }
  else if (takerEvCents <= 0) { better = 'maker'; reason = 'taking loses after the fee'; }
  else if (fill.low > breakEvenFillRate) { better = 'maker'; reason = `fill rate's lower bound ${fill.low.toFixed(3)} > break-even ${breakEvenFillRate.toFixed(3)}`; }
  else if (fill.high < breakEvenFillRate) { better = 'taker'; reason = `fill rate's upper bound ${fill.high.toFixed(3)} < break-even ${breakEvenFillRate.toFixed(3)}`; }
  else { better = 'undecided'; reason = `break-even ${breakEvenFillRate.toFixed(3)} inside the fill rate's interval`; }
  const policyFavours = mode === 'taker' ? 'taker' : mode === 'maker' ? 'maker' : null;
  return {
    source: 'shadow', n, takerEvCents, makerEvPerFilledCents, makerEvCents: paired.makerPnlCents / n,
    fillRate: makerFilled / n, fillWilson95: fill, breakEvenFillRate,
    lossRate: { all: paired.takerWrong / n, ifFilled: makerFilled ? paired.makerWrongFilled / makerFilled : null },
    better, reason, policyMode: mode, disagrees: policyFavours !== null && ['maker', 'taker'].includes(better) && better !== policyFavours,
  };
}

export function shadowEvidence(summary, exp, significance = 0.05, mode = null) {
  if (!summary) return null;
  const t = summary.taker, m = summary.maker;
  const lossRate = t.n && exp?.lossRate != null ? {
    expected: exp.lossRate, observed: t.lossRate, n: t.n, k: t.wrong, wilson95: wilson(t.wrong, t.n),
    pUpperTail: binomUpperTail(t.wrong, t.n, exp.lossRate), falsified: t.wrong >= 1 && binomUpperTail(t.wrong, t.n, exp.lossRate) < significance,
  } : null;
  return { source: 'shadow', note: summary.note, settled: summary.settled, unsettled: summary.unsettled ?? 0, taker: t, maker: m, lossRate,
    execution: executionChoice(summary.paired, { mode }), feeAssumed: summary.feeAssumed ?? 0,
    takerEv: t.evPerContractCents === null ? null : { expectedCents: exp?.takerEvPerContractCents ?? null, observedCents: t.evPerContractCents, n: t.n } };
}

/**
 * Size the limits refused, per lane, from the ledger's `refused-size` rows (written each cycle by the desk). A cycle
 * repeats a refusal while it lasts, so rows are folded per opportunity (lane, ticker, side): its largest refused size
 * and gain forgone in any one cycle, and the limits that bound it. Only rows of live cycles count; others are tallied.
 */
export function summarizeRefusals(ledgerEntries, day) {
  const out = {};
  const blank = () => ({ rows: 0, opportunities: 0, refusedContracts: 0, gainForgoneCents: 0, unknownExpectationOpportunities: 0, unknownSizeOpportunities: 0, byLimit: {}, byReason: {}, nonLiveRows: 0, top: [], expectationBasis: 'largest source-model post-fee batch expectation per distinct opportunity; maker amounts are conditional on full fill; repeats are not new forgone profit' });
  const fold = new Map();
  for (const row of ledgerEntries) {
    if (row.kind !== 'refused-size') continue;
    const lane = row.lane ?? 'unowned';
    for (const scope of ['window', ...(dayOf(row.at) === day ? ['day'] : [])]) {
      const b = ((out[lane] ??= { day: blank(), window: blank() })[scope]);
      if (row.mode && row.mode !== 'live') { b.nonLiveRows += 1; continue; }
      b.rows += 1;
      const key = `${scope}|${lane}|${row.ticker}|${row.bookSide}`;
      const seen = fold.get(key) ?? { scope, lane, ticker: row.ticker, bookSide: row.bookSide, refusedCount: null, gainForgoneCents: null, reason: row.reason ?? row.limit ?? 'unknown', limits: new Set(), cycles: 0 };
      if (Number.isFinite(row.refusedCount)) seen.refusedCount = Math.max(seen.refusedCount ?? 0, row.refusedCount);
      if (Number.isFinite(row.gainForgoneCents) && (seen.gainForgoneCents === null || row.gainForgoneCents > seen.gainForgoneCents)) { seen.gainForgoneCents = row.gainForgoneCents; seen.reason = row.reason ?? row.limit ?? 'unknown'; }
      seen.limits.add(row.limit ?? 'unknown');
      seen.cycles += 1;
      fold.set(key, seen);
    }
  }
  for (const seen of fold.values()) {
    const b = out[seen.lane][seen.scope];
    b.opportunities += 1;
    b.refusedContracts += seen.refusedCount ?? 0;
    b.gainForgoneCents += seen.gainForgoneCents === null ? 0 : Math.max(0, seen.gainForgoneCents);
    if (seen.gainForgoneCents === null) b.unknownExpectationOpportunities += 1;
    if (seen.refusedCount === null) b.unknownSizeOpportunities += 1;
    for (const limit of seen.limits) b.byLimit[limit] = (b.byLimit[limit] ?? 0) + 1;
    const reason = (b.byReason[seen.reason] ??= { opportunities: 0, gainForgoneCents: 0, unknownExpectationOpportunities: 0 });
    reason.opportunities += 1;
    reason.gainForgoneCents += seen.gainForgoneCents === null ? 0 : Math.max(0, seen.gainForgoneCents);
    if (seen.gainForgoneCents === null) reason.unknownExpectationOpportunities += 1;
    b.top.push({ ticker: seen.ticker, bookSide: seen.bookSide, refusedCount: seen.refusedCount, gainForgoneCents: seen.gainForgoneCents, reason: seen.reason, limits: [...seen.limits], cycles: seen.cycles });
  }
  for (const lane of Object.values(out)) for (const b of Object.values(lane)) {
    b.gainForgoneCents = Math.round(b.gainForgoneCents * 100) / 100;
    for (const reason of Object.values(b.byReason)) reason.gainForgoneCents = Math.round(reason.gainForgoneCents * 100) / 100;
    b.top = b.top.sort((a, c) => (c.gainForgoneCents ?? -Infinity) - (a.gainForgoneCents ?? -Infinity)).slice(0, 5);
  }
  return out;
}

/**
 * @param ledgerEntries all ledger entries in the evidence window (place/cancel/...)
 * @param fills venue fills in the window; settlements venue settlements in the window
 * @param day 'YYYY-MM-DD' under review (the day block); the window block is everything given
 * @param accountingReadings original complete per-ticker histories already collected by the caller; no I/O here
 * @param marketReadings original final binary market envelopes; manual/ticker matches never establish desk ownership
 */
export function measureLanes({ ledgerEntries, placements = null, fills = [], settlements = [], day, laneIds, expectations, accountingReadings = [], marketReadings = [], at = null, significance = 0.05, shadowScores = null, modes = {} }) {
  const places = (placements ?? ledgerEntries.filter(e => e.kind === 'place')).filter(e => /^kd-/u.test(e.clientOrderId ?? '') && e.orderId && e.lane);
  const refusals = summarizeRefusals(ledgerEntries, day), orderPlace = new Map(), conflicts = new Set();
  for (const place of places) {
    const prior = orderPlace.get(place.orderId);
    if (prior && (prior.clientOrderId !== place.clientOrderId || prior.lane !== place.lane || prior.ticker !== place.ticker || prior.bookSide !== place.bookSide)) conflicts.add(place.orderId);
    else orderPlace.set(place.orderId, place);
  }
  for (const id of conflicts) orderPlace.delete(id);
  const lanes = {};
  for (const id of [...new Set([...laneIds, 'unowned'])]) {
    const blank = () => ({ ordersPlaced: 0, contractsPlaced: 0, contractsFilled: 0, settled: 0, settledContracts: 0, settledWrong: 0, pnlCents: null, knownPnlCents: 0, pnlKnownSettled: 0, pnlUnknownSettled: 0, accountingCoveredOrders: 0, knownPnlContracts: 0, accountFillsExcluded: 0 });
    lanes[id] = { day: blank(), window: blank(), liveSettlements: [], accountingWithheld: [] };
  }
  const bucket = (id, isDay) => [lanes[id].window, ...(isDay ? [lanes[id].day] : [])];
  for (const p of orderPlace.values()) {
    const lane = p.lane in lanes ? p.lane : 'unowned';
    for (const b of bucket(lane, dayOf(p.at) === day)) { b.ordersPlaced += 1; b.contractsPlaced += num(p.count); }
  }
  const seenFills = new Map(), badFills = new Set();
  for (const f of fills) {
    const id = f.fill_id ?? f.trade_id;
    if (!id) continue;
    const old = seenFills.get(id);
    if (old && JSON.stringify(old) !== JSON.stringify(f)) badFills.add(id);
    else seenFills.set(id, f);
  }
  for (const [id, f] of seenFills) {
    if (badFills.has(id)) continue;
    const place = orderPlace.get(f.order_id);
    if (!place || f.ticker !== place.ticker || (f.client_order_id !== undefined && f.client_order_id !== place.clientOrderId) || f.book_side !== place.bookSide || !Number.isFinite(Number(f.count_fp)) || Number(f.count_fp) <= 0) {
      for (const b of bucket('unowned', dayOf(f.created_time) === day)) b.accountFillsExcluded += 1;
      continue;
    }
    const lane = place.lane in lanes ? place.lane : 'unowned';
    for (const b of bucket(lane, dayOf(f.created_time) === day)) b.contractsFilled += Number(f.count_fp);
  }
  const closed = new Set();
  for (const history of accountingReadings) {
    const issued = [...orderPlace.values()].filter(p => p.ticker === history?.ticker);
    if (!issued.length) continue;
    try {
      const zeros = reconcileKalshiDeskUnfilledOrders({ history, placements: issued, at });
      for (const row of zeros.unfilledOrders) {
        if (closed.has(row.orderId)) continue;
        const p = orderPlace.get(row.orderId), lane = p.lane in lanes ? p.lane : 'unowned';
        closed.add(row.orderId);
        for (const b of bucket(lane, dayOf(row.terminalAt) === day)) b.accountingCoveredOrders += 1;
      }
      const remaining = issued.filter(p => !closed.has(p.orderId));
      if (!remaining.length) continue;
      const marketReading = marketReadings.find(packet => packet.market?.ticker === history.ticker);
      const proof = reconcileKalshiDeskOrderOutcomes({ history, marketReading, placements: issued, at });
      for (const id of proof.unfilledOrderIds) {
        if (closed.has(id)) continue;
        const p = orderPlace.get(id), lane = p.lane in lanes ? p.lane : 'unowned';
        closed.add(id);
        for (const b of bucket(lane, dayOf(p.at) === day)) b.accountingCoveredOrders += 1;
      }
      for (const row of proof.rows) {
        if (closed.has(row.orderId)) continue;
        closed.add(row.orderId);
        const lane = row.lane in lanes ? row.lane : 'unowned', qty = Number(row.quantityHundredths) / 100;
        lanes[lane].liveSettlements.push(row);
        for (const b of bucket(lane, dayOf(row.settledAt) === day)) {
          b.accountingCoveredOrders += 1; b.settled += 1; b.settledContracts += qty;
          if (!row.won) b.settledWrong += 1;
          if (row.realizedNetMicroUsd !== null) { b.knownPnlCents += Number(row.realizedNetMicroUsd) / 10000; b.pnlKnownSettled += 1; b.knownPnlContracts += qty; }
          else b.pnlUnknownSettled += 1;
        }
      }
      for (const row of proof.withheld) {
        const p = orderPlace.get(row.orderId);
        const lane = p && p.lane in lanes ? p.lane : 'unowned';
        lanes[lane].accountingWithheld.push(row);
        if (!p) for (const b of bucket('unowned', dayOf(history.settlements[0]?.settled_time) === day)) b.pnlUnknownSettled += 1;
      }
    } catch (error) {
      for (const p of issued) lanes[p.lane in lanes ? p.lane : 'unowned'].accountingWithheld.push({ orderId: p.orderId, ticker: p.ticker, reason: error.message });
    }
  }
  // A paid account ticker is evidence that a result exists, never evidence
  // that its account-wide cost, fee, quantity or P&L belongs to the desk.
  for (const s of settlements) for (const p of orderPlace.values()) {
    if (p.ticker !== s.ticker || closed.has(p.orderId)) continue;
    const lane = p.lane in lanes ? p.lane : 'unowned';
    for (const b of bucket(lane, dayOf(s.settled_time) === day)) b.pnlUnknownSettled += 1;
    lanes[lane].accountingWithheld.push({ orderId: p.orderId, ticker: p.ticker, reason: 'account settlement lacks a complete original kd order/fill/fee/outcome close' });
    closed.add(p.orderId);
  }
  for (const [id, lane] of Object.entries(lanes)) {
    const exp = expectations?.[id] ?? null;
    for (const key of ['day', 'window']) {
      const b = lane[key];
      b.fillRate = b.contractsPlaced ? Math.min(1, b.contractsFilled / b.contractsPlaced) : null;
      b.pnlCents = b.accountingCoveredOrders && !b.pnlUnknownSettled ? b.knownPnlCents : null;
      b.evPerContractCents = b.pnlKnownSettled && b.knownPnlContracts ? b.knownPnlCents / b.knownPnlContracts : null;
      b.lossRate = b.settled ? b.settledWrong / b.settled : null;
    }
    const w = lane.window;
    lane.expectation = exp;
    if (exp) {
      const filledTrials = Math.round(Math.min(w.contractsFilled, w.contractsPlaced));
      lane.tests = {
        fillRate: exp.fillRate == null || !w.contractsPlaced ? null : {
          expected: exp.fillRate, observed: w.fillRate, n: Math.round(w.contractsPlaced), wilson95: wilson(filledTrials, Math.round(w.contractsPlaced)),
          pTwoSided: binomTwoSided(filledTrials, Math.round(w.contractsPlaced), exp.fillRate),
          note: 'contracts as trials; an order cancelled before it could rest long deflates the rate',
        },
        lossRate: !w.settled ? null : {
          expected: exp.lossRate, observed: w.lossRate, n: w.settled, k: w.settledWrong, wilson95: wilson(w.settledWrong, w.settled),
          pUpperTail: binomUpperTail(w.settledWrong, w.settled, exp.lossRate),
          falsified: w.settledWrong >= 1 && binomUpperTail(w.settledWrong, w.settled, exp.lossRate) < significance,
        },
        ev: w.evPerContractCents === null ? null : { expectedCents: exp.evPerContractCents, observedCents: w.evPerContractCents, settledContracts: w.settledContracts },
      };
      lane.tests.fillRate && (lane.tests.fillRate.consistent = lane.tests.fillRate.pTwoSided >= significance);
    } else lane.tests = null;
    lane.shadow = shadowEvidence(shadowScores?.lanes?.[id] ?? null, exp, significance, modes[id] ?? null);
    lane.refused = refusals[id] ?? null;
  }
  return lanes;
}

/**
 * Next-period lane judgments (scoped-count-posterior-v1). Each lane keeps its base fraction (baseFraction, else its
 * Kelly share): outcome evidence acts through the scoped count posteriors that price each target, and native Kelly
 * applies their uncertainty once, so the lane is not shrunk a second time. There is no permanent latch: every review
 * judges from the evidence in its window. A lane with no base capital is judged shadow.
 */
export function deriveJudgments({measurements,policy,expectationsFile,date,posteriors=null}) {
  const out={};
  for(const [id,cfg] of Object.entries(policy.lanes??{})){
    const m=measurements[id],cohorts=posteriors?.lanes?.[id]??m?.posteriors??{};
    const weights=Object.values(cohorts).filter(p=>p.informative&&Number.isFinite(p.evidenceWeight)).map(p=>p.evidenceWeight);
    const weight=weights.length?Math.max(...weights):null,base=cfg.baseFraction??cfg.kellyShare??1;
    // Target probabilities and the allocator apply current cohort uncertainty
    // once. Multiplying the lane by it again would double the same reduction.
    const fraction=base;
    out[id]={method:'scoped-count-posterior-v1',fraction,previousFraction:cfg.fraction??0,kellyShare:cfg.kellyShare??1,changed:fraction!==(cfg.fraction??0),status:fraction>0?'live':'shadow',falsifiedOn:null,
      rationale:'Current scoped payout belief prices each target; native Kelly applies its uncertainty factor once. New original outcomes can demote or recover targets without a permanent lane latch.', evidenceWeight:weight,
      posteriors:cohorts,rests:{settled:m?.window?.settled??0,settledWrong:m?.window?.settledWrong??0,evPerContractCents:m?.window?.evPerContractCents??null,liveRealized:'only original attributed kd evidence; shadow payout labels are separate probability evidence'},
      judgedOn:date,revisitOn:addDays(date,expectationsFile.judgment?.revisitDays??1)};
  }
  return out;
}

export function addDays(date, days) {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/**
 * The policy in force: the base policy with each judged lane's fraction, judgment and, once admitted,
 * its `live` status. `judgments` is a review's in-force record ({ judgedOn, lanes }) or null.
 */
export function policyInForce(policy, judgments) {
  const next = JSON.parse(JSON.stringify(policy));
  for (const [id, j] of Object.entries(judgments?.lanes ?? {})) {
    if (!next.lanes?.[id]||j.method!=='scoped-count-posterior-v1') continue;
    next.lanes[id].fraction=j.fraction;
    next.lanes[id].config={...next.lanes[id].config,posteriors:j.posteriors??{}};
    if (j.status) next.lanes[id].status = j.status;
    next.lanes[id].judgment = { judgedOn: j.judgedOn, revisitOn: j.revisitOn, rationale: j.rationale, falsifiedOn: j.falsifiedOn ?? null };
  }
  return next;
}

const usd = (c) => (c === null || c === undefined ? 'n/a' : `${c < 0 ? '-' : ''}$${(Math.abs(c) / 100).toFixed(2)}`);
const pct = (v) => (v === null || v === undefined ? 'n/a' : `${(v * 100).toFixed(1)}%`);

export function renderDigest({ date, measurements, judgments, account = null }) {
  const lines = [`# Kalshi desk review, ${date}`, ''];
  if (account) lines.push(`Account: cash ${usd(account.cashCents)}, equity ${usd(account.equityCents)}.`, '');
  for (const [id, m] of Object.entries(measurements)) {
    if (id === 'unowned' && !m.window.settled && !m.window.contractsFilled) continue;
    const d = m.day, w = m.window;
    lines.push(`## ${id}`, `- Today: ${d.ordersPlaced} orders (${d.contractsPlaced} contracts) placed, ${d.contractsFilled} filled (${pct(d.fillRate)}); ${d.settled} settled, ${d.settledWrong} wrong, realized ${d.pnlCents !== null ? usd(d.pnlCents) : 'unknown'} (${d.pnlKnownSettled} covered kd closes; ${d.pnlUnknownSettled} unknown).`,
      `- Window (30 days): ${w.contractsFilled}/${w.contractsPlaced} filled (${pct(w.fillRate)}); ${w.settled} settled, ${w.settledWrong} wrong, realized ${w.pnlCents !== null ? usd(w.pnlCents) : 'unknown'} (${w.pnlKnownSettled} covered kd closes; ${w.pnlUnknownSettled} unknown)${w.evPerContractCents === null ? '' : `, ${w.evPerContractCents.toFixed(2)}c/contract`}.`);
    const t = m.tests;
    if (t?.fillRate) lines.push(`- Fill rate vs backtest ${pct(t.fillRate.expected)}: ${pct(t.fillRate.observed)} (Wilson95 ${pct(t.fillRate.wilson95.low)}-${pct(t.fillRate.wilson95.high)}), ${t.fillRate.consistent ? 'consistent' : 'INCONSISTENT'} (p=${t.fillRate.pTwoSided.toFixed(3)}).`);
    if (t?.lossRate) lines.push(`- Loss rate vs backtest ${pct(t.lossRate.expected)}: ${t.lossRate.k}/${t.lossRate.n}, P(X>=k)=${t.lossRate.pUpperTail.toExponential(2)}${t.lossRate.falsified ? ' FALSIFIED' : ', consistent'}.`);
    if (t?.ev) lines.push(`- EV vs backtest ${t.ev.expectedCents}c/contract: ${t.ev.observedCents.toFixed(2)}c.`);
    const sh = m.shadow;
    if (sh) {
      lines.push(`- SHADOW (hypothetical, no capital, not live evidence): ${sh.settled} certified opportunities settled${sh.unsettled ? `, ${sh.unsettled} unsettled` : ''}.`,
        `  - Taking: ${sh.taker.n} scored, ${sh.taker.wrong} wrong, ${sh.taker.evPerContractCents === null ? 'n/a' : `${sh.taker.evPerContractCents.toFixed(2)}c/contract after fee`}${sh.takerEv?.expectedCents != null ? ` (backtest ${sh.takerEv.expectedCents}c)` : ''}.`,
        `  - Resting: ${sh.maker.filled}/${sh.maker.n} would have filled (${pct(sh.maker.fillRate)}; touch ${sh.maker.filledTouch}), ${sh.maker.evPerFilledContractCents === null ? 'n/a' : `${sh.maker.evPerFilledContractCents.toFixed(2)}c per filled contract`}.`);
      const x = sh.execution;
      if (x) lines.push(`  - Execution on ${x.n} opportunities scored both ways${sh.feeAssumed ? ` (${sh.feeAssumed} scored before rows carried their fee schedule)` : ''}: taking ${x.takerEvCents.toFixed(2)}c; resting ${x.makerEvCents.toFixed(2)}c (fill ${pct(x.fillRate)}, Wilson95 ${pct(x.fillWilson95.low)}-${pct(x.fillWilson95.high)}${x.breakEvenFillRate === null ? '' : `, break-even ${pct(x.breakEvenFillRate)}`}); loss rate ${pct(x.lossRate.all)}, ${pct(x.lossRate.ifFilled)} if filled. Better: ${x.better.toUpperCase()} (${x.reason})${x.policyMode ? `; policy ${x.policyMode}${x.disagrees ? ' -- DISAGREES, a decision for the founder' : ''}` : ''}.`);
      if (sh.lossRate) lines.push(`  - Shadow loss rate vs backtest ${pct(sh.lossRate.expected)}: ${sh.lossRate.k}/${sh.lossRate.n}, P(X>=k)=${sh.lossRate.pUpperTail.toExponential(2)}${sh.lossRate.falsified ? ' FALSIFIED' : ', consistent'}.`);
    }
    const r = m.refused;
    if (r && (r.window.rows || r.window.nonLiveRows)) {
      const limits = (b) => Object.entries(b.byLimit).map(([limit, n]) => `${limit} ${n}`).join(', ') || 'none';
      lines.push(`- Refusals today: ${r.day.opportunities} opportunities (${r.day.rows} cycle rows), up to ${r.day.refusedContracts} contracts and ${usd(Math.round(r.day.gainForgoneCents))} known full-fill model EV after fees; reasons with unknown EV remain excluded; limits: ${limits(r.day)}.`,
        `- Refusals, window: ${r.window.opportunities} opportunities, up to ${r.window.refusedContracts} contracts and ${usd(Math.round(r.window.gainForgoneCents))} known full-fill model EV after fees; reasons with unknown EV remain excluded; limits: ${limits(r.window)}${r.window.nonLiveRows ? ` (${r.window.nonLiveRows} rows from unarmed or paper cycles not counted)` : ''}.`);
      lines.push(`  - Unknown EV: ${r.day.unknownExpectationOpportunities ?? 0} opportunities; unknown desired size: ${r.day.unknownSizeOpportunities ?? 0}. Repeated cycle refusals are folded once per lane/ticker/side. Maker EV assumes full fill and the source probability; it is not realized lost profit.`);
      for (const [reason, value] of Object.entries(r.day.byReason ?? {}).sort((a,b) => b[1].gainForgoneCents - a[1].gainForgoneCents)) lines.push(`  - ${reason}: ${value.opportunities} opportunities, ${value.gainForgoneCents.toFixed(2)}c known model EV after fees; ${value.unknownExpectationOpportunities} with unknown EV.`);
      for (const row of r.day.top) lines.push(`  - ${row.ticker} ${row.bookSide === null ? 'side unknown' : row.bookSide === 'ask' ? 'sell YES' : 'buy YES'}: ${row.refusedCount ?? 'unknown size'} refused under ${row.limits.join(' + ')} over ${row.cycles} cycles, ${row.gainForgoneCents === null ? 'unknown EV' : `${row.gainForgoneCents.toFixed(2)}c model EV after fees`}.`);
    }
    const j = judgments[id];
    if (j) lines.push(`- Judgment: fraction ${j.previousFraction} -> ${j.fraction}${j.changed ? ' (CHANGED)' : ' (held)'}. ${j.rationale}. Revisit ${j.revisitOn}.`);
    lines.push('');
  }
  lines.push('These judgments are in force from reviews/judgments.json: the desk trades them on its next cycle.');
  return `${lines.join('\n')}\n`;
}

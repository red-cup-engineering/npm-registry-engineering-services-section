#!/usr/bin/env node
/**
 * The desk's autopilot guard: runs a live cycle itself when no cycle has completed recently.
 *
 * The desk's minute job is started by the release's job scheduler. When that scheduler is down (2026-10-10 20:04Z to
 * 2026-10-11 13:25Z: a release gap, 17 hours, no cycle) or its cycles die before completing (2026-10-11: 192 killed
 * at the job's time limit), nothing trades and nothing says so. The guard is driven by its own timer, independent of
 * the scheduler: it reads the newest completed `cycle` row of the desk's ledger (error rows do not count: a cycle that
 * crashes still writes them) and, when that is older than `--stale-seconds` (180 by default), runs one live cycle under
 * the desk's own lock, so it never overlaps a scheduled cycle. A halted desk is reported, never re-armed: a halt is
 * the founder's to lift.
 *
 *   kalshi-desk-guard.mjs [--stale-seconds=180]
 */
import { existsSync, readFileSync, statSync, openSync, readSync, closeSync } from 'node:fs';
import { settlementRoot } from '@red-cup-engineering/kalshi-services-section/data-layout';
import { deskStatePath, ledgerFile } from '../src/desk-layout.mjs';

// The desk's data root, as apps/kalshi-desk.mjs states it (deskDataRoot), and its files through the desk's own
// layout. The guard loads the desk itself only when it has a cycle to run: checking every two minutes must not cost
// the desk's whole module graph (about 116 MB on Cold Red Gate).
export const deskDataRoot = (env = process.env) => env.KALSHI_DESK_DATA_DIR ?? settlementRoot(env);

/** The time of the newest completed cycle in the ledger (today's file, else yesterday's), or null. Reads only the file's tail. */
export function lastCycleAt(dir, now = Date.now()) {
  for (const day of [new Date(now).toISOString().slice(0, 10), new Date(now - 86400000).toISOString().slice(0, 10)]) {
    const file = ledgerFile(dir, day);
    if (!existsSync(file)) continue;
    const size = statSync(file).size, take = Math.min(size, 4 * 1024 * 1024);
    const buffer = Buffer.alloc(take), fd = openSync(file, 'r');
    try { readSync(fd, buffer, 0, take, size - take); } finally { closeSync(fd); }
    const lines = buffer.toString('utf8').split('\n');
    for (let i = lines.length - 1; i >= 0; i -= 1) {
      if (!lines[i].includes('"kind":"cycle"')) continue;
      try { const row = JSON.parse(lines[i]); if (row.kind === 'cycle' && row.at) return Date.parse(row.at); } catch { /* a torn line at the cut */ }
    }
  }
  return null;
}

/** What the guard should do now: 'ok' (a cycle completed recently), 'halted' (the desk is unarmed), or 'run'. */
export function guardVerdict({ dir, now = Date.now(), staleSeconds = 180 }) {
  const arming = (() => { try { return JSON.parse(readFileSync(deskStatePath(dir, 'arming.json'), 'utf8')); } catch { return null; } })();
  const last = lastCycleAt(dir, now);
  const ageSeconds = last === null ? null : Math.round((now - last) / 1000);
  if (arming && arming.armed === false) return { action: 'halted', ageSeconds, haltReason: arming.haltReason ?? null, haltedAt: arming.haltedAt ?? null };
  if (ageSeconds !== null && ageSeconds <= staleSeconds) return { action: 'ok', ageSeconds };
  return { action: 'run', ageSeconds };
}

if (import.meta.main) {
  const flag = process.argv.find((a) => a.startsWith('--stale-seconds='));
  const dir = deskDataRoot();
  const verdict = guardVerdict({ dir, staleSeconds: flag ? Number(flag.split('=')[1]) : 180 });
  const done = (result) => process.stdout.write(`${JSON.stringify(result)}\n`, () => process.exit(result.error ? 1 : 0));
  if (verdict.action !== 'run') done({ guard: verdict });
  else import('./kalshi-desk.mjs').then(({ runCycle }) => runCycle({ live: true })).then((cycle) => done({ guard: verdict, ran: cycle.skipped ? { skipped: cycle.skipped } : { at: cycle.at, mode: cycle.mode, results: cycle.results } }),
    (error) => done({ guard: verdict, error: error.message }));
}

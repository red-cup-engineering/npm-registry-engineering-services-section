import {marketSettlementTiming} from '@red-cup-engineering/kalshi-services-section/market-facts';
import {posteriorForTarget} from '../lane-posteriors.mjs';
import {positiveEdgeWeight} from '@red-cup-engineering/forecasting/outcome-calibration';
/**
 * Lane `daily-rain`: Kalshi's daily-rain markets (series KXRAIN, "total
 * precipitation at CLIxxx strictly greater than 0 inches" for the local day,
 * trace counts as 0, settled by The Weather Company, closing early the moment
 * it rains). Evidence: forecasting-service data/records/2026-10-04-weather-coverage.
 *
 * The weather is the forecasting service's: it prices each market the day
 * before (15:00 / 21:00 station-local) with the frozen NBS P06 logistic and
 * says which side of the market's long-shot bias it falls on, with the loss
 * rate a bet there is sized on (rain-market-model priceRainMarket, rainSide;
 * rain-markets.json `sides`):
 *
 *   tail       model P(rain) <= 2%: SELL YES by taking the bid (holds NO).
 *              Record: 221 markets, 1 settled yes, +3.3c a contract after fee.
 *   favourite  model P(rain) >= 97%: BUY YES by lifting the ask. Record: 54
 *              markets, 0 settled no, +7.4c a contract after fee.
 *
 * The bet is this lane's: the price band (tail bid 3-10c, favourite ask
 * 85-97c), a whole-cent market, and an edge after Kalshi's taker fee on the
 * series' own schedule over the loss rate. Execution is taking (microstructure
 * study 2026-10-04: these markets are quiet, a resting order rarely fills).
 * The lane trades when its evidence meets the founder's strategy criteria
 * (src/strategy-admission.mjs).
 *
 * The probability priced and sized: the market's own long-shot-corrected
 * probability (rain-market-model rainMarketPrior, the measured recalibration of
 * its mid) is pooled with the model's in equal log-odds
 * (rainMarketPoolProbability), and the lane prices and sizes on the larger of
 * that pool's loss and the frozen loss rate. The rain record
 * (forecasting data/records/2026-10-04-weather-coverage) finds the pool better
 * calibrated than either alone: out-of-fold Brier 0.0863 against the model's
 * 0.0885 and the mid's 0.0903 the day before at 15h, 0.0820 against 0.0854 and
 * 0.0848 at 21h. On 2026-10-11 Pittsburgh was sized on the model's 1.95% where
 * the pool says about 3.2%. Which markets the lane bets stays the frozen model's
 * selection; `detail.marketPrior` and `detail.pooled` record both opinions.
 *
 * Correlation: rain outcomes within a date are strongly correlated and
 * strongly so across nearby cities. The allocator's `event` key is therefore
 * "<Kalshi event>:<region>" (the cities of one region on one date are sized
 * as one joint bet and share the per-event budget), and `date` is the event
 * date (the per-date budget spans every region).
 */
import { guidanceDirectory } from '../desk-layout.mjs';
import { latestStationGuidance } from '@red-cup-engineering/forecasting/nbm-station-guidance';
import { RAIN_SERIES, rainCity, rainCityCode, rainEventTicker, rainStations, priceRainMarket, rainSide, rainMarketPrior, rainMarketPoolProbability, decisionStage } from '@red-cup-engineering/forecasting/rain-market-model';
import { eventDate } from '@red-cup-engineering/forecasting/temperature-market-model';
import { feePerContract } from '@red-cup-engineering/forecasting/fees';
import { competingBook, restingAskCents, restingBidCents } from '../book.mjs';
import { feeScheduleOf, wholeCentMarket } from '../fees.mjs';

export const id = 'daily-rain';

const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const seriesOf = (ticker) => ticker.slice(0, ticker.indexOf('-'));

/** The lane's betting rules from policy.lanes[id].config: which sides it bets, their price bands, the minimum edge after the fee, and the falsifier. */
export function laneConfig(policy) {
  const raw = policy.lanes?.[id]?.config ?? {};
  return {
    maxGuidanceAgeHours: raw.maxGuidanceAgeHours ?? 8,
    tail: { enabled: true, bidMinCents: 3, bidMaxCents: 10, ...raw.tail },
    favourite: { enabled: true, askMaxCents: 97, askMinCents: 85, ...raw.favourite },
    minEdgeCents: raw.minEdgeCents ?? 0.25,
    falsifier: { maxLossesIn30Days: 3, ...raw.falsifier },
  };
}

export const ownsTicker = (ticker) => seriesOf(ticker) === RAIN_SERIES;

/** Allocator correlation: the region on the event's date is one joint bet; the date budget spans regions. */
export function correlationOf(ticker) {
  const event = rainEventTicker(ticker);
  const city = rainCity(rainCityCode(ticker));
  return { event: `${event}:${city?.region ?? 'unknown'}`, date: eventDate(event) ?? event };
}

/** Tails that settled yes (we hold NO) plus favourites that settled no (we hold YES), from the venue's settlements. */
export function laneLosses(settlements) {
  return settlements.filter((row) => ownsTicker(row.ticker)
    && ((row.market_result === 'yes' && Number(row.no_count_fp) > 0) || (row.market_result === 'no' && Number(row.yes_count_fp) > 0))).length;
}

export function createLane({ policy }) {
  const cfg = laneConfig(policy);
  return {
    id, ownsTicker, correlationOf,
    async survey({ client, account, policy: surveyPolicy, dir, ledger, at, now }) {
      const config = laneConfig(surveyPolicy ?? policy);
      let rows;
      try { rows = await client.getMarkets({ series_ticker: RAIN_SERIES, status: 'open' }); } catch (error) {
        ledger(dir, { at, lane: id, kind: 'error', step: 'markets', series: RAIN_SERIES, code: error.code, detail: error.detail ?? error.message });
        throw error; // a failed survey leaves the lane's resting orders alone
      }
      const stations = rainStations({ validatedOnly: true });
      const guidance = await latestStationGuidance({ stations, now, cacheDir: guidanceDirectory(dir, 'rain') });
      const targets = [];
      // Every listed market inside its day-before decision window, with its touch from the listing: the market-only
      // strategy the shadow game plays (src/desk-game.mjs marketOnlyShadow). It reads no model and places nothing.
      const marketOnly = [];
      for (const row of rows) {
        const listed = rainCity(rainCityCode(row.ticker));
        const listedDate = eventDate(row.event_ticker);
        const stage = listed && listedDate ? decisionStage({ targetDate: listedDate, zone: listed.zone, now }) : null;
        const bidCents = Math.round(Number(row.yes_bid_dollars) * 100), askCents = Math.round(Number(row.yes_ask_dollars) * 100);
        if (stage && row.status === 'active' && bidCents >= 1 && askCents <= 99 && bidCents <= askCents) marketOnly.push({ ticker: row.ticker, eventTicker: row.event_ticker, targetDate: listedDate, closeTime: row.close_time, ...marketSettlementTiming(row), stage, bidCents, askCents, fee: null, region: listed.region });
      }
      for (const row of rows) {
        const code = rainCityCode(row.ticker);
        const city = rainCity(code);
        const base = { ticker: row.ticker, eventTicker: row.event_ticker, seriesTicker: RAIN_SERIES, targetDate: eventDate(row.event_ticker) ?? row.event_ticker, closeTime: row.close_time, ...marketSettlementTiming(row) };
        if (!city) { targets.push({ ...base, verdict: { ok: false, reason: `city ${code} not declared` } }); continue; }
        const priced = priceRainMarket({ ticker: row.ticker }, { guidance, maxGuidanceAgeHours: config.maxGuidanceAgeHours, now });
        if (!priced.priced) { targets.push({ ...base, verdict: { ok: false, reason: priced.reason } }); continue; }
        const predicted=rainSide(priced,undefined,config.posteriors);
        const side = predicted && config[predicted.side].enabled ? predicted.side : null;
        if (!side) { targets.push({ ...base, verdict: { ok: false, reason: `model p=${priced.probability.toFixed(4)} is neither a certified tail nor a favourite` }, detail: { priced, probability: priced.probability } }); continue; }
        let orderbook = null;
        try { orderbook = await client.getOrderbook(row.ticker, 10); } catch (error) { ledger(dir, { at, lane: id, kind: 'error', step: 'orderbook', ticker: row.ticker, code: error.code }); }
        await pause(60);
        const fee = await feeScheduleOf(client, RAIN_SERIES);
        targets.push(targetOf({ base: { ...base, fee, wholeCents: wholeCentMarket(row) }, side, lossRate: predicted.lossRate, priced, orderbook, active: row.status === 'active', own: account.resting.filter((order) => order.ticker === row.ticker), config }));
      }
      const fee = marketOnly.length ? await feeScheduleOf(client, RAIN_SERIES) : null;
      for (const candidate of marketOnly) candidate.fee = fee;
      return { targets, candidates: targets.length, guidanceRun: guidance.runtime, marketOnly };
    },
  };
}

/**
 * The lane's verdict for one priced market on one side, given its book. A tail
 * is a sell of YES (bookSide ask, taken at the best bid); a favourite a buy of
 * YES (bookSide bid, taken at the best ask). The maker price is where a
 * post-only order would rest (recorded for the shadow scorer; the lane's
 * execution mode is taker).
 */
export function targetOf({ base, side, lossRate, priced, orderbook, active = true, own = [], config }) {
  const book = competingBook(orderbook, own);
  const tail = side === 'tail';
  const rule = tail ? config.tail : config.favourite;
  const bookSide = tail ? 'ask' : 'bid';
  const takerPriceCents = tail ? (book.bestBidCents > 0 ? book.bestBidCents : null) : book.bestAskCents;
  // Where a post-only order would rest; with an empty side it sits a cent inside the touch we would take.
  const makerPriceCents = (tail ? restingAskCents(book) ?? (takerPriceCents === null ? null : Math.min(99, takerPriceCents + 1))
    : restingBidCents(book) ?? (takerPriceCents === null ? null : Math.max(1, takerPriceCents - 1)));
  const detail = {
    priced, probability: priced.probability, side, competingBidCents: book.bestBidCents, competingAskCents: book.bestAskCents,
    label: `${tail ? 'tail sell' : 'favourite buy'} p=${priced.probability.toFixed(4)} ${priced.city} ${priced.stage}`,
  };
  const cohort=side,posterior=posteriorForTarget(config,cohort);
  const retained={...base,bookSide,priceCents:makerPriceCents,takerPriceCents,opportunity:{kind:tail?'rain-tail':'rain-favourite',cohort,winProbability:1-lossRate},detail:{...detail,cohort,posterior,lossRate}};
  let scopeEligible=false;const fail=reason=>({...retained,predictionEligible:scopeEligible,verdict:{ok:false,reason},detail:{...retained.detail,...detail}});
  if (!active) return fail('market not active');
  if (takerPriceCents === null) return fail(tail ? 'no bid to take' : 'no ask to take');
  if (tail && (takerPriceCents < rule.bidMinCents || takerPriceCents > rule.bidMaxCents)) return fail(`best bid ${takerPriceCents}c outside ${rule.bidMinCents}-${rule.bidMaxCents}c`);
  if (!tail && (takerPriceCents > rule.askMaxCents || takerPriceCents < rule.askMinCents)) return fail(`best ask ${takerPriceCents}c outside ${rule.askMinCents}-${rule.askMaxCents}c`);
  if (makerPriceCents === null) return fail('no price to rest at');
  // Edge per contract after the taker fee on the series' schedule (large-batch limit; the desk charges each order's exact whole-cent fee).
  const fee = feePerContract(takerPriceCents / 100, { multiplier: base.fee?.multiplier ?? 1, feeType: base.fee?.feeType });
  const edgeAt = (loss) => (tail ? takerPriceCents / 100 - loss : (1 - loss) - takerPriceCents / 100) - fee;
  const prior = rainMarketPrior({ bidCents: book.bestBidCents, askCents: book.bestAskCents });
  let sizedLoss = lossRate;
  if (prior) {
    const priorLoss = tail ? prior.probability : 1 - prior.probability;
    detail.marketPrior = { midCents: prior.midCents, probability: prior.probability, lossRate: priorLoss, edgeCents: edgeAt(priorLoss) * 100, agrees: edgeAt(priorLoss) > 0 };
    const pooled = rainMarketPoolProbability(priced.probability, prior.probability);
    detail.pooled = { probability: pooled, lossRate: tail ? pooled : 1 - pooled };
    sizedLoss = Math.max(lossRate, detail.pooled.lossRate);
  }
  scopeEligible=true;retained.opportunity.winProbability=1-sizedLoss;
  const edge=edgeAt(sizedLoss);retained.detail.lossRate=sizedLoss;retained.detail.edgeCents=edge*100;
  if (!(edge*100 > Math.max(0,config.minEdgeCents??0))) return fail(`edge ${(edge * 100).toFixed(2)}c after the taker fee at ${takerPriceCents}c is under ${config.minEdgeCents}c (loss rate ${sizedLoss.toFixed(4)})`);
  return { ...base, verdict: { ok: true, edge }, bookSide, priceCents: makerPriceCents, takerPriceCents,
    opportunity:{...retained.opportunity,capitalWeight:positiveEdgeWeight(posterior,{riskCostCents:tail?100-takerPriceCents:takerPriceCents,feePerContractCents:fee*100})?.weight??1},
    detail:{...retained.detail,...detail,lossRate:sizedLoss,predictionLossRate:lossRate, edgeCents: edge * 100 } };
}

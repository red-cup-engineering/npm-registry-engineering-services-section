import {marketSettlementTiming} from '@red-cup-engineering/kalshi-services-section/market-facts';
import {posteriorForTarget,calibratedTargetRisk} from '../lane-posteriors.mjs';
import {feePerContract} from '@red-cup-engineering/forecasting/fees';
/**
 * Lane `published-series-favorites`: Kalshi's greater-than ladders on a
 * published daily figure (AAA regular gas, national and by state, and
 * KXDIESELD). In the last hours before a ladder closes the figure for the
 * day is all but known, and the brackets that are nearly settled trade a
 * cent or two short of it:
 *
 *   favorite  within the final 2 hours, a bracket whose yes bid is 94-98c is
 *             bought YES by resting a post-only bid at the best bid (one cent
 *             inside it when the spread is two cents or more);
 *   mirror    within the final hour only, a bracket whose yes ask is 2-6c is
 *             sold YES by resting a post-only ask at the best ask (one cent
 *             inside it when the spread leaves room), i.e. NO is bought.
 *
 * Evidence (survey/gasbt.py on Kalshi's settled history): favorites at 94-98c
 * in the final two hours lost 2 of ~670 events and earned +2.1 to +2.3c a
 * contract resting at the bid (+1.3c taking the ask); the mirror turns
 * negative earlier than the final hour.
 *
 * Guard: a bracket is certified only when its strike lies at least
 * `guard.sdMultiple` daily-change standard deviations (the series' own, from
 * content/config/published-series-history.json) on the safe side of the
 * strike where the ladder's own mid-prices cross 50% -- below it for a
 * favorite, above it for the mirror. Sizing takes win probability 0.99 (a 1%
 * loss-rate floor) through the desk's allocator.
 */
import { readFileSync } from 'node:fs';
import { competingBook, restingAskCents, restingBidCents } from '../book.mjs';
import { feeScheduleOf, wholeCentMarket } from '../fees.mjs';

export const id = 'published-series-favorites';

const seriesOf = (ticker) => ticker.slice(0, ticker.indexOf('-'));
const eventOf = (ticker) => ticker.slice(0, ticker.lastIndexOf('-'));
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const cents = (dollars) => Math.round(Number(dollars) * 100);
const MONTHS = { JAN: '01', FEB: '02', MAR: '03', APR: '04', MAY: '05', JUN: '06', JUL: '07', AUG: '08', SEP: '09', OCT: '10', NOV: '11', DEC: '12' };

/** `KXAAAGASD-26OCT04` -> 2026-10-04. */
export function eventDateOf(eventTicker) {
  const match = /-(\d{2})([A-Z]{3})(\d{2})(?:$|-)/u.exec(eventTicker);
  if (!match || !MONTHS[match[2]]) return null;
  return `20${match[1]}-${MONTHS[match[2]]}-${match[3]}`;
}

export const laneConfig = (policy) => policy.lanes[id].config;

/** The series' daily-change standard deviation in cents, or null when its history is too short to trust. */
export function seriesSd(history, seriesTicker, guard) {
  const row = history.series[seriesTicker];
  if (!row || row.sdCents === null || row.consecutiveChanges < guard.minDailyChanges) return null;
  return Math.max(row.sdCents, guard.minSdCents);
}

/**
 * Where a ladder's own mid-prices cross 50%, as strikes in dollars.
 * P(value > K) falls as K rises; `low` is the first strike (scanning up)
 * where the mid falls under 50%, `high` the last. Both are interpolated
 * between neighbouring strikes. Rows with a wider spread than `maxSpreadCents`
 * say nothing and are ignored. Null when the ladder never crosses.
 * @param {{strike: number, bidCents: number, askCents: number}[]} rows
 */
export function ladderCrossing(rows, maxSpreadCents = 10) {
  const mids = rows.filter((row) => row.askCents > row.bidCents && row.askCents - row.bidCents <= maxSpreadCents)
    .map((row) => ({ strike: row.strike, mid: (row.bidCents + row.askCents) / 200 })).sort((a, b) => a.strike - b.strike);
  const at = (a, b) => a.strike + ((a.mid - 0.5) / (a.mid - b.mid)) * (b.strike - a.strike);
  let low = null, high = null;
  for (let i = 0; i + 1 < mids.length; i += 1) {
    if (mids[i].mid >= 0.5 && mids[i + 1].mid < 0.5) { const crossing = at(mids[i], mids[i + 1]); if (low === null) low = crossing; high = crossing; }
  }
  return low === null ? null : { low, high };
}

/**
 * Whether a strike is far enough from the ladder's crossing, on the safe side.
 * @param {"favorite"|"mirror"} mode
 */
export function guardVerdict({ mode, strike, crossing, sdCents, guard }) {
  if (sdCents === null) return { ok: false, reason: 'series history too short for a daily-change SD' };
  if (!crossing) return { ok: false, reason: 'ladder never crosses 50%' };
  const distanceCents = mode === 'favorite' ? (crossing.low - strike) * 100 : (strike - crossing.high) * 100;
  const distanceSd = distanceCents / sdCents;
  if (!(distanceSd >= guard.sdMultiple)) return { ok: false, reason: `strike ${strike} is ${distanceSd.toFixed(2)} SD (${sdCents.toFixed(2)}c) from the 50% crossing, under ${guard.sdMultiple}`, distanceSd };
  return { ok: true, distanceSd };
}

/** Which side of the band a market's best prices put it on, if either: ignores the window and the guard. */
export function bandOf(bidCents, askCents, cfg) {
  if (bidCents >= cfg.favorite.bidMinCents && bidCents <= cfg.favorite.bidMaxCents) return 'favorite';
  if (askCents >= cfg.mirror.askMinCents && askCents <= cfg.mirror.askMaxCents) return 'mirror';
  return null;
}

export function loadHistory(url = new URL('../../content/config/published-series-history.json', import.meta.url)) {
  return JSON.parse(readFileSync(url, 'utf8'));
}

export function createLane({ policy, history = loadHistory() }) {
  const cfg = laneConfig(policy);
  const seriesSet = new Set(Object.keys(history.series));
  return {
    id,
    seriesTickers: [...seriesSet],
    ownsTicker: (ticker) => seriesSet.has(seriesOf(ticker)),
    correlationOf: (ticker) => { const event = eventOf(ticker); return { event, date: eventDateOf(event) ?? event }; },
    /** Favorite losses in thirty days (YES held, settled no) and mirror losses (NO held, settled yes): the lane's falsifier. */
    async survey({ client, account, dir, ledger, at, now }) {
      const ownedHeld = new Set([...account.positions, ...account.resting].filter((row) => seriesSet.has(seriesOf(row.ticker))).map((row) => row.ticker));
      const targets = [];
      let events = 0;
      for (const seriesTicker of seriesSet) {
        let rows;
        try { rows = await client.getMarkets({ series_ticker: seriesTicker, status: 'open' }); } catch (error) {
          ledger(dir, { at, lane: id, kind: 'error', step: 'markets', series: seriesTicker, code: error.code, detail: error.detail ?? error.message });
          continue;
        }
        await pause(60);
        const sdCents = seriesSd(history, seriesTicker, cfg.guard);
        const byEvent = new Map();
        for (const row of rows) byEvent.set(row.event_ticker, [...(byEvent.get(row.event_ticker) ?? []), row]);
        for (const [eventTicker, eventRows] of byEvent) {
          events += 1;
          const ladder = eventRows.filter((row) => row.strike_type === 'greater' && Number.isFinite(Number(row.floor_strike)))
            .map((row) => ({ strike: Number(row.floor_strike), bidCents: cents(row.yes_bid_dollars), askCents: cents(row.yes_ask_dollars) }));
          const crossing = ladderCrossing(ladder, cfg.guard.maxLadderSpreadCents);
          for (const row of eventRows) {
            const bidCents = cents(row.yes_bid_dollars), askCents = cents(row.yes_ask_dollars);
            const held = ownedHeld.has(row.ticker);
            const band = bandOf(bidCents, askCents, cfg);
            if (!band && !held) continue; // nothing to say about a bracket nowhere near the bands
            const base = { ticker: row.ticker, eventTicker, seriesTicker, targetDate: eventDateOf(eventTicker) ?? eventTicker, closeTime: row.close_time, ...marketSettlementTiming(row), fee: await feeScheduleOf(client, seriesTicker), wholeCents: wholeCentMarket(row) };
            const hoursToClose = (Date.parse(row.close_time) - now) / 3600_000;
            const strike = Number(row.floor_strike);
            const fail = (reason, extra = {}) => targets.push({ ...base, verdict: { ok: false, reason }, detail: { band, hoursToClose, bidCents, askCents, ...extra } });
            // A held or resting bracket that left its band still needs a verdict so its resting order is withdrawn.
            if (!band) { fail('bid/ask left the band'); continue; }
            const windowHours = cfg[band].windowHours;
            if (row.status !== 'active' || row.strike_type !== 'greater') { fail('not an active greater-than bracket'); continue; }
            if (!(hoursToClose > 0 && hoursToClose <= windowHours)) { fail(`outside the ${windowHours}h ${band} window (closes in ${hoursToClose.toFixed(2)}h)`); continue; }
            const guarded = guardVerdict({ mode: band, strike, crossing, sdCents, guard: cfg.guard });
            const detail = { band, hoursToClose, bidCents, askCents, strike, crossing, sdCents, distanceSd: guarded.distanceSd ?? null };
            if (!guarded.ok) { fail(guarded.reason, detail); continue; }
            let orderbook = null;
            try { orderbook = await client.getOrderbook(row.ticker, 10); } catch (error) { ledger(dir, { at, lane: id, kind: 'error', step: 'orderbook', ticker: row.ticker, code: error.code }); fail('orderbook unavailable', detail); continue; }
            await pause(60);
            targets.push(targetFromBook({ base, band, orderbook, own: account.resting.filter((order) => order.ticker === row.ticker), cfg, detail }));
          }
        }
      }
      return { targets, candidates: events };
    },
  };
}

/** Where, and whether, the lane rests an order on a guarded, in-window bracket given its book. */
export function targetFromBook({ base, band, orderbook, own, cfg, detail }) {
  const book = competingBook(orderbook, own);
  const bookSide = band === 'favorite' ? 'bid' : 'ask';
  // The band is read from the competing book (ours removed), so a reprice cannot walk us out of it or chase our own order.
  const side = band === 'favorite' ? { low: cfg.favorite.bidMinCents, high: cfg.favorite.bidMaxCents, best: book.bestBidCents }
    : { low: cfg.mirror.askMinCents, high: cfg.mirror.askMaxCents, best: book.bestAskCents };
  if (side.best === null || side.best < side.low || side.best > side.high) return { ...base, verdict: { ok: false, reason: `competing ${bookSide === 'bid' ? 'bid' : 'ask'} ${side.best}c outside ${side.low}-${side.high}c` }, detail };
  const priceCents = band === 'favorite' ? restingBidCents(book) : restingAskCents(book);
  if (priceCents === null) return { ...base, verdict: { ok: false, reason: 'no room to rest beside the book' }, detail };
  const posterior=posteriorForTarget(cfg,band);
  const winProbability=posterior?.winMean??null;
  const takerPriceCents = bookSide === 'bid' ? book.bestAskCents : (book.bestBidCents > 0 ? book.bestBidCents : null);
  const fee=feePerContract(priceCents/100,{multiplier:base.fee?.multiplier??1,feeType:base.fee?.feeType,maker:true})*100;
  const risk=calibratedTargetRisk({posterior,winProbability,riskCostCents:bookSide==='bid'?priceCents:100-priceCents,feePerContractCents:fee});
  const edge=winProbability===null?null:100*winProbability-(bookSide==='bid'?priceCents:100-priceCents)-fee;
  return {...base,predictionEligible:true,verdict:{ok:edge!==null&&edge>0,...(edge!==null&&edge>0?{edge:edge/100}:{reason:edge===null?'actual scoped payout probability is unknown':'posterior mean edge is not strictly positive after the fee'})},bookSide,priceCents,takerPriceCents,opportunity:{kind:band,cohort:band,winProbability,capitalWeight:risk.capitalWeight},
    detail:{...detail,cohort:band,posterior,edgeCents:edge,feePerContractCents:fee,competingBidCents: book.bestBidCents, competingAskCents: book.bestAskCents, label: `${band} ${bookSide} ${detail.distanceSd?.toFixed(1)}SD hrs=${detail.hoursToClose.toFixed(2)}` } };
}

#!/usr/bin/env node
/**
 * Score the Kalshi desk's shadow book against settled public market data.
 *   node scripts/shadow-score.mjs [--days=30] [--batch=10]
 * Reads <data root>/data/logs/desk-shadow-logs/*.jsonl; writes <data root>/data/state/shadow-score-state/scores.json.
 * Public reads only (no signing, no orders).
 */
import { createKalshiClient } from '@red-cup-engineering/kalshi-services-section/client';
import { deskDataRoot } from '../apps/kalshi-desk.mjs';
import { scoreShadow } from '../src/shadow-score.mjs';

const flag = (name, fallback) => { const arg = process.argv.find((a) => a.startsWith(`--${name}=`)); return arg ? Number(arg.slice(name.length + 3)) : fallback; };

if (import.meta.main) {
  scoreShadow({ dir: deskDataRoot(), client: createKalshiClient(), days: flag('days', 30), batch: flag('batch', 10) }).then(
    (record) => process.stdout.write(`${JSON.stringify(record, null, 2)}\n`),
    (error) => { process.stderr.write(`${error.stack ?? error.message}\n`); process.exitCode = 1; },
  );
}

/**
 * What Kalshi charges the desk's bets, from each series' own fee schedule (GET /series: fee_type and
 * fee_multiplier), and which markets the desk can price at all.
 *
 * The fee rule is forecasting-service's (src/fees.mjs, the one definition): a taker pays
 * 0.07 x multiplier x C x P x (1 - P) dollars for an order of C contracts at price P, summed over the order's
 * fills and rounded UP once per order to the account's balance grid ($0.0001 for the house account, a direct
 * member; a schedule may carry `gridCents` to price another); a maker pays nothing on a plain 'quadratic'
 * series and 0.0175 x multiplier x C x P x (1 - P) on a series whose fee_type carries maker fees. A sell of YES at P is a buy of NO at 1 - P,
 * and the fee is the same either way. The desk prices, rests and takes only in whole cents, so a market
 * whose price levels are not whole cents is not one it trades.
 */
import { orderFeeCents, orderFeeCentsOfFills } from '@red-cup-engineering/forecasting/fees';

/** The schedule assumed when a series' record cannot be read: maker fees charged, so an unread schedule never makes a bet look cheaper than it is. */
export const UNREAD_SCHEDULE = Object.freeze({ feeType: 'quadratic_with_maker_fees', multiplier: 1, unread: true });

/** A series' schedule from Kalshi's series record. */
export const scheduleOf = (series) => ({ feeType: series?.fee_type ?? 'quadratic', multiplier: Number.isFinite(Number(series?.fee_multiplier)) ? Number(series.fee_multiplier) : 1 });

const schedules = new Map(); // seriesTicker -> Promise<schedule>, for the life of the process

/** The fee schedule of `seriesTicker`, read once per process; a failed read is charged as UNREAD_SCHEDULE. */
export function feeScheduleOf(client, seriesTicker, options) {
  if (!schedules.has(seriesTicker)) {
    schedules.set(seriesTicker, Promise.resolve().then(() => client.getSeries(seriesTicker, options)).then(scheduleOf).catch(() => {
      schedules.delete(seriesTicker);
      return UNREAD_SCHEDULE;
    }));
  }
  return schedules.get(seriesTicker);
}

const feeOptions = (schedule, maker) => ({ multiplier: schedule.multiplier, feeType: schedule.feeType, maker, ...(schedule.gridCents === undefined ? {} : { gridCents: schedule.gridCents }) });

/** Fee in cents for ONE order of `count` contracts at `priceCents` on the YES book, on the account's balance grid. */
export const orderFee = ({ count, priceCents, schedule = UNREAD_SCHEDULE, maker = false }) => orderFeeCents(count, priceCents, feeOptions(schedule, maker));

/** Fee in cents for ONE order filled at several levels (`fills`: {count, priceCents}), rounded to the grid once. */
export const orderFeeOfFills = ({ fills, schedule = UNREAD_SCHEDULE, maker = false }) => orderFeeCentsOfFills(fills, feeOptions(schedule, maker));

/** Whether a Kalshi market's price levels are whole cents (price_level_structure 'linear_cent', or every price range stepping by 0.01). */
export function wholeCentMarket(market) {
  if (market?.price_level_structure) return market.price_level_structure === 'linear_cent';
  if (Array.isArray(market?.price_ranges) && market.price_ranges.length) return market.price_ranges.every((range) => Math.abs(Number(range.step) - 0.01) < 1e-9);
  return true; // Kalshi's long-standing default
}

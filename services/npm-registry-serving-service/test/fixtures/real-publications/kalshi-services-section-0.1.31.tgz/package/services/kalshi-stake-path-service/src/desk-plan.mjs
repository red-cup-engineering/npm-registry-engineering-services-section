import {allocationsFor} from '@red-cup-engineering/mandate-portfolio-allocation-service/market-game';
/**
 * One cycle of the multi-lane Kalshi desk, as a pure function.
 *
 * Each lane surveys its own markets and states, per market, where it would
 * rest a post-only order and whether that order is certified (a `target`).
 * The desk then does what the weather desk's planCycle did, for every lane
 * at once and on both sides of the book:
 *   - a resting order that no longer matches its lane's target (market gone,
 *     certification lost, side changed, or old price loses after fees) is cancelled;
 *   - what remains, plus the positions held, is each lane's open exposure;
 *   - every certified target becomes an allocator opportunity, and ALL lanes
 *     are sized together by allocateOpportunities against the one account.
 *
 * A target's `bookSide` is the YES book's: `ask` sells YES (holds NO, risk
 * 100 - price, gain price), `bid` buys YES (risk price, gain 100 - price).
 *
 * Fees and cents. Every bet is costed with the fee its series charges
 * (target.fee, src/fees.mjs): the taker fee when taking, the maker fee (0 on a
 * plain quadratic series) when resting. Kalshi rounds a fee up to the cent once
 * per ORDER, so the fee per contract depends on the batch; sizing therefore runs
 * in hundredths of a cent (SIZING_UNITS_PER_CENT) with each contract's share of
 * its order's whole-cent fee, iterated until the batch sizes settle, and every
 * order that leaves is priced in whole cents with its exact whole-cent fee.
 *
 * Ranking. When cash binds, the allocator funds the opportunities that grow the
 * account fastest per day the stake is locked (growthPerDay): the Kelly growth
 * rate of the bet, net of its fee, over the days until it settles.
 */
import { allocateOpportunities } from './allocator.mjs';
import { executionConfig, admitTaker, admitTakerOptimistic, admitMaker, admitWalk, walkLadder, canTakeAt, takerFeeCents, makerFeeCents, restKey } from './execution.mjs';
import { UNREAD_SCHEDULE } from './fees.mjs';
import { THETA, MAKER_THETA } from '@red-cup-engineering/forecasting/fees';

const cents = (dollars) => Math.round(Number(dollars) * 100);

/** An explicitly configured capital floor. Payout losses update scoped
 * posterior sizing; a fixed count cannot halt an otherwise profitable desk. */
export function haltReason({ equityCents, losses30d, policy }) {
  if (policy.halts?.equityFloorUsd > 0 && equityCents < cents(policy.halts.equityFloorUsd)) return `equity $${(equityCents / 100).toFixed(2)} under the $${policy.halts.equityFloorUsd} floor`;
  return null;
}
export const collateralCents = (order) => (order.bookSide === 'bid' ? order.priceCents : 100 - order.priceCents) * order.count;

/** The allocator sizes in hundredths of a cent so a contract's share of its order's whole-cent fee is carried, not rounded away. */
export const SIZING_UNITS_PER_CENT = 100;
const U = SIZING_UNITS_PER_CENT;

/** A target's fee schedule; a lane that names none is charged as if its series had maker fees. */
const scheduleOfTarget = (target) => target?.fee ?? UNREAD_SCHEDULE;

const probabilityEvidenceOf = (lane, target) => ({ lane: lane.id, cohort: target.opportunity?.cohort ?? target.detail?.cohort ?? null,
  source: target.detail?.source ?? target.detail?.priced ?? null, sourceLaw: target.detail?.surface ?? null,
  ruleKey: target.ruleKey ?? target.detail?.ruleKey ?? null, rulesHash: target.rulesHash ?? null,
  settlementSource: target.settlementSource ?? target.detail?.settlementSource ?? null,
});

/** Fee in whole cents for one order of `count` at `priceCents`, taking or resting, on the target's schedule. */
export const orderFeeFor = ({ execution, count, priceCents, schedule }) => (execution === 'taker' ? takerFeeCents(count, priceCents, schedule) : makerFeeCents(count, priceCents, schedule));

/** A contract's share of its order's whole-cent fee, in sizing units, rounded UP to the unit; `count` null is the large-batch limit. */
export function feeUnitsPerContract({ execution, count, priceCents, schedule }) {
  if (count === null || count === undefined) {
    const theta = execution === 'taker' ? THETA : (/maker/u.test(schedule.feeType ?? '') ? MAKER_THETA : 0);
    return Math.ceil(theta * schedule.multiplier * priceCents * (100 - priceCents) / 100 * U - 1e-9);
  }
  return Math.ceil(orderFeeFor({ execution, count, priceCents, schedule }) * U / count - 1e-9);
}

/**
 * Expected log growth of the stake per day it is locked, for a bet that costs `costCents` and pays `gainCents`
 * (both net of the fee) with probability `winProbability`, at its Kelly fraction f* = p - q / b:
 * (p ln(1 + f* b) + q ln(1 - f*)) / days. -Infinity when the bet has no Kelly edge.
 */
export function growthPerDay({ winProbability, costCents, gainCents, days }) {
  if (!(costCents > 0) || !(gainCents > 0) || !(days > 0)) return -Infinity;
  const b = gainCents / costCents, q = 1 - winProbability;
  const f = Math.min(winProbability - q / b, 1 - 1e-9);
  if (!(f > 0)) return -Infinity;
  return (winProbability * Math.log1p(f * b) + q * Math.log1p(-f)) / days;
}

/** Prospective settlement horizon for ranking, never an outcome or payout proof.
 * Prefer the venue's expected expiry, plus its observed post-determination timer.
 * A missing/stale estimate falls back to the venue's latest future expiry, then
 * the existing close-plus-policy-lag assumption. No unknown clock refuses a bet.
 * A future venue projection uses its actual remaining duration, so even within
 * one hour otherwise equal economics prefer the earlier projection. Only an
 * assumed fallback retains the previous one-hour floor. Neither is a trade gate.
 */
export function settlementHorizon(target, now, lagHours = 12) {
  const timer = Number.isSafeInteger(target.settlementTimerSeconds) && target.settlementTimerSeconds >= 0
    ? target.settlementTimerSeconds : null;
  const timerMs = (timer ?? 0) * 1000;
  const future = value => {
    const expiry = typeof value === 'string' ? Date.parse(value) : NaN;
    const projected = expiry + timerMs;
    return Number.isFinite(expiry) && Number.isFinite(projected) && projected > now && projected <= 8640000000000000
      ? { expiry, projected } : null;
  };
  const expected = future(target.expectedExpirationTime), latest = future(target.latestExpirationTime);
  const closeClock = Date.parse(target.closeTime ?? '');
  const dayClock = Date.parse(`${target.targetDate}T23:59:00Z`);
  const close = Number.isFinite(closeClock) ? closeClock : Number.isFinite(dayClock) ? dayClock : now;
  const lag = Number.isFinite(lagHours) && lagHours >= 0 ? lagHours : 12;
  const chosen = expected ?? latest;
  const projected = chosen?.projected ?? close + lag * 3600000;
  return {
    projectedAt: new Date(projected).toISOString(),
    basis: expected ? 'venue-expected-expiry' : latest ? 'venue-latest-expiry' : 'close-plus-policy-lag',
    expiryAt: chosen ? new Date(chosen.expiry).toISOString() : null,
    settlementTimerSeconds: chosen ? timer : null,
    fallbackLagHours: chosen ? null : lag,
    days: (chosen ? projected - now : Math.max(projected - now, 3600000)) / 86400000,
    minimumRankingHours: chosen ? null : 1,
    determinationTiming: chosen ? 'expiry is a projection for determination; delays or review are unmodeled' : null,
    guarantee: false,
  };
}
export const daysToSettle = (target, now, lagHours = 12) => settlementHorizon(target, now, lagHours).days;

/**
 * @typedef {object} Target
 * @property {string} ticker
 * @property {string} eventTicker
 * @property {string} targetDate  correlated settlement date (YYYY-MM-DD)
 * @property {string} [closeTime]
 * @property {string|null} [expectedExpirationTime] venue expected expiry, distinct from settlement
 * @property {string|null} [latestExpirationTime] venue latest expiry
 * @property {number|null} [settlementTimerSeconds] venue post-determination timer
 * @property {string} seriesTicker
 * @property {{ok: boolean, reason?: string}} verdict
 * @property {"bid"|"ask"} [bookSide]
 * @property {number} [priceCents]   resting price on the YES book
 * @property {{winProbability: number, rankEdge?: number, kind: string}} [opportunity]
 * @property {number|null} [takerPriceCents]  YES-book price to take at: the best bid when selling YES, the best ask when buying (the desk's own orders removed)
 * @property {object} [detail]       lane evidence carried into the ledger
 *
 * @typedef {object} LaneSurvey
 * @property {string} id
 * @property {(ticker: string) => boolean} ownsTicker
 * @property {(ticker: string) => {event: string, date: string}} correlationOf
 * @property {Target[]} targets
 * @property {string|null} [paused]  a reason: the lane places nothing and withdraws what rests
 * @property {boolean} [failed]      the survey failed: the lane's resting orders are left alone, nothing is placed
 * @property {string} [skipped]      the survey deadline passed before the lane was surveyed (it is also `failed`)
 *
 * A target with `unread: true` is one whose evidence or book the cycle ran out of time to read: it certifies
 * nothing, and an order of ours resting on it is left alone, not withdrawn.
 */

/**
 * @param {{lanes: LaneSurvey[], positions: {ticker: string, costCents: number}[], resting: object[], cashCents: number, equityCents: number, policy: object, now?: number}} input
 */
export function planDesk({ lanes: surveyedLanes, positions, resting, cashCents, equityCents, policy, now = Date.now(), restCycles = new Map(), marketDecision, principal }) {
  if(marketDecision)allocationsFor(marketDecision,{venue:'kalshi',principal,instrument:'__validate_only__',side:'no',at:new Date(now).toISOString()});
  const cancels = [], skips = [], amends = [], queueRetention = [];
  // A resting order's new expiry when it is refreshed: the policy's TTL from now, never past its market's close.
  const refreshedExpiry = (closes) => Math.min(Math.floor(now / 1000) + (policy.orders?.ttlMinutes ?? 40) * 60, closes !== null ? Math.floor(closes / 1000) : Infinity);
  // Each certified target is given this cycle's execution: resting (maker) or taking (taker). A taker view
  // rests nothing: its price is the price taken and any resting order of ours on it is withdrawn first.
  const demoted = new Set(); // tickers whose taking failed the post-sizing admission
  const modeOf = (lane, target) => {
    const cfg = executionConfig(policy, lane.id);
    const unavailable = (reason) => ({ ...target, makerPriceCents: target.priceCents, verdict: { ok: false, reason } });
    const takerView = { ...target, execution: 'taker', makerPriceCents: target.priceCents, priceCents: target.takerPriceCents };
    const makerView = { ...target, execution: 'maker', makerPriceCents: target.priceCents };
    if (!target.verdict.ok || cfg.mode === 'maker') return makerView;
    const admissible = canTakeAt(target.takerPriceCents) && !demoted.has(target.ticker)
      && admitTakerOptimistic({ bookSide: target.bookSide, takerPriceCents: target.takerPriceCents, winProbability: target.opportunity.winProbability, minTakerEdgeCents: cfg.minTakerEdgeCents, schedule: scheduleOfTarget(target) }).ok;
    if (cfg.mode === 'taker') return admissible ? takerView : unavailable(`taker: ${canTakeAt(target.takerPriceCents) ? (demoted.has(target.ticker) ? 'edge after fee at the sized batch below the minimum' : 'edge after fee below the minimum') : 'no takeable price'}`);
    const matured = (restCycles.get(restKey(lane.id, target.ticker, target.bookSide)) ?? 0) >= cfg.makerCycles;
    return matured && admissible ? takerView : makerView;
  };
  const viewLanes = () => surveyedLanes.map((lane) => ({ ...lane, targets: lane.targets.map((target) => modeOf(lane, target)) }));
  let lanes = viewLanes();
  const kept = [];
  const keptByLane = new Map(lanes.map((lane) => [lane.id, []]));
  const targetsByTicker = new Map(lanes.map((lane) => [lane.id, new Map(lane.targets.map((target) => [target.ticker, target]))]));
  // Two lanes may own one ticker (every temperature bracket is forecast-edge's and a tail is also the tail lane's):
  // the ticker is the first lane's that certifies it this cycle, else the first that targets it, else the first that owns it.
  const laneOf = (ticker) => lanes.find((lane) => targetsByTicker.get(lane.id).get(ticker)?.verdict.ok)
    ?? lanes.find((lane) => targetsByTicker.get(lane.id).has(ticker)) ?? lanes.find((lane) => lane.ownsTicker(ticker));

  for (const order of resting) {
    const lane = laneOf(order.ticker);
    const target = lane && targetsByTicker.get(lane.id).get(order.ticker);
    // Hand-placed orders, foreign markets, unsurveyed lanes and unread evidence are never touched. A desk order kept
    // that way is still the lane's exposure: its limits and the joint sizing of its day must see it.
    if (!lane || lane.failed || target?.unread || order.own === false) {
      kept.push(order);
      if (lane && order.own !== false) keptByLane.get(lane.id).push(order);
      continue;
    }
    const expires = order.expiration ? Date.parse(order.expiration) : null;
    const closes = target?.closeTime ? Date.parse(target.closeTime) : null;
    // An expiry at the market's close needs no refresh: nothing can rest past it.
    const lapsing = expires !== null && expires - now < (policy.orders?.refreshWithinMinutes ?? 0) * 60_000 && !(closes !== null && expires >= closes - 60_000);
    const sameSide = target?.bookSide === (order.bookSide ?? 'ask');
    const oldQuote = target?.verdict.ok && sameSide && target.opportunity
      ? admitMaker({ bookSide: order.bookSide ?? 'ask', priceCents: order.priceCents, count: order.count, winProbability: target.opportunity.winProbability, schedule: scheduleOfTarget(target) })
      : null;
    const reason = lane.paused ? `lane paused: ${lane.paused}`
      : !target ? 'market no longer a candidate'
        : !target.verdict.ok ? target.verdict.reason
          : target.execution === 'taker' ? 'switch to taking'
          : !sameSide ? `side changed ${order.bookSide ?? 'ask'} -> ${target.bookSide}`
            : !oldQuote?.ok ? `resting price no longer profitable: ${oldQuote?.reason ?? 'probability unavailable'}`
              : null;
    if (reason) { cancels.push({ ...order, lane: lane.id, reason }); continue; }
    kept.push(order); keptByLane.get(lane.id).push(order);
    queueRetention.push({ lane: lane.id, ticker: order.ticker, orderId: order.orderId, bookSide: order.bookSide ?? 'ask', priceCents: order.priceCents, proposedPriceCents: target.priceCents, remainingCount: order.count, queuePositionFp: order.queuePositionFp ?? null, queueReceivedAt: order.queueReceivedAt ?? null, edgeCents: oldQuote.economics.edgeCents, feeCents: oldQuote.economics.feeCents, reason: 'same-side resting quote remains positive after current fees; retain price-time priority' });
    // A lapsing order still certified at its price is refreshed in place: an expiry-only amend keeps its place in the
    // queue, where cancelling and re-placing it put it at the back (2026-10-11 21:55Z, LA).
    if (lapsing) {
      const expirationTime = refreshedExpiry(closes);
      if (expirationTime * 1000 - now > 60_000) amends.push({ orderId: order.orderId, ticker: order.ticker, lane: lane.id, bookSide: order.bookSide ?? 'ask', priceCents: order.priceCents, filledCount: order.filledCount ?? 0, restingCount: order.count, remaining: order.count, expirationTime, reasons: ['refresh before expiry'] });
    }
  }

  // Exposure by lane: positions held plus the collateral of resting orders that stay.
  const exposure = { lanes: {} };
  const held = new Map();
  const heldItems = [];
  const holdItem = (exposureLane, row, kind, riskCents, grossPayoutCents, side) => {
    // Exposure ownership does not select a probability supplier. Preserve the
    // existing survey/source priority while checking every actual same-side law.
    const supplier = surveyedLanes.find(lane => {
      const target = lane.targets.find(target => target.ticker === row.ticker);
      const targetSide = target?.bookSide === 'ask' ? 'no' : target?.bookSide === 'bid' ? 'yes' : null;
      const p = target?.opportunity?.winProbability;
      return !lane.failed && !target?.unread && (target?.verdict?.ok || target?.predictionEligible) && targetSide === side && Number.isFinite(p) && p >= 0 && p <= 1;
    });
    const target = supplier?.targets.find(target => target.ticker === row.ticker);
    const feeTarget = target ?? (exposureLane && targetsByTicker.get(exposureLane.id).get(row.ticker));
    heldItems.push({ ticker: row.ticker, side, kind, lane: supplier?.id ?? null, correlation: supplier?.correlationOf(row.ticker) ?? null,
      exposureLane: exposureLane?.id ?? null, exposureCorrelation: exposureLane?.correlationOf?.(row.ticker) ?? null,
      riskCents: (riskCents + (kind === 'resting' && feeTarget?.fee ? makerFeeCents(row.count, row.priceCents, feeTarget.fee) : 0)) * U, grossPayoutCents: grossPayoutCents * U,
      feeKnown: kind !== 'resting' || Boolean(feeTarget?.fee),
      winProbability: target?.opportunity.winProbability ?? null,
      capitalWeight: target?.opportunity.capitalWeight ?? 1,
      probabilityEvidence: target ? probabilityEvidenceOf(supplier, target) : null,
      adjustable: kind === 'resting' && row.own !== false,
    });
  };
  const addRisk = (lane, ticker, cents) => {
    const c = cents * U;
    const { event, date } = lane.correlationOf(ticker);
    const book = (exposure.lanes[lane.id] ??= { byEvent: new Map(), byDate: new Map(), total: 0 });
    book.byEvent.set(event, (book.byEvent.get(event) ?? 0) + c);
    book.byDate.set(date, (book.byDate.get(date) ?? 0) + c);
    book.total += c;
    held.set(ticker, (held.get(ticker) ?? 0) + c);
  };
  for (const row of positions) {
    const lane = laneOf(row.ticker);
    if (lane) addRisk(lane, row.ticker, row.costCents);
    holdItem(lane, row, 'position', row.costCents, 100 * row.contracts, row.side);
  }
  for (const order of kept) {
    const lane = laneOf(order.ticker);
    if (lane) addRisk(lane, order.ticker, collateralCents(order));
    holdItem(lane, order, 'resting', collateralCents(order), 100 * order.count, order.bookSide === 'bid' ? 'yes' : 'no');
  }

  const reserved = kept.reduce((sum, order) => sum + collateralCents(order), 0);
  const laneConfig = Object.fromEntries(lanes.map((lane) => [lane.id, { fraction: policy.lanes?.[lane.id]?.fraction ?? 0 }]));
  // A lane's own limits (policy.lanes[id].limits, in the policy's names) replace the global ones for that lane only.
  const laneLimits = Object.fromEntries(lanes.filter((lane) => policy.lanes?.[lane.id]?.limits).map((lane) => {
    const own = policy.lanes[lane.id].limits;
    return [lane.id, Object.fromEntries([['perEventFraction', own.perEventFraction], ['perDateFraction', own.perSettlementDateFraction], ['maxOpenFraction', own.maxOpenFraction]].filter(([, value]) => value !== undefined))];
  }));
  // The allocator's input in sizing units; `limits` and `freeCashCents` (units) lift a limit, for the refused-size record.
  const allocationInput = (opportunities, { limits = {}, freeCashCents } = {}) => ({
    opportunities,
    cashCents: cashCents * U,
    // A lifted free cash is the whole equity: the allocator refuses free cash above the account it is drawn from.
    venues: [{ venue: 'kalshi', equityCents: equityCents * U, freeCashCents: freeCashCents === undefined ? (cashCents - reserved) * U : Math.min(freeCashCents, equityCents * U), minCashCents: freeCashCents === undefined ? cents(policy.limits.minCashUsd) * U : 0 }],
    lanes: laneConfig,
    sizing: { kellyMultiple: policy.sizing.kellyMultiple, ...(policy.sizing.method ? { method: policy.sizing.method } : {}), ...(policy.sizing.groupBy ? { groupBy: policy.sizing.groupBy } : {}) },
    limits: { perEventFraction: policy.limits.perEventFraction, perDateFraction: policy.limits.perSettlementDateFraction, maxOpenFraction: policy.limits.maxOpenFraction, lanes: laneLimits, ...limits },
    exposure,
    held: heldItems,
  });
  const baseSkips = skips.length;

  // Sizing. Each opportunity's cost and payoff carry its fee per contract (taker or maker, on its series' schedule),
  // which depends on the batch the allocator then chooses: iterate (fee from the last pass's count, the large-batch
  // limit on the first) until counts settle, then admit each order on its exact whole-cent fee and edge. A taker
  // that fails is demoted -- to resting for maker-then-taker lanes, dropped for taker lanes -- and the lanes are
  // sized again.
  // A taking target that states its ladder (`takerLevels`, best first, each level already clearing the lane's edge)
  // is walked: its unit cost is the average over the levels the last pass's count reaches, the count is capped at
  // the ladder's depth, every level used must clear the minimum edge on its own fee, and the order's whole cost
  // stays inside the risk the allocator gave it. The order is one IOC at the worst level used.
  const lagHours = policy.sizing?.settlementLagHours ?? 12;
  const feeUnits = new Map(); // ticker -> fee per contract in sizing units at the last pass's count
  const walkCount = new Map(); // ticker -> contracts the last pass walked to
  const walks = new Map();     // ticker -> this pass's admitted walk
  const walking = (target) => target.execution === 'taker' && Array.isArray(target.takerLevels) && target.takerLevels.length > 0;
  let allocation, byId, opportunities, takerFailures = new Map();
  for (let pass = 0; pass < 6; pass += 1) {
    skips.length = baseSkips;
    lanes = viewLanes();
    opportunities = [];
    byId = new Map();
    for (const lane of lanes) {
      if (lane.failed) continue;
      for (const target of lane.targets) {
        if (lane.paused) continue;
        if (!target.verdict.ok) { skips.push({ lane: lane.id, ticker: target.ticker, reason: target.verdict.reason }); continue; }
        if (target.wholeCents === false) { skips.push({ lane: lane.id, ticker: target.ticker, reason: 'market not priced in whole cents' }); continue; }
        if (byId.has(target.ticker)) { skips.push({ lane: lane.id, ticker: target.ticker, reason: `also certified by ${byId.get(target.ticker).lane.id}, which holds it this cycle` }); continue; }
        const ask = target.bookSide === 'ask';
        const taking = target.execution === 'taker';
        const { event, date } = lane.correlationOf(target.ticker);
        const schedule = scheduleOfTarget(target);
        let unitCost, unitGain; // in sizing units, the fee in both
        if (walking(target)) {
          const walk = walkLadder({ bookSide: target.bookSide, levels: target.takerLevels, count: walkCount.get(target.ticker) ?? 1, schedule });
          unitCost = Math.ceil((walk.costCents + walk.feeCents) * U / walk.count);
          unitGain = Math.max(Math.floor((walk.gainCents - walk.feeCents) * U / walk.count), 0);
        } else {
          const fee = feeUnits.get(target.ticker) ?? feeUnitsPerContract({ execution: target.execution, count: null, priceCents: target.priceCents, schedule });
          unitCost = (ask ? 100 - target.priceCents : target.priceCents) * U + fee;
          unitGain = Math.max((ask ? target.priceCents : 100 - target.priceCents) * U - fee, 0);
        }
        const opportunity = {
          id: target.ticker, lane: lane.id, venue: 'kalshi', instrument: { venue: 'kalshi', id: target.ticker, kind: ask ? 'binary-no' : 'binary-yes' },
          side: ask ? 'no' : 'yes', priceCents: unitCost, payoffCents: unitGain,
          winProbability: target.opportunity.winProbability, settlesOn: target.targetDate, correlation: { event, date },
          capitalWeight: target.opportunity.capitalWeight ?? 1,
          probabilityEvidence: probabilityEvidenceOf(lane, target),
          heldRiskCents: (held.get(target.ticker) ?? 0),
          // A per-market collateral budget (target.maxRiskCents) less everything already held on the ticker.
          ...(Number.isFinite(target.maxRiskCents) ? { maxNewRiskCents: Math.max(0, target.maxRiskCents * U - (held.get(target.ticker) ?? 0)) } : {}),
          rankEdge: growthPerDay({ winProbability: target.opportunity.winProbability, costCents: unitCost / U, gainCents: unitGain / U, days: daysToSettle(target, now, lagHours) }),
        };
        if (opportunity.payoffCents < 1) { skips.push({ lane: lane.id, ticker: target.ticker, reason: `${taking ? 'taker' : 'maker'}: fee consumes the gain` }); continue; }
        opportunities.push(opportunity);
        byId.set(target.ticker, { lane, target });
      }
    }
    allocation = allocateOpportunities(allocationInput(opportunities));
    takerFailures = new Map();
    walks.clear();
    let moved = false;
    for (const order of allocation.orders) {
      const { lane, target } = byId.get(order.id);
      if (walking(target)) {
        const cfg = executionConfig(policy, lane.id);
        const schedule = scheduleOfTarget(target);
        const depth = target.takerLevels.reduce((sum, level) => sum + level.count, 0);
        const walkTo = (count) => admitWalk({ bookSide: target.bookSide, levels: target.takerLevels, count, winProbability: order.winProbability, minTakerEdgeCents: cfg.minTakerEdgeCents, schedule });
        const fits = (admitted) => (admitted.walk.costCents + admitted.walk.feeCents) * U <= order.riskCents;
        let admitted = walkTo(Math.min(order.count, depth));
        if (!admitted.ok) { takerFailures.set(order.id, admitted.reason); continue; }
        // The walk's whole cost (fee included) stays inside the risk the allocator sized, so no limit is crossed by a deeper level.
        while (admitted.ok && !fits(admitted) && admitted.walk.count > 1) admitted = walkTo(admitted.walk.count - 1);
        if (!admitted.ok || !fits(admitted)) { takerFailures.set(order.id, admitted.ok ? 'walk: one contract costs more than the sized risk' : admitted.reason); continue; }
        walks.set(order.id, admitted);
        if (admitted.walk.count !== (walkCount.get(order.id) ?? 1)) moved = true;
        walkCount.set(order.id, admitted.walk.count);
        continue;
      }
      const next = feeUnitsPerContract({ execution: target.execution, count: order.count, priceCents: target.priceCents, schedule: scheduleOfTarget(target) });
      if (next !== feeUnits.get(order.id)) moved = true;
      feeUnits.set(order.id, next);
      if (target.execution !== 'taker') continue;
      const cfg = executionConfig(policy, lane.id);
      const admitted = admitTaker({ bookSide: target.bookSide, takerPriceCents: target.priceCents, count: order.count, winProbability: order.winProbability, minTakerEdgeCents: cfg.minTakerEdgeCents, schedule: scheduleOfTarget(target) });
      if (!admitted.ok) takerFailures.set(order.id, admitted.reason);
    }
    if (takerFailures.size === 0 && !moved) break;
    if (takerFailures.size > 0 && pass < 5) for (const ticker of takerFailures.keys()) demoted.add(ticker);
    if (takerFailures.size === 0 && pass === 5) break;
  }
  for (const skip of allocation.skips) skips.push({ lane: byId.get(skip.id)?.lane.id ?? null, ticker: skip.id, reason: skip.reason, ...(skip.sizingBasis ? { sizingBasis: skip.sizingBasis, winProbability: skip.winProbability, edgePerContractCents: skip.marginalEdgeUnits / U } : {}) });

  // Every order leaves in whole cents: its price, its collateral and its exact whole-cent fee.
  const places = [];
  for (const order of allocation.orders) {
    const { lane, target } = byId.get(order.id);
    if (takerFailures.has(order.id)) { skips.push({ lane: lane.id, ticker: order.id, reason: `taker: ${takerFailures.get(order.id)}` }); continue; }
    const taking = target.execution === 'taker';
    const cfg = executionConfig(policy, lane.id);
    const schedule = scheduleOfTarget(target);
    const walked = walks.get(order.id) ?? null;
    if (walked) {
      const { walk, economics } = walked;
      places.push({
        lane: lane.id, ticker: order.id, eventTicker: target.eventTicker, targetDate: target.targetDate, seriesTicker: target.seriesTicker, closeTime: target.closeTime ?? null, settlementHorizon: settlementHorizon(target, now, lagHours),
        bookSide: target.bookSide, priceCents: walk.limitPriceCents, count: walk.count,
        riskCents: walk.costCents + walk.feeCents, gainCents: walk.gainCents - walk.feeCents,
        feeCents: walk.feeCents, edgeCents: economics.edgeCents, growthPerDay: order.edge, feeSchedule: schedule,
        edge: order.edge, winProbability: order.winProbability, kellyFraction: order.kellyFraction,
        execution: 'taker', takerFeeCents: walk.feeCents, takerEdgeCents: economics.edgeCents,
        bestPriceCents: target.takerLevels[0].priceCents, levels: walk.levels,
        detail: target.detail ?? null,
      });
      continue;
    }
    const admitted = taking
      ? admitTaker({ bookSide: target.bookSide, takerPriceCents: target.priceCents, count: order.count, winProbability: order.winProbability, minTakerEdgeCents: cfg.minTakerEdgeCents, schedule })
      : admitMaker({ bookSide: target.bookSide, priceCents: target.priceCents, count: order.count, winProbability: order.winProbability, schedule });
    if (!admitted.ok) { skips.push({ lane: lane.id, ticker: order.id, reason: `${taking ? 'taker' : 'maker'}: ${admitted.reason}` }); continue; }
    const { economics } = admitted;
    places.push({
      lane: lane.id, ticker: order.id, eventTicker: target.eventTicker, targetDate: target.targetDate, seriesTicker: target.seriesTicker, closeTime: target.closeTime ?? null, settlementHorizon: settlementHorizon(target, now, lagHours),
      bookSide: target.bookSide, priceCents: target.priceCents, count: order.count,
      riskCents: economics.costCents * order.count + economics.feeCents, gainCents: economics.gainCents * order.count - economics.feeCents,
      feeCents: economics.feeCents, edgeCents: economics.edgeCents, growthPerDay: order.edge, feeSchedule: schedule,
      edge: order.edge, winProbability: order.winProbability, kellyFraction: order.kellyFraction,
      execution: taking ? 'taker' : 'maker',
      ...(taking ? { takerFeeCents: economics.feeCents, takerEdgeCents: economics.edgeCents } : { makerFeeCents: economics.feeCents }),
      detail: target.detail ?? null,
    });
  }

  // Size the book would have taken that a limit refused (PF-5): each certified opportunity is sized again with
  // the limits lifted (its Kelly stake, capped at the ladder's depth when it walks one), and then with one limit
  // lifted at a time to name the limit that bound. Recorded, never acted on.
  const refusals = refusedSizes({ opportunities, byId, allocation, places, policy, allocationInput });

  // A shared game decision caps NEW capital on this venue; it does not replace
  // local certification, cancel unrelated positions, or grant execution authority.
  if (marketDecision) {
    for (let i = places.length - 1; i >= 0; i -= 1) {
      const order = places[i];
      const funded = allocationsFor(marketDecision, { venue: 'kalshi', principal, instrument: order.ticker, side: order.bookSide === 'ask' ? 'no' : 'yes', at: new Date(now).toISOString() });
      const cap = funded.length === 1 ? funded[0].capitalCents : 0;
      const unitRisk = collateralCents({ ...order, count: 1 });
      const sized = order.count;
      const originalOrder = { ...order, levels: order.levels?.map(level => ({ ...level })) };
      order.count = Math.min(order.count, Math.floor(cap / unitRisk), Math.floor(funded[0]?.units ?? 0));
      if (order.levels) order.levels = walkLadder({ bookSide: order.bookSide, levels: order.levels, count: order.count, schedule: order.feeSchedule }).levels;
      const cfg = executionConfig(policy, order.lane);
      const admission = Date.parse(order.closeTime)===Date.parse(marketDecision.horizon) && order.count > 0 && unitRisk / 100 <= funded[0].entryPrice && (order.execution !== 'taker' || admitTaker({ bookSide: order.bookSide, takerPriceCents: order.priceCents, count: order.count, winProbability: order.winProbability, minTakerEdgeCents: cfg.minTakerEdgeCents, schedule: order.feeSchedule }).ok);
      if (!admission || collateralCents(order) + orderFeeFor({ execution: order.execution, count: order.count, priceCents: order.priceCents, schedule: order.feeSchedule }) > cap) {
        places.splice(i, 1); skips.push({ lane: order.lane, ticker: order.ticker, reason: 'no admitted capital in the shared market decision' });
        refusals.push(sharedDecisionRefusal(originalOrder, sized, 0, cap));
      } else {
        if (order.count < sized) refusals.push(sharedDecisionRefusal(originalOrder, sized, order.count, cap));
        order.riskCents = collateralCents(order); order.marketDecision = marketDecision.id;
        const fee = orderFeeFor({ execution: order.execution, count: order.count, priceCents: order.priceCents, schedule: order.feeSchedule });
        order.feeCents = fee; order.riskCents += fee; order.gainCents = (100 - unitRisk) * order.count - fee;
        if (order.execution === 'taker') { const economics = admitTaker({ bookSide: order.bookSide, takerPriceCents: order.priceCents, count: order.count, winProbability: order.winProbability, minTakerEdgeCents: cfg.minTakerEdgeCents, schedule: order.feeSchedule }).economics; order.takerFeeCents = economics.feeCents; order.takerEdgeCents = economics.edgeCents; }
      }
    }
  }

  // A rejected source/certification/price also has a ledger row. Missing probabilities
  // and desired quantities remain unknown, rather than being reported as zero EV.
  const counted = new Set(refusals.map(row => `${row.lane}|${row.ticker}`));
  for (const skip of skips) {
    const key = `${skip.lane}|${skip.ticker}`;
    if (counted.has(key)) continue;
    const lane = lanes.find(row => row.id === skip.lane);
    const target = lane?.targets.find(row => row.ticker === skip.ticker);
    const sizedOrder = allocation.orders.find(row => row.id === skip.ticker);
    const count = sizedOrder?.count ?? target?.requestedCount ?? null;
    refusals.push(pricedRefusal({ lane: skip.lane, target: target ?? { ticker: skip.ticker }, reason: skip.reason, count }));
    counted.add(key);
  }

  // The shadow book: every certified opportunity this cycle, whether or not acted on.
  const placed = new Map(places.map((order) => [order.ticker, order]));
  const keptTickers = new Set(kept.map((order) => order.ticker));
  const skipReason = new Map(skips.filter((skip) => skip.ticker).map((skip) => [skip.ticker, skip.reason]));
  const shadow = [];
  for (const lane of surveyedLanes) {
    if (lane.failed) continue;
    for (const target of lane.targets) {
      if (!target.opportunity || !target.verdict.ok && !target.predictionEligible) continue;
      const order = placed.get(target.ticker);
      const wasTaker = lanes.find((l) => l.id === lane.id)?.targets.find((t) => t.ticker === target.ticker)?.execution === 'taker';
      shadow.push({
        lane: lane.id, ticker: target.ticker, eventTicker: target.eventTicker, seriesTicker: target.seriesTicker, closeTime: target.closeTime ?? null, targetDate: target.targetDate,
        cohort: target.opportunity?.cohort ?? target.detail?.cohort ?? null, detail: target.detail ?? null,
        capitalEligible: target.verdict.ok, predictionEligible: true,
        bookSide: target.bookSide, heldSide: target.bookSide === 'ask' ? 'no' : 'yes',
        makerPriceCents: kept.find(row => row.ticker === target.ticker && row.own !== false)?.priceCents ?? target.priceCents, takerPriceCents: canTakeAt(target.takerPriceCents) ? target.takerPriceCents : null,
        takerFeeCents1: canTakeAt(target.takerPriceCents) ? takerFeeCents(1, target.takerPriceCents, scheduleOfTarget(target)) : null,
        takerFeeCents10: canTakeAt(target.takerPriceCents) ? takerFeeCents(10, target.takerPriceCents, scheduleOfTarget(target)) : null,
        feeSchedule: scheduleOfTarget(target),
        winProbability: target.opportunity.winProbability, modelProbability: target.detail?.probability ?? null,
        marketPriorLossRate: target.detail?.marketPrior?.lossRate ?? null,
        mode: executionConfig(policy, lane.id).mode,
        action: !target.verdict.ok ? 'prediction-only' : order ? (order.execution === 'taker' ? 'take' : 'rest') : keptTickers.has(target.ticker) ? 'kept-resting' : wasTaker ? 'take-refused' : 'none',
        count: order?.count ?? null, reason: order ? null : skipReason.get(target.ticker) ?? null,
      });
    }
  }
  const capitalByLane = Object.fromEntries(Object.entries(allocation.laneCapital).map(([lane, units]) => [lane, Math.floor(units / U)]));
  // Joint sizing may want less on an instrument than an order of ours already rests there: shrink the order by amend,
  // which keeps its place in the queue, rather than leave it oversized until it lapses; cancel it when the sizing
  // wants none of it. Only an instrument certified and sized this cycle is shrunk: unread evidence is no evidence.
  // The excess is the instrument's, shared by every order of ours resting on it: the newest order is shrunk first
  // (Kalshi's order ids are time-ordered), so the oldest keeps its place, and the excess is spent as orders shrink.
  const desiredContingent = allocation?.portfolio?.desiredContingentRiskCents ?? null;
  const excessLeft = new Map(); // ticker -> cents still to take off
  if (desiredContingent) for (const lane of lanes) for (const order of [...(keptByLane.get(lane.id) ?? [])].sort((a, b) => String(b.orderId).localeCompare(String(a.orderId)))) {
    if (order.own === false || !(order.ticker in desiredContingent) || !byId.has(order.ticker)) continue;
    const desiredCents = desiredContingent[order.ticker] / U;
    const contingentCents = (allocation.portfolio.contingentRiskCents[order.ticker] ?? 0) / U;
    if (!excessLeft.has(order.ticker)) excessLeft.set(order.ticker, contingentCents - desiredCents);
    const target = byId.get(order.ticker).target;
    const fee = makerFeeCents(order.count, order.priceCents, scheduleOfTarget(target));
    const unit = collateralCents({ ...order, count: 1 }) + fee / order.count;
    const excess = excessLeft.get(order.ticker);
    if (!(unit > 0) || excess < unit) continue;
    const remaining = order.count - Math.min(order.count, Math.floor(excess / unit));
    excessLeft.set(order.ticker, excess - (order.count - remaining) * unit);
    const reason = `joint sizing wants ${(desiredCents / 100).toFixed(2)} USD here, ${(contingentCents / 100).toFixed(2)} USD is resting`;
    const refresh = amends.findIndex((a) => a.orderId === order.orderId);
    if (remaining <= 0) {
      if (refresh >= 0) amends.splice(refresh, 1);
      cancels.push({ ...order, lane: lane.id, reason });
      continue;
    }
    if (refresh >= 0) { amends[refresh].remaining = remaining; amends[refresh].reasons.push(reason); }
    else amends.push({ orderId: order.orderId, ticker: order.ticker, lane: lane.id, bookSide: order.bookSide ?? 'ask', priceCents: order.priceCents, filledCount: order.filledCount ?? 0, restingCount: order.count, remaining, reasons: [reason] });
  }

  // Withdrawals without a replacing order are also refusals at the original
  // submitted price and quantity. Retain unavailable current probabilities.
  for (const order of cancels) {
    if (places.some(row => row.ticker === order.ticker)) continue;
    const lane = lanes.find(row => row.id === order.lane);
    const target = lane?.targets.find(row => row.ticker === order.ticker);
    const withdrawal = pricedRefusal({ lane: order.lane, target: { ...target, ...order, execution: 'maker', fee: target?.fee, opportunity: target?.opportunity }, reason: order.reason, count: order.count, limit: 'withdrawal' });
    const existing = refusals.findIndex(row => row.lane === order.lane && row.ticker === order.ticker);
    if (existing < 0) refusals.push(withdrawal);
    else if (refusals[existing].refusedCount === null) refusals[existing] = withdrawal;
  }
  return { cancels, places, skips, capitalByLane, shadow, refusals, amends, queueRetention, portfolio: allocation.portfolio ?? null };
}

const round2 = (x) => Math.round(x * 100) / 100;

/** Exact post-fee batch expectation under the source probability. For a maker,
 * this is conditional on the batch filling, not an identified fill probability. */
function batchEconomics(target, count) {
  const p = target?.opportunity?.winProbability;
  const price = target?.execution === 'taker' ? target.takerPriceCents ?? target.priceCents : target?.priceCents;
  if (!Number.isSafeInteger(count) || count < 1 || !canTakeAt(price) ||
      !['ask', 'bid'].includes(target?.bookSide) || !Number.isFinite(p) || p < 0 || p > 1 || !target.fee) return null;
  if (target.execution === 'taker' && target.takerLevels?.length) {
    const walk = walkLadder({ bookSide: target.bookSide, levels: target.takerLevels, count, schedule: target.fee });
    if (walk.count !== count) return null;
    return { feeCents: walk.feeCents, expectedNetCents: p * walk.gainCents - (1 - p) * walk.costCents - walk.feeCents };
  }
  const unitCost = target.bookSide === 'ask' ? 100 - price : price;
  const feeCents = orderFeeFor({ execution: target.execution ?? 'maker', count, priceCents: price, schedule: target.fee });
  return { feeCents, expectedNetCents: count * (100 * p - unitCost) - feeCents };
}
function refusalEconomics(target, wantedCount, allocatedCount = 0) {
  const wanted = batchEconomics(target, wantedCount), funded = allocatedCount === 0 ? { expectedNetCents: 0, feeCents: 0 } : batchEconomics(target, allocatedCount);
  const one = batchEconomics(target, 1);
  return {
    edgePerContractCents: wanted ? round2(wanted.expectedNetCents / wantedCount) : one ? round2(one.expectedNetCents) : null,
    gainForgoneCents: wanted && funded ? round2(wanted.expectedNetCents - funded.expectedNetCents) : null,
    wantedFeeCents: wanted?.feeCents ?? null, fundedFeeCents: funded?.feeCents ?? null,
    expectationBasis: target.execution === 'taker' ? 'source probability and displayed full batch after exact scheduled fees; execution not guaranteed' : 'source marginal probability and exact scheduled fees conditional on full fill; maker fill selection unmeasured',
    unknownExpectation: !wanted || !funded,
  };
}
/** Refusal carrier used by all existing priced decisions, including pre-sizing
 * certification failures. Unknown size, model or fee is retained explicitly. */
export function pricedRefusal({ lane, target, reason, count = null, limit = 'certification-or-execution' }) {
  const economics = refusalEconomics(target, count);
  return { lane, ticker: target.ticker, eventTicker: target.eventTicker ?? null, targetDate: target.targetDate ?? null,
    bookSide: target.bookSide ?? null, execution: target.execution ?? null, priceCents: target.priceCents ?? null,
    limit, limits: [limit], reason, wantedCount: count, sizedCount: 0, placedCount: 0, refusedCount: count,
    winProbability: target.opportunity?.winProbability ?? null, ...economics };
}

/** The policy's limits as the allocator applies them, by the policy's own names. */
// A fraction lifted to 1 is the whole lane capital: no Kelly stake (at most the lane capital) is held below it.
const LIMITS = [
  { name: 'perEventFraction', lift: { limits: { perEventFraction: 1 } }, value: (policy) => policy.limits.perEventFraction },
  { name: 'perSettlementDateFraction', lift: { limits: { perDateFraction: 1 } }, value: (policy) => policy.limits.perSettlementDateFraction },
  { name: 'maxOpenFraction', lift: { limits: { maxOpenFraction: 1 } }, value: (policy) => policy.limits.maxOpenFraction },
  { name: 'freeCash', lift: { freeCashCents: 1e14 }, value: (policy) => ({ minCashUsd: policy.limits.minCashUsd }) },
];

/**
 * Refused size, one row per certified opportunity the limits held below its Kelly stake (or below the ladder's
 * depth, when that is smaller). `limit` is the limit whose lifting alone sizes it largest; `limits` every limit whose
 * lifting alone sizes it larger; when none does alone, they bound together and `limit` is `joint`.
 */
export function refusedSizes({ opportunities, byId, allocation, places, policy, allocationInput }) {
  if (!opportunities?.length) return [];
  const countOf = (result) => new Map(result.orders.map((order) => [order.id, order.count]));
  const sized = countOf(allocation);
  const placed = new Map(places.map((order) => [order.ticker, order.count]));
  const free = countOf(allocateOpportunities(allocationInput(opportunities, { limits: { perEventFraction: 1, perDateFraction: 1, maxOpenFraction: 1, lanes: {} }, freeCashCents: 1e14 })));
  const depthOf = (target) => (Array.isArray(target.takerLevels) && target.execution === 'taker' ? target.takerLevels.reduce((sum, level) => sum + level.count, 0) : Infinity);
  const refused = opportunities.filter((opportunity) => {
    const depth = depthOf(byId.get(opportunity.id).target);
    return Math.min(free.get(opportunity.id) ?? 0, depth) > Math.min(sized.get(opportunity.id) ?? 0, depth);
  });
  if (!refused.length) return [];
  const lifted = LIMITS.map((limit) => ({ limit, counts: countOf(allocateOpportunities(allocationInput(opportunities, limit.lift))) }));
  return refused.map((opportunity) => {
    const { lane, target } = byId.get(opportunity.id);
    const depth = depthOf(target);
    const allocated = Math.min(sized.get(opportunity.id) ?? 0, depth);
    const wantedCount = Math.min(free.get(opportunity.id), depth);
    const binding = lifted.map(({ limit, counts }) => ({ limit, count: Math.min(counts.get(opportunity.id) ?? 0, depth) })).filter((row) => row.count > allocated).sort((a, b) => b.count - a.count);
    const placedCount = placed.get(opportunity.id) ?? 0;
    const refusedCount = wantedCount - allocated;
    return {
      lane: lane.id, ticker: opportunity.id, eventTicker: target.eventTicker, targetDate: target.targetDate, bookSide: target.bookSide, execution: target.execution ?? null,
      limit: binding[0]?.limit.name ?? 'joint', limitValue: binding[0] ? binding[0].limit.value(policy) : null, limits: binding.map((row) => row.limit.name),
      wantedCount, sizedCount: allocated, placedCount, refusedCount,
      unitRiskCents: round2(opportunity.priceCents / U), unitGainCents: round2(opportunity.payoffCents / U), winProbability: opportunity.winProbability,
      ...refusalEconomics(target, wantedCount, allocated),
      reason: (allocation.skips.find((skip) => skip.id === opportunity.id)?.reason) ?? `sized ${allocated} of ${wantedCount}`,
    };
  });
}

function sharedDecisionRefusal(order, wantedCount, placedCount, capCents) {
  const unitRisk = collateralCents({ ...order, count: 1 });
  const economics = refusalEconomics({ ...order, opportunity: { winProbability: order.winProbability }, fee: order.feeSchedule, takerPriceCents: order.priceCents, takerLevels: order.levels }, wantedCount, placedCount);
  return {
    lane: order.lane, ticker: order.ticker, eventTicker: order.eventTicker, targetDate: order.targetDate, bookSide: order.bookSide, execution: order.execution,
    limit: 'shared-market-decision', limitValue: { capitalCents: capCents }, limits: ['shared-market-decision'],
    wantedCount, sizedCount: wantedCount, placedCount, refusedCount: wantedCount - placedCount,
    unitRiskCents: unitRisk, unitGainCents: 100 - unitRisk, winProbability: order.winProbability,
    ...economics,
    reason: placedCount ? `shared market decision funds ${placedCount} of ${wantedCount}` : 'no admitted capital in the shared market decision',
  };
}

/** Recheck the original funded cap immediately before the existing custody path. */
export function admitSharedDeskOrder({marketDecision,principal,order,at}){
 const funded=allocationsFor(marketDecision,{venue:'kalshi',principal,instrument:order.ticker,side:order.bookSide==='ask'?'no':'yes',at});
 const allocation=funded.length===1?funded[0]:null;
 const fees=orderFeeFor({execution:order.execution,count:order.count,priceCents:order.priceCents,schedule:order.feeSchedule??UNREAD_SCHEDULE});
 if(!Number.isSafeInteger(order.count)||order.count<1||!Number.isSafeInteger(order.priceCents)||order.priceCents<=0||order.priceCents>=100||!allocation||order.marketDecision!==marketDecision.id||Date.parse(order.closeTime)!==Date.parse(marketDecision.horizon)||order.count>Math.floor(allocation.units)||collateralCents(order)+fees>allocation.capitalCents||collateralCents({...order,count:1})/100>allocation.entryPrice)throw new TypeError('current-shared-Kalshi-allocation-required');
 return {decision:marketDecision.id,principal};
}

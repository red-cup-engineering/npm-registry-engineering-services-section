/**
 * The shadow book: every certified opportunity of every cycle, whether or not
 * the desk acted on it, appended to the day's desk-shadow log (data/logs/desk-shadow-logs/). It is
 * a record of what the desk could have done, scored after settlement by
 * src/shadow-score.mjs. Shadow evidence is hypothetical and is never live
 * evidence: no capital stood behind it.
 */
import { appendFileSync, mkdirSync, readFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { logDays } from '@red-cup-engineering/kalshi-services-section/seavt-log';
import { SHADOW_FEED, shadowFile } from './desk-layout.mjs';

export function appendShadow(dir, rows, at) {
  if (!rows?.length) return 0;
  const file = shadowFile(dir, at.slice(0, 10));
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  appendFileSync(file, rows.map((row) => `${JSON.stringify({ at, ...row })}\n`).join(''), { mode: 0o600 });
  return rows.length;
}

export function readShadow(dir, fromDate, toDate) {
  const files = logDays(dir, SHADOW_FEED).filter((day) => day >= fromDate && day <= toDate).map((day) => shadowFile(dir, day));
  return files.flatMap((f) => readFileSync(f, 'utf8').split('\n').filter(Boolean).flatMap((line) => { try { return [{ ...JSON.parse(line), originalShadowSha256: 'sha256:' + createHash('sha256').update(line).digest('hex') }]; } catch { return []; } }));
}

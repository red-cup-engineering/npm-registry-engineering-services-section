/**
 * Where the desk keeps what it writes, under the settlement's data root (machine state,
 * `~/.local/state/561-group/settlements/kalshi-services-section`), filed by tier and type:
 *
 *   data/logs/desk-ledger-logs/<date>.jsonl                       the append-only ledger
 *   data/logs/desk-shadow-logs/<date>.jsonl                       the shadow book
 *   data/records/desk-review-records/                            the daily reviews and the judgments in force
 *   data/state/desk-state/                                       arming, rest state, the cycle lease, pending order effect
 *   data/state/shadow-score-state/                               the scored cache and the scores
 *   data/state/nbm-guidance-state/, rain-guidance-state/         the guidance caches the lanes read
 *
 * The directory and file names come from the store layout; nothing
 * here joins them by hand. `dir` throughout is the data root, never one of these directories.
 */
import { join } from 'node:path';
import { logFile } from '@red-cup-engineering/semiotic-eavt-services-section/layout';
import { recordDirectory, stateDirectory } from '@red-cup-engineering/kalshi-services-section/data-layout';

export const LEDGER_FEED = 'desk-ledger';
export const SHADOW_FEED = 'desk-shadow';

/** The ledger's file for one UTC day. */
export const ledgerFile = (dir, day) => logFile(dir, LEDGER_FEED, day);
/** The shadow book's file for one UTC day. */
export const shadowFile = (dir, day) => logFile(dir, SHADOW_FEED, day);
/** The desk's own state directory. */
export const deskStateDirectory = (dir) => stateDirectory(dir, 'desk');
/** A file of the desk's own state. */
export const deskStatePath = (dir, name) => join(deskStateDirectory(dir), name);
/** A file of the shadow book's scoring state. */
export const shadowScorePath = (dir, name) => join(stateDirectory(dir, 'shadow-score'), name);
/** The directory the daily reviews are recorded in. */
export const reviewDirectory = (dir) => recordDirectory(dir, 'desk-review');
/** The directory a lane's station-guidance cache is kept in (`nbm`, `rain`). */
export const guidanceDirectory = (dir, kind) => stateDirectory(dir, `${kind}-guidance`);

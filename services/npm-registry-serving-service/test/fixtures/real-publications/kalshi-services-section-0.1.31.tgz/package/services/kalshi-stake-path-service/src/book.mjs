/**
 * Kalshi's one YES book, read from either side by the desk's lanes.
 *
 * The orderbook payload lists bid ladders on each leg: `yes_dollars` are YES
 * bids, `no_dollars` are NO bids, and a NO bid at q is a YES ask at 1 - q.
 * The desk's own resting orders are removed first so a lane prices against
 * what others offer, never against itself.
 */
const cents = (dollars) => Math.round(Number(dollars) * 100);

/**
 * Venue order side as the desk's existing YES-book bid/ask representation:
 *   buy YES  = sell NO  = YES bid
 *   sell YES = buy NO   = YES ask
 *
 * The venue may report book_side directly or action plus YES/NO side.
 * For SCIENTIFIC receipt custody, ambiguous/missing direction is null,
 * never assumed to mean 'buy YES'. This does not change how orders are
 * admitted or executed.
 */
export function bookSideOfVenueOrder(order){
 const explicit=['bid','ask'].includes(order?.book_side)?order.book_side:null;
 const direct=['bid','ask'].includes(order?.side)?order.side:null;
 const inferred=((order?.side==='yes'&&order?.action==='buy')||
   (order?.side==='no'&&order?.action==='sell'))?'bid':
   ((order?.side==='yes'&&order?.action==='sell')||
   (order?.side==='no'&&order?.action==='buy'))?'ask':null;
 const declared=[explicit,direct,inferred].filter(Boolean);
 if(!declared.length||declared.some(s=>s!==declared[0]))return null;
 return declared[0];
}


/**
 * @param {{yes_dollars?: [string,string][], no_dollars?: [string,string][]}} orderbook
 * @param {{bookSide?: "bid"|"ask", priceCents: number, count: number}[]} own the desk's resting orders on this market; a missing bookSide is an ask (the weather lane's sells).
 * @returns {{bestBidCents: number, bestAskCents: number|null}} bestBidCents is 0 when no one bids.
 */
export function competingBook(orderbook, own = []) {
  const ownYes = new Map(), ownNo = new Map();
  for (const order of own) {
    if ((order.bookSide ?? 'ask') === 'bid') ownYes.set(order.priceCents, (ownYes.get(order.priceCents) ?? 0) + order.count);
    else ownNo.set(100 - order.priceCents, (ownNo.get(100 - order.priceCents) ?? 0) + order.count);
  }
  const yesBids = (orderbook?.yes_dollars ?? []).map(([p, q]) => [cents(p), Number(q) - (ownYes.get(cents(p)) ?? 0)]).filter(([p, q]) => q > (ownYes.has(p) ? 0.005 : 0));
  const noBids = (orderbook?.no_dollars ?? []).map(([p, q]) => [cents(p), Number(q) - (ownNo.get(cents(p)) ?? 0)]).filter(([, q]) => q > 0.005);
  const bestBidCents = yesBids.reduce((best, [p]) => Math.max(best, p), 0);
  const bestNoBid = noBids.reduce((best, [p]) => Math.max(best, p), 0);
  return { bestBidCents, bestAskCents: bestNoBid > 0 ? 100 - bestNoBid : null };
}

/**
 * Where a post-only sell of YES rests: one cent inside the competing ask when
 * the spread leaves room, else joining it; never at or below the bid.
 * @returns {number|null} cents on the YES book
 */
export function restingAskCents({ bestBidCents, bestAskCents }) {
  if (bestAskCents === null) return null;
  const price = bestAskCents - bestBidCents >= 2 ? bestAskCents - 1 : bestAskCents;
  return price > bestBidCents ? price : null;
}

/**
 * Where a post-only buy of YES rests: one cent inside the competing bid when
 * the spread leaves room (at least two cents), else joining it; never at or
 * above the ask. With no ask there is nothing to cross, and it joins the bid.
 * @returns {number|null} cents on the YES book
 */
export function restingBidCents({ bestBidCents, bestAskCents }) {
  if (!(bestBidCents > 0)) return null;
  if (bestAskCents === null) return bestBidCents;
  const price = bestAskCents - bestBidCents >= 2 ? bestBidCents + 1 : bestBidCents;
  return price < bestAskCents ? price : null;
}

/**
 * The levels a taking order walks, best first, with the desk's own orders removed: the YES bids a sell of YES
 * hits (highest first) or the YES asks a buy lifts (lowest first; a NO bid at q is a YES ask at 100 - q).
 * Counts are whole contracts; a level left with none is dropped.
 * @param {"bid"|"ask"} bookSide the taking order's side on the YES book (`ask` sells YES)
 * @returns {{priceCents: number, count: number}[]}
 */
export function takerLadder(orderbook, own = [], bookSide) {
  const selling = bookSide === 'ask';
  const mine = new Map();
  for (const order of own) {
    if (((order.bookSide ?? 'ask') === 'bid') !== selling) continue; // only our orders on the leg being taken
    const key = selling ? order.priceCents : 100 - order.priceCents;
    mine.set(key, (mine.get(key) ?? 0) + order.count);
  }
  const leg = selling ? orderbook?.yes_dollars : orderbook?.no_dollars;
  const levels = new Map();
  for (const [p, q] of leg ?? []) {
    const key = cents(p);
    const count = Math.floor(Number(q) - (mine.get(key) ?? 0) + 1e-9);
    if (count >= 1) levels.set(key, (levels.get(key) ?? 0) + count);
  }
  return [...levels].map(([key, count]) => ({ priceCents: selling ? key : 100 - key, count }))
    .filter((level) => level.priceCents >= 1 && level.priceCents <= 99)
    .sort((a, b) => (selling ? b.priceCents - a.priceCents : a.priceCents - b.priceCents));
}

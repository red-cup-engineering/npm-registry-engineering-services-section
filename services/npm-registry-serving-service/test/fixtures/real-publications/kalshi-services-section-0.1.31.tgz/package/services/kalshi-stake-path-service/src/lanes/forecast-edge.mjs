import {marketSettlementTiming} from '@red-cup-engineering/kalshi-services-section/market-facts';
import {posteriorForTarget,calibratedTargetRisk,cohortOfTarget} from '../lane-posteriors.mjs';
/**
 * Lane `forecast-edge`: trade every Kalshi contract where the house knows the outcome better than the book,
 * on whichever side that knowledge pays, as soon as it pays.
 *
 * The lane holds no model of its own. Its probabilities come from two places, both the forecasting
 * service's:
 *   - the observation sweep, run inside the lane every cycle because it must be fast: for each open
 *     daily-temperature bracket on its station's current climate day, the day's readings so far
 *     (station-observations, read at each reading's precision) rule brackets out or in exactly
 *     (weather-evidence observedBracketBound). A bracket already ruled out still bid at 2c or more is
 *     sold to that bid; a tail already ruled in still offered under 98c is bought.
 *   - the forecast surface the weather engine writes each cycle (forecast-surface fuseForecast): the
 *     market's mid pooled with every model that settlement grading has admitted, clipped by structural
 *     bounds. Without an admitted model the surface equals the mid and nothing is certified.
 *
 * Certification is one rule for every source: the side's win probability (the surface's low bound for
 * YES, one minus its high bound for NO) beats the executable price plus Kalshi's taker fee on the series'
 * own schedule (src/fees.mjs) by `minEdge`; the desk charges each order's exact whole-cent fee.
 * Execution is the policy's (taking by default: a known outcome is worth most the moment it is known).
 * A certified target states the ladder a taking order may walk (`takerLevels`): every level on the side
 * taken, best first, that clears the same rule on its own price, so the desk takes past the best price
 * in one order while each level still pays (src/desk-plan.mjs).
 *
 * Evidence comes in through per-family adapters (EVIDENCE_ADAPTERS; the policy's `config.adapters`
 * chooses which run). Each reads its family's open contracts and the settlement source's partial evidence
 * and returns the contracts that evidence decides, plus the evidence it could not read this cycle. A new
 * family whose source reports before the close is a new adapter here, never a new lane. A station any of
 * whose sources failed this cycle is unread: nothing it would decide is certified, by the sweep or by the
 * surface, and the cycle records it.
 */
import { TEMPERATURE_MARKETS, eventDate, temperatureSeries } from '@red-cup-engineering/forecasting/temperature-market-model';
import { climateDate, observedExtremes, latestMetar, withMetar } from '@red-cup-engineering/forecasting/station-observations';
import { observedBracketBound } from '@red-cup-engineering/forecasting/weather-evidence';
import { latestClimateReport, withClimateReport } from '@red-cup-engineering/forecasting/climate-report';
import { readForecastSurface } from '@red-cup-engineering/forecasting/weather-engine';
import { feePerContract } from '@red-cup-engineering/forecasting/fees';
import { competingBook, restingAskCents, restingBidCents, takerLadder } from '../book.mjs';
import { feeScheduleOf, wholeCentMarket } from '../fees.mjs';

export const id = 'forecast-edge';

const seriesOf = (ticker) => ticker.slice(0, ticker.indexOf('-'));
const eventOf = (ticker) => ticker.slice(0, ticker.lastIndexOf('-'));
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
/**
 * A source read raced against the cycle's survey deadline (`surveyBy`, epoch ms): an answer after it is a failure
 * this cycle, so the station is unread and the cycle goes on to plan instead of waiting out each fetch's own timeout.
 */
export function beforeDeadline(promise, surveyBy) {
  if (!Number.isFinite(surveyBy)) return promise;
  let timer;
  const late = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('survey deadline passed before the source answered')), Math.max(0, surveyBy - Date.now())); timer.unref?.(); });
  return Promise.race([promise, late]).finally(() => clearTimeout(timer));
}

export const laneConfig = (policy) => ({ minEdge: 0, minPriceCents: 1, surfaceMaxAgeMinutes: 20, adapters: ['temperature'], ...(policy.lanes?.[id]?.config ?? {}) });

/**
 * Targets for one contract against its book: the side with the larger certified edge, or the reason none is.
 * @param {{ticker: string, eventTicker: string, seriesTicker: string, targetDate: string, closeTime: string, surface: {p: number, low: number, high: number, admitted: string[], structural: string[]}, feeMultiplier?: number, source: string}} row
 */
export function targetOf(row, orderbook, resting, config) {
  const own = resting.filter((order) => order.ticker === row.ticker);
  const book = competingBook(orderbook, own);
  const fee = (price) => feePerContract(price, { multiplier: row.fee?.multiplier ?? row.feeMultiplier ?? 1, feeType: row.fee?.feeType });
  const structural=Boolean(row.surface.structural?.length),cohort=cohortOfTarget(id,row);
  const posterior=posteriorForTarget(config,cohort);
  // Both YES and NO use the qualified lower/upper band, never the point estimate.
  // A broad band is not positive executable edge, however plausible its midpoint.
  const low=row.surface.low,high=row.surface.high;
  const qualified=structural||row.surface.admitted?.length>0;
  if(!Number.isFinite(low)||!Number.isFinite(high)||!Number.isFinite(row.surface.p)||low<0||high>1||low>high||row.surface.p<low||row.surface.p>high)return {ticker:row.ticker,eventTicker:row.eventTicker,verdict:{ok:false,reason:'invalid or contradictory source probability bounds'}};
  const sides = [];
  if (book.bestAskCents !== null && book.bestAskCents < 100) {
    const ask = book.bestAskCents / 100;
    const risk=calibratedTargetRisk({posterior,winProbability:low,riskCostCents:book.bestAskCents,feePerContractCents:fee(ask)*100,conditional:!structural});
    sides.push({bookSide:'bid',takerPriceCents:book.bestAskCents,priceCents:restingBidCents(book),...risk,edge:risk.winProbability-ask-fee(ask)});
  }
  if (book.bestBidCents >= config.minPriceCents) {
    const bid = book.bestBidCents / 100;
    const risk=calibratedTargetRisk({posterior,winProbability:1-high,riskCostCents:100-book.bestBidCents,feePerContractCents:fee(1-bid)*100,conditional:!structural});
    sides.push({bookSide:'ask',takerPriceCents:book.bestBidCents,priceCents:restingAskCents(book),...risk,edge:risk.winProbability-(1-bid)-fee(1-bid)});
  }
  const best = sides.sort((a, b) => b.edge - a.edge)[0];
  const base = { ticker: row.ticker, eventTicker: row.eventTicker, seriesTicker: row.seriesTicker, targetDate: row.targetDate, closeTime:row.closeTime,expectedExpirationTime:row.expectedExpirationTime??null,latestExpirationTime:row.latestExpirationTime??null,settlementTimerSeconds:row.settlementTimerSeconds??null,rulesHash:row.rulesHash??null,ruleKey:row.ruleKey??null,settlementSource:row.settlementSource??null, fee: row.fee, wholeCents: row.wholeCents };
  if (!best) return { ...base, verdict: { ok: false, reason: 'no price on either side' } };
  const retained={...base,bookSide:best.bookSide,priceCents:best.priceCents??best.takerPriceCents,takerPriceCents:best.takerPriceCents,opportunity:{kind:structural?'structural':'forecast',cohort,winProbability:qualified?best.winProbability:null,capitalWeight:(row.surface.capitalWeight??1)*best.capitalWeight},detail:{cohort,source:row.source,ruleKey:row.ruleKey??null,settlementSource:row.settlementSource??null,adapter:row.adapter??null,surface:row.surface,posterior,bands:{low:row.surface.low,high:row.surface.high},edgeCents:qualified?best.edge*100:null,
    ...(row.sourceSurfaceAt?{forecastProvenance:{sourceSurfaceAt:row.sourceSurfaceAt,modelEvidenceId:row.modelEvidenceId??null,indexSourceEvidenceId:row.indexSourceEvidenceId??null,indexLaw:row.indexLaw??null,modelSources:row.modelSources??[],retainedPreTarget:row.retainedPreTarget??false,qualificationCheckedAt:row.qualificationCheckedAt??null,retainedAgainstEvidenceId:row.retainedAgainstEvidenceId??null}}:{})}};
  if(!qualified)return {...retained,verdict:{ok:false,reason:'no independently qualified model or structural knowledge'}};
  if (!(best.edge > Math.max(0,config.minEdge??0))) return {...retained,predictionEligible:true,verdict:{ok:false,reason:`edge ${(best.edge*100).toFixed(2)}c is not strictly positive after the fee`}};
  // Every level on the side taken that clears the same rule at its own price, best first: the ladder a taking order walks.
  const levelEdge = (cents) => best.winProbability-(best.bookSide==='bid'?cents/100:1-cents/100)-fee(best.bookSide==='bid'?cents/100:1-cents/100);
  const takerLevels = [];
  for (const level of takerLadder(orderbook, own, best.bookSide)) { if (!(levelEdge(level.priceCents) > Math.max(0,config.minEdge??0))) break; takerLevels.push(level); }
  return {
    ...base, verdict: { ok: true, edge: best.edge }, bookSide: best.bookSide, priceCents: best.priceCents ?? best.takerPriceCents, takerPriceCents: best.takerPriceCents, takerLevels,
    opportunity:{...retained.opportunity,rankEdge:best.edge},
    detail:{...retained.detail,source:row.source, ...(row.adapter ? { adapter: row.adapter } : {}), ...(row.evidenceReadAt ? { evidenceReadAt: row.evidenceReadAt } : {}), surface: row.surface, probability: row.surface.p, edgeCents: best.edge * 100, label: `${best.bookSide === 'ask' ? 'sell' : 'buy'} YES p=${row.surface.p.toFixed(4)} [${low.toFixed(4)}, ${high.toFixed(4)}]` },
  };
}

/**
 * The observation sweep: every open bracket on its station's current climate day that the day's readings already decide.
 * Listings are read first (one call per series), then every station-day's readings at once: the sweep's worth is its speed.
 * Returns the decided rows and the station-days left unread: any of whose sources (observation history, latest METAR,
 * afternoon climate report when due) failed this cycle. An unread station-day decides nothing.
 */
export async function observationSweep({ client, now, ledger, dir, at, minEdge = 0, concurrency = 12, sources = { observedExtremes, latestMetar, latestClimateReport }, surveyBy = Infinity }) {
  const open = [];
  const unread = [];
  const late = (day, step) => {
    const key = `${day.station}/${day.date}`;
    if (!unread.some((row) => row.key === key)) unread.push({ adapter: 'temperature', key, station: day.station, date: day.date, sources: ['deadline'], details: [{ source: 'deadline', detail: `survey deadline passed before ${step}` }] });
  };
  for (const series of TEMPERATURE_MARKETS.series) {
    const today = climateDate(series.timeZone, now);
    // A series not listed before the deadline is unread: its station-day decides nothing, by the sweep or the surface.
    if (Date.now() >= surveyBy) { late({ station: series.station, date: today }, `listing ${series.seriesTicker}`); continue; }
    try {
      for (const m of await beforeDeadline(client.getMarkets({ series_ticker: series.seriesTicker, status: 'open' }, { deadlineAt: surveyBy }), surveyBy)) {
        if (eventDate(m.event_ticker) === today && ['less', 'greater', 'between'].includes(m.strike_type)) open.push({ series, today, m });
      }
    } catch (error) {
      ledger(dir, { at, lane: id, kind: 'error', step: 'markets', series: series.seriesTicker, code: error.code, detail: error.detail ?? error.message });
      const key = `${series.station}/${today}`;
      if (!unread.some(row => row.key === key)) unread.push({ adapter: 'temperature', key, station: series.station, date: today, sources: ['markets'], details: [{ source: 'markets', detail: error.detail ?? error.message }] });
    }
  }
  const days = [...new Map(open.map(({ series, today }) => [`${series.station}/${today}`, { station: series.station, date: today, timeZone: series.timeZone, site: series.climateReport.replace(/^CLI/u, '') }])).values()];
  // The observation API's history (15-35 minutes behind) plus each station's latest METAR (about 2.5 minutes behind),
  // whose tenths-of-a-degree reading and six-hour extremes are what usually decide a bracket first.
  const observed = new Map();
  for (let i = 0; i < days.length; i += concurrency) {
    await Promise.all(days.slice(i, i + concurrency).map(async (day) => {
      if (Date.now() >= surveyBy) { late(day, 'the station was read'); return; }
      // The afternoon climate report (about 5 PM local) states the official high and low so far: read it from 4 PM on.
      const afternoon = Number(new Intl.DateTimeFormat('en-US', { timeZone: day.timeZone, hour: 'numeric', hourCycle: 'h23' }).format(new Date(now))) >= 16;
      const failed = [];
      const read = (step, promise) => beforeDeadline(promise, surveyBy).catch((error) => { failed.push({ source: step, detail: error.message }); ledger(dir, { at, lane: id, kind: 'error', step, station: day.station, detail: error.message }); return null; });
      const [history, metar, report] = await Promise.all([
        read('observations', Promise.resolve().then(() => sources.observedExtremes({ station: day.station, date: day.date, timeZone: day.timeZone, now }))),
        read('metar', Promise.resolve().then(() => sources.latestMetar({ station: day.station }))),
        afternoon ? read('climate-report', Promise.resolve().then(() => sources.latestClimateReport({ site: day.site, date: day.date }))) : null,
      ]);
      const key = `${day.station}/${day.date}`;
      if (failed.length) { unread.push({ adapter: 'temperature', key, station: day.station, date: day.date, sources: failed.map((row) => row.source), details: failed }); return; }
      observed.set(key, withClimateReport(withMetar(history, metar), report));
    }));
  }
  const rows = [];
  for (const { series, today, m } of open) {
    const obs = observed.get(`${series.station}/${today}`);
    if (!obs?.count) continue;
    const { structural, bound } = observedBracketBound({ kind: series.kind, proxy: true, bracket: { strikeType: m.strike_type, floorStrike: m.floor_strike, capStrike: m.cap_strike } }, obs);
    if (!structural) continue;
    // Only a price on the wrong side of the known outcome is worth a book read: a ruled-out bracket still bid, a ruled-in tail still offered.
    const bid = Number(m.yes_bid_dollars), ask = Number(m.yes_ask_dollars);
    if (!(structural.high < 0.5 ? bid > structural.high + minEdge : ask > 0 && ask < structural.low - minEdge)) continue;
    rows.push({
      ticker: m.ticker, eventTicker: m.event_ticker, seriesTicker: series.seriesTicker, targetDate: today, closeTime: m.close_time, ...marketSettlementTiming(m), wholeCents: wholeCentMarket(m), source: 'observation-sweep', adapter: 'temperature', evidenceReadAt: at,
      surface: { p: (structural.low + structural.high) / 2, low: structural.low, high: structural.high, admitted: [], structural: [`observed-extreme-${series.kind}-bound`], boundF: bound, observationLatest: obs.latest, station: series.station },
    });
  }
  return { rows, unread };
}

/**
 * Evidence adapters, one per Kalshi series family whose settlement source reports partial evidence before the close.
 *   read(input) -> { rows, unread }: rows as the sweep's (each with `surface` bounds, `source`, `adapter`), and the
 *     evidence keys it could not read this cycle;
 *   evidenceKeyOf(row) -> the key a contract's evidence would come from (or null when the family does not cover it),
 *     so an unread key certifies nothing through the forecast surface either.
 * Only `temperature` exists: the CFO's CN-11 admits a further family after a shadow job and a graded record.
 */
export const EVIDENCE_ADAPTERS = Object.freeze({
  temperature: Object.freeze({
    id: 'temperature', family: 'daily-temperature', settlementSource: 'NWS Daily Climate Report (CLI)',
    read: (input) => observationSweep(input),
    evidenceKeyOf: (row) => {
      const station = row.station ?? row.surface?.station ?? temperatureSeries(row.seriesTicker ?? seriesOf(row.ticker))?.station;
      return station && row.targetDate ? `${station}/${row.targetDate}` : null;
    },
  }),
});

/** The adapters the policy names, in order; an unknown name is an error the survey records. */
export function adaptersOf(config, registry = EVIDENCE_ADAPTERS) {
  return (config.adapters ?? ['temperature']).map((name) => {
    if (!Object.hasOwn(registry, name)) throw new RangeError(`forecast-edge: no evidence adapter ${name}`);
    return registry[name];
  });
}

export function createLane({ policy, adapters: registry = EVIDENCE_ADAPTERS }) {
  const config = laneConfig(policy);
  const surveyed = new Map(); // ticker -> {event, date}, from this cycle's survey
  return {
    id,
    pausedFor: () => null,
    // Every temperature contract, plus whatever else the surface named this cycle.
    ownsTicker: (ticker) => Boolean(temperatureSeries(seriesOf(ticker))) || surveyed.has(ticker),
    correlationOf: (ticker) => surveyed.get(ticker) ?? { event: eventOf(ticker), date: eventDate(eventOf(ticker)) },
    async survey({ client, account, dir, ledger, at, now, surveyBy = Infinity }) {
      const adapters = adaptersOf(config, registry);
      const rows = new Map(), unread = [], byAdapter = {};
      const surface = await readForecastSurface({ now, maxAgeMs: config.surfaceMaxAgeMinutes * 60000 }).catch((error) => {
        ledger(dir, { at, lane: id, kind: 'error', step: 'surface', detail: error.message });
        return null;
      });
      const targets = [], bookRead = new Set();
      const readBook = async (row) => {
        surveyed.set(row.ticker, { event: row.eventTicker, date: row.targetDate ?? row.closeTime.slice(0, 10) });
        const unavailable = reason => ({ ticker: row.ticker, eventTicker: row.eventTicker, seriesTicker: row.seriesTicker, targetDate: row.targetDate, closeTime: row.closeTime, unread: true, verdict: { ok: false, reason } });
        if (Date.now() >= surveyBy) {
          targets.push(unavailable('survey deadline passed before its book was read'));
          return;
        }
        try {
          const orderbook = await beforeDeadline(client.getOrderbook(row.ticker, 10, { deadlineAt: surveyBy }), surveyBy);
          await pause(40);
          const fee = await beforeDeadline(feeScheduleOf(client, row.seriesTicker ?? seriesOf(row.ticker), { deadlineAt: surveyBy }), surveyBy);
          targets.push(targetOf({ ...row, fee }, orderbook, account.resting.filter((order) => order.own), config));
        } catch (error) {
          ledger(dir, { at, lane: id, kind: 'error', step: 'orderbook-or-fee', ticker: row.ticker, code: error.code, detail: error.message });
          targets.push(unavailable('book or fee unavailable before the survey deadline'));
        }
      };
      const surfaceRow = c => ({ ...c, source: 'forecast-surface', surface: { p: c.p, low: c.low, high: c.high, admitted: c.admitted, structural: c.structural, capitalWeight: c.capitalWeight } });
      // The existing hourly publisher has already received these source laws.
      // Do not spend the whole survey deadline on daily station discovery before
      // their five-minute closing windows. Timing orders source work, never odds.
      const hourly = (surface?.contracts ?? []).filter(c => c.family === 'hourly-temperature' && Date.parse(c.closeTime) > now)
        .sort((a, b) => Date.parse(a.closeTime) - Date.parse(b.closeTime) || a.ticker.localeCompare(b.ticker));
      for (const c of hourly) {
        const row = surfaceRow(c);
        rows.set(c.ticker, row);
        bookRead.add(c.ticker);
        if (!row.surface.admitted?.length && !row.surface.structural?.length) {
          surveyed.set(row.ticker, { event: row.eventTicker, date: row.targetDate ?? row.closeTime.slice(0, 10) });
          targets.push({ ticker: row.ticker, eventTicker: row.eventTicker, seriesTicker: row.seriesTicker, targetDate: row.targetDate, closeTime: row.closeTime, detail: { surface: row.surface }, verdict: { ok: false, reason: 'no independently qualified model or structural knowledge' } });
          continue;
        }
        await readBook(row);
      }
      for (const adapter of adapters) {
        try {
          const read = await beforeDeadline(Promise.resolve().then(() => adapter.read({ client, now, ledger, dir, at, minEdge: config.minEdge, surveyBy })), surveyBy);
          for (const row of read.rows) if (!rows.has(row.ticker)) rows.set(row.ticker, row);
          unread.push(...read.unread);
          byAdapter[adapter.id] = { rows: read.rows.length, unread: read.unread.length };
        } catch (error) {
          // A family whose evidence could not be read at all is unread whole: none of its contracts is certified this cycle.
          ledger(dir, { at, lane: id, kind: 'error', step: `adapter:${adapter.id}`, detail: error.message });
          unread.push({ adapter: adapter.id, key: '*', sources: ['adapter'], details: [{ source: 'adapter', detail: error.message }] });
          byAdapter[adapter.id] = { rows: 0, unread: '*', error: error.message };
        }
      }
      const unreadKeys = new Set(unread.map((row) => `${row.adapter}|${row.key}`));
      const unreadFor = (row) => adapters.find((adapter) => { const key = adapter.evidenceKeyOf(row); return key !== null && (unreadKeys.has(`${adapter.id}|${key}`) || unreadKeys.has(`${adapter.id}|*`)); }) ?? null;
      for (const c of surface?.contracts ?? []) if (!rows.has(c.ticker) && Date.parse(c.closeTime) > now) {
        const row = surfaceRow(c);
        const blocked = unreadFor(row);
        if (blocked) {
          surveyed.set(row.ticker, { event: row.eventTicker, date: row.targetDate ?? row.closeTime.slice(0, 10) });
          targets.push({ ticker: row.ticker, eventTicker: row.eventTicker, seriesTicker: row.seriesTicker, targetDate: row.targetDate, closeTime: row.closeTime, verdict: { ok: false, reason: `evidence unread this cycle: ${blocked.evidenceKeyOf(row)}` } });
          continue;
        }
        rows.set(c.ticker, row);
      }
      // Positions and resting orders of the desk stay surveyed so their orders are managed, not orphaned.
      for (const row of rows.values()) {
        if (bookRead.has(row.ticker)) continue;
        // Daily observation bounds still precede other daily surface models.
        // Unread books preserve resting orders; successful hourly reads survive
        // subsequent daily adapter failures or deadline exhaustion.
        await readBook(row);
      }
      return { targets, candidates: rows.size, swept: [...rows.values()].filter((row) => row.source === 'observation-sweep').length, surfaceAt: surface?.at ?? null, unread, adapters: byAdapter };
    },
  };
}

# Kalshi Stake Path Service

**This is the Kalshi services section's desk. It runs inside the section's
MetroPlat instance, as part of its operations and its ASSIST application
`kalshi.assist.561.group`** (see the section [README](../../README.md)). The
desk trades the accounts that their Persons connect through ASSIST, and it
reacts to the market and the weather as they change. It does not run as
per-account side processes on a clock. Today's `apps/kalshi-desk.mjs` node
jobs (one cycle a minute per account) are the arrangement being replaced.

The desk and its primitives ship in `@red-cup-engineering/kalshi-services-section`.
Its canonical client, account data layout, desk authority, order recovery,
liquidity incentives, fill calibration receipts and book provenance share that
one package boundary. Venue-neutral allocation remains with its existing supplier.

The Kalshi desk: several lanes of trading on the founder's Kalshi account, sized together, with the
latest daily review's judgments in force (`apps/kalshi-desk.mjs`, `apps/kalshi-desk-review.mjs`).

## The desk (live since 2026-10-03)

`apps/kalshi-desk.mjs` is the stake path running for real on the founder's Kalshi account:
several lanes of trading on one account, sized together by the venue-neutral allocator
(`mandate-portfolio-allocation-service` `allocateOpportunities`), under
`content/config/kalshi-desk-policy.json` with the latest daily review's judgments in force.

- **forecast-edge** (live): every contract the house knows better than the book -- brackets the
  day's observations already decide, and the forecast surface where a model is graded better
  than the mid -- taken as soon as it pays (`src/lanes/forecast-edge.mjs`).
  Evidence enters through per-family adapters (`EVIDENCE_ADAPTERS`; `temperature` is the only
  one); a new family is an adapter, not a lane. A station any of whose sources failed this cycle
  is unread: it certifies nothing, and the cycle row lists it (`unreadStations`). A certified
  target carries the ladder of price levels that each clear fee and margin, and the desk takes
  down it in one IOC order at the worst level used, inside the risk the allocator sized.
- **weather-tail-premium** (live): sell YES (hold NO) on daily-temperature brackets the
  house's fat-tailed NBM model puts at 1% or less (0.5% for lows) where the market itself asks
  5c or less -- the backtest's selection, out of sample 0 of 467 settled yes
  (`src/lanes/weather-tail-premium.mjs`; forecasting-service
  `data/records/2026-10-03-kalshi-temperature-tail-backtest/`). The weather rules are
  forecasting-service's (`src/temperature-tail-prediction.mjs`, `temperature-markets.json`
  `tails`): the threshold, the decision window, no tail on the side of an active NWS
  temperature hazard, and the per-settlement-day loss rate it is sized on. It rests a cent
  inside the ask for about twenty cycles, then sells to the bid if still certified after the fee.
- **daily-rain** (live): the rain market's long-shot bias at both ends, taken the day before
  (`src/lanes/daily-rain.mjs`; the weather side is forecasting-service `rain-market-model.mjs`
  `rainSide`, `rain-markets.json` `sides`).
- **published-series-favorites** (measured, paused): AAA gas and diesel favorites; queue depth
  makes a small bid unfillable. Re-measure with book depth before re-enabling.

**Admission is by the founder's criteria, not by sign-off** (`src/strategy-admission.mjs`,
`content/config/kalshi-strategy-criteria.json`, from the economics note of 2026-09-01): public
information only, no liability beyond the stake, risk capital only, an edge measured out of sample
and positive after the fee, and a named falsifier. Each lane's evidence is its `strategy` block in
`content/config/kalshi-lane-expectations.json`. A lane that meets every rule trades at its policy
fraction; one that does not is surveyed in shadow until it does; a lane the review falsifies, or its
own falsifier pauses, stays out.

**Weather and betting are separate.** Forecasting-service says what the weather will do (a
bracket's probability, whether it is a measured tail, a rain side, the loss rate). This service
says what a bet is worth at the price on offer: Kalshi's fee on each series' own schedule
(`src/fees.mjs`: the taker fee, and the maker fee where a series charges one), whole-cent prices
only, each order's fee rounded up to the cent once per order, sizing in hundredths of a cent so a
contract's share of that fee is not rounded away, and ranking by Kelly growth per day of stake
locked (`src/desk-plan.mjs`).

Sizing follows the growth policy (economics note 2026-09-01): the Kalshi balance is
walled-off, re-seedable risk capital, and a contract cannot owe beyond its cost. The
certified opportunities of a cycle are sized together, by joint Kelly over their outcomes net of
fees, at the policy's Kelly multiple (`sizing` in `content/config/kalshi-desk-policy.json`). A
tail's loss rate is counted per settlement day, not per market, because one day's tails share
their weather. The policy's `limits` cap one event and one date as fractions of the equity, and a
lane's own `limits` replace them for that lane.

### The improvement loop

Cold Red Gate's node clock runs three jobs from released code (cold-red-gate-host `deploy/jobs`; on Bare Cedar Fog until 2026-10-05):

- `kalshi-desk` every minute: `cycle --live`. Reads Kalshi's own balance, positions and
  orders first; halts if equity is under $5 or five of its own positions settled against it in 30 days;
  asks each lane for certified targets, appends every one to the shadow book, and acts only
  while armed. Orders expire on their own, so a stopped clock leaves nothing resting. A certified
  opportunity a limit held below its Kelly stake (or the book's depth) gets a `refused-size`
  ledger row: the limit that bound, the size refused, the expected gain forgone.
- `kalshi-desk-shadow-score` hourly: grades the shadow book against settled public data
  (`scripts/shadow-score.mjs`).
- `kalshi-desk-review` daily: measures each lane's live record against its backtest
  expectation (`content/config/kalshi-lane-expectations.json`; exact binomial falsifiers),
  and writes `data/records/desk-review-records/judgments.json`. The desk trades those judgments from its next cycle, with
  the criteria admission applied over them: a falsified lane drops to 0 and stays there until its
  base policy changes; shadow evidence can only lower a lane; a lane with positive live evidence
  moves toward its Kelly share. The repository policy is the base, never rewritten. The
  digest reports each lane's refused size by limit (live cycles only).

`status`, `arm <by>`, `halt [reason]`. Arming is the founder's act. State, the append-only
ledger, the shadow book and the reviews are machine state (`~/.local/state/561-group/
settlements/kalshi-services-section/data/{logs,records,state}`, filed by type: `desk-ledger-logs`, `desk-shadow-logs`, `desk-review-records`, `desk-state`, `shadow-score-state`; see `src/desk-layout.mjs`), never the repository. The key:
kalshi-services-section `provision-kalshi-api-key` (an Ed25519 pair made on the node; the
founder registers only the public half).

Kalshi's `balance` does not set aside a resting order's collateral, so equity is cash plus
positions, and only cash beyond resting collateral is spent.

## Retired: the stake CLI pipeline (2026-10-06)

`apps/kalshi-stake-cli.mjs` and its five steps (derive-stake-intent, check-stake-mandate,
place-stake-order, reconcile-stake-fill, halt-stake-envelope), with the authority envelope that
the tests rewrote in `data/state/`, were removed. The desk replaced them on 2026-10-03, and nothing
imported them. A principal contract and a revocable grant (pluggable-venue-adapter-service `./kalshi`)
are the venue authority chain for when the principal's acceptance has a channel that reaches them.

## Tests

`node --test test/*.test.mjs`: the desk's cycle, lanes, review and execution.


## Read-only maker-fill receipt receiving (2026-10-12)

The existing stake-path service exports fill-calibration-receipts.mjs,
a pure join over OWNED desk placement ledger rows, full exchange
order-terminal records, identified fills and final source-bound
market outcomes. It only produces the exact one-contract input
needed by the upstream shared fitBinaryOutcomeFillByDay method;
this does not create a new venue collector, order path or journal.

Receiver input shape:

    joinKalshiFillCalibrationReceipts({
      ledgerEntries, orders, fills, markets, at,
      familyScope, quoteRegime, side,
      observationHorizonMs,
      fillCoverage:{from,through,complete:true},
      settlementCoverage:{from,through,complete:true}
    })

Both complete coverage claims must come from independently verified,
fully paginated source retrieval; they are NOT magically authenticated
by passing complete:true in a JSON file. The original desk
placement must cite an actual book receipt, its acquisition timestamp,
familyScope and quoteRegime as known BEFORE placing the order.
The venue order, client ID, side, post-only status, one-lot
count, terminal timestamp and fully reconciled trade IDs must agree.
No-fill requires a terminal order that survived the entire declared
horizon; early cancellations are censored, not failures to fill.
Any partial, multi-lot, resting, ambiguous, still-provisional,
post-settlement or source-mismatched record is withheld. A
settlement publication timestamp is an independent source-receipt
clock, not the market's effective date or settlement timestamp.

The desk's ordinary survey path now captures the actual YES/NO bid
book and named Kalshi market rules with their response-completion times,
keyed by BOTH lane and ticker. This wrapper returns the exact same
provider responses to each existing lane and does not change pricing
or strategy selection. On a new maker order intent, the existing desk
ledger now records a source-addressed 'book-evidence' entry containing
the actual book and contemporaneous rule snapshot BEFORE order
dispatch, with the original book ID and receipt time, source population,
quote regime and issuance time on the existing order-intent and
subsequent 'place' row. The same source book is mirrored into the
existing MetroPlat desk one-log when available; the order intent
cites its book-evidence event as a causal predecessor. This semantic
write is non-blocking, while the original ledger receipt is fsynced
before dispatch. No new storage service or timer is introduced.

The original source/venue semantics are derived only when the actual
listed rule is recognized: currently AAA regular-gasoline markets use
the existing forecasting AAA rule interpreter, with a stable
series/issuer/geographic-population key. Their observed quote regime
records maker YES/NO, the price in cents, displayed same-price book
depth band and the desk's actual order TTL. It does NOT claim to know
a trader's exact FIFO queue position. For other source families the
book/rules remain archived but originalFamilyScope and originalQuoteRegime
remain null until an independently justified source interpreter exists.

The read-only join now refuses any receipt ID not backed by matching
actual book-evidence bytes in that SAME desk ledger. It recomputes the
original SHA256 receipt, checks the market rules receipt, selected
lane and ticker, ordered source/read/intent clocks, original quote
cohort and target settlement date, and verifies that the later
final market's rules match those observed before the order. Kalshi
buy/sell/YES/NO is normalized via the existing book module; conflicting
economic side declarations are withheld. Tests also exercise a NO
position bought by selling YES.

Important HISTORICAL receiving limit: previous desk 'place' JSONL
rows lack those original book and contract-rule observations.
The exchange cannot reconstruct what the desk saw earlier, and this
change must not backfill unrecorded past information. Even NEW
journal entries remain research-only until the installed host is
confirmed to have deployed this source revision. Source-family
consistency across different methodology versions, complete query
pagination, final publisher availability stamps, exact venue order
response fields and independent day-block skill must still be
verified by separate receivers. The existing Kalshi client already
exposes read-only getOrders, getFills, getSettlements and getMarket
methods; this pure join DOES NOT call them or issue orders.

The tests include a cross-service case showing that a joined
one-contract terminal order feeds the existing shared day-block
hazard fitter but one day still produces no admissible calibration.
No new active trading, extra scheduled task or exchange order
was caused by this implementation.

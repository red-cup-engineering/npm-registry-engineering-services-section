/** Once-read financial evidence for the existing desk cycle and review.
 * No new journal, scheduler, order operation or account-wide ownership guess.
 * A caller shares this context; missing receipts remain explicit unknowns. */
import {isDeepStrictEqual} from 'node:util';
import {reconcileKalshiDeskOrderOutcomes,reconcileKalshiDeskUnfilledOrders} from '@red-cup-engineering/kalshi-services-section/settlement-accounting';
const time=x=>typeof x==='string'&&Number.isFinite(Date.parse(x));
const named=x=>typeof x==='string'&&x.length>0;
const kd=x=>typeof x==='string'&&x.startsWith('kd-');
const keyOf=p=>p.orderId+'|'+p.clientOrderId;
const receivedContexts=new WeakSet();
const freezeOutcome=row=>Object.freeze({...row,sourceIds:Object.freeze([...row.sourceIds]),...(row.fillIds?{fillIds:Object.freeze([...row.fillIds])}:{})});

/** Join an original issued intent to an original venue acknowledgment.
 * The projection does not replace or write a synthetic ledger placement. */
function placementsOf(ledgerEntries,account,intents,unknown){
 const placed=new Map(),issued=new Map(),acks=[],invalidOrders=new Set(),invalidClients=new Set();
 for(const group of [ledgerEntries,intents])for(const row of group){
  const record=row.record??row;
  if(row.kind==='place'&&kd(row.clientOrderId)&&named(row.orderId)&&named(row.lane)){
   const key=keyOf(row),prior=placed.get(key);
   if(prior&&(prior.ticker!==row.ticker||prior.lane!==row.lane||prior.bookSide!==row.bookSide))invalidOrders.add(row.orderId);
   else if(!prior)placed.set(key,row);
  }
  if((row.kind==='order-intent'||row.category==='order-intent')&&kd(record.clientOrderId)&&named(record.lane)){
   const prior=issued.get(record.clientOrderId);
   if(prior&&(prior.ticker!==record.ticker||prior.lane!==record.lane||prior.bookSide!==record.bookSide))invalidClients.add(record.clientOrderId);
   else if(!prior)issued.set(record.clientOrderId,record);
  }
  if(['place-acknowledged','place-recovered'].includes(row.kind)&&kd(row.clientOrderId)&&named(row.orderId))acks.push(row);
 }
 for(const order of account?.resting??[])if(order.own===true&&kd(order.clientOrderId))acks.push(order);
 for(const ack of acks){
  const intent=issued.get(ack.clientOrderId),key=keyOf(ack);
  if(placed.has(key))continue;
  if(invalidClients.has(ack.clientOrderId)||!intent||intent.ticker!==ack.ticker||!['bid','ask'].includes(intent.bookSide)||!time(intent.observedAt??intent.at)){
   unknown.push({orderId:ack.orderId,ticker:ack.ticker,reason:'original kd acknowledgment lacks an original scoped issued intent'});continue;
  }
  placed.set(key,{...intent,orderId:ack.orderId,at:intent.observedAt??intent.at,orderIntentAt:intent.observedAt??intent.at,
   placementBasis:'original issued intent joined to exact venue order/client acknowledgment',
   ...(ack.ack?{filled:ack.ack.fill_count_fp??ack.ack.fill_count}:{}),
   sourceIdentityRefs:[ack.orderId,ack.clientOrderId]});
 }
 const identities=new Map(),conflicts=new Set(invalidOrders);
 for(const p of placed.values()){
  const prior=identities.get(p.orderId);
  if(prior&&(prior.clientOrderId!==p.clientOrderId||prior.ticker!==p.ticker||prior.lane!==p.lane||prior.bookSide!==p.bookSide))conflicts.add(p.orderId);
  else identities.set(p.orderId,p);
 }
 for(const id of conflicts){identities.delete(id);unknown.push({orderId:id,reason:'conflicting original kd placement identities'});}
 return [...identities.values()];
}
function mergeFills(groups,unknown){
 const byId=new Map(),conflicts=new Set();
 for(const rows of groups)for(const row of rows??[]){
  const id=row.fill_id??row.trade_id;if(!named(id)){unknown.push({reason:'fill missing original identity'});continue;}
  const prior=byId.get(id);
  if(prior&&!isDeepStrictEqual(prior,row))conflicts.add(id);else byId.set(id,row);
 }
 for(const id of conflicts){byId.delete(id);unknown.push({fillId:id,reason:'conflicting original fill readings'});}
 return [...byId.values()];
}

/** Caller supplies any already collected fill/account/history receipts. This
 * function never issues a second getFills or private read for manual tickers.
 * Intent/ack joins are exposed as placements for the caller's typed projection.
 * `at` is the real clock AFTER source bodies have been received. */
export async function collectDeskAccountingContext({
 client,ledgerEntries=[],intents=[],account=null,existingContext=null,
 fills=null,knownDeskOutcomes=[],readStart=null,includeTerminalUnfilled=false,
 maxTickers=8,maxPages=10,receiptClock=()=>new Date().toISOString(),
}={}){
 const reused=existingContext&&receivedContexts.has(existingContext)?existingContext:null;
 readStart??=reused?.readStart??new Date().toISOString();
 if(!client||typeof client.call!=='function'||typeof client.getAccountingHistory!=='function'||
    !Array.isArray(ledgerEntries)||!Array.isArray(intents)||!Array.isArray(knownDeskOutcomes)||
    (fills!==null&&!Array.isArray(fills))||!time(readStart)||
    !Number.isInteger(maxTickers)||maxTickers<1||maxTickers>64||
    !Number.isInteger(maxPages)||maxPages<1||maxPages>500||typeof receiptClock!=='function'||typeof includeTerminalUnfilled!=='boolean')
  throw new TypeError('bounded original desk accounting inputs and native readers required');
 const unknown=[],placements=placementsOf(ledgerEntries,account,intents,unknown),byId=new Map(placements.map(p=>[p.orderId,p]));
 if(existingContext&&!reused)unknown.push({reason:'external context lacks collector-owned original custody'});
 if(knownDeskOutcomes.length)unknown.push({reason:'bare outcome flags/hash strings cannot qualify original financial custody'});
 const accountingReadings=[...(reused?.accountingReadings??[])],marketReadings=[...(reused?.marketReadings??[])];
 const originalFills=mergeFills([fills??reused?.fills??[],...accountingReadings.map(r=>r.fills)],unknown);
 const qualified=new Map(),unfilled=new Map((reused?.unfilledOrders??[]).map(row=>[row.orderId,row]));
 for(const row of reused?.deskOutcomes??[]){
  const p=byId.get(row.orderId);
  if(p&&p.clientOrderId===row.clientOrderId&&p.ticker===row.ticker&&p.lane===row.lane&&row.completeOrderFills===true&&Array.isArray(row.sourceIds)&&row.sourceIds.length>0&&row.sourceIds.every(id=>typeof id==='string'&&/^sha256:[a-f0-9]{64}$/u.test(id)))qualified.set(row.orderId,row);
 }
 const observedFilled=new Set(originalFills.filter(f=>{
  const p=byId.get(f.order_id);
  return p&&p.ticker===f.ticker&&(f.client_order_id===undefined||f.client_order_id===p.clientOrderId)&&Number(f.count_fp)>0;
 }).map(f=>f.order_id));
 for(const p of placements)if(Number(p.filled)>0)observedFilled.add(p.orderId);
 for(const order of account?.resting??[])if(order.own&&Number(order.filledCount)>0&&byId.has(order.orderId))observedFilled.add(order.orderId);
 const candidates=new Map();
 for(const p of placements){
  if(qualified.has(p.orderId)||unfilled.has(p.orderId))continue;
  const paid=(account?.settlements??[]).some(row=>row.ticker===p.ticker&&['yes','no'].includes(row.market_result)&&time(row.settled_time)&&Date.parse(row.settled_time)<=Date.parse(readStart));
  const close=time(p.closeTime)?Date.parse(p.closeTime):null;
  if(!paid&&close!==null&&close>Date.parse(readStart)){unknown.push({orderId:p.orderId,ticker:p.ticker,reason:'original contract close is still future; financial outcome remains pending'});continue;}
  if(!observedFilled.has(p.orderId)&&!(includeTerminalUnfilled&&(paid||close!==null&&close<=Date.parse(readStart)))){
   unknown.push({orderId:p.orderId,ticker:p.ticker,reason:'no original matched fill receipt yet; missing fills do not establish terminal no-fill'});continue;
  }
  if(!time(p.orderIntentAt??p.at)||Date.parse(p.orderIntentAt??p.at)>=Date.parse(readStart)){
   unknown.push({orderId:p.orderId,ticker:p.ticker,reason:'original issue clock unavailable or outside bounded reading'});continue;
  }
  const group=candidates.get(p.ticker)??[];group.push(p);candidates.set(p.ticker,group);
 }
 const selected=[...candidates.entries()].slice(0,maxTickers),pendingTickers=[...candidates.keys()].slice(maxTickers);
 for(const ticker of pendingTickers)unknown.push({ticker,reason:'accounting ticker bound reached; continuation remains pending'});
 for(const [ticker] of selected){
  const issued=placements.filter(p=>p.ticker===ticker),stamps=issued.map(p=>p.orderIntentAt??p.at);
  if(stamps.some(x=>!time(x))){unknown.push({ticker,reason:'complete original issued-order clocks unavailable'});continue;}
  const from=new Date(Math.min(...stamps.map(Date.parse))-1000).toISOString();
  try{
   const needsFilledOutcome=issued.some(p=>observedFilled.has(p.orderId)&&!qualified.has(p.orderId));
   let marketReading=marketReadings.find(p=>p.market?.ticker===ticker);
   if(needsFilledOutcome&&!marketReading){marketReading=Object.freeze(await client.call('GET','/markets/'+ticker,{signed:false,retainOriginal:true}));marketReadings.push(marketReading);}
   if(needsFilledOutcome&&!['settled','finalized'].includes(marketReading?.market?.status)&&!includeTerminalUnfilled){unknown.push({ticker,reason:'market has no final outcome yet'});continue;}
   let history=accountingReadings.find(r=>r.ticker===ticker&&r.subaccount===0&&Date.parse(r.from)<=Date.parse(from)&&Date.parse(r.to)>=Date.parse(readStart));
   if(!history){history=await client.getAccountingHistory({ticker,subaccount:0,from,to:readStart,maxPages});accountingReadings.push(history);}
   let at=receiptClock();if(!time(at))throw new TypeError('actual post-read financial clock required');
   const zeros=reconcileKalshiDeskUnfilledOrders({history,placements:issued,at});
   for(const row of zeros.unfilledOrders)unfilled.set(row.orderId,freezeOutcome(row));
   unknown.push(...zeros.withheld.map(row=>({...row,ticker})));
   const matchedExecuted=history.fills.some(f=>byId.has(f.order_id)&&Number(f.count_fp)>0);
   if(!matchedExecuted)continue;
   if(!marketReading){marketReading=Object.freeze(await client.call('GET','/markets/'+ticker,{signed:false,retainOriginal:true}));marketReadings.push(marketReading);}
   if(!['settled','finalized'].includes(marketReading.market?.status)){unknown.push({ticker,reason:'market has no final outcome yet'});continue;}
   at=receiptClock();
   const proof=reconcileKalshiDeskOrderOutcomes({history,marketReading,placements:issued,at});
   for(const row of proof.rows)qualified.set(row.orderId,freezeOutcome(row));
   unknown.push(...proof.withheld.map(row=>({...row,ticker})));
  }catch(error){unknown.push({ticker,reason:error.code??error.message});}
 }
 const at=receiptClock();if(!time(at)||Date.parse(at)<Date.parse(readStart))throw new TypeError('actual post-read financial clock required');
 const context=Object.freeze({type:'KalshiDeskAccountingContext',readStart,at,placements,
  accountingReadings:Object.freeze(accountingReadings),marketReadings:Object.freeze(marketReadings),deskOutcomes:Object.freeze([...qualified.values()]),unfilledOrders:Object.freeze([...unfilled.values()]),
  fills:mergeFills([originalFills,...accountingReadings.map(r=>r.fills)],unknown),
  coverage:{originalFillReadingSupplied:fills!==null||Array.isArray(reused?.fills),knownKdOrders:placements.length,
   observedFilledKdOrders:observedFilled.size,requestedTickers:selected.map(([ticker])=>ticker),pendingTickers,
   qualifiedFilledOrders:qualified.size,qualifiedUnfilledOrders:unfilled.size,complete:unknown.length===0},unknown,orderEffect:false});
 receivedContexts.add(context);return context;
}

import {Buffer} from 'node:buffer';
import {createHash} from 'node:crypto';
import {collectKalshiAccountingHistory} from '@red-cup-engineering/kalshi-services-section/accounting-history';
import {feed} from '@red-cup-engineering/kalshi-services-section/feed';
const SOURCE_BYTES=64*1048576,BODY_BYTES=16*1048576;
const shaOf=bytes=>'sha256:'+createHash('sha256').update(bytes).digest('hex');
const queryKey=query=>JSON.stringify(Object.fromEntries(Object.entries(query??{}).sort(([a],[b])=>a.localeCompare(b))));
function sourceAddress(page,path){
 const uri=new URL(page.originalUrl),base=new URL(feed.base);
 if(uri.origin!==base.origin||uri.pathname!==base.pathname+path)throw new TypeError('original production financial source address required');
 for(const [key,value] of Object.entries(page.query??{}))if(uri.searchParams.get(key)!==String(value))throw new TypeError('original financial source query mismatch');
}
function packPage(page,budget){
 const bytes=page.bytes??page.originalBytes,sha=page.sha256??page.originalSha256;
 const path=page.path??new URL(page.originalUrl).pathname.slice(new URL(feed.base).pathname.length);
 if(!(bytes instanceof Uint8Array)||bytes.byteLength<2||bytes.byteLength>BODY_BYTES||!time(page.receivedAt)||sha!==shaOf(bytes))throw new TypeError('intact original financial source body required');
 sourceAddress(page,path);budget.bytes+=bytes.byteLength;
 if(budget.bytes>SOURCE_BYTES)throw new RangeError('financial source custody exceeds the existing 64 MiB bound');
 return {path,query:structuredClone(page.query??{}),sha256:sha,originalUrl:page.originalUrl,receivedAt:page.receivedAt,bodyBase64:Buffer.from(bytes).toString('base64')};
}
function unpackPage(page,budget,at){
 const encoded=page?.bodyBase64;
 if(typeof encoded!=='string'||encoded.length>Math.ceil(BODY_BYTES/3)*4||encoded.length%4!==0||!/^[A-Za-z0-9+/]*={0,2}$/u.test(encoded)||!time(page.receivedAt)||Date.parse(page.receivedAt)>Date.parse(at))throw new TypeError('bounded original financial body and receipt clock required');
 const bytes=Buffer.from(encoded,'base64');
 if(bytes.byteLength<2||bytes.byteLength>BODY_BYTES||bytes.toString('base64')!==encoded||shaOf(bytes)!==page.sha256)throw new TypeError('original financial body encoding or digest differs');
 budget.bytes+=bytes.byteLength;if(budget.bytes>SOURCE_BYTES)throw new RangeError('financial source custody exceeds the existing 64 MiB bound');
 sourceAddress(page,page.path);
 const parsed=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 return {...parsed,originalBytes:bytes,originalSha256:page.sha256,originalUrl:page.originalUrl,receivedAt:page.receivedAt};
}

/** The EXISTING private review record carries genuine source bodies, not
 * self-certified outcome flags or a separate accounting store. Parsed venue
 * populations and outcomes are deliberately reconstructed from these bytes. */
export function serializeDeskAccountingContext(context){
 if(!receivedContexts.has(context))throw new TypeError('collector-owned financial context required');
 if(context.accountingReadings.length>64||context.marketReadings.length>64||context.placements.length>100000)throw new RangeError('existing financial source population bound exceeded');
 const budget={bytes:0};
 const accountingReadings=context.accountingReadings.map(history=>{
  if(history.originalPages.length>2500||history.originalCutoffPages?.length!==2)throw new TypeError('complete original financial pages and both cutoff bodies required');
  return {ticker:history.ticker,subaccount:history.subaccount,from:history.from,to:history.to,
   originalPages:history.originalPages.map(page=>packPage(page,budget)),originalCutoffPages:history.originalCutoffPages.map(page=>packPage(page,budget))};
 });
 return {type:'KalshiDeskAccountingSourceReceipts',version:1,readStart:context.readStart,at:context.at,
  placements:structuredClone(context.placements),accountingReadings,marketReadings:context.marketReadings.map(page=>packPage(page,budget)),
  unknown:structuredClone(context.unknown),sourceByteCount:budget.bytes,scope:'original private review source receipts; no fresh venue observation or account cash reconciliation'};
}

/** Deterministic receipt receiving: NO I/O. The existing historical collector
 * reads finite ORIGINAL source packets to revalidate route selection, cursor
 * exhaustion, archive boundaries and population identity. Financial proofs
 * are then recomputed at their original post-read clock. `restoredAt` records
 * local receiving only; it does not turn old evidence into fresh market data. */
export async function restoreDeskAccountingContext(source,{at=source?.at}={}){
 if(source?.type!=='KalshiDeskAccountingSourceReceipts'||source.version!==1||!time(source.readStart)||!time(source.at)||!time(at)||Date.parse(source.readStart)>Date.parse(source.at)||Date.parse(at)<Date.parse(source.at)||
    !Array.isArray(source.placements)||source.placements.length>100000||!Array.isArray(source.accountingReadings)||source.accountingReadings.length>64||!Array.isArray(source.marketReadings)||source.marketReadings.length>64)
  throw new TypeError('bounded original private review source receipt required');
 const budget={bytes:0},accountingReadings=[],marketReadings=source.marketReadings.map(page=>Object.freeze(unpackPage(page,budget,source.at)));
 const placements=structuredClone(source.placements),unknown=structuredClone(source.unknown??[]),qualified=new Map(),unfilled=new Map();
 for(const stored of source.accountingReadings){
  if(!Array.isArray(stored.originalPages)||stored.originalPages.length>2500||!Array.isArray(stored.originalCutoffPages)||stored.originalCutoffPages.length!==2)throw new TypeError('original finite financial population and both cutoff bodies required');
  const packets=new Map();let maxPages=1;const byPath=new Map();
  for(const page of stored.originalPages){
   const packet=unpackPage(page,budget,source.at),key=page.path+'|'+queryKey(page.query);
   if(packets.has(key))throw new TypeError('duplicate original financial request');
   packets.set(key,packet);byPath.set(page.path,(byPath.get(page.path)??0)+1);maxPages=Math.max(maxPages,byPath.get(page.path));
  }
  if(maxPages>500)throw new RangeError('existing historical source page bound exceeded');
  const cutoffs=stored.originalCutoffPages.map(page=>{if(page.path!=='/historical/cutoff')throw new TypeError('original historical cutoff body required');return unpackPage(page,budget,source.at);});
  let boundary=0;
  const history=await collectKalshiAccountingHistory({ticker:stored.ticker,subaccount:stored.subaccount,from:stored.from,to:stored.to,maxPages,requireOriginalBytes:true,
   readCutoff:()=>{if(boundary>=cutoffs.length)throw new TypeError('original cutoff receipt exhausted');return cutoffs[boundary++];},
   readPage:(path,query)=>{const key=path+'|'+queryKey(query),packet=packets.get(key);if(!packet)throw new TypeError('missing original financial page for the canonical request');packets.delete(key);return packet;}});
  if(packets.size||boundary!==2)throw new TypeError('unconsumed original financial source population');
  accountingReadings.push(history);
  const issued=placements.filter(p=>p.ticker===history.ticker);
  const zeroProof=reconcileKalshiDeskUnfilledOrders({history,placements:issued,at:source.at});
  for(const row of zeroProof.unfilledOrders)unfilled.set(row.orderId,freezeOutcome(row));
  unknown.push(...zeroProof.withheld);
  const marketReading=marketReadings.find(packet=>packet.market?.ticker===history.ticker);
  if(!marketReading)continue;
  try{
   const proof=reconcileKalshiDeskOrderOutcomes({history,marketReading,placements:issued,at:source.at});
   for(const row of proof.rows)qualified.set(row.orderId,freezeOutcome(row));unknown.push(...proof.withheld);
  }catch(error){unknown.push({ticker:history.ticker,reason:error.message});}
 }
 const context=Object.freeze({type:'KalshiDeskAccountingContext',readStart:source.readStart,at:source.at,restoredAt:at,placements,
  accountingReadings:Object.freeze(accountingReadings),marketReadings:Object.freeze(marketReadings),deskOutcomes:Object.freeze([...qualified.values()]),unfilledOrders:Object.freeze([...unfilled.values()]),
  fills:mergeFills(accountingReadings.map(history=>history.fills),unknown),
  coverage:{knownKdOrders:placements.length,qualifiedFilledOrders:qualified.size,qualifiedUnfilledOrders:unfilled.size,originalSourceBytesRevalidated:budget.bytes,complete:unknown.length===0},unknown,orderEffect:false});
 receivedContexts.add(context);return context;
}

#!/usr/bin/env node
import {orderExecutionControl} from '../../../src/execution-control.mjs';
import {readDeskAuthority,admitDeskOrder} from '../src/desk-authority.mjs';
import { slotOrderId } from '../src/slot-order-id.mjs';
/**
 * The Kalshi desk: several lanes of post-only trading on one account, sized
 * together. It grew from the one-lane weather desk; its state directory,
 * arming file and ledger are that desk's, the ledger gaining a `lane` field.
 *
 *   cycle [--live] [--lanes=a,b]
 *                    one pass: read the account once, halt if a halt rule
 *                    trips, ask each lane for its certified targets, cancel
 *                    resting orders that no longer match, size every lane's
 *                    opportunities together (src/desk-plan.mjs ->
 *                    allocateOpportunities) and rest the new orders. Without
 *                    --live, or while unarmed, the plan is only recorded.
 *   status           cash, equity, positions, resting orders, recent fills,
 *                    settled results, and the arming record.
 *   arm <by>         arm the desk (the founder's act, named by actor).
 *   halt [reason]    unarm and withdraw every resting order of the desk's lanes.
 *
 * Lanes (src/lanes/): forecast-edge, weather-tail-premium, daily-rain,
 * published-series-favorites.
 * Policy: content/config/kalshi-desk-policy.json, with the lane fractions and
 * statuses of the latest daily review (<data root>/data/records/desk-review-records/judgments.json,
 * apps/kalshi-desk-review.mjs) in force over it, and every lane whose evidence
 * meets the founder's strategy criteria admitted to capital
 * (src/strategy-admission.mjs). The venue is the source of
 * truth: each cycle starts from Kalshi's own balance, positions and orders.
 * Every order rests post-only with an expiry, so nothing stale outlives a
 * stopped timer.
 * Each cycle row names the evidence the lanes could not read (`unreadStations`;
 * nothing it would decide is certified), and each certified opportunity a limit
 * held below its size gets a `refused-size` row naming the limit, the size
 * refused and the expected gain forgone, which the daily review reports.
 */
import {spawn} from 'node:child_process';
import { constants, fstatSync, readSync, appendFileSync, fsyncSync, mkdirSync, openSync, closeSync, readFileSync, readdirSync, renameSync, lstatSync, writeFileSync } from 'node:fs';
import { dirname, join, isAbsolute } from 'node:path';
import { settlementRoot } from '@red-cup-engineering/kalshi-services-section/data-layout';
import { readDeskPolicy } from '../../../src/desk-policy.mjs';
import { kalshiAccount } from '../../../src/accounts.mjs';
import { deskStateDirectory, deskStatePath, ledgerFile, reviewDirectory } from '../src/desk-layout.mjs';
import { createKalshiClient } from '@red-cup-engineering/kalshi-services-section/client';
import { admitSharedDeskOrder, haltReason, planDesk, pricedRefusal } from '../src/desk-plan.mjs';
import { readAccount } from '../src/account.mjs';
import { restoreDeskAccountingContext } from '../src/desk-accounting-context.mjs';
import { deriveLanePosteriors } from '../src/lane-posteriors.mjs';
import { readBooks } from '../src/books.mjs';
export { readAccount };
import { policyInForce } from '../src/desk-review.mjs';
import { incentivesFor, ledgerIncentive } from '../src/liquidity-incentives.mjs';
import { executionConfig, restCyclesFrom, advanceRestState, restKey, takerOrderParams } from '../src/execution.mjs';
import {readPendingOrderEffect,recoverPendingOrderEffect,placeOrderWithCustody} from '../src/order-effect-custody.mjs';
import { appendShadow } from '../src/shadow-book.mjs';
import { deskGameShadow } from '../src/desk-game.mjs';
import { costCents, money, openDeskOneLog, resolveDeskActor } from '../src/one-log.mjs';
import { readScores } from '../src/shadow-score.mjs';
import {receivedDeskBook,receivedDeskMarket,deskBookIntentPacket} from '../src/desk-book-provenance.mjs';
import * as forecastEdge from '../src/lanes/forecast-edge.mjs';
import * as tailPremium from '../src/lanes/weather-tail-premium.mjs';
import * as dailyRain from '../src/lanes/daily-rain.mjs';
import * as favorites from '../src/lanes/published-series-favorites.mjs';
import { admitByCriteria } from '../src/strategy-admission.mjs';

export const POLICY = readDeskPolicy();
export const EXPECTATIONS = JSON.parse(readFileSync(new URL('../content/config/kalshi-lane-expectations.json', import.meta.url), 'utf8'));
export const CRITERIA = JSON.parse(readFileSync(new URL('../content/config/kalshi-strategy-criteria.json', import.meta.url), 'utf8'));
/**
 * When a cycle stops surveying (epoch ms): KALSHI_DESK_SURVEY_SECONDS after it starts, 90 by default. Lanes are surveyed
 * in order and none starts after it; a source or book not read by then is unread this cycle. Planning and placing
 * follow on what was read, so a slow host costs the cycle its later lanes instead of the whole cycle to the job limit.
 */
export function surveyDeadline(env = process.env, start = Date.now()) {
  const seconds = Number(env.KALSHI_DESK_SURVEY_SECONDS ?? 90);
  if (!(seconds > 0)) throw new RangeError(`KALSHI_DESK_SURVEY_SECONDS must be a positive number of seconds: ${env.KALSHI_DESK_SURVEY_SECONDS}`);
  return start + seconds * 1000;
}
/** The data root the desk writes under: the Kalshi settlement's, unless KALSHI_DESK_DATA_DIR names another. */
export const deskDataRoot = (env = process.env) => env.KALSHI_DESK_DATA_DIR ?? settlementRoot(env);

/** The latest review's in-force judgments, or null before the first review. */
export function readJudgments(dir) {
  try { return JSON.parse(readFileSync(join(reviewDirectory(dir), 'judgments.json'), 'utf8')); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
/** The policy the desk trades: the base policy with the latest review's judgments in force, and each lane admitted to capital or held in shadow by the founder's strategy criteria. */
export const inForcePolicy = (dir, policy, env = process.env) => {
  policy ??= readDeskPolicy(env);
  return admitByCriteria(policyInForce(policy, readJudgments(dir)), EXPECTATIONS, CRITERIA, policy);
};

const usd = (c) => `$${(c / 100).toFixed(2)}`;

/**
 * The lanes this policy runs, optionally narrowed by name. forecast-edge trades every contract the forecasting
 * service knows better than the book; weather-tail-premium and daily-rain bet where the tail and rain models are
 * measured specialists, though neither beats the market's mid overall. A ticker two lanes certify is the first
 * lane's (desk-plan): an observed bound is stronger evidence than a model's tail.
 */
export function buildLanes({ policy = POLICY, only = null } = {}) {
  const all = [
    forecastEdge.createLane({ policy }),
    tailPremium.createLane({ policy }),
    dailyRain.createLane({ policy }),
    favorites.createLane({ policy }),
  ];
  // A lane with capital runs; a "shadow" lane (fraction 0) is surveyed too, so its opportunities reach the shadow book, but the allocator gives it no capital.
  const surveyed = (lane) => (policy.lanes?.[lane.id]?.fraction ?? 0) > 0 || policy.lanes?.[lane.id]?.status === 'shadow';
  return all.filter((lane) => surveyed(lane) && (!only || only.includes(lane.id)));
}

/** Tickers the desk itself placed in the last 31 days, from its ledger: the halt counts only its own losses. */
export function placedTickers(dir, now = Date.now()) {
  const out = new Set();
  for (let d = 0; d <= 31; d += 1) {
    const day = new Date(now - d * 86400000).toISOString().slice(0, 10);
    let text;
    try { text = readFileSync(ledgerFile(dir, day), 'utf8'); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    for (const line of text.split('\n')) if (line.includes('"kind":"place"')) { try { const row = JSON.parse(line); if (row.kind === 'place' && row.ticker) out.add(row.ticker); } catch {} }
  }
  return out;
}

/** Existing ledger authority, narrowed before retention: cycle records are
 * not copied into a second history just to identify the desk's own orders. */
export function readDeskOrderLedger(dir, now = Date.now()) {
  const entries = [];
  for (let d = 0; d <= 31; d += 1) {
    const day = new Date(now - d * 86400000).toISOString().slice(0, 10);
    let text;
    try { text = readFileSync(ledgerFile(dir, day), 'utf8'); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
    for (const line of text.split('\n')) if (/"kind":"(?:place|place-acknowledged|place-recovered|order-intent)"/u.test(line)) {
      try { entries.push(JSON.parse(line)); } catch { /* Preserve the original; malformed authority is not inferred. */ }
    }
  }
  return entries;
}

export function normalizedLiveOutcomes(context) {
  const placed = new Map(context.placements.map(row => [row.orderId, row]));
  return context.deskOutcomes.flatMap(row => {
    const original = placed.get(row.orderId), market = context.marketReadings.find(reading => reading.market?.ticker === row.ticker)?.market;
    if (!original || !market) return [];
    return [{ ...row, result: row.marketResult, eventTicker: original.eventTicker ?? market.event_ticker, targetDate: original.targetDate, issuedAt: original.orderIntentAt ?? original.at, closeTime: original.closeTime ?? market.close_time, cohort: original.cohort ?? original.detail?.cohort ?? original.detail?.kind ?? null, detail: original.detail, seriesTicker: original.seriesTicker, verified: row.completeOrderFills === true, source: 'kd-settlement' }];
  });
}

/** Revalidate original venue receipts retained by the existing review job.
 * This does not fetch history or turn a file receiving clock into a new venue
 * observation. Missing evidence leaves the empirical prior in force. */
export async function readReviewedAccountingContext(dir, now = Date.now()) {
  const out = reviewDirectory(dir), day = new Date(now).toISOString().slice(0, 10);
  let files;
  try { files = readdirSync(out); } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  const earliest = new Date(now - 31 * 86400000).toISOString().slice(0, 10);
  for (const name of files.filter(name => /^\d{4}-\d{2}-\d{2}\.json$/u.test(name) && name.slice(0, 10) >= earliest && name.slice(0, 10) <= day).sort().reverse()) {
    const fd = openSync(join(out, name), constants.O_RDONLY | constants.O_NOFOLLOW);
    let record;
    try {
      const info = fstatSync(fd);
      // Original source custody is bounded to 64 MiB by its owner; base64 and
      // the existing review measurements must also fit this finite envelope.
      if (!info.isFile() || info.uid !== process.getuid() || (info.mode & 0o077) !== 0 || info.size > 96 * 1048576) throw new TypeError('bounded-private-desk-review-required');
      record = JSON.parse(readFileSync(fd, 'utf8'));
    } finally { closeSync(fd); }
    if (record.type !== 'KalshiDeskReview' || !record.accountingSource) continue;
    return await restoreDeskAccountingContext(record.accountingSource, { at: new Date(now).toISOString() });
  }
  return null;
}

function readArming(dir, env = process.env) {
  try {
    const arming = JSON.parse(readFileSync(deskStatePath(dir, 'arming.json'), 'utf8'));
    const accountId = kalshiAccount(env).id;
    if ((arming.principal && arming.principal !== accountId) || (accountId !== 'emsenn' && arming.armed && arming.principal !== accountId))
      throw new TypeError('desk-arming-account-mismatch');
    return arming;
  } catch (error) {
    if (error.code === 'ENOENT') return { armed: false, armedAt: null, armedBy: null, haltedAt: null, haltReason: null };
    throw error;
  }
}
function writeArming(dir, arming) {
  mkdirSync(deskStateDirectory(dir), { recursive: true, mode: 0o700 });
  const path = deskStatePath(dir, 'arming.json');
  writeFileSync(`${path}.tmp`, `${JSON.stringify(arming, null, 2)}\n`, { mode: 0o600 });
  renameSync(`${path}.tmp`, path);
}
// How long each certified opportunity has rested, for maker-then-taker lanes. A paper pass keeps its own file so it never matures a live order.
const restStatePath = (dir, acting) => deskStatePath(dir, acting ? 'rest-state.json' : 'rest-state.paper.json');
function readRestState(dir, acting) {
  try { return JSON.parse(readFileSync(restStatePath(dir, acting), 'utf8')); } catch (error) { if (error.code === 'ENOENT') return {}; throw error; }
}
function writeRestState(dir, acting, state) {
  mkdirSync(deskStateDirectory(dir), { recursive: true, mode: 0o700 });
  const path = restStatePath(dir, acting);
  writeFileSync(`${path}.tmp`, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 });
  renameSync(`${path}.tmp`, path);
}
function ledger(dir, entry) {
  const file = ledgerFile(dir, entry.at.slice(0, 10));
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const fd=openSync(file,'a',0o600);
  try { writeFileSync(fd,`${JSON.stringify(entry)}\n`); fsyncSync(fd); } finally { closeSync(fd); }
}

/**
 * The resting orders the desk may withdraw: its own (client order id kd-) on a ticker one of its lanes owns. An
 * order without the desk's id is the account owner's own and is never cancelled, by a cycle or by a halt.
 */
export const deskOrders = (resting, lanes) => resting.filter((order) => order.own === true && lanes.some((lane) => lane.ownsTicker(order.ticker)));

async function cancelAll(client, resting, dir, at, reason, assertCycleLock) {
  let cancelled=0,errors=0;
  for (const order of resting) {
    try { assertCycleLock(); await client.cancelOrder(order.orderId, order.ticker); cancelled++; ledger(dir, { at, kind: 'cancel', ...order, reason }); } catch (error) { errors++; ledger(dir, { at, kind: 'error', step: 'cancel', ticker: order.ticker, code: error.code, detail: error.detail ?? error.message }); }
  }
  return {cancelled,errors};
}

/**
 * One cycle's public market listings, shared by the lanes: forecast-edge and the tail lane list the same 48 temperature
 * series, and the desk has under a minute a cycle, so a series listed once is not listed again in that cycle.
 */
export function withCycleReads(client) {
  const listed = new Map();
  return { ...client, getMarkets(query, options) {
    const key = JSON.stringify(query ?? {});
    if (!listed.has(key)) listed.set(key, Promise.resolve().then(() => client.getMarkets(query, options)).catch((error) => { listed.delete(key); throw error; }));
    return listed.get(key);
  } };
}

/** Survey every lane against the one account; a lane that throws is recorded and left alone this cycle. */
export async function surveyLanes({ lanes, client, account, policy, dir, at, now, surveyBy = Infinity, sourceBooks = null, sourceMarkets = null, receiptClock = () => new Date().toISOString() }) {
  const surveyed = [];
  for (const lane of lanes) {
    const paused = lane.pausedFor?.(account.deskSettlements) ?? null;
    const base = { id: lane.id, ownsTicker: lane.ownsTicker, correlationOf: lane.correlationOf, paused };
    if (paused) { surveyed.push({ ...base, targets: [] }); continue; }
    // A lane the deadline reaches first is left alone this cycle, as a failed survey is: its orders stay, it places nothing.
    if (Date.now() >= surveyBy) {
      ledger(dir, { at, lane: lane.id, kind: 'skip', step: 'survey', reason: 'survey deadline passed' });
      surveyed.push({ ...base, targets: [], failed: true, skipped: 'survey deadline passed', failure: 'survey deadline passed' });
      continue;
    }
    try {
      // Transparent, lane-scoped receipt tap: the ORIGINAL provider response
      // still flows unmodified to the lane's existing book/pricing decision.
      // No new source fetch, storage system, price heuristic or timer.
      const observedClient = !sourceBooks && !sourceMarkets ? client : {
        ...client,
        async getMarkets(query, options) {
          const result = await client.getMarkets(query, options),receivedAt=receiptClock();
          if(sourceMarkets && Array.isArray(result))for(const market of result){
            try { if(market?.ticker)sourceMarkets.set(lane.id+'|'+market.ticker,
              receivedDeskMarket({lane:lane.id,market,receivedAt})); }
            catch { /* Unqualified source is NOT fabricated as evidence. */ }
          }
          return result;
        },
        async getOrderbook(ticker,depth,options) {
          // A failed/changed later fetch must NOT leave a stale receipt in
          // the key for this lane's newest book decision.
          const key=lane.id+'|'+ticker;
          sourceBooks?.delete(key);
          const result=await client.getOrderbook(ticker,depth,options),receivedAt=receiptClock();
          if(sourceBooks)try {
            sourceBooks.set(key,
              receivedDeskBook({lane:lane.id,ticker,book:result,receivedAt}));
          }catch { /* An unfamiliar book shape still reaches the original lane. */ }
          return result;
        },
      };
      const result = await lane.survey({ client:observedClient, account, policy, dir, ledger, at, now, surveyBy });
      surveyed.push({ ...base, targets: result.targets, candidates: result.candidates, guidanceRun: result.guidanceRun, unread: result.unread ?? [], adapters: result.adapters ?? null, marketOnly: result.marketOnly ?? [] });
    } catch (error) {
      ledger(dir, { at, lane: lane.id, kind: 'error', step: 'survey', code: error.code, detail: error.detail ?? error.message });
      surveyed.push({ ...base, targets: [], failed: true, failure: error.message });
    }
  }
  return surveyed;
}

// The desk's actor in the one log, resolved from the agency once per process (src/one-log.mjs).
let deskActor = null;
async function deskOneLog(env) { deskActor ??= await resolveDeskActor(env); return openDeskOneLog({ env, ...deskActor }); }
/** A one-log write that can only ever cost a ledger error row: the one log never blocks the desk. */
const oneLogWriter = (oneLog, dir, at) => (entry) => {
  if (!oneLog) return null;
  try { return oneLog.record({ recordedAt: at, ...entry }); } catch (error) { ledger(dir, { at, kind: 'error', step: 'one-log', category: entry.category, detail: error.message }); return null; }
};

/** One pass of the desk. */
/** OS ownership serializes cycles, recovery and halt withdrawal; elapsed time never grants ownership. */
async function acquireCycleLock(dir,{wait=false}={}) {
  const state=deskStateDirectory(dir);mkdirSync(state,{recursive:true,mode:0o700});
  const privateOwned=(info)=>info.uid===process.getuid()&&(info.mode&0o077)===0;
  const info=lstatSync(state);if(!info.isDirectory()||info.uid!==process.getuid()||(info.mode&0o022)!==0)throw new TypeError('owned-nonwritable-desk-state-required');
  const path=join(state,'cycle.lease');
  const fd=openSync(path,constants.O_WRONLY|constants.O_CREAT|constants.O_APPEND|constants.O_NOFOLLOW,0o600);
  try{const info=fstatSync(fd);if(!info.isFile()||!privateOwned(info))throw new TypeError('private-owned-desk-cycle-lease-required');}finally{closeSync(fd);}
  const child=spawn('flock',['--exclusive',...(wait?['--wait','900']:['--nonblock']),path,process.execPath,'-e','process.stdout.write("locked\\n");process.stdin.resume();process.stdin.on("end",()=>process.exit(0));'],{stdio:['pipe','pipe','pipe']});
  let exited=false,error;const finished=new Promise(resolve=>{child.once('error',e=>{error=e;exited=true;resolve();});child.once('close',()=>{exited=true;resolve();});});
  child.stdin.on('error',()=>{});child.stderr.resume();
  let ready=false;
  try{ready=await new Promise((resolve,reject)=>{
    let text='';child.once('error',reject);child.once('close',code=>code===1&&!wait?resolve(false):reject(new TypeError('desk-cycle-lock-acquisition-failed')));
    child.stdout.on('data',chunk=>{text+=chunk.toString();if(text==='locked\n')resolve(true);else if(text.length>=7)reject(new TypeError('desk-cycle-lock-handshake-invalid'));});
  });}catch(e){child.stdin.end();await finished;throw e;}
  if(!ready){child.stdin.end();await finished;return null;}
  const release=async()=>{child.stdin.end();await finished;};
  release.assertHeld=()=>{if(exited)throw error??new TypeError('desk-cycle-lock-lost');};
  release.assertHeld();return release;
}

/** Reconcile an already-dispatched effect under the same lock as placement. */
export async function reconcileDeskOrderEffects({env=process.env,dir=deskDataRoot(env),client=createKalshiClient({env})}={}){
  const at=new Date().toISOString(),release=await acquireCycleLock(dir);
  if(!release)return {at,status:'busy',blocked:true,orderEffect:false};
  try{
    const recovery=await recoverPendingOrderEffect({dir,client,record:entry=>ledger(dir,entry)});
    return {at,status:recovery.recovered?'recovered':recovery.blocked?'unresolved':'no-pending-effect',blocked:recovery.blocked,orderEffect:false,...(recovery.blocked?{clientOrderId:recovery.pending.params.clientOrderId}:{})};
  }finally{await release();}
}

export async function runCycle(options = {}) {
  if(options.live){const control=orderExecutionControl((options.env??process.env).KALSHI_ACCOUNT_ID??'emsenn');if(control.closed)return {at:new Date().toISOString(),mode:'hard-closed',reason:control.reason??'Explicit new human authorization is required'};}
  const dir = options.dir ?? deskDataRoot(options.env ?? process.env);
  const release = await acquireCycleLock(dir);
  if (!release) return { at: new Date().toISOString(), skipped: 'another cycle holds the lock' };
  try { return await runCycleLocked({ ...options, dir, assertCycleLock:release.assertHeld, policy: options.policy ?? inForcePolicy(dir, undefined, options.env ?? process.env) }); } finally { await release(); }
}

async function runCycleLocked({ live = false, only = null, env = process.env, client = createKalshiClient({env}), now = Date.now(), policy = readDeskPolicy(env), dir = deskDataRoot(env), lanes = null, marketDecision, marketDecisionPath, assertCycleLock, surveyBy = surveyDeadline(env) } = {}) {
  const at = new Date(now).toISOString();
  const arming = readArming(dir, env);
  let account = await readAccount(client, now, { includeSettlements: false });
  const recovery=live?await recoverPendingOrderEffect({dir,client,record:entry=>ledger(dir,entry)}):null;
  if(recovery?.recovered)account=await readAccount(client,now,{ includeSettlements: false });
  const scores = readScores(dir);
  let accounting = null;
  try {
    accounting = await readReviewedAccountingContext(dir, now);
    if (accounting) {
      account.deskSettlements = accounting.deskOutcomes.filter(row => row.completeOrderFills && Date.parse(row.settledAt) >= now - 30 * 86400000);
      account.losses30d = account.deskSettlements.filter(row => row.standaloneRealized && !row.won).length;
      account.deskEvidenceStatus = accounting.coverage.complete ? 'qualified-order-outcomes' : 'partial-order-outcomes';
    }
  } catch (error) { ledger(dir, { at, kind: 'error', step: 'desk-accounting', detail: error.code ?? error.message }); }
  const posteriors = deriveLanePosteriors({ liveOutcomes: accounting ? normalizedLiveOutcomes(accounting) : [], shadowOutcomes: scores?.shadowOutcomes ?? [], expectations: EXPECTATIONS, now });
  policy = admitByCriteria(policy, EXPECTATIONS, CRITERIA, readDeskPolicy(env), posteriors);
  lanes ??= buildLanes({ policy, only });
  const authority=readDeskAuthority({policy,env,at});
  const acting = live && arming.armed && authority.allowed;
  if(live&&arming.armed&&!authority.allowed)ledger(dir,{at,kind:'authority-refusal',reason:authority.reason});
  const ownedResting = deskOrders(account.resting, lanes);

  const halt = haltReason({ equityCents: account.equityCents, losses30d: account.losses30d, policy });
  if (halt && arming.armed) {
    writeArming(dir, { ...arming, armed: false, haltedAt: at, haltReason: halt });
    if (live) await cancelAll(client, ownedResting, dir, at, `halt: ${halt}`,assertCycleLock);
    ledger(dir, { at, kind: 'halt', reason: halt, equity: account.equityCents });
    if (live) oneLogWriter(await deskOneLog(env), dir, at)({ category: 'refusal', record: { id: `kalshi-desk-halt:${at}`, kind: 'halt', reason: halt, observedAt: at, equity: money(account.equityCents) } });
    return { at, halted: halt };
  }
  if (!arming.armed && arming.haltedAt && live && ownedResting.length > 0) await cancelAll(client, ownedResting, dir, at, 'desk is halted',assertCycleLock);

  if(recovery?.blocked){
    const summary={at,mode:acting?'live':'unarmed',blocked:'unresolved-order-effect',clientOrderId:recovery.pending.params.clientOrderId};
    ledger(dir,{kind:'cycle',...summary});return summary;
  }
  const sourceBooks=new Map(),sourceMarkets=new Map();
  const surveyed = await surveyLanes({ lanes, client: withCycleReads(client), account, policy, dir, at, now, surveyBy, sourceBooks, sourceMarkets });
  const gapMs = Math.max(...lanes.map((lane) => executionConfig(policy, lane.id).maxGapMinutes), 0) * 60_000;
  const restState = readRestState(dir, acting);
  let selectionRefusal=null,selectedDecisionPath=marketDecisionPath;
  if(live){
    marketDecision=undefined;
    try{selectedDecisionPath=marketDecisionPath??env.KALSHI_FLEET_DECISION_PATH??deskStatePath(dir,'fleet-decision.json');marketDecision=readSharedMarketDecision(selectedDecisionPath);}
    catch(error){selectionRefusal=error.code==='ENOENT'?'production-fleet-decision-absent':error.message;}
  }
  const planning={lanes:surveyed,positions:account.positions,resting:account.resting,cashCents:account.cashCents,equityCents:account.equityCents,policy,now:live?Date.now():now,restCycles:restCyclesFrom(restState,now,gapMs),principal:authority.principal};
  let plan;
  try{plan=planDesk({...planning,marketDecision});}
  catch(error){
    if(!live||!marketDecision)throw error;
    selectionRefusal=error.message;marketDecision=undefined;plan=planDesk(planning);
  }
  // A fleet decision, when one is published, caps new capital (planDesk); without one the desk sizes on its own policy.
  if(live&&!marketDecision&&selectionRefusal&&selectionRefusal!=='production-fleet-decision-absent')ledger(dir,{at,kind:'fleet-selection-refusal',reason:selectionRefusal});

  // Size a limit refused on a certified opportunity: one ledger row each, which the daily review reports (desk-review summarizeRefusals).
  const cycleMode = acting ? 'live' : live ? 'unarmed' : 'paper';
  // The one log (live cycles): the decision in force this cycle is the root every record of it cites.
  const toLog = oneLogWriter(live ? await deskOneLog(env) : null, dir, at);
  const decisionEvent = toLog({ category: 'decision', record: { type: 'KalshiDeskPolicyDecision', id: `kalshi-desk-cycle:${at}`, policyVersion: policy.version, mode: cycleMode, observedAt: at,
    portfolio: plan.portfolio,
    places: plan.places.map((order) => ({ lane: order.lane, ticker: order.ticker, bookSide: order.bookSide, count: order.count, priceCents: order.priceCents, execution: order.execution })) } });
  for (const row of plan.refusals) { ledger(dir, { at, kind: 'refused-size', mode: cycleMode, ...row }); toLog({ category: 'refusal', record: { kind: 'refused-size', observedAt: at, ...row }, causes: [decisionEvent] }); }
  ledger(dir, { at, kind: 'queue-observation', ...account.queueObservation });
  for (const row of plan.queueRetention ?? []) ledger(dir, { at, kind: 'queue-retained', mode: cycleMode, ...row });
  const recordPlacementRefusal = (order, reason, limit = 'placement') => {
    const target = { ...order, fee: order.feeSchedule, opportunity: { winProbability: order.winProbability }, takerPriceCents: order.priceCents, takerLevels: order.levels };
    const row = pricedRefusal({ lane: order.lane, target, reason, count: order.count, limit });
    if (limit === 'unresolved-venue-write') Object.assign(row, { refusedCount: null, gainForgoneCents: null, unknownExpectation: true, expectationBasis: 'dispatch outcome unresolved; this may already be a live order' });
    ledger(dir, { at: new Date().toISOString(), kind: 'refused-size', mode: cycleMode, ...row });
    toLog({ category: 'refusal', record: { kind: 'refused-size', observedAt: new Date().toISOString(), ...row }, causes: [decisionEvent] });
  };

  // The same cycle played as the market game, in shadow: its decision beside the policy's plan, never an order.
  let game = null;
  try { game = deskGameShadow({ surveyed, account, policy, places: plan.places, at, scores }); ledger(dir, { kind: 'game-shadow', mode: cycleMode, ...game }); }
  catch (error) { ledger(dir, { at, kind: 'error', step: 'game-shadow', detail: error.message }); }
  if (game) toLog({ category: 'game-shadow', record: { id: `kalshi-desk-game-shadow:${at}`, ...game }, causes: [decisionEvent] });
  const gameRow = new Map((game?.coverage.rows ?? []).map((row) => [`${row.ticker}|${row.side}`, row]));

  // Every certified opportunity goes to the shadow book, acted on or not.
  try { appendShadow(dir, plan.shadow, at); } catch (error) { ledger(dir, { at, kind: 'error', step: 'shadow', detail: error.message }); }
  writeRestState(dir, acting, advanceRestState(restState, plan.shadow.map((row) => ({ key: restKey(row.lane, row.ticker, row.bookSide), resting: row.action === 'rest' || row.action === 'kept-resting' })), now, gapMs));

  // Optional terms do not precede necessary order dispatch or its custody.
  const quoted = [...new Set([...plan.places.map((order) => order.ticker), ...ownedResting.map((order) => order.ticker)])];
  const placedForIncentives = [];

  const results = { cancelled: 0, amended: 0, placed: 0, errors: 0 };
  if (acting) {
    for (const order of plan.cancels) {
      try { assertCycleLock(); await client.cancelOrder(order.orderId, order.ticker); results.cancelled += 1; ledger(dir, { at, kind: 'cancel', ...order }); toLog({ category: 'refusal', record: { kind: 'cancel', observedAt: at, ...order }, causes: [decisionEvent] }); } catch (error) { results.errors += 1; ledger(dir, { at, lane: order.lane, kind: 'error', step: 'cancel', ticker: order.ticker, code: error.code, detail: error.detail ?? error.message }); }
    }
    // Amends keep an order's place in the queue: an expiry refreshed, a size shrunk to what joint sizing wants.
    for (const amend of plan.amends ?? []) {
      try {
        assertCycleLock();
        const ack = await client.amendOrder({ orderId: amend.orderId, ticker: amend.ticker, side: amend.bookSide, price: amend.priceCents / 100, count: amend.filledCount + amend.remaining, ...(amend.expirationTime ? { expirationTime: amend.expirationTime } : {}) });
        results.amended += 1;
        ledger(dir, { at, kind: 'amend', lane: amend.lane, orderId: amend.orderId, ticker: amend.ticker, bookSide: amend.bookSide, priceCents: amend.priceCents, from: amend.restingCount, remaining: amend.remaining, expirationTime: amend.expirationTime ?? null, reasons: amend.reasons, venueRemaining: ack?.remaining_count ?? null });
      } catch (error) {
        results.errors += 1;
        ledger(dir, { at, lane: amend.lane, kind: 'error', step: 'amend', ticker: amend.ticker, orderId: amend.orderId, code: error.code, detail: error.detail ?? error.message });
      }
    }
    const expires = Math.floor(now / 1000) + policy.orders.ttlMinutes * 60;
    const ordinals = new Map();
    for (const order of plan.places) {
      const closes = order.closeTime ? Math.floor(Date.parse(order.closeTime) / 1000) : Infinity;
      if (closes <= Date.now() / 1000) { recordPlacementRefusal(order, 'market has closed', 'market-close'); continue; }
      let intentEvent = null;
      const ordinalKey = `${order.lane}|${order.ticker}|${order.bookSide}`, ordinal = ordinals.get(ordinalKey) ?? 0;
      ordinals.set(ordinalKey, ordinal + 1);
      const clientOrderId = slotOrderId({ account: authority.principal, lane: order.lane, ticker: order.ticker, bookSide: order.bookSide, at, ordinal });
      try {
        const taking = order.execution === 'taker';
        const params = taking
          ? takerOrderParams({ ticker: order.ticker, bookSide: order.bookSide, count: order.count, takerPriceCents: order.priceCents, clientOrderId })
          : { ticker: order.ticker, side: order.bookSide, count: order.count, price: order.priceCents / 100, postOnly: true, clientOrderId, expirationTime: Math.min(expires, closes) };
        if(!readArming(dir,env).armed)throw new TypeError('desk-disarmed-before-placement');
        const mandate=admitDeskOrder({authority,order,params,at:new Date().toISOString()});
        if(marketDecision){
          const currentDecision=readSharedMarketDecision(selectedDecisionPath);
          if(currentDecision.id!==marketDecision.id)throw new TypeError('fleet-decision-superseded-before-placement');
          admitSharedDeskOrder({marketDecision:currentDecision,principal:mandate.principal,order,at:new Date().toISOString()});
        }
        assertCycleLock();
        const orderIntentAt=new Date().toISOString();
        ledger(dir, { at: orderIntentAt, kind: 'order-intent', clientOrderId, lane: order.lane, ticker: order.ticker, eventTicker: order.eventTicker, targetDate: order.targetDate, closeTime: order.closeTime, seriesTicker: order.seriesTicker, bookSide: order.bookSide, count: order.count, priceCents: order.priceCents, cohort: order.detail?.cohort ?? null, detail: order.detail ?? null });
        // Capture only what the actual lane saw BEFORE this order intent.
        // Persist its original book and rules IN the established desk ledger,
        // not in a sidecar store. A failed provenance capture does not change
        // the already-authorized order, and never invents an evidence receipt.
        let sourceFacts={provenanceStatus:'unavailable'},sourceEvent=null;
        if(!taking)try {
          const packet=deskBookIntentPacket({
            order,
            bookObservation:sourceBooks.get(order.lane+'|'+order.ticker),
            marketObservation:sourceMarkets.get(order.lane+'|'+order.ticker),
            intentAt:orderIntentAt,ttlMinutes:policy.orders.ttlMinutes,
          });
          if(packet.bookRecord){
            // Fsynced source bytes before order dispatch, with the same
            // content address mirrored into the existing MetroPlat one-log.
            ledger(dir,packet.bookRecord);
            sourceEvent=toLog({recordedAt:orderIntentAt,category:'book-evidence',record:{
              id:packet.bookRecord.bookReceiptId,
              ...packet.bookRecord,
              observedAt:packet.bookRecord.bookReceivedAt,
              sourceRefs:[packet.bookRecord.bookReceiptId,
                ...(packet.bookRecord.marketRulesReceiptId?
                  [packet.bookRecord.marketRulesReceiptId]:[])],
            },causes:[decisionEvent]});
          }
          sourceFacts=packet.sourceFacts;
        }catch(error){
          sourceFacts={provenanceStatus:'unavailable'};
          try{ledger(dir,{at:orderIntentAt,kind:'error',step:'book-provenance',
            ticker:order.ticker,lane:order.lane,detail:error.message});}catch{}
        }
        intentEvent = toLog({ recordedAt:orderIntentAt, category: 'order-intent', record: { id: clientOrderId, clientOrderId, lane: order.lane, ticker: order.ticker, bookSide: order.bookSide, heldSide: order.bookSide === 'ask' ? 'no' : 'yes', count: order.count, priceCents: order.priceCents, execution: order.execution, observedAt: orderIntentAt, ...sourceFacts, ...money(costCents(order)), sourceRefs: [clientOrderId,...(sourceFacts.bookReceiptId?[sourceFacts.bookReceiptId]:[]),...(sourceFacts.marketRulesReceiptId?[sourceFacts.marketRulesReceiptId]:[])] }, causes: [decisionEvent,sourceEvent].filter(Boolean) });
        const ack=await placeOrderWithCustody({dir,client,params,at,record:ack=>ledger(dir,{at,kind:'place-acknowledged',clientOrderId,orderId:ack.order_id,ticker:order.ticker,ack})});
        results.placed += 1;
        const ackReceivedAt=new Date().toISOString();
        const ackEvent = toLog({ recordedAt:ackReceivedAt, category: 'order-acknowledged', record: { id: ack.order_id, orderId: ack.order_id, clientOrderId, status: ack.status ?? null, observedAt: ackReceivedAt, economicEventAt: ack.created_time ?? null, sourceRefs: [ack.order_id, clientOrderId] }, causes: [intentEvent] });
        if (Number(ack.fill_count) > 0) toLog({ recordedAt:ackReceivedAt, category: 'fill', record: { id: `${ack.order_id}:acknowledged-fill`, orderId: ack.order_id, ticker: order.ticker, heldSide: order.bookSide === 'ask' ? 'no' : 'yes', filledCount: Number(ack.fill_count), observedAt: new Date().toISOString(), economicEventAt: ack.created_time ?? null,
          ...money(costCents({ ...order, count: Number(ack.fill_count) })), amountBasis: 'at the order limit, an upper bound on cost; per-fill prices and fees are the venue fills the review reads', sourceRefs: [ack.order_id] }, causes: [ackEvent] });
        const { detail, ...rest } = order;
        ledger(dir, { at, kind: 'place', mandate_id:mandate.grant, principal:mandate.principal, ...rest, orderIntentAt, ...sourceFacts, execution: order.execution, ...(detail?.priced ? { priced: detail.priced, probability: detail.probability, lossRate: detail.lossRate, marketPrior: detail.marketPrior } : { detail }), clientOrderId, orderId: ack.order_id, filled: ack.fill_count, oneLog: { intent: intentEvent, acknowledged: ackEvent }, incentive: null, incentiveCycleAt: at, incentiveStatus: 'pending-post-dispatch-terms', game: gameRow.get(`${order.ticker}|${order.bookSide === 'ask' ? 'no' : 'yes'}`) ?? null });
        placedForIncentives.push({ ticker: order.ticker, orderId: ack.order_id, clientOrderId, count: order.count });
      } catch (error) {
        results.errors += 1;
        const pending = readPendingOrderEffect(dir);
        recordPlacementRefusal(order, error.detail ?? error.message, pending ? 'unresolved-venue-write' : 'placement-refusal');
        ledger(dir, { at, lane: order.lane, kind: 'error', step: 'place', ticker: order.ticker, code: error.code, detail: error.detail ?? error.message, venueWrite: error.venueWrite });
        toLog({ category: 'refusal', record: { kind: 'error', step: 'place', lane: order.lane, ticker: order.ticker, code: error.code ?? null, detail: error.detail ?? error.message, venueWrite: error.venueWrite ?? null, observedAt: at }, causes: [intentEvent ?? decisionEvent] });
        // An ambiguous dispatch still reserves capital in native custody.
        // A definite rejection of this order does not reject other candidates.
        if (pending) break;
      }
    }
  }
  // Preserve observed LIP terms in this same ledger after all necessary writes.
  // All pages share one ordinary 20-second acquisition budget; they cannot
  // spend five fresh request budgets before a short-lived order is dispatched.
  let incentives = new Map();
  const incentiveRequestedAt = new Date().toISOString();
  let incentiveObservation = { status: 'not-requested', reason: 'no quoted tickers', rewardCredited: false };
  if (quoted.length) {
    try {
      incentives = await incentivesFor({ client, tickers: quoted, now: Date.now(), deadlineAt: Date.now() + 20000 });
      const observedAt = new Date().toISOString();
      incentiveObservation = { status: 'observed', requestedAt: incentiveRequestedAt, observedAt, source: '/incentive_programs', populationScope: 'observed active liquidity programs from at most five pages; omitted programs remain unknown', rewardCredited: false };
      ledger(dir, { at: observedAt, kind: 'incentive-terms', cycleAt: at, ...incentiveObservation,
        termsByTicker: Object.fromEntries(incentives),
        placements: placedForIncentives.map(order => ({ ...order, incentive: ledgerIncentive(incentives.get(order.ticker), order) })),
      });
    } catch (error) {
      const observedAt = new Date().toISOString();
      incentiveObservation = { status: 'unread', requestedAt: incentiveRequestedAt, observedAt, reason: error.code ?? error.message, rewardCredited: false };
      ledger(dir, { at: observedAt, kind: 'error', step: 'incentives', cycleAt: at, code: error.code, detail: error.detail ?? error.message });
    }
  }
  const keptResting = account.resting.length - plan.cancels.length;
  const summary = {
    at, authority, selection:{decision:marketDecision?.id??null,reason:selectionRefusal}, mode: cycleMode, lanes: surveyed.map((lane) => lane.id),
    accounting: { observedAt: accounting?.at ?? null, restoredAt: accounting?.restoredAt ?? null, coverage: accounting?.coverage ?? null, unknown: accounting?.unknown ?? [], realizedNetCents: accounting?.deskOutcomes.length && accounting.deskOutcomes.every(row => row.realizedNetMicroUsd !== null) ? accounting.deskOutcomes.reduce((sum, row) => sum + Number(row.realizedNetMicroUsd) / 10000, 0) : null },
    lanePosteriors: posteriors.lanes,
    portfolio: plan.portfolio,
    guidanceRun: surveyed.find((lane) => lane.guidanceRun)?.guidanceRun ?? null,
    cash: usd(account.cashCents), equity: usd(account.equityCents), positions: account.positions.length, resting: account.resting.length,
    shadowRows: plan.shadow.length,
    game: game ? { decisions: game.decisions.map((d) => d.id), orders: game.decisions.reduce((n, d) => n + d.orders.length, 0), refusals: game.refusals.length, coverage: `${game.coverage.covered}/${game.coverage.placements}` } : null,
    candidates: surveyed.reduce((sum, lane) => sum + (lane.targets?.length ?? 0), 0),
    certified: plan.places.length + keptResting, plan: { cancels: plan.cancels.length, amends: (plan.amends ?? []).length, places: plan.places.length }, results,
    // Evidence the lanes could not read this cycle (a station any of whose sources failed): nothing it would decide was certified.
    unreadStations: Object.fromEntries(surveyed.filter((lane) => lane.unread).map((lane) => [lane.id, lane.unread.map(({ key, sources, adapter }) => ({ adapter, key, sources }))])),
    adapters: Object.fromEntries(surveyed.filter((lane) => lane.adapters).map((lane) => [lane.id, lane.adapters])),
    refused: plan.refusals.map((row) => `${row.lane} ${row.ticker} ${row.refusedCount ?? 'unknown size'} of ${row.wantedCount ?? 'unknown size'} under ${row.limit}${row.limitValue == null ? '' : ` ${JSON.stringify(row.limitValue)}`}, forgone ${Number.isFinite(row.gainForgoneCents) ? `${row.gainForgoneCents.toFixed(2)}c model EV after fees` : 'unknown EV'}`),
    laneCapital: Object.fromEntries(Object.entries(plan.capitalByLane).map(([lane, c]) => [lane, usd(c)])),
    laneStatus: Object.fromEntries(surveyed.map((lane) => [lane.id, lane.skipped ? `skipped: ${lane.skipped}` : lane.failed ? `failed: ${lane.failure}` : lane.paused ? `paused: ${lane.paused}` : `${lane.targets.length} targets, ${lane.targets.filter((t) => t.verdict.ok).length} certified`])),
    places: plan.places.map((order) => `${order.lane} ${order.ticker} ${order.execution === 'taker' ? 'TAKE' : 'REST'} ${order.bookSide === 'ask' ? 'sell' : 'buy'} YES ${order.count}@${order.levels?.length > 1 ? `${order.levels.map((level) => `${level.count}x${level.priceCents}`).join('+')}c limit ${order.priceCents}` : order.priceCents}c fee ${Number((order.feeCents ?? 0).toFixed(2))}c edge ${(order.edgeCents ?? 0).toFixed(2)}c/contract risk ${usd(order.riskCents)} gain ${usd(order.gainCents)} win=${order.winProbability.toFixed(4)} kelly=${order.kellyFraction.toFixed(2)} growth/day=${Number.isFinite(order.growthPerDay) ? order.growthPerDay.toExponential(2) : 'n/a'}${order.detail?.label ? ` ${order.detail.label}` : ''}`),
    incentives: Object.fromEntries([...incentives].map(([ticker, rows]) => [ticker, rows.map((row) => `$${row.rewardUsdPerHour.toFixed(2)}/h target ${row.targetSize} disc ${row.discountFactor}`)])),
    incentiveObservation,
  };
  // Up to 200 skips per lane, so a busy lane cannot crowd another out of the record.
  const skipsOf = (id) => plan.skips.filter((skip) => skip.lane === id);
  ledger(dir, { kind: 'cycle', ...summary, skips: lanes.flatMap((lane) => skipsOf(lane.id).slice(0, 200)), skipCounts: Object.fromEntries(lanes.map((lane) => [lane.id, skipsOf(lane.id).length])) });
  return summary;
}

export async function status({ env = process.env, client = createKalshiClient({env}), now = Date.now(), policy = inForcePolicy(deskDataRoot(env), undefined, env) } = {}) {
  const account = await readAccount(client, now);
  const lanes = buildLanes({ policy });
  const owned = (ticker) => lanes.find((lane) => lane.ownsTicker(ticker))?.id ?? 'unowned';
  const fills = await client.getFills({ min_ts: Math.floor(now / 1000) - 7 * 86400, subaccount: 0 });
  const accounting = await readReviewedAccountingContext(deskDataRoot(env), now);
  const seed = policy.seedReferenceUsd === undefined ? policy.bankrollUsd : policy.seedReferenceUsd;
  return {
    principal: policy.principal.actorId, strategySourcePrincipal: kalshiAccount(env).strategyAccountId,
    arming: readArming(deskDataRoot(env), env), bankroll: seed === null ? null : `$${seed}`,
    cash: usd(account.cashCents), equity: usd(account.equityCents),
    equityRelativeToOriginalSeed: { difference: seed === null ? null : usd(account.equityCents - seed * 100), meaning: seed === null ? 'This account has no recorded original seed; the strategy provider’s seed is not this account’s funding.' : 'Account equity less the original seed; includes funding and manual trading, and is not desk profit.' },
    deskAccounting: { observedAt: accounting?.at ?? null, coverage: accounting?.coverage ?? null, outcomes: accounting?.deskOutcomes ?? [], unknown: accounting?.unknown ?? [] },
    positions: account.positions.map((row) => `${owned(row.ticker)} ${row.ticker} ${row.side.toUpperCase()} x${row.contracts} cost ${usd(row.costCents)}`),
    resting: account.resting.map((row) => `${owned(row.ticker)} ${row.ticker} ${row.bookSide === 'ask' ? 'sell' : 'buy'} YES ${row.count}@${row.priceCents}c`),
    fills7d: fills.map((row) => `${row.created_time} ${row.ticker} ${row.outcome_side ?? row.side} ${row.count_fp}@${row.yes_price_dollars}${row.is_taker ? ' taker' : ''}`),
    settled30d: account.settlements.map((row) => `account settlement ${row.settled_time} ${row.ticker} result=${row.market_result} YES=${row.yes_count_fp} NO=${row.no_count_fp} revenue=${usd(row.revenue)}`),
    losses30d: account.losses30d,
    books: await readBooks(client).catch((error) => ({ error: error.message })),
    lanePauses: Object.fromEntries(lanes.map((lane) => [lane.id, lane.pausedFor?.(account.deskSettlements) ?? null])),
    lanesInForce: Object.fromEntries(Object.entries(policy.lanes).map(([id, lane]) => [id, `${lane.status} ${lane.fraction}${lane.judgment ? ` (judged ${lane.judgment.judgedOn}, revisit ${lane.judgment.revisitOn})` : ''}`])),
  };
}

/** A private host record selects the shared cap; it supplies no authority. */
export function readSharedMarketDecision(path){
 if(!isAbsolute(path??''))throw new TypeError('absolute-private-market-decision-path-required');
 const fd=openSync(path,constants.O_RDONLY|constants.O_NOFOLLOW);
 try{
  const info=fstatSync(fd);
  if(!info.isFile()||info.uid!==process.getuid()||(info.mode&0o077)!==0||info.size>1048576)throw new TypeError('bounded-private-market-decision-required');
  const bytes=Buffer.alloc(info.size+1),length=readSync(fd,bytes,0,bytes.length,0);
  if(length!==info.size)throw new TypeError('market-decision-changed-during-read');
  return JSON.parse(bytes.subarray(0,length).toString('utf8'));
 }finally{closeSync(fd);}
}

async function main([command, ...rest]) {
  const dir = deskDataRoot();
  if (command === 'cycle') {
    const laneFlag = rest.find((arg) => arg.startsWith('--lanes='));
    const decisionFlag=rest.find(arg=>arg.startsWith('--market-decision='));
    const marketDecision=decisionFlag?readSharedMarketDecision(decisionFlag.slice('--market-decision='.length)):undefined;
    return runCycle({ marketDecision, marketDecisionPath:decisionFlag?decisionFlag.slice('--market-decision='.length):undefined, live: rest.includes('--live'), only: laneFlag ? laneFlag.slice('--lanes='.length).split(',') : null });
  }
  if (command === 'status') return status();
  if (command === 'arm') {
    const by = rest.join(' ').trim();
    if (!by) throw new Error('usage: kalshi-desk.mjs arm <who arms it, by actor>');
    return armDesk({ by });
  }
  if (command === 'halt') {
    const at = new Date().toISOString(), reason = rest.join(' ').trim() || 'halted by hand';
    const arming = { ...readArming(dir), armed: false, haltedAt: at, haltReason: reason };
    writeArming(dir, arming);
    const release=await acquireCycleLock(dir,{wait:true});
    try{
    release.assertHeld();
    const client = createKalshiClient();
    const { resting } = await readAccount(client);
    const withdrawal=await cancelAll(client, deskOrders(resting, buildLanes({ policy: inForcePolicy(dir) })), dir, at, `halt: ${reason}`,release.assertHeld);
    ledger(dir, { at, kind: 'halt', reason });
    return { ...arming, ...withdrawal };
    }finally{await release();}
  }
  throw new Error('usage: kalshi-desk.mjs cycle [--live] [--lanes=a,b] | status | arm <by> | halt [reason]');
}

/** The account owner's explicit act, recorded in that account's desk custody. */
export function armDesk({ by, env = process.env } = {}) {
  if (typeof by !== 'string' || !by.trim()) throw new TypeError('desk arming requires its actor');
  const dir = deskDataRoot(env), account = kalshiAccount(env), policy = readDeskPolicy(env);
  const arming = { armed: true, armedAt: new Date().toISOString(), armedBy: by,
    principal: account.id, strategySourcePrincipal: account.strategyAccountId,
    haltedAt: null, haltReason: null, policyVersion: policy.version };
  writeArming(dir, arming);
  ledger(dir, { at: arming.armedAt, kind: 'arm', by, principal: account.id });
  return arming;
}

if (import.meta.main) {
  // Exit once the result is written: a source read abandoned at the survey deadline must not hold the job open.
  main(process.argv.slice(2)).then(
    (result) => process.stdout.write(`${JSON.stringify(result, null, 2)}\n`, () => process.exit()),
    (error) => process.stderr.write(`${error.stack ?? error.message}\n`, () => process.exit(1)),
  );
}

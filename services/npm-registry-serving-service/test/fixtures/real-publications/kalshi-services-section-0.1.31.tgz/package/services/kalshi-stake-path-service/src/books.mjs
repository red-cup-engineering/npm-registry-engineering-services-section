/**
 * The account's books, rebuilt from everything Kalshi records about it, and checked against the balance Kalshi states.
 *
 *   cash = sum of applied deposits, each less its fee
 *        - sum of applied withdrawals
 *        + sum of fill cash flows: a fill that opens exposure on its outcome side pays count x that side's price plus
 *          its fee; contracts that net against the opposite side already held return $1 a pair at once
 *        + sum of settlement revenue (cents; winning contracts pay 100 each)
 *
 * Verified on the house account on 2026-10-11: its 3 deposits ($25, $50 less $1.00, $75 less $1.50), 62 fills and 27
 * settlements rebuild balance_dollars $36.4696 exactly. Two parts of the rule had not occurred on the account then
 * and are reported as `assumed` whenever they appear, until a reconciliation with them in it closes: netting against
 * an opposite position, and withdrawals (whether a withdrawal's fee is taken beside its amount is not documented).
 * Fills older than Kalshi's historical cutoff are served only by GET /historical/fills; a residual appearing on an
 * older account may be that.
 *
 * Amounts are summed in integer millionths of a dollar: prices carry at most 4 decimals and counts 2, so every
 * product is exact and the books close to the hundredth of a cent or show why not.
 */
const MICRO = 1e6;
const micro = (dollars) => Math.round(Number(dollars ?? 0) * MICRO);
const hundredths = (count) => Math.round(Number(count ?? 0) * 100);
const dollarsOf = (m) => m / MICRO;

/** The cash flow of each fill in millionths of a dollar, in time order, with the contracts it netted. */
export function fillCashFlows(fills) {
  const position = new Map(); // ticker -> hundredths of contracts, + YES, - NO
  return [...fills].sort((a, b) => String(a.created_time).localeCompare(String(b.created_time))).map((f) => {
    const side = f.outcome_side ?? (f.book_side === 'bid' ? 'yes' : f.book_side === 'ask' ? 'no' : null);
    if (side !== 'yes' && side !== 'no') throw new TypeError(`books: fill ${f.fill_id ?? f.trade_id} states no outcome side`);
    const n = hundredths(f.count_fp);
    const price = micro(side === 'yes' ? f.yes_price_dollars : f.no_price_dollars);
    const fee = micro(f.fee_cost);
    const held = position.get(f.ticker) ?? 0;
    const dir = side === 'yes' ? 1 : -1;
    const netted = Math.max(0, Math.min(n, -dir * held));
    position.set(f.ticker, held + dir * n);
    return { fill: f.fill_id ?? f.trade_id ?? null, ticker: f.ticker, side, contracts: n / 100, nettedContracts: netted / 100, feeMicro: fee, cashMicro: (-n * price + netted * MICRO) / 100 - fee };
  });
}

/**
 * The books from the account's records. `balanceDollars` is Kalshi's balance_dollars; without it the books are rebuilt
 * but not reconciled.
 */
export function rebuildBooks({ deposits = [], withdrawals = [], fills = [], settlements = [], balanceDollars = null }) {
  const applied = (rows) => rows.filter((row) => row.status === 'applied');
  const pending = (rows) => rows.filter((row) => row.status === 'pending');
  const inDeposits = applied(deposits).reduce((s, d) => s + (d.amount_cents - d.fee_cents) * 1e4, 0);
  const outWithdrawals = applied(withdrawals).reduce((s, w) => s + w.amount_cents * 1e4, 0);
  const flows = fillCashFlows(fills);
  const fillCash = flows.reduce((s, f) => s + f.cashMicro, 0);
  const revenue = settlements.reduce((s, x) => s + Number(x.revenue ?? 0) * 1e4, 0);
  const rebuilt = inDeposits - outWithdrawals + fillCash + revenue;
  const venue = balanceDollars === null || balanceDollars === undefined ? null : micro(balanceDollars);
  const residual = venue === null ? null : venue - rebuilt;
  const netted = flows.reduce((s, f) => s + f.nettedContracts, 0);
  const assumed = [
    ...(netted > 0 ? [`netting: ${netted.toFixed(2)} contracts netted against an opposite position, each returning $1 a pair at once`] : []),
    ...(applied(withdrawals).length > 0 ? [`withdrawals: ${applied(withdrawals).length} applied, their fees taken beside the amount is not counted`] : []),
  ];
  return {
    cash: { rebuiltDollars: dollarsOf(rebuilt), venueDollars: venue === null ? null : dollarsOf(venue), residualDollars: residual === null ? null : dollarsOf(residual), reconciled: residual === null ? null : Math.abs(residual) < 100 },
    deposits: { applied: applied(deposits).length, pending: pending(deposits).length, grossDollars: applied(deposits).reduce((s, d) => s + d.amount_cents, 0) / 100, feeDollars: applied(deposits).reduce((s, d) => s + d.fee_cents, 0) / 100 },
    withdrawals: { applied: applied(withdrawals).length, pending: pending(withdrawals).length, grossDollars: applied(withdrawals).reduce((s, w) => s + w.amount_cents, 0) / 100, feeDollars: applied(withdrawals).reduce((s, w) => s + w.fee_cents, 0) / 100 },
    fills: { count: flows.length, cashFlowDollars: dollarsOf(fillCash), feeDollars: dollarsOf(flows.reduce((s, f) => s + f.feeMicro, 0)), nettedContracts: netted },
    settlements: { count: settlements.length, revenueDollars: dollarsOf(revenue) },
    assumed,
  };
}

/** Every record the books need, read from the venue (whole history). */
export async function readBooks(client, collected = {}) {
  const [deposits, withdrawals, fills, settlements, balance] = await Promise.all([
    collected.deposits ?? client.getDeposits(), collected.withdrawals ?? client.getWithdrawals(), collected.fills ?? client.getFills({ min_ts: 0, subaccount: 0 }), collected.settlements ?? client.getSettlements({ min_ts: 0, subaccount: 0 }), collected.balance ?? client.getBalance(),
  ]);
  return rebuildBooks({ deposits, withdrawals, fills, settlements, balanceDollars: balance.balance_dollars ?? (Number.isFinite(balance.balance) ? balance.balance / 100 : null) });
}

const usd = (x, places = 2) => `${x < 0 ? '-' : ''}$${Math.abs(x).toFixed(places)}`;

/** The books as review lines. */
export function renderBooks(books) {
  const c = books.cash;
  return [
    '## Books',
    `- Cash rebuilt from the account's history: ${usd(c.rebuiltDollars, 4)}; Kalshi's balance ${c.venueDollars === null ? 'unread' : usd(c.venueDollars, 4)}; ${c.residualDollars === null ? 'not reconciled' : `residual ${usd(c.residualDollars, 4)}${c.reconciled ? ' (reconciled)' : ' -- UNRECONCILED'}`}.`,
    `- Deposits: ${books.deposits.applied} applied, ${usd(books.deposits.grossDollars)} in, ${usd(books.deposits.feeDollars)} in deposit fees${books.deposits.pending ? `; ${books.deposits.pending} pending` : ''}. Withdrawals: ${books.withdrawals.applied ? `${books.withdrawals.applied} applied, ${usd(books.withdrawals.grossDollars)} out` : 'none'}${books.withdrawals.pending ? `; ${books.withdrawals.pending} pending` : ''}.`,
    `- Fills: ${books.fills.count}, cash flow ${usd(books.fills.cashFlowDollars, 4)}, trading fees ${usd(books.fills.feeDollars, 4)}. Settlements: ${books.settlements.count}, revenue ${usd(books.settlements.revenueDollars)}.`,
    ...(books.assumed.length ? [`- Assumed, not yet seen to reconcile on this account: ${books.assumed.join('; ')}.`] : []),
    '',
  ];
}

import { createHash } from 'node:crypto';

// The UTC minute an instant falls in: the desk's placement slot.
export function slotMinute(at) {
  const ms = typeof at === 'number' ? at : Date.parse(at);
  if (!Number.isFinite(ms)) throw new TypeError('slot-minute-needs-a-valid-instant');
  return new Date(Math.floor(ms / 60000) * 60000).toISOString();
}

// A client order id that two nodes pricing the same slot derive identically, so the venue
// refuses the second as a duplicate. Price and count are not in the hash: they differ between
// nodes that read the book a moment apart, and an id that changes with them fences nothing.
// `ordinal` separates several orders of one (lane, ticker, side) placed in one slot.
export function slotOrderId({ account, lane, ticker, bookSide, at, ordinal = 0 }) {
  for (const [name, value] of Object.entries({ account, lane, ticker, bookSide })) {
    if (typeof value !== 'string' || !value) throw new TypeError(`slot-order-id-needs-${name}`);
  }
  if (!Number.isInteger(ordinal) || ordinal < 0) throw new TypeError('slot-order-id-needs-a-nonnegative-integer-ordinal');
  const key = [account, lane, ticker, bookSide, slotMinute(at), ordinal].join('|');
  return `kd-${createHash('sha256').update(key).digest('hex').slice(0, 32)}`;
}

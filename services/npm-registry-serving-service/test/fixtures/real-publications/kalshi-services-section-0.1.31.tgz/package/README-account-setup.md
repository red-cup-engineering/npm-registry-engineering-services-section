# Kalshi account setup

**A person's Kalshi account joins through the Kalshi ASSIST application,
`kalshi.assist.561.group`.** The steps are:
1. The person signs in with an invited Google login.
2. They connect their own Kalshi API key under Connections. The key is sealed
   to that Person, and only their Person's operations read it.
3. They consent to the desk trading it. Arming is recorded per account.

No credential file is hand-placed on a host, and no job record is copied per
account. The sections below record how Morgan's and Esther's accounts were
first connected by hand, before ASSIST hosted the desk.

Morgan's account is `emsenn`; Esther's account is `esther-davis`. Esther requested
her connection on 2026-10-14 and supplied `edavis1848@gmail.com` for Google login.
Her personal service-instance record owns that identity intention. An email is
not an authenticated Google subject or proof of a Kalshi account's owner.

Esther adopted Morgan's shared strategy on 2026-10-14 and reported Morgan's
consent to sharing it: "Esther's strategy is to use Morgan's strategy, and Morgan
consents to sharing their strategy with Esther." Both accounts use the same
strategy policy, lane criteria and shared research. Each desk uses its own
account principal, observed venue capital, holdings, reviews, results and arming.

The minimum local setup is available now through the existing
`scripts/provision-kalshi-api-key.mjs` entrance. The current source includes
upstream's Person-bound Assist application; this change does not deploy it or
claim its Google callback has been received. Once deployed and invited, each
person signs in at https://kalshi.assist.561.group and connects their own key in
Connections. Its current connection form accepts PKCS#8 PEM (Ed25519 downloads
already use this format). The shared PIS invitation, verified Google subject and
Person-scoped sealed credential store own login and key isolation.

## Registering an account key

Esther completed registration and the local API connection on 2026-10-14.
The canonical signed client received her balance, positions and resting orders.
Her service-instance record holds that receiving and the remaining runtime status.

1. Sign in to **your own** Kalshi account at
   https://kalshi.com/account/profile. Complete any account verification Kalshi
   requests. Under API Keys choose Create New API Key.
2. Name it `house-weather-desk-esther-davis`, select Ed25519, and paste the
   **public** key prepared on the signer host. It is in
   `/home/emsenn/.config/561-group/kalshi-accounts/esther-davis/private-key.pem.pub`.
   Only the public key is pasted into Kalshi; its private half stays on this host.
   Allow the account read scopes and Trade access needed to run the adopted
   strategy. Funding and transfers are outside the desk's order operations.
3. Give the agent the **Key ID** Kalshi returns. The agent completes `connect`
   below, which checks a real signed balance read before saving the connection.
   The balance read proves the key works, not who owns the account; you confirm
   ownership in your Kalshi session.

If Kalshi generates the key instead, save the downloaded private-key file and
give the agent its **file path** and the Key ID. Use `import` below. Do not paste
the private key into chat. Both Ed25519 and RSA downloads are accepted; the
existing provisioning owner converts supported keys to PKCS#8 for the signer.

Official key creation, supported algorithms, public-key registration and the
one-time download are documented by
[Kalshi](https://docs.kalshi.com/getting_started/api_keys) (read 2026-10-14).

## Signer-host commands

Run from the Kalshi repository directory. Node 22.18+ and the selected package's
declared workspace dependencies are required. These are the same maintained
provisioning and canonical client, not a parallel API implementation.

```sh
node scripts/provision-kalshi-api-key.mjs prepare \
  --account esther-davis \
  --directory /home/emsenn/.config/561-group/kalshi-accounts/esther-davis

node scripts/provision-kalshi-api-key.mjs connect \
  --account esther-davis \
  --directory /home/emsenn/.config/561-group/kalshi-accounts/esther-davis \
  --key-id REPLACE_WITH_KALSHI_KEY_ID

node scripts/provision-kalshi-api-key.mjs import \
  --account esther-davis \
  --directory /home/emsenn/.config/561-group/kalshi-accounts/esther-davis \
  --key-id REPLACE_WITH_KALSHI_KEY_ID \
  --private-key-file /absolute/path/to/kalshi-download.txt

node scripts/provision-kalshi-api-key.mjs status \
  --account esther-davis \
  --directory /home/emsenn/.config/561-group/kalshi-accounts/esther-davis
```

`prepare` generates or reuses one private key and outputs its public half.
`status` makes no network request and does not claim the key currently works.
`connect` and `import` verify the key first; a refused key does not replace the
current connection. Import does not print the private key. Caller-owned custody
uses directory mode 0700 and file mode 0600, outside source control.

Without `--directory`, setup uses the configured host credential store:
`CREDENTIALS_STORE`, `CREDENTIALS_HOST`, `CREDENTIALS_DIRECTORY`. Esther's service
is `kalshi.esther-davis`, rendering `kalshi.esther-davis.env` and
`keys/kalshi/esther-davis/house-weather-desk.pem`. Custody IDs are
`kalshi.esther-davis.api-private-key`, `kalshi.esther-davis.api-key-id`, and
`kalshi.esther-davis.account-id`. These do not replace Morgan's `kalshi.env`,
`keys/kalshi/house-weather-desk.pem`, or their custody IDs. The assisted browser
also saves Esther to `kalshi.esther-davis.json`, separate from `kalshi.json`.

An account read must select `KALSHI_ACCOUNT_ID=esther-davis`. In caller-owned
custody it additionally selects `KALSHI_CREDENTIAL_ACCOUNT_ID=esther-davis` and
`KALSHI_ENV_FILE=/home/emsenn/.config/561-group/kalshi-accounts/esther-davis/credentials.env`.
Clear any inherited `KALSHI_API_KEY_ID` and `KALSHI_PRIVATE_KEY_PATH` before
switching accounts. The reader takes a complete pair from one source; an
unbound or differently owned file/environment is refused. State goes beneath
the settlement root's `accounts/esther-davis`, while Morgan keeps the original
root. `readDeskPolicy(env)` binds the one shared strategy definition to the
selected account's principal; Esther's mandate adopts Morgan's strategy rather
than creating a separate strategy copy. Her desk's arming record names Esther,
and a mismatched account policy or arming record is refused. Morgan's historical
$25 seed is not claimed as Esther's funding; sizing uses Esther's observed equity.

## Remaining web setup

The hosted application needs a fabricated shared PIS/ASSIST composition, its
own private state root and sealing/session secrets, Google client credentials,
the exact tenant callback registered with Google, and an invitation for
`edavis1848@gmail.com` through the existing membership service. Receive the
verified Google subject and two-Person isolation before claiming either login
works. Do not invent a Google subject from Esther's email or import the host's
Morgan credentials into her Person workspace. See `README-assist.md` for the
existing application contract. Esther's strategy adoption and local Kalshi key
connection are received; account-specific trading-runtime activation remains.

## Runtime activation

The runtime is published as one Kalshi package. The desk and venue weather
modules are internal source; their external suppliers come from the root's
declared dependencies. Publication includes their source, configuration, schemas
and the source-bound rain shadow-model record. Embedded workspace installations,
signer custody and mutable account state are outside that publication boundary.
The rain record remains shadow research; packing it does not admit a live lane.

Esther explicitly requested live runtime activation on 2026-10-14. The native
operation is `kalshi-desk-cycle`; it admits only accounts allocated by the host's
existing clock declarations. The shared source exports `kalshiDeskSchedules`
from `@red-cup-engineering/kalshi-services-section/desk-runtime` for an instance's
`scheduleSources`. The current deployment selects
`{accountIds: ["esther-davis"], mode: "paper"}` explicitly.
Each account receives its own minute pulse. No additional systemd timer is needed.

`deskRuntimeEnvironment` clears another account's key and private state overrides,
binds the selected account's custody, and shares the strategy's weather source.
The host may explicitly supply `KALSHI_ACCOUNT_CUSTODY_ROOT` for caller-owned
`<accountId>/credentials.env` files; otherwise the existing rendered credential
store supplies `kalshi.env` and `kalshi.esther-davis.env`. The selected account's
own arming, holdings, uncertain orders and reviews remain its execution state.

Esther's private credentials have been received on Cold Red Gate at
`/home/emsenn/.config/561-group/kalshi-accounts/esther-davis`, with directory mode
0700 and key/environment file mode 0600. A signed balance read from the VPS
succeeded on 2026-10-14 at 23:19 UTC; its cash balance was $26.3154. No account
arming or order was performed by this setup.

After the shared runtime is fabricated and deployed, an account owner can use
its installed desk CLI with `KALSHI_ACCOUNT_ID=esther-davis`,
`KALSHI_CREDENTIAL_ACCOUNT_ID=esther-davis`, and
`KALSHI_ENV_FILE=/home/emsenn/.config/561-group/kalshi-accounts/esther-davis/credentials.env`.
Clear inherited direct key settings first. `status` reads that account's venue
and desk state; `cycle` without `--live` runs a paper cycle. The `arm` command
and `cycle --live` are the owner's live execution controls. They must be used
against the received installed runtime, with its account-specific custody.
Source publication alone does not enable continuous operation.

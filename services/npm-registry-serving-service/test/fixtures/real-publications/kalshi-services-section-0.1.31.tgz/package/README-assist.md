# Person-bound Kalshi ASSIST

Requirement: an invited Person can monitor their own connected Kalshi account,
read exact market/rule/depth/fee evidence, and request strategy or upstream work
through the existing governed enterprise. The application runs in the hosted
shared PIS/ASSIST/MetroPlat composition; it has no laptop process, venue write,
parallel store, agent loop, timer, session or sealed-secret mechanism.

`kalshiAssistRecord({publicUrl,allowedWorkScopes,runAs})` is the domain record.
`createKalshiAssistApplication(...)` supplies the existing PIS web specification;
`createKalshiAssistWorker(...)` supplies its existing Worker face. `createKalshiAssistHostedApplication({configuration,runAs})` supplies the actual synchronous MetroPlat hosted surface: declared hosts, invited authentication scheme and fetch. Configuration contains exactly hosts/publicUrl/allowedWorkScopes/environmentBindings. Six explicit environment binding names (all KALSHI_ASSIST_*) supply SESSION_SECRET, SEAL_KEY, ASSIST_STATE_ROOT, ASSIST_OWNER_EMAIL, GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET; absent bindings refuse before service. The true ASSETS source is the shared PIS committed public files plus native TUFTE runtime, through its native file/HTTP producer. The hosted
factory binds its native `runAs(subject,'work-open',opening)` callback and exact
source-owned section territories. It does not grant the Person a house office.
The shared Person broker derives the outside-party identity using the app's
process-held session secret and returns the actual native reply. Browser work
requests and analyst requests never automatically copy account evidence into
the shared board. Requirements and acceptance conditions use the native typed
work contract. Credentials and unrelated authority fields are refused.

The shared invited-Google adapter and current membership gate own admission.
Deployment must supply GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, ASSIST_OWNER_EMAIL,
SESSION_SECRET, SEAL_KEY, and a distinct ASSIST_STATE_ROOT. A real external Google
OAuth registration for the exact HTTPS tenant callback is still required; source
publication is not evidence that login works. Shared PIS owns BYOK analyst settings,
MCP token custody, session audience and current membership rejudgment.

Connection is a same-origin, cookie-authenticated POST form received by the native
bounded HTTP formData intake. Native Data admits exactly keyId, privateKeyPem,
environment production/demo, and optional subaccount 0..63. A real signed read of
balance, active positions and resting orders precedes shared sealing. The canonical
venue client receives these explicit credentials; public market tools receive null.
No household environment key, account ID or fallback is available. A successful
read binds the key/environment/subaccount; balance does not expose a venue member
ID. Actual order user IDs, when present, are private connection evidence only.
Disconnect appends the existing current-person credential revocation.

Account operations are GET-only at the adapter boundary. The shared request budget
is 40 physical fetches; 429 retry count is zero. The existing HTTP streaming receiver
bounds every decoded response to 32 KiB before buffering, retains its exact decoded
bytes hash and completion-availability clock, and passes those same bytes to the
canonical venue client. Account pages default to 25 rows, permit an explicit 1..50-row allocation, and have an explicit
nonrepeating cursor. No exchange-index filter excludes a shard. Active positions
and resting orders are not an atomic or historical account close. Four-decimal
source dollars and quantities remain in tool results; displayed dollars use at
most four decimals. Cash, marked value, realized P&L and fees remain distinct.
Private derived observations fit a 48 KiB allocation in the existing native store.
They are scoped to the authenticated principal, not a new account database.

Market study uses current public market/event/series, existing event-fee override
science and fixed-point 25-level bid books. Exact primary/secondary rules and
settlement sources accompany the source clocks/hashes. The receipt expires at the
first of one minute, market close or next known fee change. Late/closed readings
are marked expired. Unsupported or unavailable fee context is explicit while rules and depth remain readable; price/alpha assessment stays unavailable. No forecast calibration, maker-fill law, alpha, charged fee,
account-specific rounding grid, order admission or profit guarantee is invented.

The private Person Paracosm is the existing principal-scoped account observations
and analyst conversations. Optional KALSHI_ASSIST_SEMIOVERSE is the existing native
app-local realm with its separately admitted synchronous identity/enrollment/content
hooks; KALSHI_ASSIST_ENROLLMENT_NOTICE is a host-owned notice of at most 4096 characters.
Without both the UI explicitly reports enrollment unavailable. Opt-in/leave are
same-origin Person browser actions, absent from the analyst/MCP tool catalog.
Consent is explicit, identity mode is explicit, and agent mode stays off by default.
Account data is never included in shared contributions. No shared publication graph
or alternative realm is created.

The common signer retains at most 32 nonextractable CryptoKey handles with a one-minute reuse TTL (lazy access pruning), keyed only by SHA-256 of DER; it no longer retains plaintext PEM Map
keys. Temporary DER bytes are zeroed after import. The signature wire and algorithm
selection are unchanged. This bounds memoization, not venue/trading authority.

Receiving requires the complete exact shared fabricated composition first. Source
parsing alone is not application evidence. Then observe: real invited-Google
callback and membership removal; two distinct Person credential/store/session/MCP
isolation; missing/sealed/revoked key behavior; real bounded signed GET source clocks
and projections; multiple cursor pages; current rule/fee/depth hashes and expiry;
no credential in rendered HTML, tool envelopes or work openings; real native
outside-party work receipt without office grants; explicit existing Semioverse
policy refusal/admission and leave; original signing wire with nonextractable key
handles. No venue orders or fund movements belong to this receiving boundary.

Official source contracts inspected 2026-10-13:
- https://docs.kalshi.com/api-reference/portfolio/get-balance
- https://docs.kalshi.com/api-reference/portfolio/get-positions
- https://docs.kalshi.com/api-reference/orders/get-orders
- https://docs.kalshi.com/api-reference/api-keys/get-api-keys
- https://docs.kalshi.com/api-reference/market/get-multiple-market-orderbooks
- https://docs.kalshi.com/getting_started/rate_limits

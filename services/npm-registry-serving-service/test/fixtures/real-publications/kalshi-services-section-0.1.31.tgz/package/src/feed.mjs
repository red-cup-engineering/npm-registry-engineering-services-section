// The declared public market-data feed this settlement serves under its
// market-data-provision contract. Consumers fetch it themselves, read-only.
import feed from '../content/config/feed.json' with { type: 'json' };

export { feed };

/**
 * The Kalshi SEAVT feed is a VIEW of the canonical semantic substrate:
 *  SignCell evidence -> SCA identity -> SEN term -> SEAVT observation time.
 *
 * New writes use the *existing* JSON<->SEN and SEAVT providers, never a
 * private ["mark", JSON.stringify(value)] substitute. Historical rows already
 * stored as that obsolete mark are decoded at the reader boundary without
 * rewriting an immutable log or fabricating evidence that it never retained.
 *
 * A feed is not an additional truth authority. Source authorship and
 * reconciliation follow from original evidence, not a successfully logged row.
 */
import {append,logDates,readLog} from '@red-cup-engineering/semiotic-eavt-services-section/store';
import {logFile as storeLogFile} from '@red-cup-engineering/semiotic-eavt-services-section/layout';
import {seavtRow} from '@red-cup-engineering/semiotic-eavt-services-section/admit-seavt-row';
import {
  jsonToTerm,termToJson,
} from '@red-cup-engineering/computer-data-engineering-services-section/semiotic-expression-notation/json-codec';

/** The native SEN term of a JSON value (not a textual JSON pseudo-mark). */
export const mark=value=>jsonToTerm(value);
/** The JSON value told by an admitted, typed SEN term. */
export const unmark=term=>termToJson(term);

/** The existing SEAVT store's one log path. */
export const logFile=(dir,feed,day)=>storeLogFile(dir,feed,day);
const sameRow=(a,b)=>JSON.stringify([a.e,a.a,a.v,a.t])===
  JSON.stringify([b.e,b.a,b.v,b.t]);
const absolute=x=>typeof x==='string'&&
  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/u.test(x)&&
  Number.isFinite(Date.parse(x));

/** The historic Kalshi catalog fed JSON.stringify as a bare SEN mark.
 * Restore that old carrier as a JSON value via the real SEN bridge. This is
 * migration at READ, not another supported writer or an asserted witness. */
const nativeTerm=term=>{
 if(!Array.isArray(term))throw new TypeError('native Kalshi SEAVT term required');
 if(term.length===2&&term[0]==='mark'){
  let value;
  try{value=JSON.parse(term[1]);}
  catch{throw new TypeError('legacy Kalshi JSON mark is not a reproducible JSON value');}
  return jsonToTerm(value);
 }
 return term;
};
const admitRow=row=>{
 if(!absolute(row?.t))
  throw new TypeError('Kalshi SEAVT observation requires a valid absolute clock');
 return seavtRow({e:nativeTerm(row.e),a:nativeTerm(row.a),
   v:nativeTerm(row.v),t:row.t});
};
const rowOfLine=({at,e,a,v})=>admitRow({e,a,v,t:at});

/**
 * Append native SEAVT (e/a/v are closed SEN terms), never an arbitrary JSON
 * tuple. Old marks are translated at this boundary; every newly written row
 * uses the upstream canonical SEN representation.
 */
export function appendLogRows(dir,feed,rows,dayOf,{distinct=true}={}){
 const held=new Map();
 for(const raw of rows){
  const row=admitRow(raw),day=dayOf(row);
  if(row.t.slice(0,10)!==day)
   throw new TypeError('a SEAVT row belongs under the day of its source instant');
  if(distinct){
   if(!held.has(day))
    held.set(day,[...readLog(dir,feed,day)].map(({line})=>rowOfLine(line)));
   if(held.get(day).some(other=>sameRow(other,row)))continue;
   held.get(day).push(row);
  }
  append(dir,feed,{at:row.t,e:row.e,a:row.a,v:row.v});
 }
}
export const logDays=(dir,feed)=>[...logDates(dir,feed)];
export function* feedRows(dir,feed){
 for(const day of logDays(dir,feed))
  for(const {line} of readLog(dir,feed,day))
   yield rowOfLine(line);
}
/** The rows of a feed whose attribute is one of `attributes` (its JSON value), admitting no other row. */
export function* feedRowsWithAttribute(dir,feed,attributes){
 const wanted=new Set(attributes);
 for(const day of logDays(dir,feed))
  for(const {line} of readLog(dir,feed,day))
   if(wanted.has(termToJson(nativeTerm(line.a))))yield rowOfLine(line);
}
export function* feedLines(dir,feed){
 for(const row of feedRows(dir,feed))yield JSON.stringify(row);
}

/**
 * The universal Kalshi catalog as SignCell cells (pure; no network, no storage).
 *
 * Series, event and market JSON become cells whose subject is the ticker, whose predicate is
 * `kalshi:<kind>.<field>` and whose object is the value. The kind qualifies the field because a
 * single-market event shares its ticker with its market (KXELONMARS-99 is both), and their titles
 * must not collide. Every catalog field is single-valued per ticker, so every field is a
 * functional predicate of the history: the latest observation supersedes (status, result, volume,
 * open interest, liquidity and close time move; titles and rules are amended rarely, and an
 * amendment must replace, not sit beside, what it amends).
 *
 * The readers take a SignCraft history (signcraft/history) and fold it; nothing here owns state.
 */
import {cell,merge,coincides} from '@red-cup-engineering/signcell/cell';
import { historySection, queryHistory } from '@red-cup-engineering/signcraft/history';

export const VOCABULARY = 'kalshi:';
export const SOURCE = 'kalshi-api';

const SERIES_FIELDS = ['title', 'category', 'tags', 'frequency', 'fee_type', 'fee_multiplier', 'settlement_sources', 'contract_url', 'contract_terms_url'];
const EVENT_FIELDS = ['series', 'title', 'sub_title', 'strike_date', 'strike_period', 'mutually_exclusive', 'category'];
const MARKET_FIELDS = [
  'event', 'title', 'yes_sub_title', 'no_sub_title', 'market_type', 'strike_type', 'floor_strike', 'cap_strike', 'custom_strike',
  'rules_primary', 'rules_secondary', 'open_time', 'close_time', 'expected_expiration_time', 'expiration_time', 'occurrence_datetime',
  'can_close_early', 'early_close_condition', 'status', 'result', 'settlement_timer_seconds', 'notional_value',
  'volume', 'open_interest', 'liquidity', 'price_level_structure', 'price_ranges',
];
export const predicate = (kind, field) => `${VOCABULARY}${kind}.${field}`;
/** Every predicate the catalog writes; all are functional. */
export const FUNCTIONAL_PREDICATES = Object.freeze([
  ...SERIES_FIELDS.map((f) => predicate('series', f)),
  ...EVENT_FIELDS.map((f) => predicate('event', f)),
  ...MARKET_FIELDS.map((f) => predicate('market', f)),
]);

const num = (value) => (value === undefined || value === null || value === '' ? undefined : Number.isFinite(Number(value)) ? Number(value) : undefined);
const first = (...values) => values.find((v) => v !== undefined && v !== null);
const sourcesOf = (list) => (Array.isArray(list) ? list.filter((s) => s?.name).map((s) => ({ name: String(s.name), url: s.url ?? null })) : undefined);

/** One cell per present field. Empty strings and nulls are absent, not claims. */
function cellsOf(ticker, kind, fields, witness) {
  const out = [];
  for (const [field, object] of fields) {
    if (object === undefined || object === null || object === '') continue;
    out.push(cell(ticker, predicate(kind, field), object, { for: [witness] }));
  }
  return out;
}

export const seriesCells = (series, endpoint = '/series') => cellsOf(series.ticker, 'series', [
  ['title', series.title], ['category', series.category], ['tags', Array.isArray(series.tags) ? series.tags : undefined],
  ['frequency', series.frequency], ['fee_type', series.fee_type], ['fee_multiplier', num(series.fee_multiplier)],
  ['settlement_sources', sourcesOf(series.settlement_sources)], ['contract_url', series.contract_url], ['contract_terms_url', series.contract_terms_url],
], { source: SOURCE, endpoint });

export const eventCells = (event, endpoint = '/events') => cellsOf(event.event_ticker, 'event', [
  ['series', event.series_ticker], ['title', event.title], ['sub_title', event.sub_title], ['strike_date', event.strike_date],
  ['strike_period', event.strike_period], ['mutually_exclusive', event.mutually_exclusive], ['category', event.category],
], { source: SOURCE, endpoint });

export const marketCells = (market, endpoint = '/markets') => cellsOf(market.ticker, 'market', [
  ['event', market.event_ticker], ['title', market.title], ['yes_sub_title', market.yes_sub_title], ['no_sub_title', market.no_sub_title],
  ['market_type', market.market_type], ['strike_type', market.strike_type], ['floor_strike', market.floor_strike], ['cap_strike', market.cap_strike],
  ['custom_strike', market.custom_strike], ['rules_primary', market.rules_primary], ['rules_secondary', market.rules_secondary],
  ['open_time', market.open_time], ['close_time', market.close_time], ['expected_expiration_time', market.expected_expiration_time],
  ['expiration_time', market.expiration_time], ['occurrence_datetime', market.occurrence_datetime],
  ['can_close_early', market.can_close_early], ['early_close_condition', market.early_close_condition],
  ['status', market.status], ['result', market.result], ['settlement_timer_seconds', market.settlement_timer_seconds],
  ['notional_value', num(first(market.notional_value_dollars, market.notional_value))],
  ['volume', num(first(market.volume_fp, market.volume))], ['open_interest', num(first(market.open_interest_fp, market.open_interest))],
  ['liquidity', num(first(market.liquidity_dollars, market.liquidity))],
  ['price_level_structure', market.price_level_structure], ['price_ranges', Array.isArray(market.price_ranges) ? market.price_ranges : undefined],
], { source: SOURCE, endpoint });

// ---- sharding -------------------------------------------------------------------------------
// A SignCraft history is a whole reading held in memory (about 3 KB a cell once indexed, 3 million
// cells for the open catalog), so the catalog is one history per shard. A series, its events and
// their markets share a shard, keyed by the series ticker, so every reader folds one shard at a time.
export const SHARDS = 64;
/** The series ticker a market or event ticker belongs to, by Kalshi's naming (SERIES-EVENTSUFFIX-STRIKE). */
export const seriesTickerOfTicker = (ticker) => ticker.split('-')[0];
export function shardOf(seriesTicker, shards = SHARDS) {
  let h = 2166136261;
  for (let i = 0; i < seriesTicker.length; i += 1) { h ^= seriesTicker.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
  return h % shards;
}

/** The cells of one /events page with nested markets: each event and every market under it. */
export function eventPageCells(events, endpoint = '/events') {
  const out = [];
  for (const event of events) {
    out.push(...eventCells(event, endpoint));
    for (const market of event.markets ?? []) out.push(...marketCells({ event_ticker: event.event_ticker, ...market }, endpoint));
  }
  return out;
}

export const seriesPageCells = (list, endpoint = '/series') => list.flatMap((s) => seriesCells(s, endpoint));
export const marketPageCells = (list, endpoint = '/markets') => list.flatMap((m) => marketCells(m, endpoint));

/** The cells of `cells` that differ from the history's current reading (functional: one object per subject+predicate). */
export function changedCells(history, cells) {
  const out=[];
  for(const incoming of cells){
    const current=historySection(history,incoming.subject,incoming.predicate)
      .find(x=>coincides(x.object,incoming.object));
    if(!current){
      // A different value is a distinct cell and source observation.
      // SignCraft's functional-predicate history handles its causal update.
      out.push(incoming);
      continue;
    }
    // A re-observation of the same value can carry *new* independent
    // support or refutation. Dropping it on a JSON.stringify(value) match
    // destroys precisely the paraconsistent evidence we must keep.
    const joined=merge(current,incoming);
    if(!coincides(current,joined))out.push(joined);
  }
  return out;
}

// ---- readers --------------------------------------------------------------------------------

/** The current value of one field of a ticker, or undefined. */
export const fieldOf = (history, ticker, kind, field) => historySection(history, ticker, predicate(kind, field))[0]?.object;
const recordOf = (history, ticker, kind, fields) => {
  const out = {};
  for (const field of fields) { const v = fieldOf(history, ticker, kind, field); if (v !== undefined) out[field] = v; }
  return out;
};

/** The series record for a series, event or market ticker, or null. */
export function seriesOf(history, ticker) {
  let series = fieldOf(history, ticker, 'series', 'title') !== undefined ? ticker : undefined;
  if (series === undefined) {
    const event = fieldOf(history, ticker, 'market', 'event') ?? ticker;
    series = fieldOf(history, event, 'event', 'series');
  }
  return series === undefined ? null : { ticker: series, ...recordOf(history, series, 'series', SERIES_FIELDS) };
}

/** Market tickers of a series, folded through its events (reference-indexed, no full scan). */
export function marketsOfSeries(history, seriesTicker) {
  const markets = [];
  for (const { subject: event } of queryHistory(history, { predicate: predicate('event', 'series'), object: seriesTicker })) {
    for (const { subject } of queryHistory(history, { predicate: predicate('market', 'event'), object: event })) markets.push(subject);
  }
  return markets.sort();
}

const ZONE = /\b(ET|EST|EDT|CT|CST|CDT|MT|MST|MDT|PT|PST|PDT|UTC|GMT|BST|CET|JST)\b/u;

/**
 * The normalized predicate of a contract: what settles YES, against which source, over which window
 * and timezone, at what strike, paying how much, and when it may close early. The timezone is the
 * one the rules text names (Kalshi's JSON carries none); null when the text names none.
 */
export function contractSpec(history, ticker) {
  const market = recordOf(history, ticker, 'market', MARKET_FIELDS);
  if (market.title === undefined && market.rules_primary === undefined) return null;
  const event = market.event === undefined ? null : { ticker: market.event, ...recordOf(history, market.event, 'event', EVENT_FIELDS) };
  const series = seriesOf(history, ticker);
  const text = [market.rules_primary, market.rules_secondary, market.early_close_condition].filter(Boolean).join('\n');
  const zone = ZONE.exec(text)?.[1] ?? (/local time/iu.test(text) ? 'local' : null);
  return {
    ticker, event: event?.ticker ?? null, series: series?.ticker ?? null,
    yes: { subTitle: market.yes_sub_title ?? null, title: market.title ?? null, rules: market.rules_primary ?? null, clarifications: market.rules_secondary ?? null },
    sources: (series?.settlement_sources ?? []).map((s) => s.name),
    contract: { url: series?.contract_url ?? null, termsUrl: series?.contract_terms_url ?? null },
    strike: { type: market.strike_type ?? null, floor: market.floor_strike ?? null, cap: market.cap_strike ?? null, custom: market.custom_strike ?? null },
    window: { open: market.open_time ?? null, close: market.close_time ?? null, expectedExpiration: market.expected_expiration_time ?? null, expiration: market.expiration_time ?? null, occurrence: market.occurrence_datetime ?? null, timezone: zone, settlementTimerSeconds: market.settlement_timer_seconds ?? null },
    payout: { currency: 'USD', perContract: market.notional_value ?? 1, tick: market.price_level_structure ?? null, ranges: market.price_ranges ?? null },
    earlyClose: { allowed: market.can_close_early ?? null, condition: market.early_close_condition ?? null },
    fee: { type: series?.fee_type ?? null, multiplier: series?.fee_multiplier ?? null },
    state: { status: market.status ?? null, result: market.result ?? null, volume: market.volume ?? null, openInterest: market.open_interest ?? null, liquidity: market.liquidity ?? null },
  };
}

/** A market is open for trading when Kalshi reports it active. */
export const isOpen = (status) => status === 'active' || status === 'open';

/**
 * Each settlement source -> its series -> { markets, volume } over open markets. Folded one predicate
 * at a time into maps keyed by ticker, each query result dropped before the next.
 */
export function settlementIndex(history) {
  const eventOf = new Map();
  const open = new Map(); // market -> event, open markets only
  for (const { subject, object } of queryHistory(history, { predicate: predicate('market', 'status') })) if (isOpen(object)) open.set(subject, null);
  for (const { subject, object } of queryHistory(history, { predicate: predicate('market', 'event') })) if (open.has(subject)) open.set(subject, object);
  const volumes = new Map();
  for (const { subject, object } of queryHistory(history, { predicate: predicate('market', 'volume') })) if (open.has(subject)) volumes.set(subject, object);
  for (const { subject, object } of queryHistory(history, { predicate: predicate('event', 'series') })) eventOf.set(subject, object);
  const bySeries = new Map();
  for (const [market, event] of open) {
    const series = eventOf.get(event);
    if (series === undefined) continue;
    const row = bySeries.get(series) ?? { markets: 0, volume: 0 };
    row.markets += 1; row.volume += volumes.get(market) ?? 0;
    bySeries.set(series, row);
  }
  const index = {};
  for (const { subject: series, object: sources } of queryHistory(history, { predicate: predicate('series', 'settlement_sources') })) {
    const row = bySeries.get(series);
    if (!row) continue;
    for (const { name } of sources.length ? sources : [{ name: '(none declared)' }]) ((index[name] ??= {})[series] = { ...row });
  }
  for (const [series, row] of bySeries) {
    if (!queryHistory(history, { subject: series, predicate: predicate('series', 'settlement_sources') }).length) ((index['(none declared)'] ??= {})[series] = { ...row });
  }
  return index;
}

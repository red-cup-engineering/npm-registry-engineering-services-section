/**
 * The venue's live tell for one account: Kalshi's authenticated WebSocket, every market frame admitted into the
 * arena position (src/arena.mjs) as it arrives, and the account's private channels beside it.
 *
 * - The followed markets change while the stream runs (`follow`); each market channel (books, trades, lifecycle) is
 *   reconciled from the wanted set to what the venue has subscribed, one command at a time per channel. A sequence
 *   gap the arena tells re-subscribes that channel, so its books are snapshotted afresh.
 * - The private channels (fills, positions, order groups, order updates) are subscribed for the whole account.
 * - A stream that closes, errors, or goes silent for `silentMs` while it follows markets settles `failed`. It does
 *   not reconnect itself: its owner is a FeltOS application service, which the supervisor restarts with backoff, so
 *   the owner rebuilds orders and positions from the venue each time rather than trusting a gap.
 */
import { authHeaders } from './signing.mjs';
import { kalshiArena, admitFrame } from './arena.mjs';

export const KALSHI_STREAM = Object.freeze({ url: 'wss://api.elections.kalshi.com/trade-api/ws/v2' });
export const MARKET_CHANNELS = Object.freeze(['orderbook_delta', 'trade', 'market_lifecycle_v2']);
export const ACCOUNT_CHANNELS = Object.freeze(['fill', 'market_positions', 'order_group_updates', 'user_orders']);
const ARENA_TYPES = new Set(['orderbook_snapshot', 'orderbook_delta', 'trade', 'market_lifecycle_v2', 'ticker']);

/**
 * @param {{credentials: {apiKeyId: string, privateKeyPem: string}, url?: string, WebSocketImpl?: typeof WebSocket,
 *   now?: () => number, onMove?: (move: object, events: object[], receivedAt: number) => void,
 *   onAccount?: (message: object, receivedAt: number) => void, silentMs?: number, accountChannels?: string[]}} options
 */
export async function openKalshiStream({ credentials, url = KALSHI_STREAM.url, WebSocketImpl = globalThis.WebSocket, now = Date.now,
  onMove = () => {}, onAccount = () => {}, silentMs = 30_000, accountChannels = ACCOUNT_CHANNELS }) {
  const headers = await authHeaders({ ...credentials, method: 'GET', path: new URL(url).pathname });
  delete headers.accept; delete headers['content-type'];
  const socket = new WebSocketImpl(url, { headers });
  let position = kalshiArena.initialPosition(), nextId = 1, lastMessageAt = now(), settle, watchdog = null, closed = false;
  const failed = new Promise((resolve) => { settle = resolve; });
  const wanted = new Set(), commands = new Map(), sids = new Map();
  // Per market channel: the venue's subscription id, the markets it covers, and the one command in flight.
  const channels = new Map(MARKET_CHANNELS.map((c) => [c, { sid: null, markets: new Set(), inFlight: null }]));
  const fail = (reason) => { if (closed) return; closed = true; clearInterval(watchdog); try { socket.close(); } catch {} settle(reason instanceof Error ? reason : new Error(String(reason))); };
  const send = (cmd, params, channel = null) => { const id = nextId++; commands.set(id, { cmd, channel }); socket.send(JSON.stringify({ id, cmd, params })); return id; };

  function reconcile(channel) {
    const state = channels.get(channel);
    if (state.inFlight !== null || closed) return;
    if (state.sid === null) {
      if (!wanted.size) return;
      state.markets = new Set(wanted);
      state.inFlight = send('subscribe', { channels: [channel], market_tickers: [...wanted] }, channel);
      return;
    }
    const add = [...wanted].filter((t) => !state.markets.has(t)), remove = [...state.markets].filter((t) => !wanted.has(t));
    if (add.length) { for (const t of add) state.markets.add(t); state.inFlight = send('update_subscription', { sids: [state.sid], market_tickers: add, action: 'add_markets' }, channel); }
    else if (remove.length) { for (const t of remove) state.markets.delete(t); state.inFlight = send('update_subscription', { sids: [state.sid], market_tickers: remove, action: 'delete_markets' }, channel); }
  }

  socket.addEventListener('message', (event) => {
    const receivedAt = now(); lastMessageAt = receivedAt;
    let m; try { m = JSON.parse(String(event.data)); } catch { return fail(new Error('the venue sent a frame that is not JSON')); }
    const command = m.id === undefined ? null : commands.get(m.id);
    if (command) commands.delete(m.id);
    if (m.type === 'error') return fail(new Error(`venue refused ${command?.cmd ?? 'a command'}: ${m.msg?.code ?? ''} ${m.msg?.msg ?? ''}`.trim()));
    if (m.type === 'subscribed') {
      sids.set(m.msg.sid, m.msg.channel);
      const state = channels.get(m.msg.channel);
      if (state) { state.sid = m.msg.sid; state.inFlight = null; reconcile(m.msg.channel); }
      return;
    }
    if (m.type === 'ok' || m.type === 'unsubscribed') {
      if (command?.channel) { channels.get(command.channel).inFlight = null; reconcile(command.channel); }
      // An acknowledgement on a subscription still occupies its sequence.
      if (m.sid === undefined || m.seq === undefined || !sids.has(m.sid)) return;
    } else if (!ARENA_TYPES.has(m.type)) return onAccount(m, receivedAt);
    for (const move of admitFrame(position, m)) {
      const { state, events } = kalshiArena.extend(position, move);
      position = state;
      onMove(move, events, receivedAt);
      if (move.kind === 'gap') {
        // A skipped sequence leaves that channel's books unknown: drop the subscription and take it again.
        const channel = sids.get(move.sid), state = channel && channels.get(channel);
        if (state && state.sid === move.sid) { sids.delete(move.sid); send('unsubscribe', { sids: [move.sid] }); Object.assign(state, { sid: null, markets: new Set(), inFlight: null }); reconcile(channel); }
      }
    }
  });
  socket.addEventListener('close', (event) => fail(new Error(`the venue closed the stream (${event.code ?? 'no code'} ${event.reason ?? ''})`.trim())));
  socket.addEventListener('error', (event) => fail(new Error(`stream error: ${event.message ?? event.error?.message ?? 'unknown'}`)));
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    failed.then(reject);
  });
  if (accountChannels.length) send('subscribe', { channels: [...accountChannels] });
  watchdog = setInterval(() => { if (wanted.size && now() - lastMessageAt > silentMs) fail(new Error(`no venue message for ${silentMs} ms`)); }, Math.min(5_000, silentMs));
  watchdog.unref?.();

  return Object.freeze({
    /** The replicated books of every followed market. */
    position: () => position,
    lastMessageAt: () => lastMessageAt,
    /** Follow exactly these markets: newly named ones are snapshotted, dropped ones unsubscribed. */
    follow(tickers) {
      wanted.clear(); for (const t of tickers) wanted.add(t);
      for (const channel of MARKET_CHANNELS) reconcile(channel);
    },
    following: () => [...wanted],
    failed,
    close: async () => { if (!closed) { closed = true; clearInterval(watchdog); settle(new Error('closed by its owner')); try { socket.close(1000, 'owner closed'); } catch {} } },
  });
}

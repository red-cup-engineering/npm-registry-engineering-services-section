/** The desk's stored live scores (live-scores.mjs belief-score rows) in a settlement root's weather-market-making log. Read-only. */
import { feedRowsWithAttribute, unmark } from './seavt-log.mjs';

export const FEED = 'weather-market-making';

/** The belief-score rows of a root (of one account when given): the running state, never the beliefs behind it. */
export function storedScores(root, account = null) {
  const rows = [];
  try {
    for (const row of feedRowsWithAttribute(root, FEED, ['belief-score'])) {
      try { const v = unmark(row.v); if (v?.kind === 'belief-score' && (account === null || v.account === account)) rows.push(v); } catch { /* an unreadable row scores nothing */ }
    }
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  return rows;
}

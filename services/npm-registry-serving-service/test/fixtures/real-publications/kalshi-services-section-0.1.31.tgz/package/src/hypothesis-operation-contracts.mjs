import { schemaFrom } from '@red-cup-engineering/json-schema-services-section/contracts';

// The host owns custody of the research root and registered specifications. Callers
// choose resource expenditure and a pass, never filesystem paths or a new criterion.
export const hypothesisRunRequestContract = schemaFrom({
  $id: 'kalshi/hypotheses/run-request',
  type: 'object', additionalProperties: false, required: ['mode', 'requestBudget'],
  properties: {
    mode: { enum: ['collect', 'all', 'sync', 'verdict'] },
    requestBudget: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
  },
});

export const hypothesisStatusRequestContract = schemaFrom({
  $id: 'kalshi/hypotheses/status-request',
  type: 'object', additionalProperties: false,
});

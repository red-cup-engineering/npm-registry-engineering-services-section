/**
 * What the published index can still do before an hourly contract settles, and so which outcomes the observations
 * have already excluded.
 *
 * Contract (the desk's observation invariant, enforced in weather-quotes ladderQuotes): the desk never quotes to buy an
 * outcome that this module says the observed index excludes. From the latest published index value v0 at t0, the
 * value at the settlement minute lies in [v0 - fall(h) * SAFETY, v0 + rise(h) * SAFETY], h the minutes from t0 to it,
 * where rise and fall are the largest moves the index ever made over that horizon (forecasting's
 * weather-index-rate-envelope.json, derived by its scripts/hourly-index-rate-envelope.mjs from the published minute
 * series, and its rule, both imported from @red-cup-engineering/forecasting/weather-index-rate-envelope). YES (index > K.99) is
 * excluded when the whole range lies below K.99 + 0.005; NO when it lies above. When there is no fresh anchor, or the
 * city's recent readings have themselves moved further than the table over some horizon, the table does not apply
 * and nothing is excluded (the model's probability, bounded by the stake budget, is then all the desk has).
 *
 * This is a bound on the physics, not a probability: it does not make the other outcomes likely. On 2026-10-17 it
 * did not exclude Miami's 16:30Z T83.99 YES (86.72 F anchor, 29 minutes, a fall of up to 11.5 F allowed).
 */
import { reachableRange as indexReachableRange, ENVELOPE, SAFETY, MAX_ANCHOR_AGE_MS, FALSIFIER_WINDOW_MS, exceedsEnvelope } from '@red-cup-engineering/forecasting/weather-index-rate-envelope';

export { ENVELOPE, SAFETY, MAX_ANCHOR_AGE_MS, FALSIFIER_WINDOW_MS, exceedsEnvelope };

/**
 * The range [low, high] (F) the index can reach at `target` (ms), or null when no bound is told. The rate table and the
 * rule are forecasting's (it owns them; imported, not copied).
 * @param {{city: string, points: {t: number, v: number}[], now: number, target: number}} input points: published readings, ascending
 */
export function reachableRange({ city, points, now, target, envelope = ENVELOPE }) {
  const range = indexReachableRange({ city, points, now, target, envelope });
  return range ? { low: range.low, high: range.high } : null;
}

/** Which outcomes of "index above strike" the range excludes: {yes, no}. The index is whole cents, so YES is v >= strike + 0.01. */
export function excludedOutcomes(range, strike) {
  if (!range) return { yes: false, no: false };
  return { yes: range.high < strike + 0.005, no: range.low >= strike + 0.005 };
}

/**
 * A character's standing on a claim, kept in SignCraft's knowledge base (the K of the MAPE-K loop).
 *
 * A character is one of our strategies playing the arena. Each measurement about one of its claims
 * (for example "kalshi-weather-tail has-edge") is told for when its interval lies above zero and against
 * when it lies below, witnessed by the measurement's id; an interval straddling zero tells nothing.
 * Evidence only accumulates, so a claim supported by one measurement and refuted by another settles
 * told-both. The standing is that settled point read in four.mjs's extremal family.
 */
import { KnowledgeBase } from '@red-cup-engineering/signcraft/knowledge-base';
import { readingAs } from '@red-cup-engineering/computer-data-engineering-services-section/four';

export const createStandings = () => new KnowledgeBase();

/** Tell one measured interval about (character, claim), witnessed by `witness` (the measurement's id). */
export function tellInterval(kb, character, claim, witness, [lo, hi]) {
  const at = { subject: character, predicate: claim, object: character };
  if (lo > 0) kb.tell(at, witness); else if (hi < 0) kb.tellAgainst(at, witness);
  return kb;
}

/** The settled standing of (character, claim), named in four.mjs's extremal reading family. */
export const standing = (kb, character, claim) => readingAs('extremal', kb.readingAt(character, claim));

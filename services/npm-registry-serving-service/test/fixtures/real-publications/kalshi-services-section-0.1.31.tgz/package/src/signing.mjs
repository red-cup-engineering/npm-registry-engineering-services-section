// Kalshi trade-API request signing. The pre-sign text is
// `${timestampMs}${METHOD}${path}` (path without query), sent as
// KALSHI-ACCESS-KEY / KALSHI-ACCESS-SIGNATURE / KALSHI-ACCESS-TIMESTAMP.
// Kalshi picks the verification algorithm from the registered public key, so
// the signer follows the private key: Ed25519 signs the text directly, RSA
// uses PSS with SHA-256 and a digest-length salt. The PEM header does not tell
// the two apart (PKCS#8 RSA also reads BEGIN PRIVATE KEY); the key's algorithm
// identifier does.
// WebCrypto only, so the same signer runs in Node and in a Worker host. Key
// generation, which only the signer host's provisioning does, lives in
// provisioning.mjs.

const ED25519_OID = [0x06, 0x03, 0x2b, 0x65, 0x70]; // 1.3.101.112
const SALT_LENGTH = 32; // SHA-256's digest length

function derOf(pem) {
  const base64 = pem.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
  return Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
}
function isEd25519(der) {
  for (let i = 0; i + ED25519_OID.length <= der.length; i += 1) if (ED25519_OID.every((byte, j) => der[i + j] === byte)) return true;
  return false;
}
function base64Of(bytes) {
  let text = '';
  for (let i = 0; i < bytes.length; i += 0x8000) text += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(text);
}

// Cache nonextractable handles only, addressed by a digest of DER. A worker
// handling many Persons must not retain their plaintext PEM as global Map keys.
// This memoization allocation is at most 32 handles, reused for at most one minute; expired entries are pruned on access.
const imported = new Map();
const HANDLE_LIMIT = 32;
const HANDLE_TTL_MS = 60_000;
async function signerOf(privateKeyPem) {
  const der = derOf(privateKeyPem);
  try {
    const digest = await crypto.subtle.digest('SHA-256', der);
    const identity = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
    const now = Date.now();
    for (const [hash, entry] of imported) if (now - entry.importedAt >= HANDLE_TTL_MS || now < entry.importedAt) imported.delete(hash);
    const prior = imported.get(identity);
    if (prior) return prior.signer;
    const signer = isEd25519(der)
      ? { key: await crypto.subtle.importKey('pkcs8', der, { name: 'Ed25519' }, false, ['sign']), params: { name: 'Ed25519' } }
      : { key: await crypto.subtle.importKey('pkcs8', der, { name: 'RSA-PSS', hash: 'SHA-256' }, false, ['sign']), params: { name: 'RSA-PSS', saltLength: SALT_LENGTH } };
    while (imported.size >= HANDLE_LIMIT) imported.delete(imported.keys().next().value);
    imported.set(identity, { signer, importedAt: now });
    return signer;
  } finally { der.fill(0); }
}

export async function signRequest({ privateKeyPem, timestampMs, method, path }) {
  const { key, params } = await signerOf(privateKeyPem);
  const signature = await crypto.subtle.sign(params, key, new TextEncoder().encode(`${timestampMs}${method.toUpperCase()}${path}`));
  return base64Of(new Uint8Array(signature));
}

export async function authHeaders({ apiKeyId, privateKeyPem, method, path, timestampMs = Date.now() }) {
  return {
    'KALSHI-ACCESS-KEY': apiKeyId,
    'KALSHI-ACCESS-SIGNATURE': await signRequest({ privateKeyPem, timestampMs, method, path }),
    'KALSHI-ACCESS-TIMESTAMP': String(timestampMs),
    accept: 'application/json',
    'content-type': 'application/json',
  };
}

/** One strategy definition, parameterized by the account whose funds it uses. */
import source from '../services/kalshi-stake-path-service/content/config/kalshi-desk-policy.json' with { type: 'json' };
import { kalshiAccount } from './accounts.mjs';

export function readDeskPolicy(env = process.env) {
  const account = kalshiAccount(env);
  if (!account.deskOrders || account.strategyAccountId !== source.principal.actorId)
    throw new TypeError('account-strategy-unconfigured');
  const policy = structuredClone(source);
  if (account.id === source.principal.actorId) return policy;
  policy.principal = { actorId: account.id, role: 'account-owner' };
  policy.strategySource = { accountId: account.strategyAccountId, policyVersion: source.version,
    adoptedOn: '2026-10-14', basis: "Esther's strategy is to use Morgan's strategy, and Morgan consents to sharing their strategy with Esther." };
  // The source's original $25 seed is historical information about Morgan.
  // The allocator already sizes from this account's observed venue equity.
  policy.seedReferenceUsd = null;
  return policy;
}

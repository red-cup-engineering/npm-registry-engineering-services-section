/**
 * Whether the weather market maker's recorded shadow run meets the acceptance gates of
 * content/text/documents/specifications/weather-market-making.md section 8, gate 5 (shadow run), over a stated window.
 * Pure: rows in, verdict out. scripts/amm-readiness.mjs reads the rows; nothing here reads, writes or re-arms anything.
 *
 * The desk's ledger rows (weather-market-maker.mjs): `start` (mode, strategy, equity), `rest` (an order and the fair
 * value it rested at), `fill` (contracts at a price, with the fill-conditioned fair value P(YES | this fill)), and `settle`
 * (a ladder's index value, payout, cost and P&L). Everything is judged on settled ladders: a fill with no settlement
 * in the window is not yet an outcome.
 *
 * Independence. The strikes of one ladder settle on one index value, so the unit of evidence is the ladder, not the
 * contract or the fill: every statistic below is a t-statistic over per-ladder totals (cluster-robust), never over fills.
 *
 * Gates (each a stated rule; "insufficient" fails, since no evidence is not evidence of soundness):
 *   evidence      at least MIN_LADDERS settled ladders in which the desk filled, and MIN_FILLS filled contracts.
 *                 Thirty is the least for which a t-statistic's normal approximation is usable.
 *   pnl           total P&L above zero and the one-sided 95% lower bound of mean per-ladder P&L above zero (spec 8.2: positive
 *                 P&L with its confidence interval); each city with at least MIN_LADDERS ladders must not have its upper bound below zero.
 *   drawdown      the largest peak-to-trough fall of cumulative settled P&L, as a share of the equity the window began with,
 *                 within the order risk gate's loss limit (content/config/order-risk-limits.json lossFraction): a desk that
 *                 would trip the live latch in shadow is not ready to be armed.
 *   fill          the desk's quotes fill: filled contracts at least MIN_FILLS, and the fill rate (filled over rested contracts) told.
 *   modelVsMarket the model must beat the market live (live-scores.mjs): on at least MIN_LADDERS ladders scored against the
 *                 market's mid at the same instants, the bootstrap 95% interval of model-minus-market Brier and of log loss lies wholly
 *                 below zero, and no city with MIN_LADDERS ladders has its Brier interval wholly above zero. A model that does not
 *                 beat the market cannot pass: the replay's edge is a hypothesis until this gate holds.
 *   adverseSelect the wins the fills realized are not significantly fewer than the fill-conditioned fair value predicted
 *                 (one-sided 95% t on per-ladder realized-less-predicted wins), and the realized edge per contract is above zero:
 *                 the counterparties that hit the quotes did not know more than the model said they did (Glosten-Milgrom).
 */
import { liveStats, scoredLadders } from './live-scores.mjs';

export const MIN_LADDERS = 30;
export const MIN_FILLS = 30;
/** One-sided 95% normal quantile. */
export const Z95 = 1.6449;

const DAY = 86_400_000;
const eventOf = (ticker) => ticker.replace(/-T\d+(?:\.\d+)?$/u, '');
const strikeOf = (ticker) => { const m = /-T(\d+(?:\.\d+)?)$/u.exec(ticker); return m ? Number(m[1]) : null; };
const sum = (xs) => xs.reduce((a, b) => a + b, 0);
const round = (x, n = 4) => (Number.isFinite(x) ? Math.round(x * 10 ** n) / 10 ** n : null);

/** Mean, standard error and t of per-cluster totals; t is null with fewer than two clusters. */
export function clusterStats(values) {
  const n = values.length, mean = n ? sum(values) / n : 0;
  const sd = n > 1 ? Math.sqrt(sum(values.map((v) => (v - mean) ** 2)) / (n - 1)) : null, se = sd === null ? null : sd / Math.sqrt(n);
  return { n, mean, se, t: se ? mean / se : se === 0 ? (mean === 0 ? 0 : Math.sign(mean) * Infinity) : null, lower: se === null ? null : mean - Z95 * se, upper: se === null ? null : mean + Z95 * se };
}

/** Largest peak-to-trough fall of the running sum of `pnls` (in order), from a start of 0. */
export function maxDrawdown(pnls) {
  let level = 0, peak = 0, worst = 0;
  for (const p of pnls) { level += p; peak = Math.max(peak, level); worst = Math.max(worst, peak - level); }
  return worst;
}

/**
 * Assess one account's rows over the window (until - days, until].
 * @param {object[]} rows the account's ledger rows ({kind, at, ...}), any order
 * @param {{days: number, until: string, lossFraction: number}} options
 */
export function assessAccount(rows, { days, until, lossFraction }) {
  const to = Date.parse(until), from = to - days * DAY;
  const inWindow = rows.filter((r) => { const t = Date.parse(r.at); return t > from && t <= to; });
  const kind = (k) => inWindow.filter((r) => r.kind === k).sort((a, b) => Date.parse(a.at) - Date.parse(b.at));
  const settles = kind('settle'), fills = kind('fill'), rests = kind('rest'), starts = kind('start');
  const settledBy = new Map(settles.map((s) => [s.event, s]));

  // Per-ladder: P&L, and the wins the fills realized against what they predicted.
  const ladders = new Map();
  for (const s of settles) ladders.set(s.event, { event: s.event, city: s.city, pnl: s.pnl, cost: s.cost, contracts: 0, wins: 0, predicted: 0, edge: 0 });
  let unsettled = 0, unreadable = 0;
  for (const f of fills) {
    const settle = settledBy.get(eventOf(f.ticker)), strike = strikeOf(f.ticker);
    if (!settle) { unsettled += f.contracts; continue; }
    if (strike === null || !(f.fair >= 0 && f.fair <= 1) || !(f.contracts > 0)) { unreadable += 1; continue; }
    const l = ladders.get(settle.event), yesWins = settle.value > strike, wins = f.side === 'yes' ? yesWins : !yesWins;
    const predicted = f.side === 'yes' ? f.fair : 1 - f.fair;
    l.contracts += f.contracts; l.wins += f.contracts * (wins ? 1 : 0); l.predicted += f.contracts * predicted; l.edge += f.contracts * ((wins ? 1 : 0) - f.priceCents / 100);
  }
  // A ladder the desk held nothing on settles to zero and says nothing about it: P&L is judged on the ladders it traded.
  const settled = [...ladders.values()], all = settled.filter((l) => l.cost > 0 || l.contracts > 0), filled = all.filter((l) => l.contracts > 0);
  const filledContracts = sum(filled.map((l) => l.contracts)), restedContracts = sum(rests.map((r) => r.contracts));

  const pnl = clusterStats(all.map((l) => l.pnl)), total = sum(all.map((l) => l.pnl));
  const byCity = Object.fromEntries([...new Set(all.map((l) => l.city))].sort().map((city) => [city, { ladders: all.filter((l) => l.city === city).length, totalPnl: round(sum(all.filter((l) => l.city === city).map((l) => l.pnl))), ...(({ mean, lower, upper }) => ({ meanPnl: round(mean), lower: round(lower), upper: round(upper) }))(clusterStats(all.filter((l) => l.city === city).map((l) => l.pnl))) }]));
  const startEquity = settles.find((s) => s.cost > 0)?.equity ?? starts[0]?.equity ?? null;
  const drawdown = maxDrawdown(settles.filter((s) => s.cost > 0).map((s) => s.pnl)), drawdownFraction = startEquity > 0 ? drawdown / startEquity : null;
  const selection = clusterStats(filled.map((l) => l.wins - l.predicted)), edgePerContract = filledContracts ? sum(filled.map((l) => l.edge)) / filledContracts : null;

  const live = liveStats(inWindow.filter((r) => r.kind === 'belief-score')), p = live.pooled;
  const losingCities = Object.entries(live.byCity).filter(([, c]) => c.pooled.events >= MIN_LADDERS && c.pooled.dBrierCI[0] > 0).map(([city]) => city);
  const gates = {
    evidence: { pass: filled.length >= MIN_LADDERS && filledContracts >= MIN_FILLS, laddersSettled: settled.length, laddersTraded: all.length, laddersWithFills: filled.length, filledContracts, need: { laddersWithFills: MIN_LADDERS, filledContracts: MIN_FILLS } },
    pnl: { pass: total > 0 && pnl.lower !== null && pnl.lower > 0 && Object.values(byCity).every((c) => c.ladders < MIN_LADDERS || c.upper === null || c.upper >= 0), totalPnl: round(total), meanPerLadder: round(pnl.mean), lower95: round(pnl.lower), byCity },
    drawdown: { pass: drawdownFraction !== null && drawdownFraction <= lossFraction, drawdown: round(drawdown), startEquity: round(startEquity), fraction: round(drawdownFraction), limit: lossFraction },
    fill: { pass: filledContracts >= MIN_FILLS, filledContracts, restedContracts, fillRate: restedContracts ? round(filledContracts / restedContracts) : null, unsettledContracts: unsettled },
    modelVsMarket: { pass: p.events >= MIN_LADDERS && p.dBrierCI[1] < 0 && p.dLogLossCI[1] < 0 && losingCities.length === 0, laddersScored: p.events, minutes: p.minutes, modelBrier: p.modelBrier, marketBrier: p.marketBrier, dBrier: p.dBrier, dBrierCI: p.dBrierCI, dLogLoss: p.dLogLoss, dLogLossCI: p.dLogLossCI, losingCities, byCity: Object.fromEntries(Object.entries(live.byCity).map(([c, v]) => [c, { ladders: v.pooled.events, dBrier: v.pooled.dBrier, dBrierCI: v.pooled.dBrierCI }])) },
    adverseSelection: { pass: selection.t !== null && selection.t >= -Z95 && edgePerContract !== null && edgePerContract > 0, laddersWithFills: filled.length, winsRealizedMinusPredicted: round(sum(filled.map((l) => l.wins - l.predicted))), meanPerLadder: round(selection.mean), t: round(selection.t, 2), realizedEdgePerContract: round(edgePerContract), realizedWins: round(sum(filled.map((l) => l.wins)), 2), predictedWins: round(sum(filled.map((l) => l.predicted)), 2) },
  };
  const modes = [...new Set(starts.map((s) => s.mode))].sort();
  return { rows: inWindow.length, window: { from: new Date(from).toISOString(), until: new Date(to).toISOString(), days }, modes, unreadableFills: unreadable, gates, pass: Object.values(gates).every((g) => g.pass) };
}

/**
 * The verdict over every account's rows. The window ends at `until`, by default the instant of the latest row (so the
 * same rows always give the same verdict).
 * @param {object[]} rows every ledger row, each naming its account
 * @param {{days?: number, until?: string, lossFraction: number}} options
 */
export function assess(rows, { days = 7, until, lossFraction }) {
  if (!(days > 0)) throw new RangeError('the window is a positive number of days');
  if (!(lossFraction > 0)) throw new RangeError('the loss limit is a positive fraction');
  const latest = rows.reduce((m, r) => Math.max(m, Date.parse(r.at) || 0), 0);
  const end = until ?? (latest ? new Date(latest).toISOString() : null);
  if (!end) return { verdict: 'fail', reasons: ['no recorded decisions: the weather market maker has logged no rows'], window: { days, until: null }, accounts: {} };
  const accounts = Object.fromEntries([...new Set(rows.map((r) => r.account ?? 'unnamed'))].sort().map((a) => [a, assessAccount(rows.filter((r) => (r.account ?? 'unnamed') === a), { days, until: end, lossFraction })]));
  const reasons = [];
  for (const [a, r] of Object.entries(accounts)) for (const [g, v] of Object.entries(r.gates)) if (!v.pass) reasons.push(`${a}: ${g}`);
  return { verdict: reasons.length === 0 && Object.keys(accounts).length > 0 ? 'pass' : 'fail', reasons, window: { days, until: end }, accounts };
}

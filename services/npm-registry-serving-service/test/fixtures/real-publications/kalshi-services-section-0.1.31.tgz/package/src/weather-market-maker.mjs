/**
 * The Kalshi hourly-temperature market maker (content/text/documents/specifications/weather-market-making.md): the
 * section's ASSIST application keeps one running per account that has opted in, as FeltOS application services.
 *
 * - Stations. Each index city's tracker (forecasting weather-index-lattice) is fed every station reading the moment
 *   Kalshi's own index feed lists it, with the city's published calibrations and NOAA's LAMP guidance.
 * - Ladders. The open hourly ladders of each city's series are followed on the venue stream (stream.mjs), whose
 *   arena position is the book.
 * - The account. The account's holder may trade by hand beside the desk, and the Group's other accounts quote the
 *   same ladders. So the desk reads the account as the venue holds it, whoever traded it: its resting orders (REST at
 *   start, then the private order channel), its positions (likewise, the position channel) and its cash (re-read
 *   whenever a fill, a settlement or the holder's own order moves it). The Group's resting orders, every account's,
 *   are one book presence (`group`): the desk never outbids them and never trades into them. The holder's
 *   positions are holdings the desk's utility hedges like its own.
 * - Quotes. Every second each ladder's fair values (the weather model's probability, calibrated per lead and side on
 *   the fills of that side) are recomputed and quoted (weather-quotes.mjs) at the margin of the probability's band
 *   (content/config/weather-market-making.json). A resting quote is
 *   changed only when the requote rule says so (weather-quotes requote), so it keeps its place in the queue. Quotes
 *   are pulled when the station feed is stale or the book unknown.
 * - Capital. Every ladder's quotes together may not commit more than the desk's cash: the account's available cash
 *   plus what the desk's own resting orders hold (its share `capitalFraction`). When they would, the desk's capital
 *   has a price: the hurdle rate at which they just fit (position-sizing capitalTimeAllocation's KKT, here over the
 *   quotes standing now), and each ladder pays that rate times its lead as carry. A ladder that settles sooner frees
 *   its capital sooner, so turnover is preferred exactly as far as that carry says.
 * - Shadow (no executor). A quote rests virtually: it joins its price level behind the contracts already there and
 *   fills from the takes that reach it (all of a level when a take prints through it). Its fills and settlements
 *   are virtual holdings and cash on top of the account's real ones, so the ledger is what live quoting would have
 *   earned.
 * - Attribution. The ledger records the desk's own orders, fills and settlements, tagged with the account; a
 *   settlement's P&L is the desk's fills' alone, never the holder's hand trades.
 *
 * Every effect is a port: `client` (the account's venue REST client), `openStream`, `guidance(city, stations)` (the
 * latest LAMP bulletins for those stations), `ledger.append(rows)`, `clock`, and `every(ms, f)` (run f every ms, the
 * desk's own cadences; returns a stop), so a session can run on a simulated venue's clock.
 */
import { createIndexTracker, celsiusOf } from '@red-cup-engineering/forecasting/weather-index-lattice';
import { lampTemperatureChange } from '@red-cup-engineering/forecasting/lamp-station-guidance';
import { INDEX_CITIES } from '@red-cup-engineering/forecasting/weather-index';
import { ONE, marketAt } from './arena.mjs';
import { bandMargin, calibratedValue, ladderQuotes, requote, strikeProbabilitiesOf, nonIncreasing } from './weather-quotes.mjs';
import { CLIENT_ORDER_PREFIX } from './venue-executor.mjs';
import { excludedOutcomes, reachableRange } from './weather-exclusion.mjs';
import { scoreLadder, scoredLadders, cellStats, BUCKETS as SCORE_BUCKETS, LIVE_MIN_EVENTS, LIVE_MIN_POOLED_EVENTS } from './live-scores.mjs';
import { liveTolerance, liveStakeCap } from './policy-derivation.mjs';

const MINUTE = 60_000, HOUR = 3_600_000, BUCKETS = [5, 10, 20, 30, 45, 61], CENT = ONE / 100;
const bucketOf = (lead) => `<${BUCKETS.find((b) => lead < b) ?? 61}`;
const localHourOf = (city) => {
  const format = new Intl.DateTimeFormat('en-US', { timeZone: INDEX_CITIES[city].timeZone, hour: 'numeric', hourCycle: 'h23' }), cache = new Map();
  return (t) => { const key = Math.floor(t / 3_600_000); let h = cache.get(key); if (h === undefined) { h = Number(format.format(new Date(key * 3_600_000))); cache.set(key, h); } return h; };
};
const fixed = (value) => { const n = Number(value); return Number.isFinite(n) ? n : null; };

/** The open hourly ladders of an event list: greater-than strikes by strike, settling in the future. */
export function laddersOf(events, now) {
  const out = [];
  for (const event of events) {
    const strikes = (event.markets ?? []).filter((m) => m.strike_type === 'greater' && m.status === 'active' && Number.isFinite(Number(m.floor_strike)))
      .map((m) => ({ ticker: m.ticker, strike: Number(m.floor_strike), settle: Date.parse(m.close_time), last: Number.isFinite(Number(m.last_price_dollars)) && Number(m.last_price_dollars) > 0 ? Number(m.last_price_dollars) : null })).sort((a, b) => a.strike - b.strike);
    if (!strikes.length || !(strikes[0].settle > now) || strikes.some((s) => s.settle !== strikes[0].settle)) continue;
    out.push({ event: event.event_ticker, settle: strikes[0].settle, strikes: strikes.map(({ ticker, strike }) => ({ ticker, strike })), last: Object.fromEntries(strikes.map(({ ticker, last }) => [ticker, last])) });
  }
  return out;
}

/**
 * A virtual resting order, filled from the takes that reach it. A YES bid at p is hit by a taker selling YES at
 * p or lower; a NO bid at n is a YES ask at 100 - n, lifted by a taker buying YES at it or higher. A take at the
 * price eats the queue ahead first; one through the price consumed the whole level.
 * @returns {number} contracts filled by this take
 */
export function fillFromTake(order, take) {
  const remaining = order.contracts - order.filled;
  if (remaining <= 0 || take.ticker !== order.ticker) return 0;
  const priceCents = take.price / CENT, size = take.size / 100;
  const atLevel = order.side === 'yes' ? take.taker === 'no' && priceCents <= order.priceCents : take.taker === 'yes' && priceCents >= 100 - order.priceCents;
  if (!atLevel) return 0;
  const through = order.side === 'yes' ? priceCents < order.priceCents : priceCents > 100 - order.priceCents;
  if (through) { order.ahead = 0; order.filled = order.contracts; return remaining; }
  const eaten = Math.min(order.ahead, size); order.ahead -= eaten;
  const filled = Math.min(remaining, size - eaten); order.filled += filled;
  return filled;
}

/**
 * The Group's resting orders on the venue, every account's, as one book presence: the desks of several accounts
 * share one, so no account's desk outbids or trades into another's (or its own holder's) orders.
 */
export function createGroupBook() {
  const orders = new Map();
  return Object.freeze({
    /** Record (or with null, forget) one account's resting order. */
    set(account, orderId, entry) { const id = `${account}:${orderId}`; if (entry && entry.remaining > 0) orders.set(id, { account, ...entry }); else orders.delete(id); },
    /** Forget every order of one account (its venue reading is replaced). */
    clear(account) { for (const [id, o] of orders) if (o.account === account) orders.delete(id); },
    /** The Group's contracts resting at a price (cents) on one side of a market. */
    at(ticker, side, cents) { let n = 0; for (const o of orders.values()) if (o.ticker === ticker && o.side === side && o.priceCents === cents) n += o.remaining; return n; },
    size: () => orders.size,
  });
}

/**
 * A venue order (REST row or private order message) as the bid it rests as, {ticker, side, priceCents, remaining,
 * desk}, or null when it does not rest. The book holds YES bids and NO bids: a buy of YES, or a sell of NO, is a YES
 * bid at its YES price; a sell of YES, or a buy of NO, is a NO bid at 100 less it (`book_side` bid / ask says which).
 */
export function restingOf(o) {
  const outcome = o.outcome_side ?? o.side, buys = (o.action ?? 'buy') === 'buy';
  const side = o.book_side === 'bid' ? 'yes' : o.book_side === 'ask' ? 'no' : outcome === 'yes' || outcome === 'no' ? ((outcome === 'yes') === buys ? 'yes' : 'no') : null;
  const yes = fixed(o.yes_price_dollars), remaining = fixed(o.remaining_count_fp ?? o.remaining_count);
  if (!side || yes === null || remaining === null || typeof o.ticker !== 'string') return null;
  if ((o.status ?? 'resting') !== 'resting' || !(remaining > 0)) return null;
  const priceCents = Math.round(side === 'yes' ? 100 * yes : 100 - 100 * yes);
  return { ticker: o.ticker, side, priceCents, remaining, clientOrderId: o.client_order_id ?? null, desk: String(o.client_order_id ?? '').startsWith(CLIENT_ORDER_PREFIX) };
}

/**
 * @param {object} options
 *   account: the account's name in the ledger and the Group book; group: the Group book shared by every account's
 *   desk; capitalFraction: the share of the account's cash the desk may use (the holder's consent; all of it by
 *   default); subaccount: the account's subaccount the desk trades (0 is the primary); strategy: the release that
 *   quotes, named on the run's start so a record is judged by the strategy that made it. onSettle(row): told each
 *   settled ladder.
 */
const intervals = (ms, f) => { const t = setInterval(f, ms); t.unref?.(); return () => clearInterval(t); };

export function createWeatherMarketMaker({ policy, fits, client, openStream, guidance = async () => [], ledger = { append: () => {} }, clock = Date.now, every = intervals, log = () => {}, executor = null, capitalFraction = 1, subaccount = 0, account = 'account', group = createGroupBook(), strategy = null, onSettle = () => {}, scoreHistory = [] }) {
  if (!(capitalFraction > 0 && capitalFraction <= 1)) throw new RangeError('the desk is given a positive share of the account, at most all of it');
  if (!(policy.maxStakeFraction > 0)) throw new RangeError('the policy bounds what one ladder may stake, as a positive share of the desk\'s equity (maxStakeFraction)');
  // The model scored live (live-scores.mjs): the desk's disagreement tolerance and stake cap are taken from its own settled
  // ladders once a cell holds LIVE_MIN_EVENTS of them (the cap, LIVE_MIN_POOLED_EVENTS across cells), else from the replay's.
  const liveRows = [...scoreHistory];
  let liveVersion = 0, liveCache = null;
  function live() {
    if (liveCache?.version === liveVersion) return liveCache;
    const ladders = scoredLadders(liveRows), cells = new Map();
    for (const city of new Set(ladders.map((l) => l.city))) for (const b of SCORE_BUCKETS) {
      const bucket = `<${b}`;
      cells.set(`${city}:${bucket}`, cellStats(ladders.filter((l) => l.city === city).map((l) => l.cells[bucket]), { resamples: 300 }));
    }
    liveCache = { version: liveVersion, cells, cap: liveStakeCap([...cells.values()], LIVE_MIN_EVENTS, LIVE_MIN_POOLED_EVENTS), ladders: ladders.length };
    return liveCache;
  }
  const stakeFraction = () => live().cap ?? policy.maxStakeFraction;
  const cities = Object.keys(policy.cities), scope = subaccount ? { subaccount } : {};
  const state = new Map(cities.map((city) => [city, { city, tracker: null, calibrations: [], bulletins: [], ladders: new Map(), staleSince: null }]));
  const orders = new Map(), desk = new Map(), settled = [];
  // The account as the venue holds it: resting orders by venue ID, net positions by ticker (+ YES, - NO), cash.
  const venueOrders = new Map(), positions = new Map();
  // The desk's cash as of the last reading: the account's available cash and what the desk's acknowledged resting
  // orders held when that reading was asked for (the venue holds a resting order's price out of available cash).
  let stream = null, available = 0, base = 0, virtualCash = 0, timers = [], closed = false, hurdle = 0, reading = null, wantCash = false;

  function trackerOf(s) {
    if (s.tracker) return s.tracker;
    const fit = fits.cities[s.city];
    s.tracker = createIndexTracker({ params: fit.params, climate: fit.climateDriftCPerMinuteByLocalHour, climateVariance: fit.climateVarianceC2PerMinuteByLocalHour,
      localHour: localHourOf(s.city), calibrations: s.calibrations, guidance: (station, from, to) => s.change?.(station, from, to) ?? null });
    return s.tracker;
  }

  /** Feed one poll of the city's index: every station record not yet seen, in minute order; a missing one once official. */
  function admitIndex(s, body, now) {
    const tracker = trackerOf(s);
    for (const point of [...(body?.timeseries ?? [])].sort((a, b) => a.t - b.t)) {
      for (const r of point.stations ?? []) {
        if (['ok', 'pending'].includes(r.code) && Number.isFinite(r.temp_f)) tracker.observe(r.station_id, point.t, { code: 'ok', celsius: celsiusOf(r.temp_f, r.source), source: r.source });
        else if (now >= point.t + 300_000) tracker.observe(r.station_id, point.t, { code: r.code ?? 'missing' });
      }
      if (point.v !== null && point.v !== undefined) s.published = { ...(s.published ?? {}), [point.t]: point.v };
    }
  }

  // --- The account, as the venue holds it.
  function noteOrder(orderId, o) {
    const entry = o ? restingOf(o) : null;
    if (entry) venueOrders.set(orderId, entry); else venueOrders.delete(orderId);
    group.set(account, orderId, entry);
    return entry;
  }
  /**
   * Read the account's cash. The desk's cash is the account's available cash plus what the desk's own resting orders
   * hold, both as of one moment: the desk resting, moving or cancelling its own orders shifts cash between the two and
   * leaves the sum alone, so only a fill, a settlement or the holder's own order is a reason to read again (Kalshi
   * allows one balance read a second). For the two halves to be of one moment, armed, a reading is taken only when no
   * desk write is in flight, and no desk write is sent while it is (tick waits for both); a reason arriving during a
   * reading reads again after it.
   */
  function readCash() {
    wantCash = false;
    const held = executor?.heldCost?.() ?? 0;
    reading = client.getBalance(scope).then((b) => { available = (b?.balance ?? 0) / 100; base = available + held; }, (error) => { wantCash = true; log(`[weather-market-maker] ${account} balance: ${error.message}\n`); })
      .finally(() => { reading = null; });
    return reading;
  }
  /** A reason to read the account's cash: read now when nothing is in flight (always, in shadow), else when tick can. */
  function rereadCash() {
    wantCash = true;
    if (!reading && (!executor || !pending.size)) return readCash();
    return reading;
  }
  /** A private-channel message: the account's orders, positions and fills, whoever placed them. */
  function onAccount(message) {
    const m = message?.msg ?? {};
    if (message?.type === 'user_order' && typeof m.order_id === 'string') {
      noteOrder(m.order_id, m);
      if (!String(m.client_order_id ?? '').startsWith(CLIENT_ORDER_PREFIX)) rereadCash();
    } else if (message?.type === 'market_position' && typeof m.market_ticker === 'string') {
      const n = fixed(m.position_fp); if (n !== null) positions.set(m.market_ticker, n);
    } else if (message?.type === 'fill') {
      executor?.account(message);
      rereadCash();
    } else if (message?.type === 'order_group_updates') executor?.account(message);
  }

  // --- The desk's own holdings (attribution) and, in shadow, its virtual cash.
  const deskOf = (ticker) => { if (!desk.has(ticker)) desk.set(ticker, { yes: 0, no: 0, costYes: 0, costNo: 0 }); return desk.get(ticker); };
  /** The account's holdings of a strike, for the utility: the venue's (the holder's and the desk's) plus, in shadow, the desk's virtual ones. */
  const heldOf = (ticker) => {
    const n = positions.get(ticker) ?? 0, h = { yes: Math.max(0, n), no: Math.max(0, -n) };
    if (!executor) { const d = desk.get(ticker); if (d) { h.yes += d.yes; h.no += d.no; } }
    return h;
  };
  // Armed, each quote's venue writes run in order (a cancel never overtakes the rest it follows); shadow, none run.
  // A quote with a write in flight is not decided again until that write is answered, so the desk never asks the
  // venue for more than one change per quote at a time and its writes can never outrun the account's write budget.
  // A write the venue refuses (a post-only rest the book has since reached, an amend of an order that has filled)
  // leaves the desk not knowing what rests for that quote: unless a later write for it is already queued, whatever
  // the venue still holds for it is cancelled and the quote forgotten, so the next tick plans it afresh.
  // A write that frees cash (a cancel, a move down, a shrink) is sent at once; one that needs more (a rest, a move up,
  // a growth) only when no write at all is in flight. The plan fits the desk's cash once every change has landed; with
  // every earlier change landed, each increase is weighed against the venue's settled state, and the plan's
  // increases less its releases fit what is free, so it keeps fitting while they land.
  const queues = new Map(), pending = new Set(), orphans = new Set();
  let releasing = 0;
  const venue = (key, effect, { releases = false } = {}) => {
    if (!executor) return;
    pending.add(key);
    if (releases) releasing += 1;
    const next = (queues.get(key) ?? Promise.resolve()).then(effect).catch(async (error) => {
      log(`[weather-market-maker] ${account} ${key}: ${error.message}\n`); ledger.append([{ kind: 'venue-error', account, at: at(clock()), key, error: error.message }]);
      if (queues.get(key) === next) { orders.delete(key); await executor.cancel({ key }).catch(() => {}); }
    }).finally(() => { if (releases) releasing -= 1; if (queues.get(key) === next) pending.delete(key); });
    queues.set(key, next);
  };
  /** Cancel the desk's resting orders this run does not own: rested by a write whose answer never came, or left by an earlier run. */
  function cancelOrphans(now) {
    for (const id of orphans) if (!venueOrders.has(id)) orphans.delete(id);
    for (const [id, o] of venueOrders) {
      if (!o.desk || orphans.has(id) || executor.owns({ order_id: id, client_order_id: o.clientOrderId })) continue;
      orphans.add(id);
      venue(`orphan:${id}`, () => executor.cancelOrphan(id, o.ticker));
      ledger.append([{ kind: 'cancel', account, at: at(now), order: id, ticker: o.ticker, side: o.side, priceCents: o.priceCents, contracts: o.remaining, reason: 'orphan' }]);
    }
  }
  /** Apply a fill of the quote `key` (from the shadow book or the venue): the desk's holdings, cash and the ledger. */
  function applyFill(key, n, priceCents, takeAt = null) {
    const order = orders.get(key); if (!order || !(n > 0)) return;
    const filled = Math.min(n, order.contracts - order.filled); order.filled += filled;
    const d = deskOf(order.ticker), cost = (filled * order.priceCents) / 100;
    d[order.side] += filled; d[order.side === 'yes' ? 'costYes' : 'costNo'] += cost;
    // The fill spent that cash on a position: the desk's cash falls by it now, not when the next reading lands (in
    // shadow, the virtual cash; armed, the reading's sum, which a re-read then confirms).
    if (!executor) virtualCash -= cost; else base -= cost;
    ledger.append([{ kind: 'fill', account, at: at(clock()), order: order.id, ticker: order.ticker, side: order.side, priceCents: order.priceCents, contracts: filled, fair: order.fair, lead: order.lead, takeAt, venue: Boolean(executor) }]);
    if (order.filled >= order.contracts) orders.delete(key);
  }
  // Holdings marked at their ladder's fair value (the midpoint of its two fill-conditioned values), at cost before
  // the ladder has one: a fill trades cash for a claim, it does not lose the cash.
  const markOf = (ladder) => ladder.strikes.reduce((sum, { ticker }) => {
    const h = heldOf(ticker), p = ladder.fair?.fair?.[ticker], d = desk.get(ticker);
    return sum + (Number.isFinite(p) ? h.yes * p + h.no * (1 - p) : (d?.costYes ?? 0) + (d?.costNo ?? 0));
  }, 0);
  const ladders = () => [...state.values()].flatMap((c) => [...c.ladders.values()]);
  // The desk's cash: the account's available cash plus what the desk's own resting orders hold on the venue (armed),
  // or plus its virtual fills and settlements (shadow), at the holder's consented share.
  const capital = () => Math.max(0, capitalFraction * (base + (executor ? 0 : virtualCash)));
  const wealth = () => capital() + ladders().reduce((sum, l) => sum + markOf(l), 0);
  const at = (now) => new Date(now).toISOString();

  function pull(ladder, reason, now) {
    for (const [key, order] of orders) if (order.event === ladder.event) { orders.delete(key); venue(key, () => executor.cancel(order), { releases: true }); ledger.append([{ kind: 'cancel', account, at: at(now), ...order, reason }]); }
  }

  /**
   * One strike's book in cents: everyone else's (the book less the Group's own resting orders) for priority, and the
   * whole book's best bid and offer for crossing. Null without depth.
   */
  function bookOf(position, ticker) {
    const m = position ? marketAt(position, ticker) : null;
    if (!m || m.stale || !m.yes || !m.no) return null;
    const levels = (side) => Object.entries(m[side]).map(([units, q]) => ({ cents: Number(units) / CENT, contracts: q / 100 }));
    const yes = levels('yes'), no = levels('no');
    const othersAt = (side) => (cents) => { const l = (side === 'yes' ? yes : no).find((x) => x.cents === cents); return l ? Math.max(0, l.contracts - group.at(ticker, side, cents)) : 0; };
    const best = (ls, f) => ls.reduce((b, l) => (f(l) > 0 && (b === null || l.cents > b) ? l.cents : b), null);
    const others = { yes: othersAt('yes'), no: othersAt('no') };
    const bestOthers = { yes: best(yes, (l) => others.yes(l.cents)), no: best(no, (l) => others.no(l.cents)) };
    const whole = { yes: best(yes, (l) => l.contracts), no: best(no, (l) => l.contracts) };
    return { bid: bestOthers.yes, ask: bestOthers.no === null ? null : 100 - bestOthers.no, cross: { bid: whole.yes, ask: whole.no === null ? null : 100 - whole.no }, othersAt: others, othersBest: bestOthers };
  }

  /** One ladder's state for quoting now (fair values, books, holdings), or why it is pulled. */
  function prepare(s, ladder, now) {
    const lead = (ladder.settle - now) / MINUTE, leadPolicy = policy.cities[s.city].leads?.[bucketOf(lead)];
    const tracker = trackerOf(s), latest = tracker.lastMinute();
    if (lead <= 0) return { pull: 'closed' };
    if (latest === null || now - latest > policy.staleAfterMs) { s.staleSince ??= now; return { pull: 'stations-stale' }; }
    s.staleSince = null;
    const position = stream?.position(), books = ladder.strikes.map(({ ticker }) => bookOf(position, ticker));
    if (books.some((b) => !b)) return { pull: 'book-unknown' };
    // What the published index can still reach by the settlement minute: the outcomes beyond it are never bought.
    const range = reachableRange({ city: s.city, points: Object.entries(s.published ?? {}).map(([t, v]) => ({ t: Number(t), v })).sort((a, b) => a.t - b.t), now, target: ladder.settle });
    const outcomes = ladder.strikes.map(({ strike }) => excludedOutcomes(range, strike));
    const excluded = { yes: outcomes.map((o) => o.yes), no: outcomes.map((o) => o.no) };
    const distribution = tracker.distribution(ladder.settle);
    if (!distribution) return { pull: 'no-distribution' };
    const model = strikeProbabilitiesOf(distribution, ladder.strikes.map((k) => k.strike));
    // The weather's probability, calibrated on the fills of each side; a side without a calibration at this lead abstains.
    const fairOf = (side) => (leadPolicy?.[side]?.calibration ? nonIncreasing(model.map((q) => calibratedValue(policy.calibrationEdges, leadPolicy[side].calibration, q))) : null);
    const fair = { yes: fairOf('yes'), no: fairOf('no') };
    const margins = { yes: model.map((q) => (fair.yes ? bandMargin(leadPolicy.yes.bands, q) : null)), no: model.map((q) => (fair.no ? bandMargin(leadPolicy.no.bands, q) : null)) };
    const mid = model.map((q, j) => (fair.yes && fair.no ? (fair.yes[j] + fair.no[j]) / 2 : fair.yes?.[j] ?? fair.no?.[j] ?? q));
    const byTicker = (values) => (values ? Object.fromEntries(ladder.strikes.map(({ ticker }, j) => [ticker, values[j]])) : null);
    ladder.fair = { at: now, lead, reachable: range, model: byTicker(model), fair: byTicker(mid), yes: byTicker(fair.yes), no: byTicker(fair.no) };
    const held = { yes: ladder.strikes.map(({ ticker }) => heldOf(ticker).yes), no: ladder.strikes.map(({ ticker }) => heldOf(ticker).no) };
    // The utility's base wealth: the desk's equity less this ladder's own mark, whose holdings it counts band by band.
    // The model-market disagreement the desk leans through at this lead (derived from the model's out-of-sample Brier excess
    // over the market, derive-fits.mjs); a lead without one never leans where observation has not settled the outcome.
    const liveTol = liveTolerance(live().cells.get(`${s.city}:${bucketOf(lead)}`), LIVE_MIN_EVENTS);
    return { lead, books, model, fair, margins, held, excluded, observed: latest, tolerance: liveTol ?? leadPolicy?.disagreementTolerance ?? 0, base: wealth() - markOf(ladder) };
  }

  /**
   * Log the model's probability for each strike beside the market's best bid and ask, when either has changed since the
   * last row for it (live-scores.mjs): a market is stored by its changes, never by its ticks.
   */
  function recordBeliefs(s, ladder, p, now) {
    const rows = [];
    ladder.beliefs ??= []; ladder.lastBelief ??= new Map();
    ladder.strikes.forEach(({ ticker }, j) => {
      const q = Math.round(p.model[j] * 1e4) / 1e4, { bid = null, ask = null } = p.books[j].cross ?? {}, key = `${q}|${bid}|${ask}`;
      if (ladder.lastBelief.get(ticker) === key) return;
      ladder.lastBelief.set(ticker, key);
      rows.push({ kind: 'belief', account, at: at(now), id: ticker, city: s.city, settle: ladder.settle, q, bid, ask, obs: `${s.city}@${at(p.observed)}` });
    });
    if (rows.length) { ladder.beliefs.push(...rows); ledger.append(rows); }
  }

  /** The ladder's quotes when the desk's capital costs `rate` (log growth per hour) for each hour it is locked. */
  function quotesAt(ladder, p, rate) {
    return ladderQuotes({ strikes: ladder.strikes, fair: p.fair, book: p.books.map(({ bid, ask }) => ({ bid, ask })), cross: p.books.map((b) => b.cross), wealth: p.base, holdings: p.held,
      relativeRiskAversion: policy.relativeRiskAversion, marginCents: p.margins, excluded: p.excluded, tolerance: p.tolerance,
      // Inventory limit (weather-quotes soundness): the same share of the desk's equity, counted on contracts held, not their model mark.
      inventoryBudget: stakeFraction() * wealth(),
      // One ladder is one weather: it stakes at most the policy's share of the desk's equity, counting what it holds.
      stakeBudget: Math.max(0, stakeFraction() * wealth() - markOf(ladder)),
      maxContracts: Math.max(0, Math.floor(capital() * 100)), carry: (rate * (p.lead * MINUTE)) / HOUR });
  }

  /**
   * One ladder's changes toward the plan: keep, resize, move or cancel each resting quote by the requote rule, rest
   * the new ones. Returns them, each marked by whether it frees cash, for tick to send in that order.
   */
  function changes(ladder, p, quotes, now) {
    const out = [];
    const { lead, books, model, fair } = p;
    const wanted = new Map(quotes.map((q) => [`${q.ticker}:${q.side}`, q]));
    const indexOf = (ticker) => ladder.strikes.findIndex((k) => k.ticker === ticker);
    const seen = (ticker, side) => { const j = indexOf(ticker); return { fair: side === 'yes' ? fair.yes[j] : fair.no[j], bid: books[j].bid, ask: books[j].ask, model: model[j] }; };
    for (const [key, order] of orders) {
      if (order.event !== ladder.event) continue;
      const q = wanted.get(key), book = books[indexOf(order.ticker)];
      wanted.delete(key);
      if (pending.has(key)) continue;
      // Everyone else's contracts at the order's price bound those still ahead of it (cancellations leave the queue).
      order.ahead = Math.min(order.ahead, book.othersAt[order.side](order.priceCents));
      const decision = requote({ order: { priceCents: order.priceCents, remaining: order.contracts - order.filled, ahead: order.ahead }, quote: q, othersAt: book.othersAt[order.side], othersBest: book.othersBest[order.side] });
      if (decision === 'keep') continue;
      if (decision === 'cancel') { out.push({ releases: true, send: () => { orders.delete(key); venue(key, () => executor.cancel(order), { releases: true }); ledger.append([{ kind: 'cancel', account, at: at(now), ...order, reason: 'unwanted' }]); } }); continue; }
      const price = decision === 'move' ? q.priceCents : order.priceCents, releases = price * q.contracts < order.priceCents * (order.contracts - order.filled);
      out.push({ releases, send: () => {
        const { fair: f, ...context } = seen(q.ticker, q.side);
        if (decision === 'move') Object.assign(order, { priceCents: q.priceCents, ahead: book.othersAt[order.side](q.priceCents), fair: f, reservationCents: q.reservationCents, lead });
        order.contracts = order.filled + q.contracts;
        const amended = { ...order, contracts: q.contracts };
        venue(key, () => executor.amend(amended), { releases });
        // An amend records what changed and why; the order itself is in its rest row, under the same order id.
        ledger.append([{ kind: 'amend', account, at: at(now), order: order.id, priceCents: order.priceCents, contracts: q.contracts, ahead: order.ahead, fair: order.fair, ...context, hurdle, reason: decision }]);
      } });
    }
    for (const [key, q] of wanted) {
      if (pending.has(key)) continue;
      out.push({ releases: false, send: () => {
        const book = books[indexOf(q.ticker)], { fair: f, ...context } = seen(q.ticker, q.side);
        const order = { id: `${account}:${q.ticker}:${q.side}:${now}`, key, event: ladder.event, ticker: q.ticker, side: q.side, priceCents: q.priceCents, contracts: q.contracts, filled: 0,
          ahead: book.othersAt[q.side](q.priceCents), placedAt: now, settle: ladder.settle, fair: f, reservationCents: q.reservationCents, lead };
        orders.set(key, order);
        const rested = { ...order };
        venue(key, () => executor.rest(rested));
        ledger.append([{ kind: 'rest', account, at: at(now), ...order, ...context, hurdle }]);
      } });
    }
    return out;
  }

  function onTake(take, now) {
    // The queue ahead of every quote shrinks with the takes at its price; shadow, the takes that reach it fill it
    // (armed, the venue's own fills do).
    for (const [key, order] of [...orders]) {
      const probe = { ...order }, n = fillFromTake(probe, take);
      order.ahead = probe.ahead;
      if (n && !executor) applyFill(key, n, order.priceCents, take.t ?? null);
    }
  }

  /** Settle a ladder from the index Kalshi published at its settlement minute: the desk's own fills' P&L. */
  function settle(s, ladder, now) {
    const value = s.published?.[ladder.settle];
    if (value === undefined || now < ladder.settle + 300_000) return false;
    let payout = 0, cost = 0;
    const equity = wealth();
    for (const { ticker, strike } of ladder.strikes) {
      const d = desk.get(ticker); if (!d) continue;
      payout += value > strike ? d.yes : d.no; cost += d.costYes + d.costNo;
      desk.delete(ticker);
    }
    if (!executor) virtualCash += payout; else rereadCash();
    const row = { kind: 'settle', account, at: at(now), event: ladder.event, city: s.city, settle: ladder.settle, equity, value, payout, cost, pnl: payout - cost };
    settled.push(row); ledger.append([row]); onSettle(row);
    // Score the ladder's recorded beliefs against the outcome and the market, and keep the running sums.
    const scored = scoreLadder(ladder.beliefs ?? [], row);
    if (scored.length) { ledger.append(scored); liveRows.push(...scored); liveVersion += 1; }
    return true;
  }

  async function poll(s) {
    const now = clock();
    try {
      const body = await client.call('GET', `/live_data/weather/${s.city}`, { query: { from: now - 15 * MINUTE, to: now, detailed: true }, signed: false });
      admitIndex(s, body, clock());
    } catch (error) { log(`[weather-market-maker] ${s.city} index: ${error.message}\n`); }
  }
  async function refreshLadders(s) {
    const now = clock();
    try {
      const events = await client.getEvents({ series_ticker: policy.cities[s.city].series, status: 'open', with_nested_markets: true });
      // A ladder that has closed stays held until it settles (tick); only new ladders are added here.
      for (const ladder of laddersOf(events, now)) if (!s.ladders.has(ladder.event)) s.ladders.set(ladder.event, ladder);
      stream?.follow([...state.values()].flatMap((c) => [...c.ladders.values()].flatMap((l) => l.strikes.map((k) => k.ticker))));
    } catch (error) { log(`[weather-market-maker] ${s.city} ladders: ${error.message}\n`); }
  }
  async function refreshCalibrations(s) {
    try {
      const body = await client.call('GET', `/live_data/weather/${s.city}/calibrations`, { signed: false });
      s.calibrations.splice(0, s.calibrations.length, ...(body?.calibrations ?? []));
    } catch (error) { log(`[weather-market-maker] ${s.city} calibrations: ${error.message}\n`); }
  }
  async function refreshGuidance(s) {
    try {
      // The members' ICAO stations; a new bulletin is usable only after its posting latency, so the last few are kept.
      const stations = [...new Set(s.calibrations.flatMap((c) => c.stations.map((m) => m.station_id.slice(0, 4))))];
      const fresh = stations.length ? await guidance(s.city, stations) : [];
      const byRuntime = new Map([...s.bulletins, ...fresh].map((b) => [b.runtime, b]));
      s.bulletins = [...byRuntime.values()].sort((a, b) => Date.parse(a.runtime) - Date.parse(b.runtime)).slice(-3);
      if (s.bulletins.length) s.change = lampTemperatureChange(s.bulletins);
    } catch (error) { log(`[weather-market-maker] ${s.city} guidance: ${error.message}\n`); }
  }
  /** The account as the venue holds it now: resting orders, positions and cash. */
  async function readAccount() {
    const [resting, held] = await Promise.all([client.getOrders({ status: 'resting', ...scope }), client.getPositions({ count_filter: 'position', ...scope })]);
    venueOrders.clear(); group.clear(account);
    for (const o of resting ?? []) if (typeof o.order_id === 'string') noteOrder(o.order_id, o);
    positions.clear();
    for (const p of held?.market_positions ?? []) { const n = fixed(p.position_fp ?? p.position); if (typeof p.ticker === 'string' && n) positions.set(p.ticker, n); }
    await rereadCash();
  }
  /**
   * Quote every open ladder at one hurdle: 0 when their quotes fit the desk's cash, else the rate at which they just
   * fit (the quotes' cost falls as carry rises), found by doubling then bisection.
   */
  function tick() {
    const now = clock(), open = [];
    for (const s of state.values()) for (const [event, ladder] of s.ladders) {
      if (now >= ladder.settle) { pull(ladder, 'closed', now); if (settle(s, ladder, now)) s.ladders.delete(event); continue; }
      const p = prepare(s, ladder, now);
      if (p.pull) pull(ladder, p.pull, now); else { recordBeliefs(s, ladder, p, now); open.push({ ladder, p }); }
    }
    const available = capital(), plan = (rate) => open.map(({ ladder, p }) => quotesAt(ladder, p, rate));
    const cost = (quotes) => quotes.flat().reduce((sum, q) => sum + (q.contracts * q.priceCents) / 100, 0);
    let rate = 0, chosen = plan(0);
    if (cost(chosen) > available) {
      let lo = 0, hi = 1 / 64;
      while (cost(plan(hi)) > available && hi < 2 ** 40) { lo = hi; hi *= 2; }
      for (let i = 0; i < 30; i += 1) { const mid = (lo + hi) / 2; if (cost(plan(mid)) > available) lo = mid; else hi = mid; }
      rate = hi; chosen = plan(hi);
    }
    hurdle = rate;
    // A cash reading in flight, or one waiting for the desk's writes to land, holds every write back.
    if (executor && wantCash && !reading && !pending.size) readCash();
    if (executor && (reading || wantCash)) return;
    const planned = open.flatMap(({ ladder, p }, i) => changes(ladder, p, chosen[i], now));
    const settled = !pending.size;
    for (const c of planned) if (c.releases) c.send();
    if (settled && !releasing) for (const c of planned) if (!c.releases) c.send();
    if (executor) cancelOrphans(now);
  }

  return Object.freeze({
    /** FeltOS application service start: read the account, open the stream, and begin. */
    async start({ signal } = {}) {
      if (executor) await executor.open();
      await readAccount();
      stream = await openStream({ onMove: (move, events) => { const now = clock(); for (const e of events) if (e.kind === 'take') onTake(e, now); }, onAccount });
      for (const s of state.values()) { await refreshCalibrations(s); await Promise.all([refreshGuidance(s), refreshLadders(s), poll(s)]); }
      const cadence = (ms, f) => timers.push(every(ms, f));
      cadence(policy.pollMs, () => { for (const s of state.values()) poll(s); });
      cadence(policy.quoteMs, tick);
      cadence(30_000, () => { for (const s of state.values()) refreshLadders(s); });
      cadence(15 * MINUTE, () => { for (const s of state.values()) refreshGuidance(s); });
      cadence(6 * 60 * MINUTE, () => { for (const s of state.values()) refreshCalibrations(s); });
      signal?.addEventListener('abort', () => close());
      executor?.tripped?.then((error) => ledger.append([{ kind: 'halt', account, at: at(clock()), reason: error.message }]));
      ledger.append([{ kind: 'start', account, strategy, at: at(clock()), mode: executor ? 'armed' : 'shadow', equity: capital(), capitalFraction, cities, holderOrders: [...venueOrders.values()].filter((o) => !o.desk).length, positions: positions.size }]);
      return { close, failed: executor?.tripped ? Promise.race([stream.failed, executor.tripped]) : stream.failed, status };
    },
    tick, admitIndex: (city, body) => admitIndex(state.get(city), body, clock()), onTake: (take) => onTake(take, clock()), onAccount, applyFill,
    settled: () => Promise.allSettled([...queues.values()]),
    status,
  });

  function status() {
    return {
      live: { ladders: live().ladders, stakeFraction: stakeFraction(), stakeSource: live().cap === null ? 'replay' : 'live' },
      account, mode: executor ? 'armed' : 'shadow', available, capitalFraction, equity: capital(), wealth: wealth(), hurdle, settled: settled.length, pnl: settled.reduce((s, r) => s + r.pnl, 0),
      resting: [...orders.values()].map(({ ticker, side, priceCents, contracts, filled, ahead }) => ({ ticker, side, priceCents, contracts, filled, ahead })),
      holder: { orders: [...venueOrders.values()].filter((o) => !o.desk).length, positions: positions.size },
      cities: Object.fromEntries([...state.values()].map((s) => [s.city, { lastMinute: s.tracker?.lastMinute() ?? null, stale: s.staleSince !== null,
        ladders: Object.fromEntries([...s.ladders.values()].map((l) => [l.event, l.fair ?? null])) }])),
    };
  }
  async function close() {
    if (closed) return; closed = true;
    for (const stop of timers) stop();
    await Promise.allSettled([...queues.values()]);
    await executor?.close();
    await stream?.close();
    ledger.append([{ kind: 'stop', account, at: at(clock()), ...status() }]);
  }
}

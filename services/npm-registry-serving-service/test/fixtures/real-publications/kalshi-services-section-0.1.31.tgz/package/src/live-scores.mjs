/**
 * The lattice model scored live, against the market, on the markets the desk quotes.
 *
 * Recording. Whenever the desk computes the model's probability for a market, and that probability or the market's
 * best bid or ask has changed since the last row for it, the desk logs a `belief` row (weather-market-maker.mjs):
 * {kind, account, at, id: ticker, city, settle (ms), q (the lattice's P(index > strike), 4 places), bid, ask (cents,
 * the whole book's best), obs (the observation state's id: the city's latest observed minute)}. A row stands until
 * the next one for its market, so a market is stored by its changes, never by its ticks.
 *
 * Scoring. When the ladder settles, each belief is scored against the outcome (the index above the strike) and
 * against the market's mid at the same instant ((bid + ask) / 2; a belief with a one-sided or empty book has no mid and
 * is not scored). Each belief counts for the minutes it stood, split at the lead buckets the desk uses
 * (<5 ... <61 minutes to the settlement minute). The sums go in `belief-score` rows, one per settled ladder and lead
 * bucket (a log line is at most 4096 bytes): the running state, small, from which every statistic below is computed
 * without rereading the beliefs.
 *
 * Statistics. Per city and lead bucket (and pooled): the time-weighted Brier score and log loss of the model and of the
 * market, their difference (model minus market: negative is the model ahead), and a percentile bootstrap 95% interval of
 * that difference, resampling whole ladders (the strikes and minutes of one ladder share one weather, so the ladder is the
 * independent unit). The generator is seeded: the same rows give the same interval.
 */
export const BUCKETS = [5, 10, 20, 30, 45, 61];
export const bucketOf = (lead) => `<${BUCKETS.find((b) => lead < b) ?? 61}`;
/** Probabilities are clamped here before a logarithm, so a model at exactly 0 or 1 costs a finite 9.2 nats, not infinity. */
export const CLAMP = 1e-4;
/** The least scored ladders a cell needs before a live statistic replaces the replay's in the desk's policy. */
export const LIVE_MIN_EVENTS = 30;
/** And the least pooled across all cells before the stake cap is taken from the live scores. */
export const LIVE_MIN_POOLED_EVENTS = 120;
export const RESAMPLES = 2000;

const MINUTE = 60_000;
export const eventOf = (ticker) => ticker.replace(/-T\d+(?:\.\d+)?$/u, '');
export const strikeOf = (ticker) => { const m = /-T(\d+(?:\.\d+)?)$/u.exec(ticker); return m ? Number(m[1]) : null; };
const clamp = (p) => Math.min(1 - CLAMP, Math.max(CLAMP, p));
const logLoss = (p, y) => -Math.log(y ? clamp(p) : 1 - clamp(p));
const emptyCell = () => ({ w: 0, mB: 0, kB: 0, mL: 0, kL: 0, d2: 0, n: 0 });

/** A belief row's market mid as a probability, or null with no two-sided book. */
export const midOf = ({ bid, ask }) => (Number.isFinite(bid) && Number.isFinite(ask) && ask >= bid ? (bid + ask) / 200 : null);

/**
 * The belief-score row of one settled ladder.
 * @param {object[]} beliefs the ladder's belief rows (any order)
 * @param {{event: string, city: string, settle: number, value: number, at: string, account?: string}} settled the settle row
 * @returns the rows (one per lead bucket with anything scored), empty when nothing could be scored
 */
export function scoreLadder(beliefs, settled) {
  const byTicker = new Map();
  for (const b of [...beliefs].sort((x, y) => Date.parse(x.at) - Date.parse(y.at))) {
    if (eventOf(b.id) !== settled.event) continue;
    if (!byTicker.has(b.id)) byTicker.set(b.id, []);
    byTicker.get(b.id).push(b);
  }
  const cells = {};
  for (const [ticker, rows] of byTicker) {
    const strike = strikeOf(ticker); if (strike === null) continue;
    const y = settled.value > strike ? 1 : 0;
    rows.forEach((b, i) => {
      const m = midOf(b); if (m === null || !(b.q >= 0 && b.q <= 1)) return;
      const from = Date.parse(b.at), to = Math.min(i + 1 < rows.length ? Date.parse(rows[i + 1].at) : b.settle, b.settle);
      // the minutes this belief stood, split at the bucket edges
      for (let k = 0; k < BUCKETS.length; k += 1) {
        const edge = k === 0 ? 0 : BUCKETS[k - 1], start = Math.max(from, b.settle - BUCKETS[k] * MINUTE), end = Math.min(to, b.settle - edge * MINUTE);
        const w = (end - start) / MINUTE; if (!(w > 0)) continue;
        const cell = (cells[`<${BUCKETS[k]}`] ??= emptyCell());
        cell.w += w; cell.n += 1;
        cell.kB += w * (b.q - y) ** 2; cell.mB += w * (m - y) ** 2; cell.kL += w * logLoss(b.q, y); cell.mL += w * logLoss(m, y); cell.d2 += w * (b.q - m) ** 2;
      }
    });
  }
  const round = (x) => Math.round(x * 1e6) / 1e6;
  for (const c of Object.values(cells)) for (const k of ['w', 'mB', 'kB', 'mL', 'kL', 'd2']) c[k] = round(c[k]);
  return Object.entries(cells).map(([bucket, cell]) => ({ kind: 'belief-score', account: settled.account, at: settled.at, event: settled.event, city: settled.city, settle: settled.settle, bucket, cell }));
}

/** The settled ladders, {event, city, cells: {bucket: cell}}, from belief-score rows (the latest of an event and bucket wins; other kinds are ignored), in event order so a resample is reproducible. */
export function scoredLadders(rows) {
  const ladders = new Map();
  for (const r of rows) {
    if (r.kind !== 'belief-score') continue;
    if (!ladders.has(r.event)) ladders.set(r.event, { event: r.event, city: r.city, cells: {} });
    ladders.get(r.event).cells[r.bucket] = r.cell;
  }
  return [...ladders.values()].sort((a, b) => (a.event < b.event ? -1 : 1));
}

const sum = (xs) => xs.reduce((a, b) => a + b, 0);
function mulberry32(seed) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 2 ** 32; }; }

/** The statistics of one set of ladders' cells (each ladder one cell object, or undefined where it had none). */
export function cellStats(cells, { resamples = RESAMPLES, seed = 1 } = {}) {
  const used = cells.filter((c) => c && c.w > 0), w = sum(used.map((c) => c.w));
  if (!used.length) return { events: 0, minutes: 0 };
  const mean = (key, set = used) => sum(set.map((c) => c[key])) / sum(set.map((c) => c.w));
  const rnd = mulberry32(seed), dB = [], dL = [];
  for (let r = 0; r < resamples; r += 1) {
    let b = 0, l = 0, ww = 0;
    for (let i = 0; i < used.length; i += 1) { const c = used[Math.floor(rnd() * used.length)]; b += c.kB - c.mB; l += c.kL - c.mL; ww += c.w; }
    dB.push(b / ww); dL.push(l / ww);
  }
  const q = (xs, p) => xs.sort((a, b) => a - b)[Math.floor(p * (xs.length - 1))];
  const r4 = (x) => Math.round(x * 1e4) / 1e4;
  return {
    events: used.length, minutes: r4(w),
    modelBrier: r4(mean('kB')), marketBrier: r4(mean('mB')), dBrier: r4(mean('kB') - mean('mB')), dBrierCI: [r4(q(dB, 0.025)), r4(q(dB, 0.975))],
    modelLogLoss: r4(mean('kL')), marketLogLoss: r4(mean('mL')), dLogLoss: r4(mean('kL') - mean('mL')), dLogLossCI: [r4(q(dL, 0.025)), r4(q(dL, 0.975))],
    rmsDisagreement: r4(Math.sqrt(mean('d2'))),
  };
}

/** Statistics per city and lead bucket, per bucket across cities, and pooled, from belief-score rows. */
export function liveStats(scoreRows, options) {
  const ladders = scoredLadders(scoreRows), cities = [...new Set(ladders.map((l) => l.city))].sort();
  const of = (set, bucket) => set.map((l) => l.cells[bucket]);
  const stats = { byCity: {}, byBucket: {}, pooled: null };
  for (const city of cities) {
    const mine = ladders.filter((l) => l.city === city);
    stats.byCity[city] = { pooled: cellStats(mine.map((l) => pooledCell(l.cells)), options), buckets: Object.fromEntries(BUCKETS.map((b) => [`<${b}`, cellStats(of(mine, `<${b}`), options)])) };
  }
  for (const b of BUCKETS) stats.byBucket[`<${b}`] = cellStats(of(ladders, `<${b}`), options);
  stats.pooled = cellStats(ladders.map((l) => pooledCell(l.cells)), options);
  return stats;
}

/** A ladder's cells added across lead buckets. */
export function pooledCell(cells) {
  const out = emptyCell();
  for (const c of Object.values(cells)) for (const k of Object.keys(out)) out[k] += c[k];
  return out;
}

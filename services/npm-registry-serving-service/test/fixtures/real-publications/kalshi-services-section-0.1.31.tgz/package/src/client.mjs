import {assertOrderExecutionOpen} from './execution-control.mjs';
import {retryAfterDelayMs} from '@red-cup-engineering/http-services-section/retry-after';
import {isDeepStrictEqual} from 'node:util';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {collectKalshiAccountingHistory} from './accounting-history.mjs';
// The one Kalshi trade-API client. Every venue read and write in this section
// goes through `createKalshiClient`: public market data unsigned, portfolio
// and order calls signed (src/signing.mjs, Ed25519 or RSA-PSS by key type)
// over the path without its query. Orders use the V2 shape
// (POST /portfolio/events/orders): one YES book, `bid` buys YES and `ask`
// sells YES (long NO at 1 - price), fixed-point dollar prices and fractional
// counts. Credentials come from the signer host's environment, or the
// house's private env file, never from a caller or a record.
import { kalshiCredentials } from './account-credentials.mjs';
import { kalshiAccount, KALSHI_ACCOUNTS } from './accounts.mjs';
export { kalshiCredentials, kalshiEnvFile } from './account-credentials.mjs';
import { signRequest, authHeaders } from './signing.mjs';
export { signRequest, authHeaders };
import { createOrderRiskGate, orderRiskPaths } from './order-risk-gate.mjs';
import { recordDirectory, sectionRoot, settlementRoot, stateDirectory } from './data-layout.mjs';
import { readFileText } from '@red-cup-engineering/computer-file-engineering-services-section/read-file';
import { deriveKalshiLedger, reconcileKalshiLedger } from './kalshi-ledger.mjs';

import activation from '../content/config/activation.json' with { type: 'json' };
import feed from '../content/config/feed.json' with { type: 'json' };
import orderRiskLimits from '../content/config/order-risk-limits.json' with { type: 'json' };
import section from '../package.json' with { type: 'json' };

export class KalshiVenueError extends Error {
  constructor(code, detail, { status = null, venueWrite = false } = {}) {
    super(`${code}: ${detail}`);
    Object.assign(this, { code, detail, status, venueWrite });
  }
}

/** A dollar or count value as Kalshi's fixed-point string. */
export const dollars = (value) => Number(value).toFixed(4);
export const contracts = (value) => (Math.floor(Number(value) * 100 + 1e-9) / 100).toFixed(2);

/**
 * A client bound to one host and (optionally) one credential. Every write to the production exchange (any
 * kalshi.com host) that the human execution control admits then passes the order risk gate
 * (src/order-risk-gate.mjs); a caller may supply its own gate, but cannot remove it there.
 * @param {{credentials?: {apiKeyId: string, privateKeyPem: string}|null, baseUrl?: string, fetchImpl?: typeof fetch, timeoutMs?: number, riskGate?: {admit: Function}}} [options]
 */
export function createKalshiClient({ env = process.env, credentials = kalshiCredentials(env), baseUrl = env.KALSHI_USE_DEMO === '1' ? feed.demo : feed.base, fetchImpl = fetch, timeoutMs = 20000, retries429 = 6, minIntervalMs = null, pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms)), clock = () => Date.now(), riskGate } = {}) {
  const accountId = credentials?.accountId ?? kalshiAccount(env).id;
  const basePath = new URL(baseUrl).pathname;
  const { hostname } = new URL(baseUrl);
  const productionExchange = hostname === 'kalshi.com' || hostname.endsWith('.kalshi.com');
  // The order risk gate, made on the first write: the caller's, or on the production exchange the section's own,
  // keeping its latch and baselines in the section's state.
  let gate = riskGate ?? null;
  function gateFor() {
    if (gate || !productionExchange) return gate;
    const accountEnv = { ...env, KALSHI_ACCOUNT_ID: accountId };
    gate = createOrderRiskGate({
      ...orderRiskPaths({ hostStateDirectory: stateDirectory(sectionRoot(env), 'order-risk'), accountStateDirectory: stateDirectory(settlementRoot(accountEnv), 'order-risk') }),
      release: `${section.name}@${section.version}`, accountId, limits: orderRiskLimits, clock,
      venue: {
        // The double-entry ledger derived from the venue's own records, reconciled against its balance and positions.
        books: async () => reconcileKalshiLedger(...await ledgerInputs()).gate,
        balance: () => call('GET', '/portfolio/balance'),
        positions: (event) => pagedEnvelope('/portfolio/positions', ['market_positions', 'event_positions'], { event_ticker: event }).then((result) => result.market_positions),
        restingOrders: (event) => paged('/portfolio/orders', 'orders', { status: 'resting', ...(event ? { event_ticker: event } : {}) }),
        deposits: () => paged('/portfolio/deposits', 'deposits'),
        withdrawals: () => paged('/portfolio/withdrawals', 'withdrawals'),
        cancel: (orderId, ticker) => call('DELETE', `/portfolio/events/orders/${orderId}`, { query: { market_ticker: ticker } }),
      },
    });
    return gate;
  }
  // The account's request rate is three budgets at the venue (docs: rate limits), whoever in this host spends them:
  // reads, writes and the balance, each its own token bucket. Basic sustains 20 reads, 10 writes and 1 balance read
  // a second; each lane is paced at its sustained rate. Every attempt (retries too) takes the next slot of its lane,
  // and a 429 -- an empty bucket -- moves that lane's slot back for every caller, not only the one refused. A given
  // minIntervalMs paces every lane at it.
  const INTERVALS = { read: 50, write: 100, balance: 1000 };
  const nextSlot = { read: 0, write: 0, balance: 0 };
  const laneOf = (method, apiPath) => (apiPath === '/portfolio/balance' ? 'balance' : method === 'GET' ? 'read' : 'write');
  async function takeSlot(lane, deadline) {
    const now = clock();
    const at = Math.max(now, nextSlot[lane]);
    if(at>=deadline)throw new KalshiVenueError('request-deadline','shared pacing or server retry delay exceeds the original acquisition deadline');
    nextSlot[lane] = at + (minIntervalMs ?? INTERVALS[lane]);
    if (at > now) await pause(at - now);
  }

  async function call(method, apiPath, { query, body, signed = true, retainOriginal = false, deadlineAt = Infinity } = {}) {
    if (apiPath.includes('?')) throw new KalshiVenueError('query-in-signed-path', 'pass query parameters as `query`');
    const write = method !== 'GET';
    assertOrderExecutionOpen(accountId,{method,apiPath,baseUrl,demoUrl:feed.demo});
    if (write && !KALSHI_ACCOUNTS[accountId]?.deskOrders)
      throw new KalshiVenueError('account-order-authority-absent', 'the selected account has no account-specific desk mandate');
    if (signed && !credentials) throw new KalshiVenueError('credentials-absent', 'KALSHI_API_KEY_ID and KALSHI_PRIVATE_KEY_PATH are required');
    if (write && gateFor()) {
      const verdict = await gate.admit({ method, apiPath, body });
      if (!verdict.admit) throw new KalshiVenueError(verdict.code, verdict.detail, { venueWrite: false });
    }
    const url = new URL(`${baseUrl}${apiPath}`);
    for (const [key, value] of (query instanceof URLSearchParams ? query : Object.entries(query ?? {}))) if (value !== undefined && value !== null && value !== '') url.searchParams.append(key, String(value));
    if (deadlineAt !== Infinity && !Number.isFinite(deadlineAt)) throw new KalshiVenueError('request-deadline', 'absolute acquisition deadline must be finite');
    const deadline=Math.min(clock()+timeoutMs,deadlineAt), lane=laneOf(method, apiPath);
    let res;
    // Kalshi answers 429 when the token bucket is empty, with no Retry-After, and a 429 is never
    // a write, so it is retried with backoff. The signature is fresh each attempt (it carries a timestamp).
    for (let attempt = 0; ; attempt += 1) {
      await takeSlot(lane, deadline);
      const headers = signed ? await authHeaders({ ...credentials, method, path: basePath + apiPath }) : { accept: 'application/json' };
      assertOrderExecutionOpen(accountId,{method,apiPath,baseUrl,demoUrl:feed.demo});
      try {
        const remaining=deadline-clock();
        if(remaining<=0)throw new Error('original acquisition deadline exhausted');
        // AbortSignal.timeout takes whole milliseconds; pacing jitter and caller deadlines need not be whole.
        res = await fetchImpl(url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(Math.max(1, Math.floor(remaining))) });
      } catch (error) {
        // A write whose response never came may still have reached the venue.
        throw new KalshiVenueError('network', error.message, { venueWrite: write });
      }
      if (res.status !== 429 || attempt >= retries429) break;
      const receivedAt=clock(),serverDelay=retryAfterDelayMs(res.headers?.get('retry-after'),receivedAt);
      await res.body?.cancel().catch(()=>{});
      nextSlot[lane] = Math.max(nextSlot[lane], receivedAt + Math.max(serverDelay??0,500 * 2 ** attempt + Math.random() * 250));
    }
    // The historical accounting receiver needs the ORIGINAL response bytes.
    // Re-serializing parsed JSON changes the source and cannot authenticate
    // what the venue actually returned. Ordinary existing calls are unchanged.
    if (retainOriginal && res.ok) {
      if (typeof res.arrayBuffer !== 'function')
        throw new KalshiVenueError('source-bytes-unavailable','exchange response body cannot be preserved');
      let bytes;
      try { bytes = new Uint8Array(await res.arrayBuffer()); }
      catch { throw new KalshiVenueError('source-bytes-unavailable','cannot read original exchange response'); }
      if (bytes.byteLength<2||bytes.byteLength>16*1048576)
        throw new KalshiVenueError('source-bytes-invalid','original exchange response size outside bounded admission');
      let parsed;
      try { parsed=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)); }
      catch { throw new KalshiVenueError('source-json-invalid','original exchange response is not valid UTF-8 JSON'); }
      if (!parsed || typeof parsed!=='object' || Array.isArray(parsed))
        throw new KalshiVenueError('source-json-invalid','accounting response must be a JSON object');
      return {
        ...parsed,
        originalBytes:bytes,
        originalSha256:'sha256:'+createHash('sha256').update(bytes).digest('hex'),
        originalUrl:url.toString(),
        receivedAt:new Date().toISOString(),
      };
    }
    const payload = await res.json().catch(() => null);
    if (!res.ok) throw new KalshiVenueError(`http-${res.status}`, payload?.error?.message ?? payload?.message ?? res.statusText, { status: res.status, venueWrite: write && res.status >= 500 });
    return payload;
  }

  async function pagedEnvelope(apiPath, keys, query, { signed = true, maxPages = 50, deadlineAt = Infinity } = {}) {
    const rows=Object.fromEntries(keys.map(key=>[key,[]])),seen=new Set();
    let cursor=query?.cursor,first;
    if(cursor)seen.add(cursor);
    for(let page=0;page<maxPages;page+=1){
      const payload=await call('GET',apiPath,{query:{limit:200,...query,cursor},signed,deadlineAt});
      first??=payload;
      for(const key of keys){
        if(!Array.isArray(payload[key]))throw new KalshiVenueError('pagination-invalid',`missing ${key} array`);
        rows[key].push(...payload[key]);
      }
      const next=payload.cursor;
      if(next===undefined||next===null||next==='')return {...first,...rows,cursor:'',pagination:{pages:page+1,completeFromStart:!query?.cursor,atomicSnapshot:false}};
      if(typeof next!=='string'||seen.has(next))throw new KalshiVenueError('pagination-invalid','nonadvancing or invalid cursor');
      seen.add(next);cursor=next;
    }
    throw new KalshiVenueError('pagination-incomplete',`more than ${maxPages} pages; partial readings cannot be admitted`);
  }
  /**
   * Everything the ledger and its reconciliation need, read-only (GETs): the account's deposits, withdrawals, fills,
   * settlements and inter-wallet transfers, its balance (with balance_breakdown per exchange_index) and positions, and,
   * where margin (Perps) is enabled, the margin balance, positions, fills and funding history
   * (docs.kalshi.com: margin, margin-rest/portfolio/*, margin-rest/funding/get-funding-history).
   * @returns {Promise<[object, object]>} the arguments of `deriveKalshiLedger` and `reconcileKalshiLedger`.
   */
  async function ledgerInputs() {
    const [deposits, withdrawals, fills, settlements, transfers, balance, held, marginOn] = await Promise.all([
      paged('/portfolio/deposits', 'deposits'), paged('/portfolio/withdrawals', 'withdrawals'), paged('/portfolio/fills', 'fills'),
      paged('/portfolio/settlements', 'settlements'), paged('/portfolio/intra_exchange_instance_transfers', 'transfers'),
      call('GET', '/portfolio/balance'), positions(), call('GET', '/margin/enabled').then((r) => r.enabled === true),
    ]);
    let perpsFills = [], perpsFunding = [], margin;
    if (marginOn) {
      const times = [...transfers.map((t) => t.created_ts * 1000), ...deposits.map((d) => d.created_ts * 1000)].filter(Number.isFinite);
      const day = (ms) => new Date(ms).toISOString().slice(0, 10);
      const [marginBalance, marginPositions, fundingRows] = await Promise.all([
        call('GET', '/margin/balance'), call('GET', '/margin/positions'),
        call('GET', '/margin/funding_history', { query: { start_date: day(Math.min(...times, clock()) - 86400000), end_date: day(clock() + 86400000) } }),
      ]);
      perpsFills = await paged('/margin/fills', 'fills');
      perpsFunding = fundingRows.funding_history ?? [];
      margin = { balance: marginBalance, positions: marginPositions };
    }
    // Movements the API does not list (promotional credits; deposits or withdrawals it omits), from attested evidence.
    let attested = {};
    try { attested = JSON.parse(await readFileText(join(recordDirectory(settlementRoot({ ...env, KALSHI_ACCOUNT_ID: accountId }), 'kalshi-attested-movement'), 'movements.json'))); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    return [deriveKalshiLedger({
      accountId, fills, settlements, transfers, perpsFills, perpsFunding,
      deposits: [...deposits, ...(attested.deposits ?? [])], withdrawals: [...withdrawals, ...(attested.withdrawals ?? [])], credits: attested.credits ?? [],
    }), { balance, positions: held, margin }];
  }
  async function paged(apiPath,key,query,options){return (await pagedEnvelope(apiPath,[key],query,options))[key];}
  async function positions(query){
    const result=await pagedEnvelope('/portfolio/positions',['market_positions','event_positions'],query);
    for(const [key,identity] of [['market_positions','ticker'],['event_positions','event_ticker']]){
      const byId=new Map();
      for(const row of result[key]){
        const id=row?.[identity];
        if(typeof id!=='string'||!id)throw new KalshiVenueError('pagination-invalid',`position ${identity} required`);
        if(byId.has(id)&&!isDeepStrictEqual(byId.get(id),row))throw new KalshiVenueError('position-pagination-inconsistent',`conflicting ${identity} across pages`);
        byId.set(id,row);
      }
      result[key]=[...byId.values()];
    }
    result.pagination.settlementStatus=query?.settlement_status??'unsettled';
    result.pagination.historicalCoverage=false;
    return result;
  }

  return Object.freeze({
    signed: Boolean(credentials),
    call,
    // Public market data.
    getSeries: (seriesTicker, { deadlineAt = Infinity } = {}) => call('GET', `/series/${seriesTicker}`, { signed: false, deadlineAt }).then((p) => p.series),
    getEvents: (query) => paged('/events', 'events', query, { signed: false }),
    getMarkets: (query, { deadlineAt = Infinity } = {}) => paged('/markets', 'markets', query, { signed: false, deadlineAt }),
    getMarket: (ticker) => call('GET', `/markets/${ticker}`, { signed: false }).then((p) => p.market),
    getOrderbook: (ticker, depth, { deadlineAt = Infinity } = {}) => call('GET', `/markets/${ticker}/orderbook`, { query: { depth }, signed: false, deadlineAt }).then((p) => p.orderbook_fp),
    getCandlesticks: (seriesTicker, ticker, query) => call('GET', `/series/${seriesTicker}/markets/${ticker}/candlesticks`, { query, signed: false }).then((p) => p.candlesticks ?? []),
    // Portfolio.
    // A subaccount (0 is the primary) is named on every portfolio read and write that acts on one.
    getBalance: ({ subaccount } = {}) => call('GET', '/portfolio/balance', subaccount ? { query: { subaccount } } : {}),
    getPositions: positions,
    getOrders: (query) => paged('/portfolio/orders', 'orders', query),
    // Authenticated exchange priority, not displayed depth or a fill promise.
    getQueuePositions: (query) => call('GET', '/portfolio/orders/queue_positions', { query }),
    getFills: (query) => paged('/portfolio/fills', 'fills', query),
    getSettlements: (query) => paged('/portfolio/settlements', 'settlements', query),
    // Real read-only historical/current coverage, including documented archive
    // handoff and cursor exhaustion; never claims an atomic account close.
    getAccountingHistory: ({ticker,subaccount,from,to,maxPages}={}) =>
      collectKalshiAccountingHistory({
        ticker,subaccount,from,to,maxPages,
        requireOriginalBytes:true,
        readCutoff:()=>call('GET','/historical/cutoff',{signed:false,retainOriginal:true}),
        readPage:(path,query)=>call('GET',path,{query,retainOriginal:true}),
      }),
    // Money moved in and out of the account: amount_cents and fee_cents, status pending | applied | failed | returned.
    getLedgerInputs: ledgerInputs,
    // Moves between event-contract shards and the margined (Perps) wallet.
    getIntraAccountTransfers: (query) => paged('/portfolio/intra_exchange_instance_transfers', 'transfers', query),
    getDeposits: (query) => paged('/portfolio/deposits', 'deposits', query),
    getWithdrawals: (query) => paged('/portfolio/withdrawals', 'withdrawals', query),
    // Orders (V2).
    createOrder({ ticker, side, count, price, timeInForce = 'good_till_canceled', postOnly = false, expirationTime, clientOrderId, reduceOnly, orderGroupId, subaccount }) {
      if (side !== 'bid' && side !== 'ask') throw new TypeError('createOrder: side is bid (buy YES) or ask (sell YES / buy NO)');
      const body = {
        ticker, side, count: contracts(count), price: dollars(price), time_in_force: timeInForce,
        self_trade_prevention_type: 'taker_at_cross', post_only: postOnly, cancel_order_on_pause: true,
        ...(clientOrderId ? { client_order_id: clientOrderId } : {}),
        ...(expirationTime ? { expiration_time: Math.floor(expirationTime) } : {}),
        ...(reduceOnly ? { reduce_only: true } : {}),
        // An order group cancels all its orders when their fills in a rolling 15 seconds pass its limit.
        ...(orderGroupId ? { order_group_id: orderGroupId } : {}),
        ...(subaccount ? { subaccount } : {}),
      };
      return call('POST', '/portfolio/events/orders', { body });
    },
    cancelOrder: (orderId, ticker, { subaccount } = {}) => call('DELETE', `/portfolio/events/orders/${orderId}`, { query: { market_ticker: ticker, ...(subaccount ? { subaccount } : {}) } }),
    // Amend a resting order. Changing only its expiry, or decreasing its size, keeps its place in the queue; a new
    // price or a larger size sends it to the back (docs: amend-order-v2). `count` is the order's total fillable count:
    // what has filled plus what should rest after the amend.
    amendOrder({ orderId, ticker, side, count, price, expirationTime, clientOrderId, updatedClientOrderId, subaccount }) {
      if (side !== 'bid' && side !== 'ask') throw new TypeError('amendOrder: side is bid (buy YES) or ask (sell YES / buy NO)');
      const body = {
        ticker, side, count: contracts(count), price: dollars(price),
        ...(expirationTime ? { expiration_time: Math.floor(expirationTime) } : {}),
        ...(clientOrderId ? { client_order_id: clientOrderId } : {}),
        ...(updatedClientOrderId ? { updated_client_order_id: updatedClientOrderId } : {}),
        ...(subaccount ? { subaccount } : {}),
      };
      return call('POST', `/portfolio/events/orders/${orderId}/amend`, { body });
    },
  });
}

const shared = new Map();
const client = () => {
  const accountId = kalshiAccount().id;
  if (!shared.has(accountId)) shared.set(accountId, createKalshiClient());
  return shared.get(accountId);
};
const datum = (promise, write) => promise.then((object) => ({ type: 'Accept', object }), (error) => ({ type: 'Reject', code: error.code ?? 'error', detail: error.detail ?? error.message, venueWrite: error.venueWrite ?? write }));

// Reads need credentials but not live activation: the custodian may verify
// balances during onboarding while orders remain refused.
export const getBalance = () => datum(client().getBalance(), false);
export const getPositions = () => datum(client().getPositions(), false);
export const getFills = () => datum(client().getFills(), false);

/**
 * A buy of `side` (yes|no) at `priceCents`, the shape the stake path forms,
 * placed as its V2 equivalent: buying YES at p is a bid at p; buying NO at p
 * is an ask on the YES book at 1 - p. A venue write additionally requires the
 * activation policy raised to live.
 */
export function createOrder({ ticker, action = 'buy', side, count, priceCents, clientOrderId }) {
  if (activation.orderExecution !== 'live') {
    return Promise.resolve({ type: 'Reject', code: 'activation-refused', detail: `order execution is ${activation.orderExecution}`, venueWrite: false });
  }
  const longYes = (action === 'buy') === (side === 'yes');
  const yesPrice = side === 'yes' ? priceCents / 100 : 1 - priceCents / 100;
  return datum(client().createOrder({ ticker, side: longYes ? 'bid' : 'ask', count, price: yesPrice, clientOrderId }), true);
}

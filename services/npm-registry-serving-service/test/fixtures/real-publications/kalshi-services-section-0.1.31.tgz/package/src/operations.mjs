import { rankKalshiResearchCandidates } from "../scripts/rank-kalshi-research-candidates.mjs";
/**
 * Kalshi as an operation family, so the venue's offices act through MetroPlat: read a market, form an
 * order intent from the org's own calibrated forecast, and place an order through the shared
 * activation gate (open once the venue credentials are in the host's custody; credentials
 * come from that custody, never from the caller).
 */
import { operation } from "@red-cup-engineering/computer-system-engine/rpc/operation";
import { weatherStatusPageRequestContract, weatherStationSkillPageRequestContract } from "./weather-page-contracts.mjs";
import { readKalshiMarket } from "../scripts/read-kalshi-market.mjs";
import { formKalshiOrderIntent } from "../scripts/form-kalshi-order-intent.mjs";
import { kalshiAccount } from './accounts.mjs';
import { runAccountDeskCycle } from './desk-runtime.mjs';

import { runWeatherCycle, scoreWeather, weatherRoot, weatherStatusPage, weatherStationSkillPage } from '@red-cup-engineering/forecasting/weather-engine';
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { runHypotheses, readStatuses } from '@red-cup-engineering/forecasting/hypotheses';
import { hypothesisRunRequestContract, hypothesisStatusRequestContract } from './hypothesis-operation-contracts.mjs';
import { runObserveAndForecast, runScoreClosedMarkets } from "@red-cup-engineering/forecasting/forecast-weather-markets-cli";

const WEATHER_CONFIG = fileURLToPath(import.meta.resolve("@red-cup-engineering/forecasting/weather-markets.json"));
// The forecasting journal: its host's own root when one is configured, else beside MetroPlat's.
const forecastRoot = (binding) => process.env.FORECASTING_DAILY_CYCLE_DATA_ROOT ?? join(binding?.dataRoot ?? process.cwd(), "data", "state", "forecasting");

export function kalshiOperations(binding, options = {}) {
  // Native network expenditure is allocated by this instance's existing clock
  // declarations. The loader supplies these process-owned inputs; an RPC body
  // cannot substitute them. Unallocated modes remain unavailable for network use.
  const researchBudgets = new Map();
  const tradingAccounts = new Map();
  for (const schedule of options.instanceSchedules ?? []) {
    if (schedule.verb === 'kalshi-desk-cycle') {
      const input = schedule.input;
      if (!input || typeof input.accountId !== 'string' || Object.keys(input).length !== 2 || !['paper', 'live'].includes(input.mode) || Object.keys(input).some(key => !['accountId', 'mode'].includes(key))) throw new TypeError('one scheduled Kalshi account is required');
      const accountId = kalshiAccount({ KALSHI_ACCOUNT_ID: input.accountId }).id;
      if (tradingAccounts.has(accountId) && tradingAccounts.get(accountId) !== input.mode) throw new TypeError('conflicting Kalshi account cycle modes');
      tradingAccounts.set(accountId, input.mode);
    }
    if (schedule.verb !== 'kalshi-hypotheses-run') continue;
    const { mode, requestBudget } = schedule.input ?? {};
    if (!['collect', 'all', 'sync', 'verdict'].includes(mode) || !Number.isSafeInteger(requestBudget) || requestBudget < 0 || mode === 'verdict' && requestBudget !== 0)
      throw new TypeError('Kalshi research schedule requires a mode and nonnegative request allocation');
    researchBudgets.set(mode, Math.max(researchBudgets.get(mode) ?? 0, requestBudget));
  }
  return Object.freeze([
    operation({
      verb: 'kalshi-desk-cycle', inputFormat: 'json', outputFormat: 'json',
      summary: 'Run one paper or live desk cycle for a host-allocated account using its own arming, capital and order custody.',
      description: 'Domain: {accountId, mode: paper|live}. The account must have an existing instance schedule allocation. Host-owned credential and research roots are used; caller paths, keys and policy overrides are refused. An unarmed account remains unarmed. The canonical desk owns strategy admission, sizing, placement and uncertain-order recovery.',
      reads: ['kalshi/account', 'kalshi/weather-state', 'kalshi/desk-state'],
      writes: ['kalshi/orders', 'kalshi/desk-state', 'kalshi/desk-ledger'],
      run: input => {
        if (!input || typeof input !== 'object' || Array.isArray(input) || Object.keys(input).length !== 2 || !tradingAccounts.has(input.accountId) || tradingAccounts.get(input.accountId) !== input.mode)
          throw new TypeError('host-allocated-kalshi-account-required');
        return runAccountDeskCycle({ accountId: input.accountId, mode: input.mode });
      },
    }),
    // One registered research engine; the host's clock owns collection and scoring.
    // The superseded C1/DT scripts are not independent operation owners.
    operation({
      verb: 'kalshi-hypotheses-run', inputFormat: 'json', outputFormat: 'json',
      domain: hypothesisRunRequestContract,
      summary: 'Collect and score registered forward research within the instance allocation and caller budget; public GETs only.',
      description: 'Domain: {mode: collect|all|sync|verdict, requestBudget: nonnegative integer}. Network modes require an existing instance schedule allocation and cannot exceed its request budget. Verdict requires budget zero. The host owns research roots and criteria. Passed research does not activate a trading lane.',
      reads: ['kalshi/public-market-data', 'espn/public-scoreboard'],
      writes: ['forecasting/hypotheses-observations', 'forecasting/hypotheses-indexes'],
      run: (input) => {
        const allocated = input.mode === 'verdict' ? 0 : researchBudgets.get(input.mode);
        if (allocated === undefined || input.requestBudget > allocated)
          throw new RangeError('Kalshi research request budget exceeds the instance allocation');
        return runHypotheses({ mode: input.mode, requestBudget: input.requestBudget });
      },
    }),
    operation({
      verb: 'kalshi-hypotheses-status', inputFormat: 'json', outputFormat: 'json',
      domain: hypothesisStatusRequestContract,
      summary: 'Read each registered hypothesis verdict, missing evidence and last observation without fetching.',
      reads: ['forecasting/hypotheses-indexes'],
      run: () => ({ orderEffect: false, hypotheses: readStatuses() }),
    }),
    operation({
      verb: "kalshi-weather-status-page", inputFormat: "json", outputFormat: "json",
      domain: weatherStatusPageRequestContract,
      summary: "Read bounded weather status or one complete page from the existing source record; no venue effect.",
      description: "Domain: { field?: contracts|forecasts|grades|errors|opportunities|research|scoring, offset?: nonnegative integer, limit?: 1..100, sourceRevision? }. Omit field for complete collection counts and status. Codomain: original source revision, count, complete rows and nextOffset. Reusing a changed source revision refuses.",
      reads: ["kalshi/weather-state"], run: (input = {}) => weatherStatusPage({ ...input, root: weatherRoot() }),
    }),
    operation({
      verb: "kalshi-weather-station-skill-page", inputFormat: "json", outputFormat: "json",
      domain: weatherStationSkillPageRequestContract,
      summary: "Read one bounded station-science page with unchanged truth sources and scores; no venue effect.",
      description: "Domain: { station?: ICAO|index:miami|index:nyc|index:chicago|index:la-coastal, field?: metrics|comparisons|parameters, offset?: nonnegative integer, limit?: 1..100, sourceRevision? }. Codomain: source revision, complete filtered count, rows and nextOffset. Full library readers stay separate.",
      reads: ["kalshi/station-science"], run: (input = {}) => weatherStationSkillPage({ ...input, root: weatherRoot() }),
    }),
    operation({
      verb: "kalshi-research-candidates-rank",
      inputFormat: "json", outputFormat: "json",
      summary: "Rank research candidates by aligned settlement evidence, calibration uncertainty and net costs; no venue effect.",
      run: (input) => rankKalshiResearchCandidates(input),
    }),
    operation({
      verb: "kalshi-weather-research-cycle",
      summary: "Collect supplemental all-market weather experiments and independent station verification.",
      run: () => runWeatherCycle(),
    }),
    operation({
      verb: "kalshi-weather-research-score",
      summary: "Score supplemental model experiments against definitive venue settlements.",
      run: () => scoreWeather(),
    }),
    operation({
      verb: "kalshi-weather-forecast",
      summary: "Observe the configured Kalshi weather markets and record the house forecast beside each market's implied probability.",
      reads: ["kalshi/public-market-data", "nws/forecasts"],
      writes: ["forecasting/forecasts"],
      run: () => runObserveAndForecast({ configPath: WEATHER_CONFIG, dataRoot: forecastRoot(binding) }),
    }),
    operation({
      verb: "kalshi-weather-score",
      summary: "Score the house's weather forecasts against Kalshi's settled results, once per forecast, into the calibration record.",
      reads: ["kalshi/public-market-data", "forecasting/forecasts"],
      writes: ["forecasting/calibration"],
      run: () => runScoreClosedMarkets({ configPath: WEATHER_CONFIG, dataRoot: forecastRoot(binding) }),
    }),
    operation({
      verb: "kalshi-market-read",
      summary: "Read one Kalshi market's prices and order book with fetch-time witnesses.",
      description: "Domain: the KalshiMarketReadRequest (the market, observedAt, optional baseUrl). Codomain: the KalshiMarketRead record.",
      reads: ["kalshi/public-market-data"],
      run: (input) => readKalshiMarket(input),
    }),
    operation({
      verb: "kalshi-order-intent",
      summary: "Form a bounded Kalshi order intent from the org's calibrated forecast, or refuse.",
      description: "Domain: { forecast, calibrationRecord, marketRead, sleeve, feeSchedule?, formedAt }. Codomain: the KalshiOrderIntent, or a Reject (no-calibration-record, calibration-insufficient, no-edge-after-fees, sleeve-exhausted).",
      run: (input) => formKalshiOrderIntent(input),
    }),
    operation({
      verb: "kalshi-order-place",
      summary: "Place one admitted Kalshi order through the venue's activation gate.",
      description: "Domain: { intent, clientOrderId? }. Codomain: the venue's own acknowledgement, or a Reject (activation-refused, credentials-absent, venue-not-activated, venue-http-<status>). Credentials are read from the environment the venue's activation record names.",
      writes: ["kalshi/orders"],
      run: async (input) => (await import("./orders.mjs")).placeOrder(input),
    }),
  ]);
}


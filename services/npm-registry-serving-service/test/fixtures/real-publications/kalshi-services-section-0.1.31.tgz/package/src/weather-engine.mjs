// Compatibility for existing Group Operations consumers. Forecasting owns the
// engine; all venue access returns through this release's guarded client.
export * from '@red-cup-engineering/forecasting/weather-engine';

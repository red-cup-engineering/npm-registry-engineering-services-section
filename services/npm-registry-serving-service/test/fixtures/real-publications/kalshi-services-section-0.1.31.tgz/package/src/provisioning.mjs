import { createHash, createPrivateKey, createPublicKey, randomUUID } from 'node:crypto';
import { chmod, mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { dirname } from 'node:path';
import { credentialPath, keepCredential } from '@red-cup-engineering/credential-custody-service/keep';
import { kalshiCredentials, kalshiEnvFile } from './account-credentials.mjs';
import { accountCredentialLayout, assertCredentialAccount } from './accounts.mjs';
import { generateKeyPairSync } from 'node:crypto';

/** A fresh Ed25519 key pair as PEM strings: Kalshi's recommended key type, registered by its public half so the private half never leaves the signer host. */
export function generateEd25519KeyPair() {
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  return {
    privateKeyPem: privateKey.export({ type: 'pkcs8', format: 'pem' }),
    publicKeyPem: publicKey.export({ type: 'spki', format: 'pem' }),
  };
}

/**
 * Putting a Kalshi API key in the signer host's custody, with the person at
 * the node in the assisted browser (the custodian office's
 * keeping-venue-account-custody duty).
 *
 * The account belongs to the selected person (KYC, Google sign-in); only its own
 * authority registers a key. So the node makes an Ed25519 key pair, keeps
 * the private half in the host's credential store, and the person registers
 * the public half on Kalshi's profile page and pastes back the Key ID, which
 * is not a secret. The private key never leaves the node and is never shown.
 * If the person instead lets Kalshi make the key, they paste the private key
 * Kalshi shows once into the panel's secret field and it goes straight to
 * the key file. Either way the key is checked by a signed balance read
 * before the env file names it, and the receipt holds no secret.
 */
export const KEY_NAME = 'house-weather-desk';
/** The desk's private key: at its place in this process's credentials directory, or where KALSHI_PRIVATE_KEY_PATH (a caller-owned file) says. */
export const keyPath = (env = process.env) => {
  assertCredentialAccount(env);
  return env.KALSHI_PRIVATE_KEY_PATH ?? credentialPath(accountCredentialLayout(env).keyPlace, env);
};

/** Keep the desk's private key in the host's credential store (or write the caller-owned file); returns where it is read. */
async function keepKey(pem, env) {
  assertCredentialAccount(env);
  if (env.KALSHI_PRIVATE_KEY_PATH) { await writePrivate(env.KALSHI_PRIVATE_KEY_PATH, pem); return env.KALSHI_PRIVATE_KEY_PATH; }
  const layout = accountCredentialLayout(env);
  return (await keepCredential({ id: layout.keyCredentialId, service: layout.service, path: layout.keyPlace, variable: 'KALSHI_PRIVATE_KEY_PATH', value: pem, kind: 'private-key', provider: 'kalshi' }, env)).path;
}
const KEY_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/iu;
const PEM_PATTERN = /-----BEGIN ((?:RSA |EC )?PRIVATE KEY)-----\s*([A-Za-z0-9+/=\s]+?)\s*-----END \1-----/u;
const PROFILE = 'https://kalshi.com/account/profile';
const stopped = () => Object.assign(new Error('the person stopped provisioning'), { code: 'PROVISION_STOPPED' });

async function writePrivate(path, text) {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  await chmod(dirname(path), 0o700);
  const temporary = `${path}.${randomUUID()}.tmp`;
  try {
    await writeFile(temporary, text, { mode: 0o600, flag: 'wx' });
    await chmod(temporary, 0o600);
    await rename(temporary, path);
  } finally { await unlink(temporary).catch(error => { if (error.code !== 'ENOENT') throw error; }); }
}

/** A private key PEM as pasted into a one-line field: newlines may be gone, so the body is rewrapped. */
export function normalizePrivateKeyPem(pasted) {
  const match = PEM_PATTERN.exec(String(pasted ?? ''));
  if (!match) return null;
  const lines = match[2].replace(/\s+/gu, '').match(/.{1,64}/gu);
  if (!lines) return null;
  const body = lines.join('\n');
  const pem = `-----BEGIN ${match[1]}-----\n${body}\n-----END ${match[1]}-----\n`;
  try {
    const key = createPrivateKey(pem);
    if (!['ed25519', 'rsa'].includes(key.asymmetricKeyType)) return null;
    return key.export({ type: 'pkcs8', format: 'pem' });
  } catch { return null; }
}

/** The node's key pair: the one already in custody, or a new Ed25519 pair kept there now. */
export async function custodyKeyPair(env = process.env) {
  let privateKeyPem, path = keyPath(env);
  try { privateKeyPem = await readFile(path, 'utf8'); } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    privateKeyPem = generateEd25519KeyPair().privateKeyPem;
    path = await keepKey(privateKeyPem, env);
  }
  const publicKeyPem = createPublicKey(createPrivateKey(privateKeyPem)).export({ type: 'spki', format: 'pem' });
  const fingerprint = createHash('sha256').update(createPublicKey(publicKeyPem).export({ type: 'spki', format: 'der' })).digest('hex').slice(0, 16);
  return { path, privateKeyPem, publicKeyPem, fingerprint };
}

/** Whether a key id and private key sign in: a signed balance read, outcome only. */
export async function checkKey({ apiKeyId, privateKeyPem, accountId }, { fetchImpl, env = process.env } = {}) {
  try {
    const { createKalshiClient } = await import('./client.mjs');
    const balance = await createKalshiClient({ env, credentials: { apiKeyId, privateKeyPem, accountId }, fetchImpl, retries429: 0 }).getBalance();
    const value = balance.balance_dollars ?? (Number.isSafeInteger(balance.balance) ? (balance.balance / 100).toFixed(2) : null);
    if (typeof value !== 'string' || !/^\d+(?:\.\d{1,4})?$/u.test(value)) return { ok: false, reason: 'Kalshi returned no valid balance' };
    return { ok: true, balanceDollars: value };
  } catch (error) {
    if (error.status === 401 || error.status === 403) return { ok: false, reason: `Kalshi refused it (${error.status}): the Key ID and the registered key do not match` };
    return { ok: false, reason: `Kalshi could not be reached to check it (${error.code})` };
  }
}

/** Name the key id beside its key: in the credential store (rendered into kalshi.env), or the caller-owned env file. */
async function keepKeyId(env, { apiKeyId, keyFile }) {
  const { account, service, idCredentialId } = accountCredentialLayout(env);
  if (env.KALSHI_ENV_FILE) {
    if (/[\r\n]/u.test(keyFile)) throw new TypeError('private key path must not contain newlines');
    await writePrivate(env.KALSHI_ENV_FILE, `# Kalshi API key in the signer host's custody; no private key here.\nKALSHI_CREDENTIAL_ACCOUNT_ID=${account.id}\nKALSHI_API_KEY_ID=${apiKeyId}\nKALSHI_PRIVATE_KEY_PATH=${keyFile}\n`);
    return env.KALSHI_ENV_FILE;
  }
  await keepCredential({ id: `${service}.account-id`, service, variable: 'KALSHI_CREDENTIAL_ACCOUNT_ID', value: account.id, kind: 'other', provider: 'kalshi' }, env);
  await keepCredential({ id: idCredentialId, service, variable: 'KALSHI_API_KEY_ID', value: apiKeyId, kind: 'other', provider: 'kalshi', purpose: `The Kalshi API key id for ${account.name}, paired with that account's private key` }, env);
  return kalshiEnvFile(env);
}

/** Prepare only: the secret stays in custody; output contains the public half. */
export async function prepareApiKey({ env = process.env } = {}) {
  const account = assertCredentialAccount(env), pair = await custodyKeyPair(env);
  const publicKeyFile = env.KALSHI_PRIVATE_KEY_PATH ? `${pair.path}.pub` : null;
  if (publicKeyFile) await writePrivate(publicKeyFile, pair.publicKeyPem);
  return { type: 'KalshiApiKeyPreparation', accountId: account.id, name: account.name,
    keyName: account.id === 'emsenn' ? KEY_NAME : `${KEY_NAME}-${account.id}`,
    publicKeyPem: pair.publicKeyPem, publicKeyFile, fingerprint: pair.fingerprint, keyFile: pair.path,
    profileUrl: PROFILE, connected: false, orderEffect: false };
}

/** Receive a downloaded key from a private file; check before replacing custody. */
export async function importApiKey({ apiKeyId, privateKeyFile, env = process.env } = {}, capabilities = {}) {
  const account = assertCredentialAccount(env);
  if (!KEY_ID_PATTERN.test(apiKeyId)) throw new TypeError('a Kalshi Key ID (UUID) is required');
  const pem = normalizePrivateKeyPem(await readFile(privateKeyFile, 'utf8'));
  if (!pem) throw new TypeError('an Ed25519 or RSA private key file is required');
  const checked = await checkKey({ apiKeyId, privateKeyPem: pem, accountId: account.id }, { fetchImpl: capabilities.fetch, env });
  if (!checked.ok) throw new Error(checked.reason);
  const keyFile = await keepKey(pem, env);
  const envFile = await keepKeyId(env, { apiKeyId, keyFile });
  return { type: 'KalshiApiKeyCustody', accountId: account.id, apiKeyId, keyFile, envFile,
    balanceDollars: checked.balanceDollars, orderEffect: false, at: new Date().toISOString() };
}

/** Connect the public key prepared on this host after its owner registers it. */
export async function connectApiKey({ apiKeyId, env = process.env } = {}, capabilities = {}) {
  return importApiKey({ apiKeyId, privateKeyFile: keyPath(env), env }, capabilities);
}

/**
 * Provision the desk's key: already in custody and signing in, or obtained
 * through the person now. Resolves with a receipt naming the key id, key
 * file and fingerprint, and the balance the check read.
 */
export async function provisionApiKey({ env = process.env, notify } = {}, capabilities = {}) {
  const account = assertCredentialAccount(env);
  const fetchImpl = capabilities.fetch;
  const existing = kalshiCredentials(env);
  if (existing) {
    const checked = await checkKey(existing, { fetchImpl, env });
    if (checked.ok) return { type: 'KalshiApiKeyCustody', accountId: account.id, apiKeyId: existing.apiKeyId, already: true, balanceDollars: checked.balanceDollars, at: new Date().toISOString() };
  }
  const pair = await custodyKeyPair(env);
  const { openAccount } = capabilities.openAccount ? { openAccount: capabilities.openAccount } : await import('@red-cup-engineering/assisted-browser-services-section/accounts');
  const { stepGuide } = capabilities.stepGuide ? { stepGuide: capabilities.stepGuide } : await import('@red-cup-engineering/assisted-browser-services-section/assist');
  const storageState = account.id === 'emsenn' ? undefined :
    (await import('@red-cup-engineering/assisted-browser-services-section/session-custody')).sessionFile(`kalshi.${account.id}.json`, env);
  const { context, page, close } = await openAccount('kalshi', { visible: true, notify, ...(storageState ? { storageState } : {}) }, capabilities.browser ?? {});
  try {
    if (!page.url().startsWith(PROFILE)) await page.goto(PROFILE, { waitUntil: 'domcontentloaded', timeout: 60_000 }).catch(() => {});
    const guide = await stepGuide(context, { notify });
    for (let refusal = ''; ;) {
      const answer = await guide.show(
        `${refusal}Connect ${account.name}'s own Kalshi account. Confirm the signed-in account belongs to ${account.name}.\n\n` +
        '1. Sign in if Kalshi asks (Continue with Google).\n' +
        '2. On Profile, under API Keys, choose Create New API Key and use your own public key: paste the public key below and name it as below. If it offers access levels, allow reading and trading only.\n' +
        '3. Paste the Key ID Kalshi shows here.\n\n' +
        'If Kalshi only offers to make the key itself, let it, and choose "Kalshi made the key".',
        {
          values: [{ label: 'Key name', value: account.id === 'emsenn' ? KEY_NAME : `${KEY_NAME}-${account.id}` }, { label: 'Public key (Ed25519)', value: pair.publicKeyPem.trim() }],
          labels: ['Use this Key ID', 'Kalshi made the key', 'Stop'],
          input: { label: 'Key ID', pattern: KEY_ID_PATTERN, placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' },
        },
      );
      if (answer.label === 'Stop') throw stopped();
      let credentials = { apiKeyId: answer.value, privateKeyPem: pair.privateKeyPem }, keyFile = pair.path;
      if (answer.label === 'Kalshi made the key') {
        const keyId = await guide.show('Paste the Key ID Kalshi shows for the key it made.', { labels: ['Next', 'Stop'], input: { label: 'Key ID', pattern: KEY_ID_PATTERN } });
        if (keyId.label !== 'Next') throw stopped();
        const secret = await guide.show('Paste the private key Kalshi shows (it shows it once; the downloaded .txt holds the same text). It goes straight to the node\'s key file and is never shown again.', {
          labels: ['Use this key', 'Stop'], input: { label: 'Private key (-----BEGIN … PRIVATE KEY-----)', pattern: PEM_PATTERN, secret: true },
        });
        if (secret.label !== 'Use this key') throw stopped();
        const pem = normalizePrivateKeyPem(secret.value);
        if (!pem) { refusal = 'That was not used: the pasted text is not a private key.\n\n'; continue; }
        credentials = { apiKeyId: keyId.value, privateKeyPem: pem };
        keyFile = null;
      }
      const checked = await checkKey({ ...credentials, accountId: account.id }, { fetchImpl, env });
      if (!checked.ok) { refusal = `That was not used: ${checked.reason}.\n\n`; continue; }
      if (!keyFile) keyFile = await keepKey(credentials.privateKeyPem, env);
      const envFile = await keepKeyId(env, { apiKeyId: credentials.apiKeyId, keyFile });
      await guide.show(`Done: the desk's key signs in. Balance read: $${checked.balanceDollars}. This window closes in a minute.`, { labels: ['Close'], timeout: 60_000 }).catch(() => {});
      return { type: 'KalshiApiKeyCustody', accountId: account.id, apiKeyId: credentials.apiKeyId, keyFile, fingerprint: keyFile === pair.path ? pair.fingerprint : null, envFile, balanceDollars: checked.balanceDollars, orderEffect: false, at: new Date().toISOString() };
    }
  } catch (error) {
    if (error?.code === 'PROVISION_STOPPED') return { type: 'KalshiApiKeyCustody', stoppedEarly: true, at: new Date().toISOString() };
    throw error;
  } finally {
    await close();
  }
}

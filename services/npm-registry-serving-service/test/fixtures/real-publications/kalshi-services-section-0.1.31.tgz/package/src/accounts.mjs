/** Local signer accounts. Google subject identity belongs to ASSIST/PIS. */
export const KALSHI_ACCOUNTS = Object.freeze({
  emsenn: Object.freeze({ id: 'emsenn', name: 'Morgan (emsenn)', principal: 'urn:principal:emsenn', deskOrders: true, strategyAccountId: 'emsenn' }),
  // Esther, 2026-10-14: "Esther's strategy is to use Morgan's strategy, and Morgan consents to sharing their strategy with Esther."
  'esther-davis': Object.freeze({ id: 'esther-davis', name: 'Esther Davis', principal: 'urn:principal:esther-davis', deskOrders: true, strategyAccountId: 'emsenn' }),
});

export function kalshiAccount(env = process.env) {
  const id = env.KALSHI_ACCOUNT_ID ?? 'emsenn';
  if (!Object.hasOwn(KALSHI_ACCOUNTS, id)) throw new TypeError('unknown Kalshi account; select emsenn or esther-davis');
  return KALSHI_ACCOUNTS[id];
}

/** The original signer locations continue to belong to Morgan. */
export function accountCredentialLayout(env = process.env) {
  const account = kalshiAccount(env), original = account.id === 'emsenn';
  return {
    account,
    service: original ? 'kalshi' : `kalshi.${account.id}`,
    keyPlace: original ? 'keys/kalshi/house-weather-desk.pem' : `keys/kalshi/${account.id}/house-weather-desk.pem`,
    keyCredentialId: original ? 'kalshi.api-private-key' : `kalshi.${account.id}.api-private-key`,
    idCredentialId: original ? 'kalshi.api-key-id' : `kalshi.${account.id}.api-key-id`,
  };
}

/** Explicit files/environment keys need an owner assertion for a second signer. */
export function assertCredentialAccount(env = process.env) {
  const account = kalshiAccount(env), bound = env.KALSHI_CREDENTIAL_ACCOUNT_ID;
  if ((bound && bound !== account.id) || (account.id !== 'emsenn' &&
      (env.KALSHI_API_KEY_ID || env.KALSHI_PRIVATE_KEY_PATH || env.KALSHI_ENV_FILE) && bound !== account.id)) {
    throw new TypeError('Kalshi credential account does not match the selected account; do not reuse another signer environment');
  }
  return account;
}

/**
 * The numbers of content/config/weather-market-making.json that are derived from the model's out-of-sample scores
 * rather than chosen, as pure functions (scripts/derive-fits.mjs writes them; test/weather-soundness.test.mjs and
 * test/policy-derivation.test.mjs hold them to their inputs).
 *
 * The model is fitted on September and scored on October (forecasting record 2026-10-16-hourly-index-station-lattice,
 * results/market-<city>.json): per city and lead bucket, its Brier score and the market's (the previous trade's price)
 * on the same contracts.
 */

/** Kalshi's price tick as a probability: prices a tick apart do not disagree. */
export const TICK = 0.01;

/**
 * The model's mean squared error against the market, and its root, from one bucket's Brier scores.
 * Brier(model) - Brier(market) = E[(p - m)^2] + 2 E[(p - m)(m - y)]. If the market already holds what the model knows,
 * the second term is zero, and the Brier excess is the model's mean squared disagreement with the market, all of it
 * error. A model that scores better than the market has no measured error against it: excess 0.
 */
export const modelError = ({ modelBrier, marketBrier }) => { const excess = Math.max(0, modelBrier - marketBrier); return { excess, sd: Math.sqrt(excess) }; };

/** The disagreement (a probability) the desk leans through where observation has not settled the outcome: one RMS model error, at least a tick. */
export const disagreementTolerance = (scores) => Math.round(1e4 * Math.max(TICK, modelError(scores).sd)) / 1e4;

/** Per lead bucket of a city's market scores: the tolerance and the scores it was derived from. */
export const tolerancesOf = (market) => Object.fromEntries(Object.entries(market.byLeadMinutes).map(([bucket, r]) => [bucket, {
  disagreementTolerance: disagreementTolerance(r),
  toleranceBasis: { window: market.window, contracts: r.contracts, modelBrier: r.modelBrier, marketBrier: r.marketBrier },
}]));

/**
 * The most one ladder may stake, as a share of the desk's equity: fractional Kelly with a haircut for the estimation
 * error of the edge.
 *
 * - Kelly (1956): buying at price c a claim that wins with probability p, the growth-optimal share of wealth to stake is
 *   f* = (p - c) / (1 - c) = e / (1 - c), e the edge. For any price f* >= e, so a stake share of at most k e never
 *   exceeds k times Kelly's, whatever the price.
 * - The edge is estimated with error. Shrinking an estimate e of a true edge by the factor k = e^2 / (e^2 + s^2), s the
 *   standard deviation of the estimate's error, is the Bayesian posterior weight on the estimate (Baker and McHale 2013
 *   derive the same first-order haircut for Kelly under parameter uncertainty); fractional Kelly is this shrinkage
 *   (MacLean, Thorp and Ziemba 2010).
 * - s is the model's RMS error against the market (modelError), pooled over cities and leads weighted by contracts.
 *   The largest edge the desk acts on where observation has not settled the outcome is one such error (beyond it, it
 *   quotes around the market, weather-quotes.mjs), so e = s, k = 1/2, and the cap is s / 2.
 * Where the model scored better than the market in every bucket, s is 0 and the cap would be 0; the cap is floored at a tick.
 * @param {{contracts: number, modelBrier: number, marketBrier: number}[]} buckets
 * @returns {{errorSd: number, edge: number, haircut: number, cap: number}}
 */
export function stakeCap(buckets) {
  return capFromErrors(buckets.map((b) => ({ weight: b.contracts, sd: modelError(b).sd })));
}

/** The cap from per-bucket model errors (their standard deviations, weighted): the derivation above, whatever measured them. */
export function capFromErrors(errors) {
  const total = errors.reduce((sum, e) => sum + e.weight, 0);
  if (!(total > 0)) throw new RangeError('a stake cap needs scored contracts');
  const errorSd = Math.sqrt(errors.reduce((sum, e) => sum + (e.weight / total) * e.sd ** 2, 0));
  const edge = errorSd, haircut = edge > 0 ? (edge * edge) / (edge * edge + errorSd * errorSd) : 0;
  return { errorSd, edge, haircut, cap: Math.round(1e4 * Math.max(TICK, haircut * edge)) / 1e4 };
}

/**
 * Merge freshly derived city lead policies into the existing ones, keeping every key the derivation does not own:
 * a lead's other keys, a side's other keys, a city's other keys.
 * @param {object} city the existing cities.<city> policy
 * @param {Record<string, Record<string, {calibration: number[], bands: object[]}>>} derivedSides bucket -> side -> derived
 * @param {Record<string, object>} derivedLead bucket -> derived lead keys (tolerance)
 */
export function mergeLeads(city, derivedSides, derivedLead) {
  const leads = { ...city.leads };
  for (const [bucket, sides] of Object.entries(derivedSides)) {
    const existing = city.leads?.[bucket] ?? {};
    leads[bucket] = { ...existing, ...derivedLead[bucket], ...Object.fromEntries(Object.entries(sides).map(([side, derived]) => [side, { ...existing[side], ...derived }])) };
  }
  return { ...city, leads };
}

// ---- From the live scores (src/live-scores.mjs), once there are enough of them.

/**
 * The model's error against the market in one live cell, as a standard deviation of probability.
 * Where the model scores worse than the market (or not significantly better), it is the replay's rule: the root of the
 * Brier excess, all of it error. Where its bootstrap interval for model-minus-market Brier lies wholly below zero, the
 * model knows something the market does not, its disagreements are paid for, and the error it can be trusted through is
 * the root-mean-square disagreement itself: a model that earns its disagreements is not made stricter for having them.
 */
export function liveError(cell) {
  const beats = cell.dBrierCI?.[1] < 0;
  return beats ? cell.rmsDisagreement : Math.sqrt(Math.max(0, cell.dBrier));
}

/** The disagreement tolerance of a live cell, or null while it has fewer than `minEvents` scored ladders (the replay's stands). */
export function liveTolerance(cell, minEvents) {
  return cell && cell.events >= minEvents ? Math.round(1e4 * Math.max(TICK, liveError(cell))) / 1e4 : null;
}

/**
 * The stake cap from the live cells (city by lead bucket), or null until the cells with at least `minEvents` ladders hold
 * `minPooled` between them. Weighted by the minutes scored, the same fractional Kelly rule (capFromErrors).
 */
export function liveStakeCap(cells, minEvents, minPooled) {
  const enough = cells.filter((c) => c && c.events >= minEvents);
  if (enough.reduce((sum, c) => sum + c.events, 0) < minPooled) return null;
  return capFromErrors(enough.map((c) => ({ weight: c.minutes, sd: liveError(c) }))).cap;
}

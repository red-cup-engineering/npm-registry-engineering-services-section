import {hashPosition} from '@red-cup-engineering/gaming/running/rules';
import {binarySettlement} from './market-facts.mjs';

function fixed(value, places) {
 if(typeof value!=='string'||!/^\d+(?:\.\d+)?$/.test(value))throw new TypeError('nonnegative-fixed-decimal-required');
 const [whole,fraction='']=value.split('.');
 if(fraction.length>places)throw new TypeError('fixed-decimal-precision-exceeded');
 return BigInt(whole)*10n**BigInt(places)+BigInt(fraction.padEnd(places,'0'));
}
/** Verify the venue's settlement payout, not the full account cash book.
 * Costs and fees are venue-attested; they are not independently reconstructed fills. */
export function reconcileSettlementPayout({settlement,market,observedAt}) {
 const final=binarySettlement(market),at=Date.parse(observedAt),paidAt=Date.parse(settlement?.settled_time);
 if(!final||!Number.isFinite(at)||!Number.isFinite(paidAt)||Date.parse(final.settledAt)>at||paidAt>at||market.ticker!==settlement?.ticker||market.event_ticker!==settlement.event_ticker||final.result!==settlement.market_result||fixed(market.notional_value_dollars,6)!==1000000n)throw new TypeError('matching-finalized-one-dollar-settlement-required');
 if(!Number.isSafeInteger(settlement.revenue)||settlement.revenue<0||!Number.isSafeInteger(settlement.exchange_index)||settlement.exchange_index<0)throw new TypeError('exact-settlement-revenue-and-exchange-required');
 const yes=fixed(settlement.yes_count_fp,2),no=fixed(settlement.no_count_fp,2);
 const expected=(final.outcome===1?yes:no)*10000n,reported=BigInt(settlement.revenue)*10000n;
 const costs=fixed(settlement.yes_total_cost_dollars,6)+fixed(settlement.no_total_cost_dollars,6),fees=fixed(settlement.fee_cost,6);
 const source=structuredClone({settlement,market,observedAt});
 const body={type:'KalshiSettlementPayoutReconciliation',version:1,ticker:market.ticker,exchangeIndex:settlement.exchange_index,settledAt:settlement.settled_time,observedAt,scope:'finalized binary payout against venue-reported settled holdings',expectedRevenueMicroUsd:expected.toString(),reportedRevenueMicroUsd:reported.toString(),venueReportedCostMicroUsd:costs.toString(),venueReportedFeesMicroUsd:fees.toString(),settledPositionNetMicroUsd:(reported-costs-fees).toString(),payoutReconciled:expected===reported,accountCashReconciled:false,costBasisReconstructed:false,source};
 return {id:hashPosition(body),...body};
}

// The same Kalshi accounting provider now also checks an entire isolated
// position against original fill cost, fees, payout and account cash.
export {reconcileIsolatedKalshiYesClose,reconcileKalshiDeskOrderOutcomes,reconcileKalshiDeskUnfilledOrders,readFinalBinaryMarket} from './settlement-fill-accounting.mjs';

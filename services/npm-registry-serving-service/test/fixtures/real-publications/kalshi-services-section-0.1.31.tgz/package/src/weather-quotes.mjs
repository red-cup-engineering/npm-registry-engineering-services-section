/**
 * The quotes a market maker rests on one hourly temperature ladder: from what the weather makes possible by
 * settlement, given a fill, the book, what the account holds, and the margin the tape says a fill costs.
 *
 * 1. Fair value is the weather. The station lattice's P(index > K) knows what the stations, the diurnal climatology
 *    and the guidance make physically reachable in the time left. A resting quote fills only when a taker chooses to
 *    trade against it (Glosten-Milgrom), so each side is valued at the model's probability calibrated on the fills of
 *    that side: the YES bid at P(YES | q, a taker sells YES), the NO bid at P(YES | q, a taker buys YES), monotone in
 *    q, per lead (forecasting record 2026-10-16-hourly-index-station-lattice, calibrate-model.mjs). The market's
 *    price is not an input: where the weather has put a strike out of reach the tape's takers still pay 2-5 cents for
 *    it, and that is the edge. Each side's values are made coherent across the ladder (a higher strike is never more
 *    likely; pool-adjacent-violators) and differenced into the outcome bands.
 * 2. Reservation prices. For each strike and side, the price at which one more contract leaves the account's
 *    expected CRRA utility over that side's bands unchanged, given its holdings across the ladder and the carry of
 *    the capital the contract locks until settlement (position-sizing ladderReservationPrices: carry = the hurdle
 *    rate of the desk's capital times the ladder's lead). Inventory skew, cross-strike hedging and turnover
 *    preference are this, not added terms. The holdings are the account's, whoever traded them.
 * 3. Margin. Per lead, side and band of the model's probability, the one the tape says earned most, held out in
 *    both directions; a strike whose band has none is one the side abstains on. The target is the reservation price
 *    less the margin, on the cent grid.
 * 4. Priority. Price-time priority rewards one cent better than everyone else's best bid; paying more buys nothing.
 *    A bid goes to the lower of its target and that best bid plus a cent. A bid that cannot at least join everyone
 *    else's best is not rested: behind the touch it fills only when a sweep runs through the levels ahead of it, the
 *    fills that are most against it, and meanwhile it holds cash the quotes at the touch could use. "Everyone else" excludes the account's own
 *    resting orders (the desk's and its holder's): the desk never outbids its own account. A bid never goes to or
 *    above the best offer of the whole book, the account's own included (post-only, and no trade with itself).
 * 5. Size. The number of contracts that maximizes expected utility at the order's price plus the margin (what a
 *    fill is expected to cost), given holdings (position-sizing ladderOptimalContracts), within `maxContracts`.
 * 6. Bounds (ladderQuotes). Three invariants hold for every quote, whatever the model says:
 *    - Never buy an excluded outcome. When the observed index cannot reach the outcome a bid buys (weather-exclusion:
 *      the index's recorded rate envelope from the latest published value), the strike's side is not quoted.
 *    - Never pay more than fair value. A bid's price plus its margin never exceeds the side's win probability (the
 *      coherent fair value of the outcome it buys), even where a hedge's reservation price is higher.
 *    - Never stake the account on one weather. Fair values are calibrated point estimates, and log-utility sizing
 *      treats them as known: at a calibrated 0.979 against a 66c price it stakes 94% of equity, so one storm the
 *      model has no term for (2026-10-17, Miami: 58 contracts, $38.28) ruins the account. All of a ladder's quotes
 *      together commit at most `stakeBudget` dollars (the policy's maxStakeFraction of the desk's equity, less what
 *      the ladder already holds), spent on the largest edge (win probability less price) first.
 * 7. Requote (requote). Kalshi keeps an order's place in its queue only when an amend shrinks it; a new price or a
 *    larger size goes to the back. So a resting order is moved only when it must be (it stands above its target or
 *    overpays everyone else's best bid) or when the move gains rank, and it is grown only when no one waits behind it.
 *
 * 8. Soundness (ladderQuotes), on the grounds of standard market-making practice.
 *    - Inventory control (Avellaneda-Stoikov 2008; Gueant-Lehalle-Fernandez-Tapia 2013). A market maker's reservation
 *      price is the mid less inventory x risk aversion x variance x time left, so quotes skew against the inventory it
 *      holds (item 2 is that skew, with the CRRA utility's risk aversion; it needs no added term), and past an
 *      inventory limit it stops quoting the side that adds to it. The limit here is `inventoryBudget` dollars of
 *      same-direction inventory at the quote's price, counted in contracts held (not their model mark: a mark that
 *      falls with the model would reopen the budget just as the desk is wrong), so the desk never accumulates one
 *      side without bound.
 *    - Adverse-selection protection (Glosten-Milgrom 1985; Easley-O'Hara). A counterparty who trades against a quote
 *      may know more. Where the model and the market disagree by more than `tolerance` and the observations have not
 *      determined the outcome, the model is more likely missing a term (a storm) than ahead of the market, so the
 *      desk quotes around the market, never above the model, at one contract: it still provides the liquidity but
 *      does not lean. The tolerance is the model's own error against the market, derived from its out-of-sample
 *      Brier scores in derive-fits.mjs (cities.<city>.leads.<bucket>.disagreementTolerance).
 *    - Leaning is for what observation has settled. A side is leant on only where weather-exclusion (the single
 *      source) excludes the opposite outcome. There the model is not the only evidence, the physics bounds the outcome.
 *
 * Prices are whole cents (Kalshi's hourly ladders tick in cents); a YES ask at a is a NO bid at 100 - a.
 */
import { ladderReservationPrices, ladderOptimalContracts } from '@red-cup-engineering/position-sizing-service';

/** The size of a quote the desk will not lean on: it provides the liquidity and risks one contract. */
export const MINIMAL_CONTRACTS = 1;

/** P(index > strike) for each strike, from an index distribution [{value, p}]. */
export function strikeProbabilitiesOf(distribution, strikes) {
  return strikes.map((k) => { let p = 0; for (const d of distribution) if (d.value > k) p += d.p; return Math.min(1, Math.max(0, p)); });
}

/** The calibrated value of a model probability: the step of `values` over the bins `edges` that holds q. */
export function calibratedValue(edges, values, q) {
  let i = 0; while (i < edges.length - 2 && q >= edges[i + 1]) i += 1;
  return values[i];
}

/** The margin (cents) of the band of `bands` ([{from, to, marginCents}]) that holds q; null (abstain) outside them. */
export function bandMargin(bands, q) {
  return bands?.find((b) => q >= b.from && q < b.to)?.marginCents ?? null;
}

/** The closest non-increasing sequence in least squares (pool adjacent violators), clipped to [0, 1]. */
export function nonIncreasing(values) {
  const blocks = [];
  for (const v of values) {
    blocks.push({ sum: v, n: 1 });
    while (blocks.length > 1 && blocks.at(-2).sum / blocks.at(-2).n < blocks.at(-1).sum / blocks.at(-1).n) { const b = blocks.pop(); blocks.at(-1).sum += b.sum; blocks.at(-1).n += b.n; }
  }
  return blocks.flatMap((b) => Array.from({ length: b.n }, () => Math.min(1, Math.max(0, b.sum / b.n))));
}

/** Outcome-band probabilities of a ladder from its coherent strike probabilities (band 0 below the first strike). */
export function bandsOf(strikeProbabilities) {
  const p = nonIncreasing(strikeProbabilities), bands = [1 - p[0]];
  for (let j = 1; j < p.length; j += 1) bands.push(p[j - 1] - p[j]);
  bands.push(p.at(-1));
  const total = bands.reduce((s, x) => s + x, 0);
  return bands.map((x) => Math.max(0, x) / total);
}

/**
 * Contract, before the code: the quotes returned (a) never include a side of a strike whose bought outcome `excluded[side][j]`
 * marks as excluded by observation, (b) never have price + margin above 100 x the side's coherent win probability,
 * and (c) together cost no more than `stakeBudget` dollars at their prices.
 * @param {{strikes: {ticker: string, strike: number}[], fair: {yes: number[], no: number[]}, book: ({bid: number|null, ask: number|null}|null)[],
 *   cross?: ({bid: number|null, ask: number|null}|null)[], wealth: number, holdings?: {yes: number[], no: number[]}, relativeRiskAversion: number,
 *   marginCents: {yes: (number|null)[], no: (number|null)[]}, maxContracts: number, carry?: number,
 *   excluded?: {yes: boolean[], no: boolean[]}, stakeBudget?: number}} input
 *   excluded[side][j]: the outcome that side's bid buys at strike j (YES for the YES bid, NO for the NO bid) is excluded by observation;
 *   stakeBudget: dollars all the quotes together may commit (default: no bound; the desk always passes one)
 *   tolerance: the largest model-market disagreement in probability the desk leans through; beyond it, where observation has not
 *   determined the outcome, a quote is around the market at `MINIMAL_CONTRACTS` (default null: no guard; the desk always passes one)
 *   inventoryBudget: dollars of same-direction inventory the ladder may hold at a quote's price, held contracts included (default: no bound)
 *   marginCents per side and strike, null where that side abstains on that strike
 *   fair.yes[j] / fair.no[j]: coherent P(YES) per strike given a fill of the YES bid / the NO bid; book: everyone
 *   else's best YES bid and ask, in cents; cross: the whole book's (default: book); carry: the hurdle rate times the
 *   lead (0 when the desk's capital does not bind)
 * @returns {{ticker: string, side: 'yes'|'no', priceCents: number, targetCents: number, contracts: number, reservationCents: number}[]}
 */
export function ladderQuotes({ strikes, fair, book, cross = book, wealth, holdings, relativeRiskAversion, marginCents, maxContracts, carry = 0, excluded = null, stakeBudget = Infinity, tolerance = null, inventoryBudget = Infinity }) {
  if (!(wealth > 0)) return [];
  const held = holdings ?? { yes: strikes.map(() => 0), no: strikes.map(() => 0) }, quotes = [];
  // Held same-direction inventory in contracts: YES bids add to net-YES strikes, NO bids to net-NO strikes.
  const heldDirection = { yes: 0, no: 0 };
  strikes.forEach((_, j) => { const net = (held.yes[j] ?? 0) - (held.no[j] ?? 0); heldDirection.yes += Math.max(0, net); heldDirection.no += Math.max(0, -net); });
  if (!(stakeBudget > 0)) return [];
  for (const side of ['yes', 'no']) {
    const margins = marginCents?.[side];
    if (!fair?.[side] || !margins?.some((m) => m !== null && m !== undefined)) continue;
    const bands = bandsOf(fair[side]), coherent = nonIncreasing(fair[side]), reservation = ladderReservationPrices({ bands, wealth, holdings: held, relativeRiskAversion, carry })[side];
    strikes.forEach(({ ticker }, j) => {
      const margin = margins[j];
      if (margin === null || margin === undefined || excluded?.[side]?.[j]) return;
      // The side's win probability: the coherent P(YES) for the YES bid, its complement for the NO bid.
      const win = side === 'yes' ? coherent[j] : 1 - coherent[j];
      // Lean only on what observation has determined: the opposite outcome is excluded (weather-exclusion). Elsewhere the
      // model leans only while it agrees with the market, whose mid (others' book; one side alone is its price) anchors it.
      const { bid: otherBid = null, ask: otherAsk = null } = book[j] ?? {};
      const marketYes = otherBid !== null && otherAsk !== null ? (otherBid + otherAsk) / 200 : otherBid !== null ? otherBid / 100 : otherAsk !== null ? otherAsk / 100 : null;
      const marketWin = marketYes === null ? null : side === 'yes' ? marketYes : 1 - marketYes;
      const determined = Boolean(excluded?.[side === 'yes' ? 'no' : 'yes']?.[j]);
      const leans = tolerance === null || determined || (marketWin !== null && Math.abs(win - marketWin) <= tolerance);
      if (!leans && marketWin === null) return; // disagreement cannot be measured and nothing has settled it: no quote
      const anchor = leans ? win : Math.min(win, marketWin);
      const r = leans ? reservation[j] : Math.min(reservation[j], anchor), target = Math.floor(100 * r - margin + 1e-9);
      // The side's own book: a NO bid at n is a YES ask at 100 - n.
      const { bid = null, ask = null } = book[j] ?? {}, whole = cross[j] ?? {};
      const best = side === 'yes' ? bid : ask === null ? null : 100 - ask;
      const against = side === 'yes' ? whole.ask ?? null : whole.bid === null || whole.bid === undefined ? null : 100 - whole.bid;
      let price = best === null ? target : Math.min(target, best + 1);
      if (against !== null) price = Math.min(price, against - 1);
      // Never above fair value: a hedge may be worth more than the outcome it buys (its reservation), but is never paid above it.
      price = Math.min(price, Math.floor(100 * anchor - margin + 1e-9));
      if (price < 1 || price > 99 || (best !== null && price < best)) return;
      const sized = Math.min(leans ? maxContracts : MINIMAL_CONTRACTS, ladderOptimalContracts({ bands, wealth, holdings: held, relativeRiskAversion, strike: j, side, price: Math.min(1, (price + margin) / 100), max: maxContracts, carry }));
      if (sized > 0) quotes.push({ ticker, side, priceCents: price, targetCents: target, contracts: sized, reservationCents: 100 * r, edgeCents: 100 * anchor - price, ...(leans ? {} : { aroundMarket: true }) });
    });
  }
  // The stake budget, spent on the largest edge first; quotes keep their ladder order.
  // The inventory limit then takes what the same direction already holds, and what earlier quotes of it take, off the room.
  let left = stakeBudget;
  const taken = { yes: 0, no: 0 };
  for (const q of [...quotes].sort((a, b) => b.edgeCents - a.edgeCents)) {
    const room = Math.floor((inventoryBudget * 100) / q.priceCents + 1e-9) - heldDirection[q.side] - taken[q.side];
    q.contracts = Math.max(0, Math.min(q.contracts, Math.floor((left * 100) / q.priceCents + 1e-9), room));
    left -= (q.contracts * q.priceCents) / 100;
    taken[q.side] += q.contracts;
  }
  return quotes.filter((q) => q.contracts > 0).map(({ edgeCents, ...q }) => q);
}

/**
 * What to do with one resting order, given the quote wanted on its strike and side now (Kalshi: price-time priority;
 * an amend keeps the order's place only when it shrinks it).
 *
 * - cancel: no quote is wanted.
 * - move (to the wanted price and size): the order stands above the wanted price, so it is above its target (unsafe)
 *   or overpays everyone else's best bid (one cent above it is as good); or it waits behind someone and its target
 *   has cleared its price by a full cent, so the move gains rank. A target within a cent of the order's price is the
 *   cent grid's rounding, and chasing it would only spend the order's place.
 * - resize: the order is kept, at a smaller size (always: an amend that shrinks keeps its place) or a larger one
 *   by more than one contract (an optimum alternating between neighbouring integers is rounding, like the cent
 *   above) when no one waits behind it at its price (growing then costs nothing).
 * - keep.
 * @param {{order: {priceCents: number, remaining: number, ahead: number}, quote?: {priceCents: number, targetCents: number, contracts: number},
 *   othersAt: (priceCents: number) => number, othersBest: number|null}} input
 *   ahead: everyone else's contracts queued before the order at its price; othersAt: everyone else's contracts at a
 *   price on the order's side; othersBest: everyone else's best price on that side (null when none)
 * @returns {'cancel'|'move'|'resize'|'keep'}
 */
export function requote({ order, quote, othersAt, othersBest }) {
  if (!quote) return 'cancel';
  const r = order.priceCents;
  if (r > quote.priceCents) return 'move';
  const first = order.ahead <= 0 && !(othersBest !== null && othersBest > r);
  if (!first && r < Math.min(quote.priceCents, quote.targetCents - 1)) return 'move';
  if (quote.contracts < order.remaining) return 'resize';
  if (quote.contracts >= order.remaining + 2 && othersAt(r) <= order.ahead) return 'resize';
  return 'keep';
}

/**
 * The market maker's quotes resting on the venue for one account, when that account is armed.
 *
 * - Identity. Every order carries a client order ID with the desk's own prefix (`kd-wmm-`); the executor touches
 *   no order without it, so a person's hand-placed orders are never moved or cancelled.
 * - Kill switch. All of a run's orders belong to one order group. Kalshi cancels every order in a group when more
 *   contracts match within a rolling 15 seconds than the group's limit. The venue can match no more than the desk
 *   offers, so the limit is bounded by what the desk believes it has offered: the contracts resting in the group plus
 *   those it has seen fill in the last 15 seconds. A legitimate sweep of every quote never trips it; what trips it is
 *   the venue filling contracts the desk does not know it offered (an order it thinks cancelled, one rested twice, a
 *   fill it never heard of). The limit is raised before an order rests or grows past it, to twice what is then
 *   offered, and never lowered: every limit change is a write against the same budget as the quotes, and raising it
 *   only when the book outgrows it keeps those writes logarithmic in the book's size.
 * - Tripped. When the venue tells the group was triggered (or deleted), `tripped` settles: the desk stops, and its
 *   supervisor restarts it into a fresh run that re-reads the account from the venue.
 * - Gone orders. An amend or cancel the venue answers 404 is of an order that no longer rests (filled, expired,
 *   cancelled by the venue): the executor forgets it rather than retrying.
 * - Ownership. The executor owns the orders it has rested and those still in flight; a resting order with the desk's
 *   prefix that it does not own (left by a write whose answer never came, or by an earlier run) is an orphan, and
 *   `cancelOrphan` removes it.
 * - Restart. Opening cancels every resting order of ours left by an earlier run, so a restarted service never
 *   trusts quotes it did not place.
 * - Account. Orders and the group name the account's subaccount (0 is the primary).
 * - Orders are post-only, cancel on a trading pause, never trade with the account's own orders, and expire at their
 *   ladder's settlement. A reprice amends the order rather than replacing it.
 * - Fills come from the account's private channel (stream.mjs onAccount), by order ID.
 */
import { createHash } from 'node:crypto';

export const CLIENT_ORDER_PREFIX = 'kd-wmm-';
/** Kalshi's order-group window: contracts matched within it are counted against the group's limit. */
export const ORDER_GROUP_WINDOW_MS = 15_000;

/** A client order ID: the prefix and a digest of the run, the quote and its version (a venue ID is at most 64). */
export const clientOrderId = (run, key, version) => `${CLIENT_ORDER_PREFIX}${createHash('sha256').update(`${run}:${key}:${version}`).digest('hex').slice(0, 32)}`;

/**
 * @param {{client: object, run: string, subaccount?: number, onFill: (key: string, contracts: number, priceCents: number) => void,
 *   log?: (line: string) => void, clock?: () => number}} options
 *   client: the account's venue client (createKalshiClient); run: this run's identity
 */
export function createVenueExecutor({ client, run, subaccount = 0, onFill, log = () => {}, clock = Date.now }) {
  if (!Number.isSafeInteger(subaccount) || subaccount < 0 || subaccount > 63) throw new RangeError('a subaccount is 0..63');
  const byOrderId = new Map(), byKey = new Map(), recent = [], inflight = new Set();
  let trip = () => {};
  const tripped = new Promise((resolve) => { trip = resolve; });
  let group = null, versions = 0, limit = null, limits = Promise.resolve();
  const account = subaccount ? { subaccount } : {};

  /** YES bid at p cents is a buy of YES at p; a NO bid at n is a sell of YES at 100 - n (Kalshi V2 order sides). */
  const venueSide = (order) => (order.side === 'yes' ? { side: 'bid', price: order.priceCents / 100 } : { side: 'ask', price: (100 - order.priceCents) / 100 });
  const offered = (extra = 0) => {
    const since = clock() - ORDER_GROUP_WINDOW_MS;
    while (recent.length && recent[0].at < since) recent.shift();
    let n = extra;
    for (const held of byKey.values()) n += held.resting;
    for (const fill of recent) n += fill.contracts;
    return Math.max(1, Math.ceil(n));
  };
  /** Raise the group's limit to twice what is offered when what is offered (plus `extra` about to rest) passes it. */
  const keepLimit = (extra = 0) => {
    limits = limits.then(async () => {
      const needed = offered(extra);
      if (needed <= limit) return;
      const wanted = 2 * needed;
      await client.call('PUT', `/portfolio/order_groups/${group}/limit`, { body: { contracts_limit: wanted }, query: account });
      limit = wanted;
    });
    return limits;
  };
  const gone = (error) => error?.status === 404 || /^http-404/u.test(error?.message ?? '');
  const forget = (key) => { const held = byKey.get(key); if (held) { byKey.delete(key); byOrderId.delete(held.orderId); } };

  return Object.freeze({
    async open() {
      const resting = await client.getOrders({ status: 'resting', ...account });
      const ours = resting.filter((o) => String(o.client_order_id ?? '').startsWith(CLIENT_ORDER_PREFIX));
      for (const o of ours) await client.cancelOrder(o.order_id, o.ticker, account);
      const created = await client.call('POST', '/portfolio/order_groups/create', { body: { contracts_limit: 1, ...account } });
      group = created?.order_group_id; limit = 1;
      if (typeof group !== 'string' || !group) throw new Error('the venue did not return an order group');
      log(`[venue-executor] run ${run}: cancelled ${ours.length} stale order(s); order group ${group}, limited to what this run offers\n`);
      return { cancelled: ours.length, group };
    },
    /** Rest one quote ({key, ticker, side, priceCents, contracts, settle}); resolves with the venue order ID. */
    async rest(order) {
      await keepLimit(order.contracts);
      const id = clientOrderId(run, order.key, versions += 1), { side, price } = venueSide(order);
      inflight.add(id);
      const reply = await client.createOrder({ ticker: order.ticker, side, count: order.contracts, price, postOnly: true, clientOrderId: id,
        expirationTime: Math.floor(order.settle / 1000), orderGroupId: group, ...account }).finally(() => inflight.delete(id));
      // The V2 create (POST /portfolio/events/orders) answers the order's ID at the top level (docs: create-order-v2).
      const orderId = reply?.order_id;
      if (typeof orderId !== 'string') throw new Error(`the venue did not acknowledge ${order.ticker} ${order.side}`);
      byOrderId.set(orderId, order.key); byKey.set(order.key, { orderId, ticker: order.ticker, side: order.side, priceCents: order.priceCents, clientOrderId: id, resting: order.contracts });
      return orderId;
    },
    /** Move a resting quote to a new price or size (`contracts`: what should rest after the amend). */
    async amend(order) {
      const held = byKey.get(order.key); if (!held) return this.rest(order);
      const growth = Math.max(0, order.contracts - held.resting);
      if (growth) await keepLimit(growth);
      const { side, price } = venueSide(order), updated = clientOrderId(run, order.key, versions += 1);
      try { await client.amendOrder({ orderId: held.orderId, ticker: order.ticker, side, count: (order.filled ?? 0) + order.contracts, price, clientOrderId: held.clientOrderId, updatedClientOrderId: updated, ...account }); }
      catch (error) { if (gone(error)) forget(order.key); throw error; }
      held.resting = order.contracts; held.priceCents = order.priceCents; held.clientOrderId = updated;
      return held.orderId;
    },
    async cancel(order) {
      const held = byKey.get(order.key); if (!held) return false;
      try { await client.cancelOrder(held.orderId, held.ticker, account); }
      catch (error) { if (!gone(error)) throw error; }
      forget(order.key);
      return true;
    },
    /** An account message from the stream: a fill of one of our orders is reported by its quote key. */
    account(message) {
      if (message?.type === 'order_group_updates' && message.msg?.order_group_id === group && ['triggered', 'deleted'].includes(message.msg?.event_type)) {
        trip(new Error(`the venue ${message.msg.event_type} order group ${group}: the desk stops and restarts from the venue's account`));
        return;
      }
      if (message?.type !== 'fill') return;
      const m = message.msg ?? {}, key = byOrderId.get(m.order_id);
      if (!key) return;
      const contracts = Number(m.count_fp ?? m.count), held = byKey.get(key);
      const yesPrice = Number(m.yes_price_dollars), priceCents = held?.side === 'no' ? Math.round(100 * (1 - yesPrice)) : Math.round(100 * yesPrice);
      if (!(Number.isFinite(contracts) && contracts > 0 && Number.isFinite(priceCents))) return;
      // A fill moves contracts from resting to the window's matched count: what is offered does not change.
      if (held) held.resting = Math.max(0, held.resting - contracts);
      recent.push({ at: clock(), contracts });
      onFill(key, contracts, priceCents);
    },
    /** Cancel every order of this run (drain). */
    async close() {
      for (const [key] of [...byKey]) { try { await this.cancel({ key }); } catch (error) { log(`[venue-executor] cancel ${key}: ${error.message}\n`); } }
    },
    /** What the acknowledged resting orders hold out of the account's available cash ($). */
    heldCost() { let c = 0; for (const held of byKey.values()) c += (held.resting * held.priceCents) / 100; return c; },
    /** Whether a venue order ({order_id, client_order_id}) is one this run rested or is resting now. */
    owns: (o) => byOrderId.has(o?.order_id) || inflight.has(o?.client_order_id),
    /** Cancel a desk order this run does not own (gone already counts as cancelled). */
    async cancelOrphan(orderId, ticker) {
      try { await client.cancelOrder(orderId, ticker, account); } catch (error) { if (!gone(error)) throw error; }
    },
    /** Settles with an Error when the venue trips the run's order group. */
    tripped,
    group: () => group,
    limit: () => limit,
  });
}

/**
 * Kalshi market data as EAVT facts for the house journal. Pure.
 *
 * The data layer is the MetroPlat journal (computer-system-engine `openJournal(root).appendRows(feed, rows)`)
 * under the kalshi-services-section settlement territory, carrying `@red-cup-engineering/eavt-services-section` rows
 * {e, a, v, t}. Current state is the journal's own projection (`journal.projectState(log, FUNCTIONAL)`: the
 * latest value of each functional attribute per entity, folded in memory bounded by entities × attributes),
 * and SignCraft admits rows into cells only when something reasons over them. Nothing here keeps a private
 * store.
 *
 * Feeds: `kalshi-catalog` (series, event and market facts; only changed values are appended),
 * `kalshi-sources` (settlement-source arrivals). Trades and lifecycle events are not kept: Kalshi serves them
 * again for every market (GET /markets/trades, GET /markets/{ticker}). Units follow the arena: prices in ten-thousandths of a dollar, quantities in hundredths.
 */

const pips = (dollars) => (dollars === undefined || dollars === null || dollars === '' ? null : Math.round(Number(dollars) * 10000));
const hundredths = (fp) => (fp === undefined || fp === null || fp === '' ? null : Math.round(Number(fp) * 100));
const iso = (ms) => new Date(ms).toISOString();

/**
 * One Kalshi event ticker's declared LOCAL CALENDAR DAY. A ticker date is
 * neither a UTC settlement instant nor permission to use future source data.
 *
 * This venue-wide decoder is shared by weather, gasoline, diesel and other
 * series. It rejects impossible Gregorian dates instead of normalizing
 * e.g. 26FEB30 to March. No extra venue-specific data type.
 */
const TICKER_MONTHS=Object.freeze({JAN:1,FEB:2,MAR:3,APR:4,MAY:5,JUN:6,
  JUL:7,AUG:8,SEP:9,OCT:10,NOV:11,DEC:12});
export function eventDate(eventTicker){
 const m=/-([0-9]{2})([A-Z]{3})([0-9]{2})$/u.exec(eventTicker??'');
 if(!m||!TICKER_MONTHS[m[2]])return null;
 const year=2000+Number(m[1]),month=TICKER_MONTHS[m[2]],day=Number(m[3]);
 const utc=new Date(Date.UTC(year,month-1,day));
 if(utc.getUTCFullYear()!==year||utc.getUTCMonth()+1!==month||utc.getUTCDate()!==day)
  return null;
 return utc.toISOString().slice(0,10);
}


export const FEEDS = Object.freeze({ catalog: 'kalshi-catalog', sources: 'kalshi-sources' });

/** Catalog attributes whose latest value is the current one (all catalog fields are single-valued). */
const SERIES_FIELDS = ['title', 'category', 'tags', 'frequency', 'fee_type', 'fee_multiplier', 'settlement_sources', 'contract_url', 'contract_terms_url'];
const EVENT_FIELDS = ['series_ticker', 'title', 'sub_title', 'strike_date', 'mutually_exclusive', 'category'];
const MARKET_FIELDS = ['event_ticker', 'title', 'yes_sub_title', 'strike_type', 'floor_strike', 'cap_strike', 'custom_strike', 'rules_primary', 'rules_secondary', 'open_time', 'close_time', 'expected_expiration_time', 'latest_expiration_time', 'settlement_timer_seconds', 'can_close_early', 'status', 'result', 'market_type', 'settlement_ts', 'settlement_value_dollars', 'notional_value_dollars', 'is_provisional', 'volume_fp', 'open_interest_fp', 'liquidity_dollars', 'price_level_structure'];
export const FUNCTIONAL = Object.freeze([
  ...SERIES_FIELDS.map((f) => `kalshi:series.${f}`), ...EVENT_FIELDS.map((f) => `kalshi:event.${f}`), ...MARKET_FIELDS.map((f) => `kalshi:market.${f}`),
]);

const factsOf = (kind, ticker, obj, fields, t) => fields.filter((f) => obj[f] !== undefined && obj[f] !== null && obj[f] !== '').map((f) => ({ e: ticker, a: `kalshi:${kind}.${f}`, v: obj[f], t }));

/** Catalog facts for one series, event or market object observed at `t` (ISO). */
export const seriesRows = (s, t) => factsOf('series', s.ticker, s, SERIES_FIELDS, t);
export const eventRows = (e, t) => factsOf('event', e.event_ticker, e, EVENT_FIELDS, t);
export const marketRows = (m, t) => factsOf('market', m.ticker, m, MARKET_FIELDS, t);

/**
 * The rows that change the current state: those whose value differs from `current(e, a)` (the projected
 * latest value, or undefined). Values compare by canonical JSON, so an unchanged re-observation appends nothing.
 */
export function changedRows(rows, current) {
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  return rows.filter((r) => !same(current(r.e, r.a), r.v));
}

/** A settlement-source arrival (a communicating CloudEvent from src/sources.mjs) as one fact. */
export const arrivalRow = (event, settlementSource) => ({
  e: event.data.deduplicationKey ?? event.id, a: 'kalshi:source.arrival',
  v: { source: settlementSource, url: event.source, feed: event.data.feed?.id ?? null, item: event.data.item ?? event.data.value ?? null }, t: event.time,
});

/** Preserve the venue's distinct timing declarations for prospective ranking.
 * Expiration is an estimate of event expiry; the timer starts at determination.
 * These declarations do not certify a future settlement or change outcome odds.
 * https://docs.kalshi.com/api-reference/market/get-market */
export function marketSettlementTiming(market) {
  const clock = value => typeof value === 'string' && Number.isFinite(Date.parse(value)) ? value : null;
  const timer = market?.settlement_timer_seconds;
  return {
    expectedExpirationTime: clock(market?.expected_expiration_time),
    latestExpirationTime: clock(market?.latest_expiration_time),
    settlementTimerSeconds: Number.isSafeInteger(timer) && timer >= 0 ? timer : null,
  };
}

/** Definitive binary label, with the venue's actual settlement clock. Never use expiration as settlement. */
export function binarySettlement(market) {
  if (!market || !['finalized', 'settled'].includes(market.status)
      || market.market_type !== 'binary' || market.is_provisional === true
      || !['yes', 'no'].includes(market.result)) return null;
  const time = Date.parse(market.settlement_ts);
  if (!Number.isFinite(time)) return null;
  const outcome = market.result === 'yes' ? 1 : 0;
  // An explicit nonbinary payout is not a binary calibration label.
  if (market.settlement_value_dollars != null) {
    const notional = Number(market.notional_value_dollars);
    if (!Number.isFinite(notional) || notional <= 0
        || Number(market.settlement_value_dollars) !== outcome * notional) return null;
  }
  return { ticker: market.ticker, status: market.status, result: market.result,
    outcome, settledAt: new Date(time).toISOString(), marketType: market.market_type };
}

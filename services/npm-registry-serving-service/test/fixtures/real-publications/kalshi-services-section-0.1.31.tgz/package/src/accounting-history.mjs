/**
 * Read the COMPLETE paginated, documented Kalshi order/fill/settlement
 * query population for one historical interval and one subaccount.
 *
 * This is a read-only operation over the existing Kalshi client, not another
 * journal/ledger/adapter or a statement that a multi-page query is atomic.
 *
 * Kalshi moves older fills and completed orders out of /portfolio and into
 * /historical when /historical/cutoff advances. We must read BOTH affected
 * sources across the exact requested period; a cursor exhausting on one
 * endpoint does NOT mean the economic history is complete.
 *
 * The derived rows are ready for the existing exact Kalshi reconciliation
 * ONLY after Operations independently verifies original bytes, issuer,
 * account cash/positions, ALL cash movements, and consistent snapshots.
 * No object here asserts accounting completeness, authentication or P&L.
 */
import {isDeepStrictEqual} from 'node:util';
import {createHash} from 'node:crypto';

const stamp=x=>typeof x==='string'&&
 /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(x)&&
 Number.isFinite(Date.parse(x));
const named=x=>typeof x==='string'&&x.trim().length>0;
const cmp=(a,b)=>a<b?-1:a>b?1:0;
const TICKER=/^[A-Za-z0-9][A-Za-z0-9._-]{1,150}$/;
const KINDS=['orders','fills','settlements'];
const idOf=(kind,row)=>{
 if(kind==='orders')return row.order_id;
 if(kind==='fills')return row.fill_id??row.trade_id;
 return (row.ticker??'')+'|'+String(row.exchange_index)+'|'+row.settled_time;
};
const dateOf=(kind,row)=>kind==='orders'
 ?row.last_update_time??row.updated_time
 :kind==='fills'?row.created_time:row.settled_time;
const requireCutoff=cutoff=>{
 if(!cutoff||!['orders_updated_ts','trades_created_ts'].every(key=>
   stamp(cutoff[key])))throw new TypeError('Kalshi historical cutoff was not independently read');
 return {
  orders_updated_ts:cutoff.orders_updated_ts,
  trades_created_ts:cutoff.trades_created_ts,
 };
};
const time=x=>Date.parse(x);
const seconds=ms=>Math.floor(ms/1000);
const startQuery=ms=>seconds(ms)-1; // Kalshi's "after" filter is exclusive
const endQuery=ms=>Math.ceil(ms/1000)+1; // Kalshi's "before" filter is exclusive

/**
 * readCutoff(): Promise<documented /historical/cutoff response>
 * readPage(path,query): Promise<original parsed exchange envelope>
 *
 * Throws unless EVERY required page and every archive boundary is covered.
 * This verifies query exhaustion, not atomicity/issuer identity. No credentials
 * are handled here: createKalshiClient owns the signed request transport.
 */
export async function collectKalshiAccountingHistory({
 ticker,subaccount,from,to,readCutoff,readPage,maxPages=50,
 requireOriginalBytes=false,
}={}) {
 if(!named(ticker)||!TICKER.test(ticker)||
    !Number.isSafeInteger(subaccount)||subaccount<0||subaccount>63||
    !stamp(from)||!stamp(to)||time(from)>=time(to)||
    typeof readCutoff!=='function'||typeof readPage!=='function'||
    !Number.isInteger(maxPages)||maxPages<1||maxPages>500||
    typeof requireOriginalBytes!=='boolean')
  throw new TypeError('bounded Kalshi market, subaccount, explicit time window and genuine page reader required');
 const fromMs=time(from),toMs=time(to);
 const originalCutoffPages=[];
 const beginPacket=await readCutoff(),begin=requireCutoff(beginPacket);
 if(requireOriginalBytes||beginPacket.originalBytes!==undefined)originalCutoffPages.push(cutoffSource(beginPacket));
 const boundaries={
  orders:time(begin.orders_updated_ts),
  fills:time(begin.trades_created_ts),
 };
 const sources=[
  ...((fromMs<boundaries.orders)?[{kind:'orders',path:'/historical/orders'}]:[]),
  // Active/resting orders remain on /portfolio regardless of archive cutoff.
  {kind:'orders',path:'/portfolio/orders'},
  ...((fromMs<boundaries.fills)?[{kind:'fills',path:'/historical/fills'}]:[]),
  ...((toMs>=boundaries.fills)?[{kind:'fills',path:'/portfolio/fills'}]:[]),
  {kind:'settlements',path:'/portfolio/settlements'},
 ];
 const items={orders:new Map(),fills:new Map(),settlements:new Map()};
 const originalPages=[];
 let originalByteCount=0;
 const routes=[],globalCount={orders:0,fills:0,settlements:0};
 const query={
  ticker,subaccount,min_ts:startQuery(fromMs),max_ts:endQuery(toMs),
  limit:200,
 };
 for(const {kind,path} of sources){
  const seenCursors=new Set(),seenOnRoute=new Set();
  let cursor='',pages=0;
  for(;pages<maxPages;pages++){
   const pageQuery={...query,...(cursor?{cursor}:{})};
   const response=await readPage(path,pageQuery);
   if(!response||typeof response!=='object'||Array.isArray(response)||
      !Array.isArray(response[kind])||typeof response.cursor!=='string')
    throw new TypeError('Kalshi page missing required rows or explicit cursor: '+path);
   if(response.originalBytes!==undefined){
    if(!(response.originalBytes instanceof Uint8Array)||
       response.originalBytes.byteLength<2||
       originalByteCount+response.originalBytes.byteLength>64*1048576)
      throw new RangeError('original Kalshi source byte custody exceeds bounded finite memory');
    const bytes=response.originalBytes;
    const digest='sha256:'+createHash('sha256').update(bytes).digest('hex');
    if(response.originalSha256!==digest||
       !stamp(response.receivedAt))
      throw new TypeError('original Kalshi source body or received timestamp was altered');
    let parsed;
    try{parsed=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}
    catch{throw new TypeError('original Kalshi source body is not valid JSON');}
    if(!isDeepStrictEqual(parsed[kind],response[kind])||
       parsed.cursor!==response.cursor)
      throw new RangeError('parsed financial rows or cursor disagree with original Kalshi bytes');
    // The source URL and query are derived from the actual signed client
    // call; the receiver must still independently validate the issuer.
    if(typeof response.originalUrl!=='string')
      throw new RangeError('original Kalshi source URL missing from received endpoint');
    let uri;
    try{uri=new URL(response.originalUrl);}catch{
      throw new RangeError('original Kalshi source URL invalid');
    }
    if(!uri.pathname.endsWith(path) ||
       Object.entries(pageQuery).some(([key,value])=>
         uri.searchParams.get(key)!==String(value)))
      throw new RangeError('original Kalshi source URL or query differs from the requested page');
    originalByteCount+=bytes.byteLength;
    originalPages.push(Object.freeze({
      path,query:Object.freeze(pageQuery),sha256:digest,
      receivedAt:response.receivedAt,originalUrl:response.originalUrl,
      bytes,
    }));
   }else if(requireOriginalBytes){
    throw new TypeError('original response bytes missing from Kalshi accounting API');
   }
   for(const row of response[kind]){
    const id=idOf(kind,row),eventAt=dateOf(kind,row);
    if(!named(id)||!stamp(eventAt))
      throw new TypeError('undated/unnamed original Kalshi '+kind+' row');
    if(seenOnRoute.has(id))
      throw new RangeError('duplicated original Kalshi '+kind+' row on '+path);
    seenOnRoute.add(id);
    const rowTime=time(eventAt);
    const actualTicker=row.ticker??row.market_ticker;
    if(actualTicker!==ticker||
       (kind!=='settlements'&&row.subaccount_number!==subaccount))
      throw new RangeError('cross-market or cross-subaccount economic event in '+path);
    // A correctly queried API must not silently return events outside the
    // requested window plus one-second boundary slack.
    if(rowTime<fromMs-1000||rowTime>toMs+1000)
      throw new RangeError('Kalshi source returned an event outside its requested time window');
    if(rowTime<fromMs||rowTime>toMs)continue;
    const found=items[kind].get(id);
    if(found && !isDeepStrictEqual(found,row))
      throw new RangeError('contradictory historical/current Kalshi '+kind+' identity');
    if(!found){items[kind].set(id,row);globalCount[kind]++;}
   }
   const next=response.cursor;
   if(next==='')break;
   if(seenCursors.has(next)||next.length>4096)
    throw new RangeError('nonadvancing, repeated or oversized Kalshi page cursor');
   seenCursors.add(next);
   cursor=next;
  }
  if(pages>=maxPages)
   throw new RangeError('Kalshi page limit exhausted before original history was complete');
  routes.push(Object.freeze({kind,path,pages:pages+1,queryStart:from,queryEnd:to}));
 }
 // The archive cutoff is a moving boundary. If it changed while we read
 // multiple endpoints, there could be a hole even though each cursor ended.
 const endPacket=await readCutoff(),end=requireCutoff(endPacket);
 if(requireOriginalBytes||endPacket.originalBytes!==undefined)originalCutoffPages.push(cutoffSource(endPacket));
 if(!isDeepStrictEqual(begin,end))
  throw new RangeError('Kalshi historical cutoff shifted during cross-endpoint reading');
 return Object.freeze({
  kind:'kalshi-accounting-history-reading',
  ticker,subaccount,from,to,
  orders:Object.freeze([...items.orders.values()].sort((a,b)=>cmp(a.order_id,b.order_id))),
  fills:Object.freeze([...items.fills.values()].sort((a,b)=>cmp(idOf('fills',a),idOf('fills',b)))),
  settlements:Object.freeze([...items.settlements.values()].sort((a,b)=>
   cmp(idOf('settlements',a),idOf('settlements',b)))),
  routes:Object.freeze(routes),
  originalPages:Object.freeze(originalPages),
  originalCutoffPages:Object.freeze(originalCutoffPages),
  originalCutoffPagesRetained:originalCutoffPages.length===2,
  originalPagesRetained:originalPages.length===routes.reduce((n,r)=>n+r.pages,0),
  historicalCutoff:Object.freeze(begin),
  paginationExhausted:true,
  historicalRoutesCovered:true,
  atomicSnapshot:false,
  accountCashMovementsCovered:false,
  originalSourceAuthenticated:false,
  independentlyReconciled:false,
  tradeEligible:false,
 });
}

/** Preserve the two original archive-boundary observations without extra GETs.
 * Their source bodies are needed to revalidate coverage after a restart. */
function cutoffSource(packet){
 const bytes=packet.originalBytes,sha=packet.originalSha256;
 if(!(bytes instanceof Uint8Array)||bytes.byteLength<2||bytes.byteLength>16*1048576||
    sha!=='sha256:'+createHash('sha256').update(bytes).digest('hex')||!stamp(packet.receivedAt))
  throw new TypeError('original historical cutoff source bytes required');
 const parsed=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 if(!isDeepStrictEqual(requireCutoff(parsed),requireCutoff(packet)))throw new TypeError('historical cutoff differs from original bytes');
 const uri=new URL(packet.originalUrl);
 if(!uri.pathname.endsWith('/historical/cutoff'))throw new TypeError('historical cutoff source URL mismatch');
 return Object.freeze({path:'/historical/cutoff',query:Object.freeze({}),bytes,sha256:sha,originalUrl:packet.originalUrl,receivedAt:packet.receivedAt});
}

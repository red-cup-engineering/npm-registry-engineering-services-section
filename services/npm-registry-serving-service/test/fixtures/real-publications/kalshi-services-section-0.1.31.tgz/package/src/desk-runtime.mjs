/** Bind a scheduled desk to host-owned custody and shared strategy research. */
import { join } from 'node:path';
import { kalshiAccount, assertCredentialAccount } from './accounts.mjs';
import { settlementRoot, stateDirectory } from './data-layout.mjs';

export function deskRuntimeEnvironment(accountId, environment = process.env) {
  if (typeof accountId !== 'string') throw new TypeError('one explicit Kalshi account is required');
  const account = kalshiAccount({ KALSHI_ACCOUNT_ID: accountId });
  const current = kalshiAccount(environment);
  const env = { ...environment, KALSHI_ACCOUNT_ID: account.id };
  if (current.id !== account.id) {
    for (const name of ['KALSHI_API_KEY_ID', 'KALSHI_PRIVATE_KEY_PATH', 'KALSHI_ENV_FILE',
      'KALSHI_CREDENTIAL_ACCOUNT_ID', 'KALSHI_DESK_DATA_DIR', 'KALSHI_DESK_STATE_DIR', 'KALSHI_FLEET_DECISION_PATH']) delete env[name];
  }
  if (environment.KALSHI_ACCOUNT_CUSTODY_ROOT) {
    env.KALSHI_ENV_FILE = join(environment.KALSHI_ACCOUNT_CUSTODY_ROOT, account.id, 'credentials.env');
    env.KALSHI_CREDENTIAL_ACCOUNT_ID = account.id;
    delete env.KALSHI_API_KEY_ID;
    delete env.KALSHI_PRIVATE_KEY_PATH;
  }
  // Forecast/source knowledge is shared; private executions and reviews are not.
  env.KALSHI_WEATHER_STATE_DIR ??= stateDirectory(settlementRoot({ ...environment,
    KALSHI_ACCOUNT_ID: account.strategyAccountId }), 'weather');
  assertCredentialAccount(env);
  return env;
}

/** Clock declarations consumed by MetroPlat's existing scheduleSources loader. */
export function kalshiDeskSchedules({ accountIds, mode = 'paper' } = {}, { account } = {}) {
  if (!['paper', 'live'].includes(mode)) throw new TypeError('Kalshi cycle mode must be paper or live');
  if (typeof account !== 'string' || !account || !Array.isArray(accountIds) || !accountIds.length ||
      accountIds.length > 2 || new Set(accountIds).size !== accountIds.length)
    throw new TypeError('a clock actor and distinct configured Kalshi accounts are required');
  return accountIds.map(accountId => {
    if (typeof accountId !== 'string') throw new TypeError('one explicit Kalshi account is required');
    const selected = kalshiAccount({ KALSHI_ACCOUNT_ID: accountId });
    return { id: `kalshi-desk-${selected.id}`, verb: 'kalshi-desk-cycle',
      input: { accountId: selected.id, mode }, account, firstDueAt: '1970-01-01T00:00:00Z',
      everySeconds: 60, maxAttempts: 1 };
  });
}

export async function runAccountDeskCycle({ accountId, mode = 'paper', env = process.env } = {}) {
  if (!['paper', 'live'].includes(mode)) throw new TypeError('Kalshi cycle mode must be paper or live');
  const selected = deskRuntimeEnvironment(accountId, env);
  const { runCycle } = await import('../services/kalshi-stake-path-service/apps/kalshi-desk.mjs');
  const cycle = await runCycle({ env: selected, live: mode === 'live' });
  return { accountId, strategySourceAccount: kalshiAccount(selected).strategyAccountId, ...cycle };
}

/**
 * Exact, finite Kalshi settlement → fill → cash proof for an ISOLATED
 * long-YES position opened inside the observed account interval.
 *
 * One venue/market, one subaccount, zero initial holdings, all opening
 * fills BUY YES, no transfers/credits/other economic effects, full order,
 * fill, activity and settlement coverage, zero residual holdings. This
 * intentionally FAILS CLOSED for NO, sells, netting, uncertain pagination,
 * incomplete cost basis, or other account activity.
 *
 * This is a read-only numerical derivation. A 'complete:true' field is a
 * coverage premise, NOT evidence of independent collection; Operations must
 * authenticate original source bytes and pagination before the result can
 * become observed economic knowledge. It does not issue an order or mutate
 * SignCraft, its upstream game, or a ledger.
 *
 * Kalshi units:
 *  - fill counts and settled counts: two decimal contract places
 *  - YES prices: four decimal USD places
 *  - fill/settlement fees and position costs: six decimal USD places
 *  - settlement.revenue: integer CENTS, not dollars
 *  - account cash: integer MICRO-USD as decimal string
 */
const named=x=>typeof x==='string'&&x.trim().length>0;
const clock=x=>typeof x==='string'&&
 /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(x)&&
 Number.isFinite(Date.parse(x));
const time=(x,label)=>{if(!clock(x))throw new TypeError(label+'-absolute-clock-required');return Date.parse(x);};
const safe=(x,label)=>{if(!Number.isSafeInteger(x)||x<0)throw new TypeError(label+'-nonnegative-safe-integer-required');return BigInt(x);};
const fixed=(x,d,label)=>{
 if(typeof x!=='string'||x.length>100||!/^\d+(?:\.\d+)?$/.test(x))
  throw new TypeError(label+'-exact-source-decimal-required');
 const [whole,frac='']=x.split('.');
 // V2 responses may spell a cent-grid price with six decimals. Trailing
 // zeroes do not change its exact precision; nonzero excess digits do.
 if(frac.length>d&&/[^0]/u.test(frac.slice(d)))throw new RangeError(label+'-source-decimal-precision-exceeded');
 return BigInt(whole)*10n**BigInt(d)+BigInt(frac.slice(0,d).padEnd(d,'0'));
};
const atomic=(x,label)=>{
 if(typeof x!=='string'||!/^(?:0|[1-9]\d*|-?[1-9]\d*)$/.test(x)||x.length>100)
  throw new TypeError(label+'-exact-integer-atomic-cash-required');
 return BigInt(x);
};
const instantPresent=(row,at,label)=>{
 const observed=time(row?.observedAt,label+'-observation');
 const available=time(row?.availableAt,label+'-availability');
 if(available>observed||observed>at)
  throw new RangeError(label+'-unavailable-or-future-source');
 return observed;
};
const same=(a,b)=>a===b;
const sort=(a,b)=>a<b?-1:a>b?1:0;

/**
 * @param {object} input Original fully observed venue payloads and source
 * custody clock envelopes. Only mathematical reconciliation is returned.
 */
export function reconcileIsolatedKalshiYesClose({
 market,settlement,orders,fills,opening,closing,coverage,at,
}={}){
 const cutoff=time(at,'receiving');
 if(!named(market?.ticker)||!named(market.event_ticker)||
    market.market_type!=='binary'||!['finalized','settled'].includes(market.status)||
    market.is_provisional!==false||!['yes','no'].includes(market.result)||
    fixed(market.notional_value_dollars,6,'notional')!==1000000n)
  throw new TypeError('finalized-one-dollar-binary-market-required');
 const settledAt=time(market.settlement_ts,'market-settlement');
 const paidAt=time(settlement?.settled_time,'settlement-payment');
 if(settledAt>paidAt||paidAt>cutoff||
    settlement.ticker!==market.ticker||
    settlement.event_ticker!==market.event_ticker||
    settlement.market_result!==market.result||
    !['yes','no'].includes(settlement.market_result)||
    (market.settlement_value_dollars!==undefined&&
     fixed(market.settlement_value_dollars,6,'settlement-value')!==
      (market.result==='yes'?1000000n:0n)))
  throw new RangeError('mismatched-or-unavailable-binary-settlement');
 if(!Number.isSafeInteger(settlement.exchange_index)||settlement.exchange_index<0||
    !Number.isSafeInteger(settlement.revenue)||settlement.revenue<0)
  throw new TypeError('exact-exchange-and-settlement-revenue-cents-required');
 if(!Array.isArray(orders)||!Array.isArray(fills)||orders.length<1||
    fills.length<1||orders.length>10000||fills.length>100000)
  throw new TypeError('bounded-nonempty-actual-orders-and-fills-required');
 const opened=instantPresent(opening,cutoff,'opening-account');
 const closed=instantPresent(closing,cutoff,'closing-account');
 if(!(opened<closed)||opened>settledAt||closed<paidAt||
    !named(opening.accountReference)||opening.accountReference!==closing.accountReference||
    opening.subaccount_number!==closing.subaccount_number||
    !Number.isSafeInteger(opening.subaccount_number)||opening.subaccount_number<0||opening.subaccount_number>63)
  throw new RangeError('same-subaccount-preentry-and-postsettlement-boundaries-required');
 const startCash=atomic(opening.cashMicroUsd,'opening-cash');
 const endCash=atomic(closing.cashMicroUsd,'closing-cash');
 if(fixed(opening.yes_count_fp,2,'opening-yes')!==0n||
    fixed(opening.no_count_fp,2,'opening-no')!==0n||
    fixed(closing.yes_count_fp,2,'closing-yes')!==0n||
    fixed(closing.no_count_fp,2,'closing-no')!==0n)
  throw new RangeError('isolated-zero-initial-and-final-position-required');
 const populations=['fills','orders','settlements','accountMovements'];
 for(const scope of populations){
  const row=coverage?.[scope];
  if(row?.complete!==true||
     time(row.from,scope+'-begin')>opened||
     time(row.through,scope+'-end')<closed||
     time(row.through,scope+'-end')>cutoff)
   throw new RangeError('complete-independent-coverage-premise-required:'+scope);
 }
 if(coverage.accountMovements.unrelatedMovements!==0)
  throw new RangeError('isolated-interval-refuses-other-account-movements');
 const os=new Map();
 for(const order of orders){
  if(!named(order?.order_id)||os.has(order.order_id)||
     !named(order.client_order_id)||order.ticker!==market.ticker||
     order.book_side!=='bid'||!['executed','canceled','cancelled','expired'].includes(order.status)||
     order.subaccount_number!==opening.subaccount_number||
     (order.exchange_index!==undefined&&order.exchange_index!==settlement.exchange_index))
   throw new TypeError('unique-terminal-same-account-long-yes-order-required');
  const born=time(order.created_time,'order-created'),
    completed=time(order.last_update_time??order.updated_time,'order-terminal');
  if(born<opened||completed<born||completed>paidAt)
   throw new RangeError('order-outside-observed-holding-interval');
  const initial=fixed(order.initial_count_fp,2,'initial-contracts');
  const reported=fixed(order.fill_count_fp,2,'filled-contracts');
  const remaining=fixed(order.remaining_count_fp,2,'remaining-contracts');
  if(!initial||reported>initial||remaining>initial||reported+remaining!==initial)
   throw new RangeError('venue-order-quantity-conservation-refused');
  os.set(order.order_id,{order,initial,reported,remaining,born,completed,
   quantity:0n,cost:0n,fees:0n});
 }
 const seen=new Set();let allQty=0n,cost=0n,fees=0n;
 for(const fill of fills){
  const id=fill?.fill_id??fill?.trade_id;
  if(!named(id)||seen.has(id))throw new TypeError('duplicate-or-unnamed-fill-custody');
  seen.add(id);
  const entry=os.get(fill.order_id);
  if(!entry||fill.ticker!==market.ticker||
     fill.subaccount_number!==opening.subaccount_number||
     fill.exchange_index!==settlement.exchange_index||
     fill.outcome_side!=='yes'||fill.book_side!=='bid'||
     fill.action!=='buy'||
     (fill.client_order_id!==undefined&&
      fill.client_order_id!==entry.order.client_order_id))
   throw new TypeError('fill-not-a-matching-opening-long-yes-event');
  const happened=time(fill.created_time,'fill-execution');
  if(happened<entry.born||happened>entry.completed||happened>settledAt)
   throw new RangeError('fill-executed-outside-observed-order');
  const size=fixed(fill.count_fp,2,'fill-count');
  const yesPrice=fixed(fill.yes_price_dollars,4,'fill-yes-price');
  const fillFee=fixed(fill.fee_cost,6,'fill-fee');
  if(size===0n||yesPrice===0n||yesPrice>=10000n)
   throw new RangeError('positive-interior-market-fill-required');
  // (count / 100) * (price / 10^4) = count*price MICRO-USD.
  const fillCost=size*yesPrice;
  entry.quantity+=size;entry.cost+=fillCost;entry.fees+=fillFee;
  allQty+=size;cost+=fillCost;fees+=fillFee;
 }
 for(const {order,quantity,reported} of os.values()){
  if(quantity!==reported)
   throw new RangeError('complete-order-fill-quantity-mismatch:'+order.order_id);
 }
 const heldYes=fixed(settlement.yes_count_fp,2,'settled-yes-count');
 const heldNo=fixed(settlement.no_count_fp,2,'settled-no-count');
 const venueCost=fixed(settlement.yes_total_cost_dollars,6,'settled-yes-cost')+
   fixed(settlement.no_total_cost_dollars,6,'settled-no-cost');
 const venueFees=fixed(settlement.fee_cost,6,'settlement-fees');
 const expectedPayout=(market.result==='yes'?heldYes:heldNo)*10000n;
 const actualPayout=safe(settlement.revenue,'reported-revenue')*10000n;
 // Contested numbers are useful contradictory evidence, not a profitable
 // result or permission to update the score. Failure is a refused close.
 const checks=Object.freeze({
  holding:heldYes===allQty&&heldNo===0n,
  settlement:expectedPayout===actualPayout,
  costBasis:venueCost===cost,
  fees:venueFees===fees,
  cash:endCash-startCash===actualPayout-cost-fees,
 });
 const accepted=Object.values(checks).every(x=>x===true);
 const net=actualPayout-cost-fees;
 return Object.freeze({
  kind:'isolated-kalshi-yes-position-cash-equation-v1',
  marketTicker:market.ticker,accountReference:opening.accountReference,
  subaccountNumber:opening.subaccount_number,exchangeIndex:settlement.exchange_index,at,
  orderIds:Object.freeze([...os.keys()].sort(sort)),
  fillIds:Object.freeze([...seen].sort(sort)),
  quantityHundredths:allQty.toString(),
  purchaseCostMicroUsd:cost.toString(),
  fillFeesMicroUsd:fees.toString(),
  settlementRevenueMicroUsd:actualPayout.toString(),
  // This is a numeric reconstruction, NOT independently authenticated profit.
  mathematicalNetMicroUsd:accepted?net.toString():null,
  observedAccountDeltaMicroUsd:(endCash-startCash).toString(),
  checks,
  mathematicallyReconciled:accepted,
  // The outside receiver must independently establish coverage, original
  // source bytes/issuer, and no unreported cash activity.
  originalSourcesReceived:false,accountingAuthenticated:false,
  // A subcent outcome cannot be silently cast to whole-cent money.
  netWholeCents:accepted&&net%10000n===0n?
    (net/10000n).toString():null,
  costBasisReconstructed:accepted,
  tradeEligible:false,orderEffect:false,
 });
}

/** The exposure one fill positioned the account for (Kalshi Trade API 3.34, Fill): `outcome_side`, which
 * `book_side` restates ('bid' is 'yes', 'ask' is 'no'). The deprecated `side`/`action` name the contract and verb:
 * buy-yes and sell-no give 'yes' exposure, buy-no and sell-yes give 'no'. All present must agree. */
function fillExposure(fill){
 const exposure=fill.outcome_side??(fill.book_side==='bid'?'yes':fill.book_side==='ask'?'no':null);
 if(!['yes','no'].includes(exposure)||fill.book_side!==(exposure==='yes'?'bid':'ask'))throw new TypeError('fill-direction-required');
 if(fill.side!==undefined||fill.action!==undefined){
  const legacy=['yes','no'].includes(fill.side)&&['buy','sell'].includes(fill.action)?((fill.side==='yes')===(fill.action==='buy')?'yes':'no'):null;
  if(legacy!==exposure)throw new TypeError('contradictory-fill-direction');
 }
 return exposure;
}

/** Matched desk orders' terminal economic contribution. This reconstructs
 * signed YES-book fill payoffs at the final binary outcome, including NO
 * purchases, sales and exits. It never allocates manual trades or claims
 * reconciliation of the whole account's cash or its fungible cost basis. */
export function reconcileKalshiDeskOrderOutcomes({history,marketReading,placements,at}={}) {
 const cutoff=time(at,'desk-accounting');
 if(!Array.isArray(placements)||placements.length>10000)throw new TypeError('bounded-original-desk-placements-required');
 verifyDeskHistory(history,cutoff);
 const market=readFinalBinaryMarket({reading:marketReading,ticker:history.ticker,at});
 const settlements=history.settlements.filter(s=>s.ticker===market.ticker&&(s.subaccount_number===undefined||s.subaccount_number===history.subaccount)&&s.market_result===market.result&&time(s.settled_time,'paid')<=cutoff);
 if(settlements.length!==1)throw new TypeError('unique-paid-binary-settlement-required');
 const settlement=settlements[0],paid=time(settlement.settled_time,'paid'),rows=[],withheld=[],unfilledOrderIds=[];
 if(settlement.event_ticker!==market.event_ticker||fixed(settlement[market.result==='yes'?'yes_count_fp':'no_count_fp'],2,'paid-quantity')*10000n!==safe(settlement.revenue,'paid-revenue')*10000n)throw new TypeError('original-final-payout-does-not-reconcile');
 const orders=new Map(history.orders.map(o=>[o.order_id,o])),seen=new Set();
 for(const place of placements){
  const id=place?.orderId;
  if(!named(id)||seen.has(id)){withheld.push({orderId:id??null,reason:'missing-or-duplicated-original-desk-order'});continue;}
  seen.add(id);
  try{
   const order=orders.get(id);
   if(!order||!named(place.lane)||!/^kd-/u.test(place.clientOrderId??'')||
      order.client_order_id!==place.clientOrderId||order.ticker!==place.ticker||
      order.ticker!==history.ticker||order.subaccount_number!==history.subaccount||
      !['bid','ask'].includes(place.bookSide)||order.book_side!==place.bookSide||
      !['executed','canceled','cancelled','expired'].includes(order.status))
    throw new TypeError('matching-terminal-kd-order-required');
   const born=time(order.created_time,'order-created'),ended=time(order.last_update_time??order.updated_time,'order-ended');
   if(born<time(history.from,'history-begin')||ended>cutoff||ended<born||time(place.at,'desk-issued')>paid)
    throw new TypeError('complete-order-life-through-settlement-required');
   const fills=history.fills.filter(f=>f.order_id===id),reported=fixed(order.fill_count_fp,2,'order-filled');
   let quantity=0n,net=0n,fees=0n;
   for(const fill of fills){
    const executed=time(fill.created_time,'fill-execution');
    if(fill.ticker!==history.ticker||fill.subaccount_number!==history.subaccount||
       fill.exchange_index!==settlement.exchange_index||fill.book_side!==place.bookSide||executed<born||executed>ended||executed>paid||
       (fill.client_order_id!==undefined&&fill.client_order_id!==place.clientOrderId))
     throw new TypeError('fill-not-matching-original-kd-order');
    fillExposure(fill);
    const n=fixed(fill.count_fp,2,'fill-size'),yes=fixed(fill.yes_price_dollars,4,'yes-price'),no=fill.no_price_dollars===undefined?10000n-yes:fixed(fill.no_price_dollars,4,'no-price'),fee=fixed(fill.fee_cost,6,'fill-fee');
    if(n<=0n||yes<=0n||yes>=10000n||yes+no!==10000n)throw new TypeError('exact-binary-fill-economics-required');
    const payoff=market.result==='yes'?10000n:0n;
    net+=n*(place.bookSide==='bid'?payoff-yes:yes-payoff)-fee;quantity+=n;fees+=fee;
   }
   if(quantity!==reported)throw new TypeError('original-order-fill-quantity-mismatch');
   if(quantity===0n){unfilledOrderIds.push(id);continue;}
   rows.push({orderId:id,clientOrderId:place.clientOrderId,lane:place.lane,ticker:history.ticker,
    subaccountNumber:history.subaccount,exchangeIndex:settlement.exchange_index,bookSide:place.bookSide,heldSide:place.bookSide==='bid'?'yes':'no',marketResult:market.result,
    won:place.bookSide==='bid'?market.result==='yes':market.result==='no',settledAt:settlement.settled_time,
    quantityHundredths:quantity.toString(),feesMicroUsd:fees.toString(),terminalContributionNetMicroUsd:net.toString(),realizedNetMicroUsd:null,
    fillIds:fills.map(f=>f.fill_id??f.trade_id),sourceIds:[marketReading.sha256??marketReading.originalSha256,...history.originalPages.map(p=>p.sha256)],
    completeOrderFills:true,standaloneRealized:false,accountCashReconciled:false,scope:'matched kd order contribution at final binary outcome; manual trades and whole-account cost-basis allocation excluded'});
  }catch(error){withheld.push({orderId:id,reason:error.message});}
 }
 for(const order of history.orders)if(/^kd-/u.test(order.client_order_id??'')&&!seen.has(order.order_id))withheld.push({orderId:order.order_id,reason:'venue kd order lacks original desk placement and lane'});
 // The binary payout is linear in position, so each fill's contribution at the final outcome, n x (payout - price)
 // on its exposure side, is exact and additive. Netting against other holdings in the account changes collateral
 // and cash timing, never a fill's contribution. A ticker's rows are realized once every desk order on it reconciles.
 for(const row of rows){
  row.standaloneRealized=withheld.length===0;
  row.realizedNetMicroUsd=row.standaloneRealized?row.terminalContributionNetMicroUsd:null;
  row.realizedBasis=row.standaloneRealized?'every original kd order on the ticker reconciled; per-fill contributions at the final binary outcome; whole-account cash not reconciled':'terminal order contribution only; another kd order on the ticker did not reconcile';
 }
 return {kind:'kalshi-desk-terminal-order-outcomes',at,rows,withheld,unfilledOrderIds,
  sourcePages:history.originalPages.length+1,accountCashReconciled:false,orderEffect:false};
}

import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {feed} from './feed.mjs';
/** One original final-market reader shared by live and shadow accounting. */
export function readFinalBinaryMarket({reading,ticker,at}) {
 const cutoff=time(at,'market-accounting'),market=originalKalshiPage(reading,'/markets/'+ticker,cutoff).market;
 if(market?.ticker!==ticker||!named(market.event_ticker)||market.market_type!=='binary'||
    !['settled','finalized'].includes(market.status)||market.is_provisional===true||
    !['yes','no'].includes(market.result)||fixed(market.notional_value_dollars,6,'notional')!==1000000n||
    time(market.settlement_ts,'market-settlement')>time(reading.receivedAt,'source-received')||
    market.settlement_value_dollars!==undefined&&fixed(market.settlement_value_dollars,6,'settlement-value')!==(market.result==='yes'?1000000n:0n))
  throw new TypeError('original-final-one-dollar-binary-market-required');
 return market;
}
function originalKalshiPage(page,path,cutoff){
 const bytes=page?.bytes??page?.originalBytes,sha=page?.sha256??page?.originalSha256,uri=new URL(page?.originalUrl??'about:blank'),base=new URL(feed.base);
 if(!(bytes instanceof Uint8Array)||bytes.byteLength<2||bytes.byteLength>16*1048576||sha!=='sha256:'+createHash('sha256').update(bytes).digest('hex')||
    uri.origin!==base.origin||uri.pathname!==base.pathname+path||
    time(page.receivedAt,'source-received')>cutoff)
  throw new TypeError('original-production-Kalshi-financial-body-required');
 for(const [key,value] of Object.entries(page.query??{}))if(uri.searchParams.get(key)!==String(value))throw new TypeError('financial-source-query-mismatch');
 return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}

function verifyDeskHistory(history,cutoff){
 if(!history||history.kind!=='kalshi-accounting-history-reading'||
    history.paginationExhausted!==true||history.historicalRoutesCovered!==true||
    history.originalPagesRetained!==true||!Array.isArray(history.originalPages)||
    history.originalPages.length>2500||time(history.to,'history-end')>cutoff)
  throw new TypeError('complete-original-desk-accounting-reading-required');
 const sources={orders:new Map(),fills:new Map(),settlements:new Map()};
 const identity=(kind,row)=>kind==='orders'?row.order_id:kind==='fills'?row.fill_id??row.trade_id:row.ticker+'|'+row.exchange_index+'|'+row.settled_time;
 for(const page of history.originalPages){
  const kind=page.path.split('/').at(-1);
  if(page.query?.subaccount!==history.subaccount)throw new TypeError('original-financial-subaccount-query-required');
  if(!(kind in sources))throw new TypeError('unexpected-accounting-source');
  const raw=originalKalshiPage(page,page.path,cutoff);
  if(!Array.isArray(raw[kind]))throw new TypeError('original-financial-population-required');
  for(const row of raw[kind]){
   const stamp=kind==='orders'?row.last_update_time??row.updated_time:kind==='fills'?row.created_time:row.settled_time;
   const ms=time(stamp,'original-economic-event');
   if(ms<time(history.from,'history-begin')||ms>time(history.to,'history-end'))continue;
   if((row.ticker??row.market_ticker)!==history.ticker||(row.subaccount_number!==undefined&&row.subaccount_number!==history.subaccount))throw new TypeError('original-financial-source-scope-mismatch');
   const id=identity(kind,row),prior=sources[kind].get(id);
   if(!named(id)||prior&&!isDeepStrictEqual(prior,row))throw new TypeError('conflicting-original-economic-identity');
   sources[kind].set(id,row);
  }
 }
 for(const kind of Object.keys(sources)){
  if(!Array.isArray(history[kind])||history[kind].length!==sources[kind].size||
     history[kind].some(row=>!isDeepStrictEqual(sources[kind].get(identity(kind,row)),row)))
   throw new TypeError('derived-financial-rows-differ-from-original-bytes');
 }
}

/** Complete original order/fill custody proves a terminal zero-fill without
 * requiring an account payout or a future outcome. It supplies no trial. */
export function reconcileKalshiDeskUnfilledOrders({history,placements,at}={}){
 const cutoff=time(at,'unfilled-receiving');verifyDeskHistory(history,cutoff);
 if(!Array.isArray(placements)||placements.length>10000)throw new TypeError('bounded-original-desk-placements-required');
 const orders=new Map(history.orders.map(o=>[o.order_id,o])),unfilledOrders=[],withheld=[];
 for(const p of placements){
  const o=orders.get(p.orderId);
  if(!o||o.client_order_id!==p.clientOrderId||!/^kd-/u.test(p.clientOrderId??'')||
     o.ticker!==p.ticker||p.ticker!==history.ticker||o.subaccount_number!==history.subaccount||
     !named(p.lane)||o.book_side!==p.bookSide)continue;
  if(!['canceled','cancelled','expired'].includes(o.status))continue;
  try{
   const born=time(o.created_time,'order-created'),ended=time(o.last_update_time??o.updated_time,'order-terminal');
   if(born<time(history.from,'history-begin')||ended<born||ended>time(history.to,'history-end')||ended>cutoff)
    throw new TypeError('complete-original-terminal-order-lifetime-required');
   if(fixed(o.fill_count_fp,2,'original-order-filled')!==0n||history.fills.some(f=>f.order_id===p.orderId))continue;
   unfilledOrders.push({orderId:p.orderId,clientOrderId:p.clientOrderId,lane:p.lane,ticker:p.ticker,
    terminalAt:o.last_update_time??o.updated_time,quantityHundredths:'0',realizedNetMicroUsd:'0',
    completeOrderFills:true,terminalNoFill:true,sourceIds:history.originalPages.map(r=>r.sha256),
    scope:'original terminal kd order with zero executed quantity and complete original fill population; no forecast trial'});
  }catch(error){withheld.push({orderId:p.orderId,reason:error.message});}
 }
 return {kind:'kalshi-desk-terminal-unfilled-orders',at,unfilledOrders,unfilledOrderIds:unfilledOrders.map(p=>p.orderId),withheld,orderEffect:false};
}

import { readFileSync } from 'node:fs';
import { credentialPath } from '@red-cup-engineering/credential-custody-service/keep';
import { accountCredentialLayout, assertCredentialAccount } from './accounts.mjs';

export function kalshiEnvFile(env = process.env) {
  assertCredentialAccount(env);
  return env.KALSHI_ENV_FILE ?? credentialPath(`${accountCredentialLayout(env).service}.env`, env);
}

function readEnvFile(path) {
  try {
    return Object.fromEntries(readFileSync(path, 'utf8').split('\n')
      .map(line => /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/u.exec(line)).filter(Boolean)
      .map(m => [m[1], m[2].replace(/^"(.*)"$/u, '$1')]));
  } catch (error) { if (error.code === 'ENOENT') return {}; throw error; }
}

/** A single owner and complete pair; never combine environment and file keys. */
export function kalshiCredentials(env = process.env) {
  const account = assertCredentialAccount(env);
  const direct = Boolean(env.KALSHI_API_KEY_ID);
  const source = direct ? env : (env.KALSHI_ENV_FILE || env.CREDENTIALS_DIRECTORY) ? readEnvFile(kalshiEnvFile(env)) : {};
  if (source.KALSHI_CREDENTIAL_ACCOUNT_ID && source.KALSHI_CREDENTIAL_ACCOUNT_ID !== account.id)
    throw new TypeError('Kalshi credential file belongs to a different account');
  if (account.id !== 'emsenn' && source.KALSHI_API_KEY_ID && source.KALSHI_CREDENTIAL_ACCOUNT_ID !== account.id)
    throw new TypeError('a second Kalshi account requires an owner-bound credential file');
  const apiKeyId = source.KALSHI_API_KEY_ID, keyPath = source.KALSHI_PRIVATE_KEY_PATH;
  if (!apiKeyId || !keyPath) return null;
  return { accountId: account.id, apiKeyId, privateKeyPem: readFileSync(keyPath, 'utf8') };
}

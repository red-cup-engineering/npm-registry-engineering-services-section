import {marketBuyWalk, marketSellWalk} from '@red-cup-engineering/gaming/market';
import {gradedFromParts} from '@red-cup-engineering/computer-data-engineering-services-section/number/graded';
/**
 * The Kalshi arena presented by its rules (gaming faculty `gameRules`, the arenas note 2026-07-07).
 *
 * Units: prices are integer ten-thousandths of a dollar (Kalshi quotes four decimals, and sub-cent
 * ticks trade), quantities integer hundredths of a contract, so replay is exact. The position keeps its
 * markets in 64 hash buckets so a move copies one bucket, not every market: `extend` stays pure (replay
 * threads positions) at a cost independent of how many thousands of markets are subscribed.
 *
 * Kalshi's book is a concurrent game too large to list, so its rules present it. A position is the
 * replicated state of every subscribed market (both bid ladders in cents, last trade, lifecycle, result)
 * and the last sequence number per subscription. Moves are what the venue tells over its WebSocket:
 * `snapshot`, `delta` (an Opponent places or pulls), `trade` (an Opponent takes), `lifecycle` (nature
 * determines or settles a market), `quote` (the ticker channel's top of book, for markets whose depth
 * is not subscribed), and `gap` (the venue's own sequence skipped, so the subscription's
 * books are no longer known). A delta on a book we do not know is still the venue's tell: it is admitted
 * and changes nothing but the sequence. `extend` refuses what is not enabled: a sequence number that does
 * not follow its subscription, or a delta that would leave a negative quantity. So the journal of
 * admitted moves is the venue's whole tell as a play record (`{seq, intent, ts}`),
 * `playVerifier(kalshiArena)` re-checks it, and replay rebuilds exactly the position the live client held
 * (sealed arrival = replay).
 *
 * `moveOfFrame` is the codec from a raw WS message to a move (every sequenced frame is one, so the
 * sequence is checkable: an update_subscription ack is a `told` move); `admitFrame` is what a live client
 * does with one frame: a sequence skip is told first as a `gap`, and a delta its book cannot absorb is
 * told as that one market's `unknown` (its book is unknown until its next snapshot).
 */
import { gameRules } from '@red-cup-engineering/gaming/running/rules';

export const ONE = 10000; // a dollar, the payout of one contract, in price units
const pips = (dollars) => Math.round(Number(dollars) * ONE);
const hundredths = (fp) => Math.round(Number(fp) * 100);
const ladderOf = (rows = []) => Object.fromEntries(rows.map(([p, q]) => [pips(p), hundredths(q)]).filter(([, q]) => q > 0));

const BUCKETS = 64;
const bucketOf = (ticker) => { let h = 2166136261; for (let i = 0; i < ticker.length; i += 1) { h ^= ticker.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return h % BUCKETS; };
/** The market record of `ticker` at a position, or undefined. */
export const marketAt = (position, ticker) => position.buckets[bucketOf(ticker)][ticker];
/** Every [ticker, market] at a position. */
export const marketsOf = (position) => position.buckets.flatMap((b) => Object.entries(b));
const withMarket = (position, ticker, market, seq = position.seq) => {
  const i = bucketOf(ticker); const buckets = position.buckets.slice(); buckets[i] = { ...buckets[i], [ticker]: market };
  return { buckets, seq };
};

/** A raw Kalshi WS message (the `m` of a journal frame) as an arena move, or null for non-moves. */
export function moveOfFrame(m) {
  const x = m?.msg ?? {}; const at = { sid: m?.sid, seq: m?.seq };
  switch (m?.type) {
    case 'orderbook_snapshot': return { kind: 'snapshot', ...at, ticker: x.market_ticker, yes: ladderOf(x.yes_dollars_fp), no: ladderOf(x.no_dollars_fp) };
    case 'orderbook_delta': return { kind: 'delta', ...at, ticker: x.market_ticker, side: x.side, price: pips(x.price_dollars), delta: hundredths(x.delta_fp), t: x.ts_ms ?? null };
    case 'trade': return { kind: 'trade', ...at, ticker: x.market_ticker, price: pips(x.yes_price_dollars), size: hundredths(x.count_fp), taker: x.taker_outcome_side ?? x.taker_side, t: x.ts ? x.ts * 1000 : null };
    case 'market_lifecycle_v2': return { kind: 'lifecycle', ...at, ticker: x.market_ticker, event: x.event_type, result: x.result ?? null };
    // the ticker channel's top of book: the only book view for markets whose depth we don't subscribe
    case 'ticker': return { kind: 'quote', ...at, ticker: x.market_ticker, bid: x.yes_bid_dollars === undefined ? null : pips(x.yes_bid_dollars), ask: x.yes_ask_dollars === undefined ? null : pips(x.yes_ask_dollars), last: x.price_dollars === undefined ? null : pips(x.price_dollars), volume: x.volume_fp === undefined ? null : hundredths(x.volume_fp), t: x.ts_ms ?? null };
    // any other sequenced frame (an update_subscription ack) still occupies its subscription's sequence
    default: return m?.sid !== undefined && m?.seq !== undefined ? { kind: 'told', ...at, type: m.type } : null;
  }
}

export const initialPosition = () => ({ buckets: Array.from({ length: BUCKETS }, () => ({})), seq: {} });

function sequenced(position, move) {
  if (move.sid === undefined || move.seq === undefined) return position.seq;
  const prev = position.seq[move.sid];
  if (prev !== undefined && move.seq !== prev + 1 && move.kind !== 'snapshot') throw new RangeError(`seq ${move.seq} does not follow ${prev} on subscription ${move.sid}`);
  return { ...position.seq, [move.sid]: move.seq };
}

const live = (position, ticker) => { const m = marketAt(position, ticker); return m && !m.stale ? m : null; };

/** The legal extension x -> x + {move}; throws on a move not enabled at x. */
export function extend(position, move) {
  switch (move.kind) {
    case 'snapshot': {
      const prior = marketAt(position, move.ticker) ?? {};
      const market = { ...prior, sid: move.sid, yes: move.yes, no: move.no, stale: false };
      return { state: withMarket(position, move.ticker, market, sequenced(position, move)), events: [{ kind: 'book-known', polarity: 'N', ticker: move.ticker }] };
    }
    case 'quote': {
      const m = marketAt(position, move.ticker) ?? {};
      return { state: withMarket(position, move.ticker, { ...m, quote: { bid: move.bid, ask: move.ask, t: move.t }, ...(move.last === null ? {} : { last: move.last }), ...(move.volume === null ? {} : { volume: move.volume }) }, sequenced(position, move)), events: [{ kind: 'quote', polarity: 'O', ticker: move.ticker, bid: move.bid, ask: move.ask, t: move.t }] };
    }
    case 'told': return { state: { ...position, seq: sequenced(position, move) }, events: [] };
    case 'unknown': {
      const m = marketAt(position, move.ticker) ?? {};
      return { state: withMarket(position, move.ticker, { ...m, stale: true }, sequenced(position, move)), events: [{ kind: 'book-unknown', polarity: 'N', ticker: move.ticker }] };
    }
    case 'gap': {
      // rare: a gap re-reads every bucket once
      const buckets = position.buckets.map((b) => (Object.values(b).some((m) => m.sid === move.sid) ? Object.fromEntries(Object.entries(b).map(([t, m]) => [t, m.sid === move.sid ? { ...m, stale: true } : m])) : b));
      return { state: { buckets, seq: { ...position.seq, [move.sid]: move.seq } }, events: [{ kind: 'books-unknown', polarity: 'N', sid: move.sid }] };
    }
    case 'delta': {
      const m = live(position, move.ticker);
      if (!m) return { state: { ...position, seq: sequenced(position, move) }, events: [] };
      const ladder = { ...m[move.side] }; const q = (ladder[move.price] ?? 0) + move.delta;
      if (q < 0) throw new RangeError(`delta leaves ${move.ticker} ${move.side}@${move.price} at ${q}`);
      if (q === 0) delete ladder[move.price]; else ladder[move.price] = q;
      return { state: withMarket(position, move.ticker, { ...m, [move.side]: ladder }, sequenced(position, move)), events: [{ kind: move.delta > 0 ? 'place' : 'pull', polarity: 'O', ticker: move.ticker, side: move.side, price: move.price, size: Math.abs(move.delta), t: move.t }] };
    }
    case 'trade': {
      const m = marketAt(position, move.ticker) ?? {};
      return { state: withMarket(position, move.ticker, { ...m, last: move.price }, sequenced(position, move)), events: [{ kind: 'take', polarity: 'O', ticker: move.ticker, price: move.price, size: move.size, taker: move.taker, t: move.t }] };
    }
    case 'lifecycle': {
      const m = marketAt(position, move.ticker) ?? {};
      return { state: withMarket(position, move.ticker, { ...m, status: move.event, ...(move.result ? { result: move.result } : {}) }, sequenced(position, move)), events: [{ kind: move.event, polarity: 'N', ticker: move.ticker, result: move.result }] };
    }
    default: throw new TypeError(`extend: unknown move kind ${move.kind}`);
  }
}

export const kalshiArena = gameRules(initialPosition, extend);

/**
 * What a live client does with one raw frame at `position`: the moves to admit, in order.
 */
export function admitFrame(position, m) {
  const move = moveOfFrame(m); if (!move) return [];
  const prev = move.sid === undefined ? undefined : position.seq[move.sid];
  const out = [];
  let at = position;
  if (prev !== undefined && move.seq !== prev + 1 && move.kind !== 'snapshot') { const gap = { kind: 'gap', sid: move.sid, seq: move.seq - 1 }; out.push(gap); at = extend(at, gap).state; }
  try { extend(at, move); out.push(move); } catch { out.push({ kind: 'unknown', sid: move.sid, seq: move.seq, ticker: move.ticker }); }
  return out;
}

/** Best YES bid and ask in price units (a NO bid at q is a YES ask at ONE - q), sizes in contracts. */
export function top(position, ticker) {
  const m = marketAt(position, ticker); if (!m) return null;
  if (!m.yes) return m.quote ? { bid: m.quote.bid, ask: m.quote.ask, bidSize: null, askSize: null, mid: m.quote.bid && m.quote.ask ? (m.quote.bid + m.quote.ask) / 2 : null, last: m.last ?? null, stale: false, from: 'ticker' } : null;
  const yes = Object.entries(m.yes).map(([p, q]) => [Number(p), q]); const no = Object.entries(m.no).map(([p, q]) => [Number(p), q]);
  const [bid, bidQ] = yes.reduce((b, x) => (x[0] > b[0] ? x : b), [0, 0]);
  const [noBid, askQ] = no.reduce((b, x) => (x[0] > b[0] ? x : b), [0, 0]);
  const ask = noBid ? ONE - noBid : null;
  return { bid, ask, bidSize: bidQ / 100, askSize: askQ / 100, mid: bid && ask !== null ? (bid + ask) / 2 : null, last: m.last ?? null, stale: Boolean(m.stale) };
}

/** Contracts resting ahead of a new bid at `price` (price units) on the `side` ladder. */
export const queueAhead = (position, ticker, side, price) => (marketAt(position, ticker)?.[side]?.[price] ?? 0) / 100;

/**
 * Shadow execution of one resting bid against the Opponent takes that followed it, queue-aware and
 * pessimistic: it joins behind `aheadAtPlace` contracts at its price; only takes that hit its ladder at
 * or through its price advance the queue; pulls ahead are assumed to come from behind it. A take printed
 * through its price (a YES bid's take below it) means the whole level was consumed first: it fills in full.
 * intent: {ticker, side: 'yes'|'no' ladder, price: price units on that ladder, size: contracts, placedAt: ms}
 * events: arena `take` events (size in hundredths, taker 'yes'|'no', t ms).
 */
export function shadowRest(intent, aheadAtPlace, events) {
  let ahead = Math.round(aheadAtPlace * 100); const want = Math.round(intent.size * 100); let filled = 0; const fills = [];
  for (const e of events) {
    if (e.kind !== 'take' || e.ticker !== intent.ticker || (e.t ?? 0) < intent.placedAt) continue;
    // a YES-ladder bid at p is hit by a taker selling YES (taker 'no') at yes price <= p; a NO-ladder bid at q by a taker buying YES at >= ONE - q
    const hits = intent.side === 'yes' ? e.taker === 'no' && e.price <= intent.price : e.taker === 'yes' && e.price >= ONE - intent.price;
    if (!hits) continue;
    const through = intent.side === 'yes' ? e.price < intent.price : e.price > ONE - intent.price;
    if (through) { fills.push({ t: e.t, size: (want - filled) / 100 }); filled = want; break; }
    let s = e.size; const eat = Math.min(ahead, s); ahead -= eat; s -= eat;
    const f = Math.min(s, want - filled);
    if (f > 0) { filled += f; fills.push({ t: e.t, size: f / 100 }); }
    if (filled >= want) break;
  }
  return { filled: filled / 100, fills };
}

/** Exact executable book in upstream gaming's graded monetary carrier. */
export function orderBookOf(position, ticker, side = 'yes') {
  const m = marketAt(position, ticker);
  if (!m?.yes || m.stale || ['closed', 'determined', 'settled', 'deactivated'].includes(m.status)) throw new RangeError('known live depth required');
  if (!['yes', 'no'].includes(side)) throw new TypeError('YES or NO book required');
  const levels = (ladder, complement = false) => Object.entries(ladder).map(([p, q]) => ({ price: gradedFromParts(complement ? ONE - Number(p) : Number(p), ONE, 'USD'), quantity: gradedFromParts(q, 100, `kalshi:${ticker}:${side}`) }));
  return { bids: levels(m[side]), asks: levels(m[side === 'yes' ? 'no' : 'yes'], true) };
}

/** Depth, slippage and liquidity shortfall use the one upstream book walk. */
export function walkTake(position, ticker, side, quantityHundredths, action = 'buy') {
  if (!Number.isSafeInteger(quantityHundredths) || quantityHundredths < 1) throw new RangeError('positive quantity in hundredths required');
  if (!['buy', 'sell'].includes(action)) throw new TypeError('buy or sell action required');
  const quantity = gradedFromParts(quantityHundredths, 100, `kalshi:${ticker}:${side}`);
  return (action === 'buy' ? marketBuyWalk : marketSellWalk)(orderBookOf(position, ticker, side), quantity);
}

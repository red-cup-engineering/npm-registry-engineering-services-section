/**
 * Kalshi venue records -> balanced Beancount transactions -> reconciliation against the venue.
 *
 * THE LEDGER IS FAROLFI'S. The Group's books are Beancount journals read by Farolfi's ledger engine
 * (`@red-cup-engineering/farolfi/ledger/reports`; the same engine behind MetroPlat's `ledger` operations and the
 * read-ledger-report / read-set-of-ledger-readings services). This module only DERIVES transactions from Kalshi's
 * records, because Kalshi's record semantics are this section's knowledge. Every question about the books
 * (credits received, withdrawn per rail, cash per wallet, realized P&L by market, fees by kind) is a Farolfi query
 * over the journal -- see scripts/query-kalshi-books.mjs -- not code here.
 *
 * ONE CHART OF ACCOUNTS, per holder H, commodity USD. Anything that moves value touches exactly these:
 *   Assets:Kalshi:H:Cash:Event-<n>              cash in event-contract exchange shard n (balance_breakdown exchange_index)
 *   Assets:Kalshi:H:Cash:Perps                  cash in the margined (Perps) wallet
 *   Assets:Kalshi:H:Cash:In-Transit             debited from one wallet, not yet credited to the other
 *   Assets:Kalshi:H:Positions:<MKT>:Yes|No     open contracts of a market side, at average cost
 *   Equity:Kalshi:H:Contributions:<Rail>        owner money in    (rail = deposit `type`: Ach, Wire, Crypto, Debit, Apm)
 *   Equity:Kalshi:H:Withdrawals:<Rail>          owner money out
 *   Income:Kalshi:H:Credits:<Kind>              money Kalshi gives (promotional credits)
 *   Income:Kalshi:H:Realized-PnL:Event:<MKT>    realized by fills that close contracts and by the market's settlement
 *   Income:Kalshi:H:Realized-PnL:Perps:<MKT>    realized by Perps fills
 *   Income:Kalshi:H:Funding                     Perps funding received (paid is negative)
 *   Expenses:Kalshi:H:Fees:Trading|Deposit|Withdrawal|Perpetuals
 *
 * ONE DERIVATION PER RECORD KIND, each a single balanced transaction (stage-wise for transfers). The venue records
 * that move value, from Kalshi's own documentation (docs.kalshi.com), are exactly:
 *   GET /portfolio/deposits, /portfolio/withdrawals      api-reference/portfolio/get-deposits, get-withdrawals
 *       {id, status pending|applied|failed|returned, type ach|wire|crypto|debit|apm, amount_cents, fee_cents, created_ts,
 *        finalized_ts}. Only `applied` moves cash; `fee_cents` is a further charge to cash.
 *   GET /portfolio/fills                                 api-reference/portfolio/get-fills; one YES book: `book_side` bid buys
 *       YES (closing NO first), ask sells YES (closing YES first, then opening NO). A closed contract pays its own side's
 *       price, an opened one costs the opened side's price (collateralized: nothing is received for opening a short);
 *       `fee_cost` (6 places) is charged to cash with the fill.
 *   GET /portfolio/settlements                           get-settlements; `revenue` is integer cents paid into cash and
 *       releases the market's positions. Its `fee_cost` equals the market's fill fees and is not charged again.
 *   GET /portfolio/intra_exchange_instance_transfers     api-reference/portfolio/get-intra-account-transfers
 *       {transfer_id, source, destination: event_contract|margined, *_exchange_shard, amount (dollars), status
 *        pending|complete, created_ts}. Neither contribution nor withdrawal: stage one moves the amount from the source
 *        wallet to In-Transit, stage two (when complete) from In-Transit to the destination.
 *   GET /margin/fills, /margin/funding_history           margin-rest/portfolio/get-fills, margin-rest/funding/get-funding-history
 *       a Perps fill books `realized_pnl` and `fees` to the Perps wallet; a funding payment `funding_amount` likewise.
 *   GET /portfolio/subaccounts/transfers                 api-reference/portfolio/get-subaccount-transfers (empty for both
 *       accounts; subaccounts are not modeled until used).
 * Kalshi documents NO endpoint for promotional/free credits, nor for movements the deposits and withdrawals lists omit
 * (checked: the OpenAPI at docs.kalshi.com/openapi.yaml lists no other value-moving /portfolio or /account path).
 * Those arrive as `credits` (and extra `deposits` / `withdrawals`) records supplied from attested evidence, in the same
 * shapes, and run through the same derivations; until they exist the break below names the missing amount.
 *
 * BREAKS. `reconcileKalshiLedger` compares every wallet with the venue (balance_breakdown per exchange_index; margin
 * account_equity = Perps cash + unrealized_pnl) and positions, and names each difference with its amount
 * (venue minus books). Nothing is plugged.
 *
 * IDEMPOTENCE. Every transaction carries `source_id: "kalshi:<account>:<kind>:<venue id>[:stage]"` (Farolfi's intake key)
 * and the `digest` of its canonical venue record. `postKalshiRecords` appends only unseen source_ids and reports, never
 * rewrites, one whose digest changed. All arithmetic is exact BigInt micro-dollars.
 */
import { createHash } from 'node:crypto';

const MICRO = 1_000_000n;

/** Exact decimal string -> BigInt scaled by 10^places; refuses nonzero digits beyond `places`. */
export function fixed(text, places, label = 'value') {
  const s = typeof text === 'number' ? String(text) : text;
  if (typeof s !== 'string' || !/^-?\d+(?:\.\d+)?$/u.test(s)) throw new TypeError(`${label}: exact decimal required, got ${JSON.stringify(text)}`);
  const negative = s.startsWith('-');
  const [whole, frac = ''] = (negative ? s.slice(1) : s).split('.');
  if (frac.length > places && /[^0]/u.test(frac.slice(places))) throw new RangeError(`${label}: more than ${places} decimal places in ${s}`);
  const n = BigInt(whole) * 10n ** BigInt(places) + BigInt(frac.slice(0, places).padEnd(places, '0'));
  return negative ? -n : n;
}
/** Micro-dollars -> Beancount amount text with six places. */
export function dollarsText(micro) {
  const negative = micro < 0n, abs = negative ? -micro : micro;
  return `${negative ? '-' : ''}${abs / MICRO}.${String(abs % MICRO).padStart(6, '0')}`;
}
const divRound = (num, den) => (2n * num + den) / (2n * den);
const abs = (n) => (n < 0n ? -n : n);
const canonical = (value) => JSON.stringify(value, (_k, v) => (v && typeof v === 'object' && !Array.isArray(v)
  ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, v[k]])) : v));
export const digestOf = (record) => `sha256:${createHash('sha256').update(canonical(record)).digest('hex')}`;

const word = (text) => String(text).split(/[^A-Za-z0-9]+/u).filter(Boolean).map((p) => p[0].toUpperCase() + p.slice(1)).join('-');
const marketSegment = (ticker) => { const s = ticker.replace(/\./gu, 'p').replace(/[^A-Za-z0-9-]/gu, '-'); return /^[A-Z0-9]/u.test(s) ? s : `M${s}`; };

export function chartOfAccounts(accountId) {
  const h = word(accountId), k = `Kalshi:${h}`;
  return Object.freeze({
    cashPrefix: `Assets:${k}:Cash:`,
    event: (shard = 0) => `Assets:${k}:Cash:Event-${shard}`,
    perps: `Assets:${k}:Cash:Perps`,
    inTransit: `Assets:${k}:Cash:In-Transit`,
    position: (ticker, side) => `Assets:${k}:Positions:${marketSegment(ticker)}:${side === 'yes' ? 'Yes' : 'No'}`,
    contributions: (rail) => `Equity:${k}:Contributions:${word(rail ?? 'Unknown')}`,
    withdrawals: (rail) => `Equity:${k}:Withdrawals:${word(rail ?? 'Unknown')}`,
    credits: (kind) => `Income:${k}:Credits:${word(kind ?? 'Promotional')}`,
    pnlEvent: (ticker) => `Income:${k}:Realized-PnL:Event:${marketSegment(ticker)}`,
    pnlPerps: (ticker) => `Income:${k}:Realized-PnL:Perps:${marketSegment(ticker)}`,
    funding: `Income:${k}:Funding`,
    fees: (kind) => `Expenses:${k}:Fees:${kind}`,
  });
}

const iso = (seconds) => new Date(Number(seconds) * 1000).toISOString();
const timeOf = (row, keys) => { for (const k of keys) if (row[k] !== undefined && row[k] !== null) return typeof row[k] === 'number' ? iso(row[k]) : new Date(row[k]).toISOString(); throw new TypeError(`record has no time (${keys.join('|')})`); };

/** One balanced transaction; throws unless debits equal credits. */
function entry({ at, sourceId, record, narration, meta = {}, postings }) {
  const live = postings.filter((p) => p.amount !== 0n);
  const residual = live.reduce((s, p) => s + p.amount, 0n);
  if (residual !== 0n) throw new RangeError(`unbalanced entry ${sourceId}: residual ${dollarsText(residual)}`);
  return Object.freeze({ at, date: at.slice(0, 10), sourceId, digest: digestOf(record), narration, meta, postings: Object.freeze(live) });
}

/**
 * Derive the complete journal of one Kalshi account from its venue records.
 * @returns `{accountId, coa, transactions, wallets, positions, skipped, anomalies}`: transactions are chronological and
 *   balanced; `wallets` maps each cash account to micro-dollars; `positions` are the open markets; `skipped` are records
 *   that move nothing; `anomalies` are records that contradict each other.
 */
export function deriveKalshiLedger({ accountId, deposits = [], withdrawals = [], credits = [], fills = [], settlements = [], transfers = [], perpsFills = [], perpsFunding = [] }) {
  const coa = chartOfAccounts(accountId);
  const events = [], skipped = [], anomalies = [];
  const moves = (rows, kind) => { for (const r of rows) {
    if (r.status !== undefined && r.status !== 'applied') skipped.push({ kind, id: r.id, status: r.status, reason: 'not applied: moves no cash' });
    else events.push({ order: 0, at: timeOf(r, ['finalized_ts', 'created_ts', 'at']), kind, r });
  } };
  moves(deposits, 'deposit'); moves(withdrawals, 'withdrawal'); moves(credits, 'credit');
  for (const r of transfers) events.push({ order: 0, at: timeOf(r, ['created_ts']), kind: 'transfer', r });
  for (const r of fills) events.push({ order: 1, at: timeOf(r, ['created_time', 'ts']), kind: 'fill', r });
  for (const r of perpsFills) events.push({ order: 1, at: timeOf(r, ['created_time']), kind: 'perps-fill', r });
  for (const r of perpsFunding) events.push({ order: 1, at: timeOf(r, ['funding_time']), kind: 'funding', r });
  for (const r of settlements) events.push({ order: 2, at: timeOf(r, ['settled_time']), kind: 'settlement', r });
  events.sort((a, b) => (a.at < b.at ? -1 : a.at > b.at ? 1 : a.order - b.order));

  const book = new Map(); // ticker -> { yes: {qty, cost}, no: {qty, cost} }; qty in hundredths, cost in micro-dollars
  const held = (ticker, s) => { if (!book.has(ticker)) book.set(ticker, { yes: { qty: 0n, cost: 0n }, no: { qty: 0n, cost: 0n } }); return book.get(ticker)[s]; };
  const fillFees = new Map(), seen = new Set(), wallets = new Map(), transactions = [];
  const id = (kind, venueId, stage) => `kalshi:${accountId}:${kind}:${venueId}${stage ? `:${stage}` : ''}`;
  const post = (tx) => {
    if (seen.has(tx.sourceId)) throw new RangeError(`duplicate venue record id ${tx.sourceId}`);
    seen.add(tx.sourceId); transactions.push(tx);
    for (const p of tx.postings) if (p.account.startsWith(coa.cashPrefix)) wallets.set(p.account, (wallets.get(p.account) ?? 0n) + p.amount);
  };

  for (const { at, kind, r } of events) {
    if (kind === 'deposit' || kind === 'withdrawal' || kind === 'credit') {
      const cents = r.amount_cents, fee = BigInt(r.fee_cents ?? 0) * 10_000n;
      if (!Number.isSafeInteger(cents) || cents <= 0) throw new TypeError(`${kind} ${r.id}: positive integer amount_cents required`);
      const amount = BigInt(cents) * 10_000n, wallet = coa.event(r.exchange_index ?? 0);
      const other = kind === 'deposit' ? coa.contributions(r.type) : kind === 'withdrawal' ? coa.withdrawals(r.type) : coa.credits(r.type);
      const inflow = kind !== 'withdrawal';
      post(entry({
        at, sourceId: id(kind, r.id), record: r, narration: `Kalshi ${kind} (${r.type ?? 'unknown'})`, meta: { venue_id: r.id, rail: r.type, evidence: r.evidence },
        postings: [{ account: wallet, amount: inflow ? amount : -amount }, { account: other, amount: inflow ? -amount : amount },
          { account: wallet, amount: -fee }, { account: coa.fees(kind === 'deposit' ? 'Deposit' : 'Withdrawal'), amount: fee }],
      }));
    } else if (kind === 'transfer') {
      const wallet = (instance, shard) => (instance === 'margined' ? coa.perps : instance === 'event_contract' ? coa.event(shard) : null);
      const from = wallet(r.source, r.source_exchange_shard ?? 0), to = wallet(r.destination, r.destination_exchange_shard ?? 0);
      if (!r.transfer_id || !from || !to) throw new TypeError(`transfer ${r.transfer_id}: known source and destination required`);
      if (!['pending', 'complete'].includes(r.status)) { skipped.push({ kind, id: r.transfer_id, status: r.status, reason: 'unknown status: moves nothing' }); continue; }
      const amount = fixed(r.amount, 6, `transfer ${r.transfer_id} amount`);
      if (amount <= 0n) throw new RangeError(`transfer ${r.transfer_id}: positive amount required`);
      const stages = { record: { ...r, status: undefined }, meta: { venue_id: r.transfer_id, from: `${r.source}/${r.source_exchange_shard ?? 0}`, to: `${r.destination}/${r.destination_exchange_shard ?? 0}` } };
      post(entry({ at, sourceId: id(kind, r.transfer_id, 'debit'), ...stages, narration: 'Kalshi inter-wallet transfer: debited from source', postings: [{ account: from, amount: -amount }, { account: coa.inTransit, amount }] }));
      if (r.status === 'complete') post(entry({ at, sourceId: id(kind, r.transfer_id, 'credit'), ...stages, narration: 'Kalshi inter-wallet transfer: credited to destination', postings: [{ account: coa.inTransit, amount: -amount }, { account: to, amount }] }));
    } else if (kind === 'fill') {
      const fid = r.fill_id ?? r.trade_id;
      if (!fid) throw new TypeError('fill without fill_id');
      const count = fixed(r.count_fp, 2, `fill ${fid} count`), yes = fixed(r.yes_price_dollars, 4, `fill ${fid} yes price`), no = fixed(r.no_price_dollars, 4, `fill ${fid} no price`);
      const fee = fixed(r.fee_cost ?? '0', 6, `fill ${fid} fee`);
      if (count <= 0n || yes + no !== 10_000n) throw new RangeError(`fill ${fid}: positive count and complementary prices required`);
      if (r.book_side !== 'bid' && r.book_side !== 'ask') throw new TypeError(`fill ${fid}: book_side bid|ask required`);
      const bid = r.book_side === 'bid';
      const closing = held(r.ticker, bid ? 'no' : 'yes'), opening = held(r.ticker, bid ? 'yes' : 'no');
      const closeQty = count < closing.qty ? count : closing.qty, openQty = count - closeQty;
      const proceeds = closeQty * (bid ? no : yes), opened = openQty * (bid ? yes : no); // hundredths x 1e-4 dollars = micro-dollars
      const relieved = closeQty === 0n ? 0n : closeQty === closing.qty ? closing.cost : divRound(closing.cost * closeQty, closing.qty);
      closing.qty -= closeQty; closing.cost -= relieved; opening.qty += openQty; opening.cost += opened;
      fillFees.set(r.ticker, (fillFees.get(r.ticker) ?? 0n) + fee);
      post(entry({
        at, sourceId: id(kind, fid), record: r, narration: `Kalshi ${r.book_side} ${r.count_fp} ${r.ticker} @ yes ${r.yes_price_dollars}`,
        meta: { venue_id: fid, market: r.ticker, order_id: r.order_id, taker: String(Boolean(r.is_taker)) },
        postings: [
          { account: coa.event(r.exchange_index ?? 0), amount: proceeds - opened - fee },
          { account: coa.position(r.ticker, bid ? 'no' : 'yes'), amount: -relieved },
          { account: coa.position(r.ticker, bid ? 'yes' : 'no'), amount: opened },
          { account: coa.pnlEvent(r.ticker), amount: relieved - proceeds },
          { account: coa.fees('Trading'), amount: fee },
        ],
      }));
    } else if (kind === 'settlement') {
      const { ticker } = r, yesHeld = held(ticker, 'yes'), noHeld = held(ticker, 'no');
      if (!['yes', 'no'].includes(r.market_result)) throw new TypeError(`settlement ${ticker}: market_result yes|no required`);
      if (!Number.isSafeInteger(r.revenue) || r.revenue < 0) throw new TypeError(`settlement ${ticker}: integer revenue cents required`);
      const payout = BigInt(r.revenue) * 10_000n, cost = yesHeld.cost + noHeld.cost;
      const expected = (r.market_result === 'yes' ? yesHeld.qty : noHeld.qty) * 10_000n;
      if (expected !== payout) anomalies.push({ code: 'settlement-payout-differs-from-fills', market: ticker, venue: dollarsText(payout), books: dollarsText(expected) });
      const venueFee = fixed(r.fee_cost ?? '0', 6, `settlement ${ticker} fee`), bookFee = fillFees.get(ticker) ?? 0n;
      if (venueFee !== bookFee) anomalies.push({ code: 'settlement-fee-differs-from-fill-fees', market: ticker, venue: dollarsText(venueFee), books: dollarsText(bookFee) });
      const tx = entry({
        at, sourceId: id(kind, `${ticker}:${r.exchange_index ?? 0}`), record: r, narration: `Kalshi settlement ${ticker} -> ${r.market_result}`,
        meta: { market: ticker, event: r.event_ticker, result: r.market_result, revenue_cents: String(r.revenue) },
        postings: [{ account: coa.event(r.exchange_index ?? 0), amount: payout }, { account: coa.position(ticker, 'yes'), amount: -yesHeld.cost },
          { account: coa.position(ticker, 'no'), amount: -noHeld.cost }, { account: coa.pnlEvent(ticker), amount: cost - payout }],
      });
      yesHeld.qty = yesHeld.cost = noHeld.qty = noHeld.cost = 0n;
      post(tx);
    } else if (kind === 'perps-fill') {
      const realized = fixed(r.realized_pnl ?? '0', 6, `perps fill ${r.fill_id} realized_pnl`), fee = fixed(r.fees ?? '0', 6, `perps fill ${r.fill_id} fees`);
      post(entry({
        at, sourceId: id(kind, r.fill_id), record: r, narration: `Kalshi perps ${r.side} ${r.count} ${r.ticker} @ ${r.price}`,
        meta: { venue_id: r.fill_id, market: r.ticker, order_id: r.order_id },
        postings: [{ account: coa.perps, amount: realized - fee }, { account: coa.pnlPerps(r.ticker), amount: -realized }, { account: coa.fees('Perpetuals'), amount: fee }],
      }));
    } else { // funding
      const amount = fixed(r.funding_amount, 6, `funding ${r.market_ticker} amount`);
      post(entry({
        at, sourceId: id(kind, `${r.market_ticker}:${r.funding_time}:${r.subaccount_number ?? 0}`), record: r, narration: `Kalshi perps funding ${r.market_ticker}`,
        meta: { market: r.market_ticker, subaccount: r.subaccount_number },
        postings: [{ account: coa.perps, amount }, { account: coa.funding, amount: -amount }],
      }));
    }
  }

  const positions = [];
  for (const [ticker, p] of book) if (p.yes.qty !== 0n || p.no.qty !== 0n || p.yes.cost !== 0n || p.no.cost !== 0n) positions.push({ ticker, yes: p.yes, no: p.no });
  return Object.freeze({ accountId, coa, transactions: Object.freeze(transactions), wallets, positions, skipped, anomalies });
}

const renderTx = (tx) => [
  `${tx.date} * "${tx.narration}"`,
  `  source_id: "${tx.sourceId}"`, `  digest: "${tx.digest}"`, `  at: "${tx.at}"`,
  ...Object.entries(tx.meta).filter(([, v]) => v !== undefined && v !== null && v !== '').map(([k, v]) => `  ${k}: "${String(v).replace(/"/gu, "'")}"`),
  ...tx.postings.map((p) => `  ${p.account}  ${dollarsText(p.amount)} USD`),
].join('\n');

/** source_id -> digest for every transaction already in a journal text. */
export function postedIn(journalText = '') {
  const posted = new Map();
  for (const block of journalText.split(/\n(?=\d{4}-\d{2}-\d{2} )/u)) {
    const sourceId = /^\s+source_id:\s*"([^"]+)"/mu.exec(block)?.[1];
    if (sourceId) posted.set(sourceId, /^\s+digest:\s*"([^"]+)"/mu.exec(block)?.[1] ?? null);
  }
  return posted;
}

/**
 * Post a derived ledger into a journal idempotently, by venue record id.
 * @returns `{ appendText, posted, alreadyPosted, conflicts }`: append `appendText` to the holder's journal; `conflicts` are
 *   source_ids already posted whose venue record has since changed (never overwritten).
 */
export function postKalshiRecords(ledger, journalText = '') {
  const have = postedIn(journalText), fresh = [], conflicts = [];
  for (const tx of ledger.transactions) {
    if (!have.has(tx.sourceId)) fresh.push(tx);
    else if (have.get(tx.sourceId) !== tx.digest) conflicts.push({ sourceId: tx.sourceId, journalDigest: have.get(tx.sourceId), venueDigest: tx.digest });
  }
  const open = new Set([...journalText.matchAll(/^\d{4}-\d{2}-\d{2} open (\S+)/gmu)].map((m) => m[1])), first = new Map();
  for (const tx of fresh) for (const p of tx.postings) if (!open.has(p.account) && !first.has(p.account)) first.set(p.account, tx.date);
  const opens = [...first].map(([account, date]) => `${date} open ${account} USD`);
  const appendText = fresh.length ? `${opens.join('\n')}\n\n${fresh.map(renderTx).join('\n\n')}\n` : '';
  return Object.freeze({ appendText, posted: fresh.map((t) => t.sourceId), alreadyPosted: ledger.transactions.length - fresh.length - conflicts.length, conflicts });
}

/** The whole journal text of a derived ledger. */
export const renderJournal = (ledger) => postKalshiRecords(ledger, '').appendText;

/**
 * Reconcile the books with the venue, wallet by wallet. Every break names its wallet or market, the books' amount, the
 * venue's amount and `delta` = venue minus books.
 * @param {object} ledger from `deriveKalshiLedger`
 * @param {{balance: object, positions: object, margin?: {balance: object, positions: object}}} venue GET /portfolio/balance,
 *   GET /portfolio/positions and, where margin is enabled, GET /margin/balance and GET /margin/positions
 * @param {{toleranceDollars?: number}} [options]
 * @returns a serializable result; `gate` is what the order-risk gate consumes: `{admit: true}` or `{admit: false, code, detail}`.
 */
export function reconcileKalshiLedger(ledger, venue, { toleranceDollars = 0.01 } = {}) {
  const tolerance = BigInt(Math.round(toleranceDollars * 1e6)), { coa } = ledger;
  const breaks = [], wallets = [];
  const compare = (code, subject, account, books, theirs, detail, note) => {
    const delta = theirs - books;
    wallets.push({ wallet: subject, account, books: dollarsText(books), venue: dollarsText(theirs), delta: dollarsText(delta), ...(note ? { note } : {}) });
    if (abs(delta) > tolerance) breaks.push({ code, subject, books: dollarsText(books), venue: dollarsText(theirs), delta: dollarsText(delta), detail });
  };

  // Event-contract wallets: GET /portfolio/balance balance_breakdown[{exchange_index, balance}].
  const { balance, positions } = venue;
  const shards = new Map((balance.balance_breakdown ?? [{ exchange_index: 0, balance: balance.balance_dollars }]).map((b) => [Number(b.exchange_index), fixed(b.balance, 6, 'balance_breakdown balance')]));
  for (const account of ledger.wallets.keys()) { const m = /:Cash:Event-(\d+)$/u.exec(account); if (m && !shards.has(Number(m[1]))) shards.set(Number(m[1]), 0n); }
  for (const [index, theirs] of [...shards].sort((a, b) => a[0] - b[0]))
    compare('wallet-break', `event-contract shard ${index}`, coa.event(index), ledger.wallets.get(coa.event(index)) ?? 0n, theirs, 'venue cash minus the books for this exchange_index: a deposit, withdrawal, credit, transfer, fill or settlement is missing from the records');

  // Perps wallet: GET /margin/balance account_equity (summed over subaccounts) = Perps cash + GET /margin/positions unrealized_pnl.
  const perpsBooks = ledger.wallets.get(coa.perps) ?? 0n;
  if (venue.margin) {
    const theirs = (venue.margin.balance?.subaccount_balances ?? []).reduce((sum, row) => sum + fixed(row.account_equity, 6, 'account_equity'), 0n);
    const unrealized = (venue.margin.positions?.positions ?? []).reduce((sum, row) => sum + fixed(row.unrealized_pnl, 6, 'unrealized_pnl'), 0n);
    compare('wallet-break', 'perps (margined)', coa.perps, perpsBooks + unrealized, theirs, 'venue margin equity minus the books (Perps cash + unrealized P&L): a transfer, margin fill or funding payment is missing', `books cash ${dollarsText(perpsBooks)} + unrealized ${dollarsText(unrealized)}`);
  } else if (ledger.wallets.has(coa.perps)) {
    breaks.push({ code: 'perps-not-read', subject: 'perps (margined)', books: dollarsText(perpsBooks), venue: null, delta: null, detail: 'the books hold Perps cash but the margin balance and positions were not supplied' });
  }

  // Event positions: GET /portfolio/positions position_fp (YES positive, NO negative) and market_exposure_dollars.
  const theirsByMarket = new Map((positions?.market_positions ?? []).map((row) => [row.ticker, row]));
  const booksByMarket = new Map(ledger.positions.map((p) => [p.ticker, p]));
  for (const ticker of new Set([...theirsByMarket.keys(), ...booksByMarket.keys()])) {
    const v = theirsByMarket.get(ticker), b = booksByMarket.get(ticker);
    const theirQty = v ? fixed(v.position_fp, 2, `position_fp ${ticker}`) : 0n, bookQty = b ? b.yes.qty - b.no.qty : 0n;
    if (theirQty !== bookQty) breaks.push({ code: 'position-break', subject: ticker, books: `${Number(bookQty) / 100}`, venue: `${Number(theirQty) / 100}`, delta: `${Number(theirQty - bookQty) / 100}`, detail: 'signed contracts (YES positive, NO negative) differ from position_fp' });
    const theirCost = v?.market_exposure_dollars === undefined ? null : fixed(v.market_exposure_dollars, 6, `market_exposure_dollars ${ticker}`);
    const bookCost = b ? b.yes.cost + b.no.cost : 0n;
    if (theirCost !== null && abs(theirCost - bookCost) > tolerance) breaks.push({ code: 'exposure-break', subject: ticker, books: dollarsText(bookCost), venue: dollarsText(theirCost), delta: dollarsText(theirCost - bookCost), detail: 'position at cost differs from market_exposure_dollars' });
  }
  const portfolioValue = BigInt(balance.portfolio_value ?? 0) * 10_000n;
  if (ledger.positions.length === 0 && portfolioValue !== 0n)
    breaks.push({ code: 'portfolio-value-break', subject: 'portfolio_value', books: '0.000000', venue: dollarsText(portfolioValue), delta: dollarsText(portfolioValue), detail: 'the venue marks a portfolio the books hold no positions for' });
  for (const a of ledger.anomalies) breaks.push({ code: a.code, subject: a.market, books: a.books, venue: a.venue, delta: dollarsText(fixed(a.venue, 6) - fixed(a.books, 6)), detail: 'venue records contradict each other or the fills' });

  const ok = breaks.length === 0;
  return Object.freeze({
    type: 'KalshiLedgerReconciliation', version: 2, accountId: ledger.accountId, ok, breaks, wallets,
    inTransit: dollarsText(ledger.wallets.get(coa.inTransit) ?? 0n), toleranceDollars,
    // The order-risk gate's input: refuse writes when the books do not agree with the venue.
    gate: ok ? { admit: true } : { admit: false, code: 'ledger-break', detail: `books do not reconcile with the venue for ${ledger.accountId}: ${breaks.map((b) => `${b.code} ${b.subject}${b.delta ? ` ${b.delta}` : ''}`).join(', ')}` },
  });
}

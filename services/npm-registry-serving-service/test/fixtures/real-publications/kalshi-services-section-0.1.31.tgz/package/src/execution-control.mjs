// The host's human order-execution control is independent of strategy, arming,
// source releases and the rest of FeltOS. Missing/unreadable control is closed.
import {readFileSync,mkdirSync,writeFileSync,renameSync} from 'node:fs';
import {homedir} from 'node:os';
import {dirname,join} from 'node:path';
export const executionControlPath=()=>join(process.env.KALSHI_SETTLEMENT_DIR??join(homedir(),'.local/state/561-group/settlements/kalshi-services-section'),'data/state/order-execution-state/control.json');
export function orderExecutionControl(accountId) {
 try {
  const record=JSON.parse(readFileSync(executionControlPath(),'utf8'));
  if(record.kind!=='kalshi-order-execution-control'||record.closed!==false||!Array.isArray(record.accounts)||!record.accounts.includes(accountId)||typeof record.authorizedBy!=='string'||!record.authorizedBy.trim()||!Number.isFinite(Date.parse(record.authorizedAt)))return {...record,closed:true};
  return record;
 }catch(error){return {kind:'kalshi-order-execution-control',closed:true,reason:error.code==='ENOENT'?'No explicit live execution authorization':'Execution control is unreadable'};}
}
export function hardCloseOrderExecution(reason) {
 if(typeof reason!=='string'||!reason.trim())throw new TypeError('A human closure reason is required');
 const path=executionControlPath(),record={kind:'kalshi-order-execution-control',closed:true,reason,closedAt:new Date().toISOString()};
 mkdirSync(dirname(path),{recursive:true,mode:0o700});
 const temporary=path+'.'+process.pid+'.tmp';writeFileSync(temporary,JSON.stringify(record,null,2)+'\n',{mode:0o600});renameSync(temporary,path);
 return {...record,path};
}
export class KalshiExecutionClosed extends Error {
 constructor(control){super('Kalshi live execution is hard-closed: '+(control.reason??'explicit new human authorization is required'));this.code='KALSHI_EXECUTION_HARD_CLOSED';this.venueWrite=false;}
}
export function assertOrderExecutionOpen(accountId,{method,apiPath,baseUrl,demoUrl}) {
 if(['GET','HEAD'].includes(method)||new URL(baseUrl).origin===new URL(demoUrl).origin)return;
 // Closing preserves cancellation, including the native group trigger. It
 // never authorizes a replacement, amendment, deposit or new order group.
 if(method==='DELETE'&&/^\/portfolio\/(?:events\/)?orders(?:\/[^/]+)?$/u.test(apiPath))return;
 if(method==='DELETE'&&/^\/portfolio\/order_groups\/[^/]+$/u.test(apiPath))return;
 if(method==='POST'&&/^\/portfolio\/order_groups\/[^/]+\/trigger$/u.test(apiPath))return;
 const control=orderExecutionControl(accountId);if(control.closed)throw new KalshiExecutionClosed(control);
}

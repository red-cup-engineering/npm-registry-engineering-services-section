/**
 * Where the Kalshi section keeps what it writes at run time. The settlement's data lives in machine
 * state, `~/.local/state/561-group/settlements/kalshi-services-section`, filed by tier and type:
 * `data/logs/<type>-logs/`, `data/records/<type>-records/`, `data/state/<object>-state/`. The
 * directory names come from the data-artifact address law (eavt-services-section), never from here.
 */
import { homedir } from 'node:os';
import { join } from 'node:path';
import { dataKindDirectory } from '@red-cup-engineering/eavt-services-section/data-artifact-address';
import { kalshiAccount } from './accounts.mjs';

/** The host's settlement root for the section, shared by every account on the host. */
export const sectionRoot = (env = process.env) =>
  env.KALSHI_SETTLEMENT_DIR ?? join(env.HOME ?? homedir(), '.local', 'state', '561-group', 'settlements', 'kalshi-services-section');

/** The settlement root whose `data/` holds the section's logs, records and state. */
export function settlementRoot(env = process.env) {
  const root = sectionRoot(env);
  const account = kalshiAccount(env);
  return account.id === 'emsenn' ? root : join(root, 'accounts', account.id);
}

/** The directory of an object's state under a settlement root. */
export const stateDirectory = (root, object) => dataKindDirectory(root, 'state', object);
/** The directory of a type's records under a settlement root. */
export const recordDirectory = (root, type) => dataKindDirectory(root, 'record', type);

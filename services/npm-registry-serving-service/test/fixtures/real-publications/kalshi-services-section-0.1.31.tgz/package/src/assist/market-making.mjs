import {orderExecutionControl} from '../execution-control.mjs';
/**
 * The weather market maker as the Kalshi ASSIST application's FeltOS application services: one per account whose
 * holder has opted it in, each started once per process (context.services.ensure), restarted with backoff when its
 * venue stream fails, closed on drain, and reported in /healthz. Every account's desk shares one Group book, so the
 * Group's accounts are one presence on the venue and never outbid one another. Their runs are logged as one SEAVT
 * feed under the section's settlement root (data/logs/weather-market-making-logs), each row naming its account.
 *
 * Opting in. The target declares the accounts (`configuration.marketMaking.accounts`), each by the environment
 * variables that carry its key: { API_KEY_ID, PRIVATE_KEY_PATH } for a key the host renders, or { ENV_FILE } for the
 * account's own credentials file (KALSHI_API_KEY_ID, KALSHI_PRIVATE_KEY_PATH, KALSHI_CREDENTIAL_ACCOUNT_ID). A
 * declared account is one whose holder has agreed to the desk using its prediction-market cash; under an armed
 * release its desk quotes on the venue, under a shadow release it quotes virtually. The account's holder may still
 * trade by hand: the desk reads the account as the venue holds it (weather-market-maker.mjs).
 */
import { readFileSync } from 'node:fs';
import { createVenueExecutor } from '../venue-executor.mjs';
import { createKalshiClient } from '../client.mjs';
import { openKalshiStream } from '../stream.mjs';
import { createGroupBook, createWeatherMarketMaker } from '../weather-market-maker.mjs';
import { KALSHI_ACCOUNTS } from '../accounts.mjs';
import { kalshiCredentials } from '../account-credentials.mjs';
import { appendLogRows, mark } from '../seavt-log.mjs';
import { settlementRoot, stateDirectory } from '../data-layout.mjs';
import { storedScores } from '../live-score-store.mjs';
import { latestLampGuidance } from '@red-cup-engineering/forecasting/lamp-station-guidance';
import fits from '@red-cup-engineering/forecasting/weather-index-lattice-fit.json' with { type: 'json' };
import policy from '../../content/config/weather-market-making.json' with { type: 'json' };

export const MARKET_MAKER_SERVICE = 'kalshi-weather-market-maker';
const FEED = 'weather-market-making';
const { version } = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));

/** The market maker's run log: each row a SEAVT observation (entity: the run's kind and object; value: the row). */
export function seavtLedger(root) {
  // The SEAVT store files a feed under its root's data/logs/<feed>-logs itself.
  return Object.freeze({
    append(rows) {
      appendLogRows(root, FEED, rows.map((row) => ({ e: mark([FEED, row.kind, row.order ?? row.id ?? row.event ?? row.at]), a: mark(row.kind), v: mark(JSON.parse(JSON.stringify(row))), t: row.at })),
        (row) => row.t.slice(0, 10), { distinct: false });
    },
  });
}

/** The service name of one account's desk. */
export const serviceOf = (account) => `${MARKET_MAKER_SERVICE}:${account}`;

/** One declared account's key, read through the section's own credential rules (an account's file is its own). */
export function accountCredentials(account, bindings, env = process.env) {
  const named = (key) => env[bindings[key]];
  const scoped = bindings.ENV_FILE
    ? { KALSHI_ACCOUNT_ID: account, KALSHI_CREDENTIAL_ACCOUNT_ID: account, KALSHI_ENV_FILE: named('ENV_FILE') }
    : { KALSHI_ACCOUNT_ID: account, KALSHI_CREDENTIAL_ACCOUNT_ID: account, KALSHI_API_KEY_ID: named('API_KEY_ID'), KALSHI_PRIVATE_KEY_PATH: named('PRIVATE_KEY_PATH') };
  if (bindings.ENV_FILE ? !scoped.KALSHI_ENV_FILE : !(scoped.KALSHI_API_KEY_ID && scoped.KALSHI_PRIVATE_KEY_PATH))
    throw new Error(`the target has not supplied ${Object.values(bindings).join(' and ')} for ${account}`);
  const credentials = kalshiCredentials(scoped);
  if (!credentials) throw new Error(`${account}'s credentials name no complete key`);
  return credentials;
}

const declared = (bindings) => {
  const keys = Object.keys(bindings ?? {}).sort().join(',');
  return (keys === 'API_KEY_ID,PRIVATE_KEY_PATH' || keys === 'ENV_FILE') && Object.values(bindings).every((v) => /^KALSHI_[A-Z0-9_]+$/u.test(v));
};

/**
 * Start (once each) the desks of the hosted application's declared accounts. `marketMaking` is the target's
 * declaration: { accounts: { <account>: { environmentBindings: {...}, subaccount? } } }. Without it, or without a host
 * that keeps application services, nothing starts.
 */
export function ensureWeatherMarketMaker({ services, marketMaking, env = process.env, log = (line) => process.stderr.write(line) }) {
  if (!marketMaking || typeof services?.ensure !== 'function') return null;
  const accounts = marketMaking.accounts;
  if (Object.keys(marketMaking).some((key) => key !== 'accounts') || !accounts || typeof accounts !== 'object' || !Object.keys(accounts).length
    || Object.entries(accounts).some(([id, a]) => !Object.hasOwn(KALSHI_ACCOUNTS, id) || !declared(a?.environmentBindings) || Object.keys(a).some((k) => k !== 'environmentBindings' && k !== 'subaccount')))
    throw new TypeError('market making names the Group\'s opted-in accounts and the environment variables of each key: { accounts: { <account>: { environmentBindings: { API_KEY_ID, PRIVATE_KEY_PATH } | { ENV_FILE }, subaccount? } } }');
  const group = createGroupBook();
  return Object.entries(accounts).filter(([account])=>{const control=orderExecutionControl(account);if(control.closed)log(`[weather-market-maker] ${account}: hard-closed; no trading service started\n`);return !control.closed;}).map(([account, { environmentBindings, subaccount = 0 }]) => services.ensure(serviceOf(account), {
    async start({ signal }) {
      const credentials = accountCredentials(account, environmentBindings, env);
      const root = settlementRoot(env), client = createKalshiClient({ env: {}, credentials });
      const guidanceCache = stateDirectory(root, 'lamp-guidance');
      let maker = null;
      const executor = policy.mode === 'armed' ? createVenueExecutor({ client, run: `${account}:${Date.now().toString(36)}`, subaccount, onFill: (key, contracts, priceCents) => maker?.applyFill(key, contracts, priceCents), log }) : null;
      log(`[weather-market-maker] ${account}: kalshi-services-section ${version}, ${executor ? 'armed' : 'shadow'}\n`);
      maker = createWeatherMarketMaker({
        policy, fits, client, log, ledger: seavtLedger(root), scoreHistory: storedScores(root, account), executor, subaccount, account, group, strategy: `kalshi-services-section@${version}`,
        openStream: (options) => openKalshiStream({ credentials, ...options }),
        guidance: async (_city, stations) => [await latestLampGuidance({ stations, cacheDir: guidanceCache })],
      });
      return maker.start({ signal });
    },
  }));
}

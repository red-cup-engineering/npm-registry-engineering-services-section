/**
 * A Kalshi exchange simulator at the venue's own boundary: the REST API as a `fetch` (for createKalshiClient's
 * fetchImpl) and the WebSocket API as a `WebSocket` class (for openKalshiStream's WebSocketImpl). The section's real
 * client (pacing, signing, retries, error parsing), stream, arena, executor and maker run against it unchanged, so a
 * test of the desk is a test of what the venue will see, not of a fake written to the code's own assumptions.
 *
 * What it implements, from Kalshi's documentation (docs.kalshi.com, 2026-10):
 * - Books. Each market holds YES bids and NO bids (a YES ask at a is a NO bid at 100 - a), matched in price-time
 *   priority. Prices are whole cents, counts whole contracts.
 * - Orders (V2). POST /portfolio/events/orders: side bid (YES bid at price) or ask (NO bid at 100 - price);
 *   post-only orders that would cross are refused; the reply carries order_id at the top level. Amend
 *   (POST .../{id}/amend): count is the total fillable (filled plus resting); a new price or a larger resting size goes
 *   to the back of the queue, a smaller one keeps its place. Cancel (DELETE .../{id}). An order that no longer rests is
 *   404 to both.
 * - Cash. A resting bid holds its price times its size out of the account's cash; a fill turns that into a position;
 *   an order the account cannot cover is refused for insufficient balance. Positions net: YES and NO of one market
 *   held together pay their dollar back at once.
 * - Budgets. Each account's reads, writes and balance reads are token buckets (Basic: 200 tokens a second up to 600,
 *   100 up to 100, and one balance read a second; 10 tokens a request); a request the bucket cannot pay is a 429.
 * - Order groups. POST /portfolio/order_groups/create, PUT .../{id}/limit. When more contracts match within a rolling
 *   15 seconds than the group's limit, every order in it is cancelled, the group is triggered, and an
 *   order_group_updates "triggered" is told; a triggered group takes no new orders.
 * - Expiry. An order expires at its expiration_time.
 * - Streams. orderbook_snapshot on subscription, then orderbook_delta (naming the client_order_id when the
 *   subscriber's own order caused it) and trade, each frame numbered on its subscription; the private channels fill,
 *   user_orders, market_positions and order_group_updates.
 *
 * One semantic the documentation leaves open is an option: `balanceExcludesResting` (does GET /portfolio/balance
 * report cash less what resting orders hold?). The desk's conformance run against Kalshi's demo exchange settles it.
 *
 * The rest of the market is driven by the test: `seed` rests someone else's order, `take` sends someone else's
 * marketable order through the book, `settle` settles a market, `marketData` answers the public reads (events, the
 * weather index) the desk makes. Time is `clock`.
 */
const WINDOW_MS = 15_000;
const TIERS = { basic: { read: [200, 600], write: [100, 100], balance: [1, 1] } };
const fp = (n) => Number(n).toFixed(2);
const dollars = (cents) => (cents / 100).toFixed(4);
const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } });
const refuse = (status, code, message) => json(status, { error: { code, message } });

export function createExchangeSimulator({ clock, tier = 'basic', balanceExcludesResting = true, marketData = async () => null } = {}) {
  const accounts = new Map(), books = new Map(), sockets = new Set(), log = [];
  let ids = 0, seq = 0;
  const now = () => clock();
  const bookOf = (ticker) => { if (!books.has(ticker)) books.set(ticker, { yes: [], no: [] }); return books.get(ticker); };

  /** An account: its key, its cash in cents, and its state on the venue. */
  function open(id, { apiKeyId = id, cashCents = 0 } = {}) {
    const limits = TIERS[tier];
    const bucket = ([rate, capacity]) => ({ rate, capacity, tokens: capacity, at: now() });
    const account = { id, apiKeyId, cash: cashCents, reserved: 0, positions: new Map(), orders: new Map(), groups: new Map(), buckets: { read: bucket(limits.read), write: bucket(limits.write), balance: bucket(limits.balance) } };
    accounts.set(apiKeyId, account);
    return account;
  }
  const spend = (b, cost) => { const t = now(); b.tokens = Math.min(b.capacity, b.tokens + ((t - b.at) / 1000) * b.rate); b.at = t; if (b.tokens < cost) return false; b.tokens -= cost; return true; };

  // --- What a subscriber is told.
  function tell(account, type, msg) { for (const s of sockets) if (s.account === account && s.private.has(type)) s.push({ type, sid: s.private.get(type), msg }); }
  function tellMarket(channel, ticker, type, msg, causedBy = null) {
    for (const s of sockets) {
      const sub = s.market.get(channel); if (!sub || !sub.tickers.has(ticker)) continue;
      const own = causedBy && causedBy.account === s.account && causedBy.clientOrderId ? { client_order_id: causedBy.clientOrderId } : {};
      s.push({ type, sid: sub.sid, seq: (sub.seq += 1), msg: { market_ticker: ticker, ...msg, ...own } });
    }
  }
  const levelDelta = (order, delta) => tellMarket('orderbook_delta', order.ticker, 'orderbook_delta', { price_dollars: dollars(order.priceCents), delta_fp: fp(delta), side: order.side, ts_ms: now() }, order);
  const userOrder = (order, status, reason = null) => order.account && tell(order.account, 'user_order', {
    order_id: order.id, ticker: order.ticker, status, side: order.side, outcome_side: order.side, book_side: order.side === 'yes' ? 'bid' : 'ask',
    yes_price_dollars: dollars(order.side === 'yes' ? order.priceCents : 100 - order.priceCents), remaining_count_fp: fp(status === 'resting' ? order.remaining : 0),
    fill_count_fp: fp(order.filled), initial_count_fp: fp(order.filled + order.remaining), client_order_id: order.clientOrderId ?? '', ...(order.group ? { order_group_id: order.group } : {}),
    ...(reason ? { last_update_reason: reason } : {}), last_updated_ts_ms: now(),
  });
  const positionTold = (account, ticker) => tell(account, 'market_position', { market_ticker: ticker, position_fp: fp(account.positions.get(ticker) ?? 0) });

  // --- The book.
  function insert(order) {
    const level = bookOf(order.ticker)[order.side];
    order.seq = (seq += 1);
    level.push(order);
    level.sort((a, b) => b.priceCents - a.priceCents || a.seq - b.seq);
  }
  function remove(order) {
    const level = bookOf(order.ticker)[order.side], i = level.indexOf(order);
    if (i >= 0) level.splice(i, 1);
  }
  const crosses = (ticker, side, priceCents) => { const other = bookOf(ticker)[side === 'yes' ? 'no' : 'yes'][0]; return Boolean(other && other.priceCents + priceCents >= 100); };
  function release(order) { if (order.account) { order.account.reserved -= order.priceCents * order.remaining; order.account.orders.delete(order.id); } }
  function cancel(order, reason) { remove(order); levelDelta(order, -order.remaining); release(order); userOrder(order, 'canceled', reason); }
  function expire() { for (const book of books.values()) for (const side of ['yes', 'no']) for (const order of [...book[side]]) if (order.expiresAt && order.expiresAt <= now()) cancel(order, 'ExpiryCancel'); }

  /** Credit `n` contracts of `side` to an account at `priceCents` each; YES and NO held together pay their dollar back. */
  function credit(account, ticker, side, n, priceCents) {
    account.cash -= priceCents * n;
    const delta = side === 'yes' ? n : -n, before = account.positions.get(ticker) ?? 0, after = before + delta;
    const netted = before !== 0 && Math.sign(delta) !== Math.sign(before) ? Math.min(Math.abs(before), n) : 0;
    account.cash += 100 * netted;
    if (after) account.positions.set(ticker, after); else account.positions.delete(ticker);
    positionTold(account, ticker);
  }
  /** Match a marketable order of `count` buying `side` at up to `limitCents` against the other side's bids. */
  function match(ticker, side, limitCents, count, taker = null) {
    const against = bookOf(ticker)[side === 'yes' ? 'no' : 'yes'];
    let left = count;
    while (left > 0 && against.length && 100 - against[0].priceCents <= limitCents) {
      const maker = against[0], n = Math.min(left, maker.remaining), yesPrice = side === 'yes' ? 100 - maker.priceCents : maker.priceCents;
      maker.remaining -= n; maker.filled += n; left -= n;
      levelDelta(maker, -n);
      tellMarket('trade', ticker, 'trade', { yes_price_dollars: dollars(yesPrice), count_fp: fp(n), taker_outcome_side: side, ts: Math.floor(now() / 1000) });
      if (maker.account) {
        maker.account.reserved -= maker.priceCents * n;
        credit(maker.account, ticker, maker.side, n, maker.priceCents);
        tell(maker.account, 'fill', { order_id: maker.id, market_ticker: ticker, side: maker.side, is_taker: false, yes_price_dollars: dollars(yesPrice), count_fp: fp(n), client_order_id: maker.clientOrderId ?? '', ts: Math.floor(now() / 1000) });
        if (maker.group) matched(maker.account, maker.group, n);
      }
      if (taker) credit(taker, ticker, side, n, side === 'yes' ? yesPrice : 100 - yesPrice);
      if (maker.remaining === 0) { remove(maker); if (maker.account) { maker.account.orders.delete(maker.id); userOrder(maker, 'executed', 'Trade'); } }
      else if (maker.account) userOrder(maker, 'resting', 'Trade');
    }
    return count - left;
  }
  function matched(account, groupId, n) {
    const group = account.groups.get(groupId); if (!group || group.triggered) return;
    group.window.push({ at: now(), n });
    group.window = group.window.filter((m) => m.at > now() - WINDOW_MS);
    if (group.window.reduce((s, m) => s + m.n, 0) <= group.limit) return;
    group.triggered = true;
    for (const order of [...account.orders.values()]) if (order.group === groupId) cancel(order, 'OrderGroupCancel');
    tell(account, 'order_group_updates', { event_type: 'triggered', order_group_id: groupId, ts_ms: now() });
  }

  // --- REST.
  async function route(account, method, path, query, body) {
    if (method === 'GET' && path === '/portfolio/balance') return json(200, { balance: account.cash - (balanceExcludesResting ? account.reserved : 0), portfolio_value: 0, updated_ts: Math.floor(now() / 1000) });
    if (method === 'GET' && path === '/portfolio/orders') {
      const rows = [...account.orders.values()].filter(() => (query.get('status') ?? 'resting') === 'resting').map((o) => ({
        order_id: o.id, ticker: o.ticker, status: 'resting', side: o.side, action: 'buy', book_side: o.side === 'yes' ? 'bid' : 'ask', yes_price_dollars: dollars(o.side === 'yes' ? o.priceCents : 100 - o.priceCents),
        no_price_dollars: dollars(o.side === 'no' ? o.priceCents : 100 - o.priceCents), remaining_count_fp: fp(o.remaining), client_order_id: o.clientOrderId ?? '' }));
      return json(200, { orders: rows, cursor: '' });
    }
    if (method === 'GET' && path === '/portfolio/positions') return json(200, { market_positions: [...account.positions].map(([ticker, n]) => ({ ticker, position_fp: fp(n) })), event_positions: [], cursor: '' });
    if (method === 'POST' && path === '/portfolio/order_groups/create') {
      const id = `group-${(ids += 1)}`; account.groups.set(id, { limit: Number(body.contracts_limit), window: [], triggered: false });
      tell(account, 'order_group_updates', { event_type: 'created', order_group_id: id, contracts_limit_fp: fp(body.contracts_limit), ts_ms: now() });
      return json(201, { order_group_id: id });
    }
    let m = /^\/portfolio\/order_groups\/([^/]+)\/limit$/u.exec(path);
    if (method === 'PUT' && m) {
      const group = account.groups.get(m[1]); if (!group) return refuse(404, 'not_found', 'not found');
      group.limit = Number(body.contracts_limit);
      tell(account, 'order_group_updates', { event_type: 'limit_updated', order_group_id: m[1], contracts_limit_fp: fp(group.limit), ts_ms: now() });
      return json(200, {});
    }
    if (method === 'POST' && path === '/portfolio/events/orders') {
      const side = body.side === 'bid' ? 'yes' : body.side === 'ask' ? 'no' : null, yes = Math.round(Number(body.price) * 100), count = Math.round(Number(body.count));
      if (!side || !(yes >= 1 && yes <= 99) || !(count >= 1)) return refuse(400, 'invalid_parameters', 'invalid order');
      const priceCents = side === 'yes' ? yes : 100 - yes, group = body.order_group_id ? account.groups.get(body.order_group_id) : null;
      if (body.order_group_id && (!group || group.triggered)) return refuse(400, 'order_group_triggered', 'order group triggered');
      if (body.post_only && crosses(body.ticker, side, priceCents)) return refuse(400, 'post_only_cross', 'post only cross');
      if (priceCents * count > account.cash - account.reserved) return refuse(400, 'insufficient_balance', 'insufficient balance');
      const order = { id: `order-${(ids += 1)}`, account, ticker: body.ticker, side, priceCents, remaining: count, filled: 0, clientOrderId: body.client_order_id ?? null, group: body.order_group_id ?? null, expiresAt: body.expiration_time ? body.expiration_time * 1000 : null };
      account.reserved += priceCents * count; account.orders.set(order.id, order); insert(order);
      levelDelta(order, count); userOrder(order, 'resting');
      return json(201, { order_id: order.id, client_order_id: order.clientOrderId, fill_count: fp(0), remaining_count: fp(count), ts_ms: now() });
    }
    m = /^\/portfolio\/events\/orders\/([^/]+)(\/amend)?$/u.exec(path);
    if (m) {
      const order = account.orders.get(m[1]);
      if (!order) return refuse(404, 'not_found', 'not found');
      if (method === 'DELETE' && !m[2]) { const n = order.remaining; cancel(order, null); return json(200, { order_id: order.id, client_order_id: order.clientOrderId, reduced_by: fp(n), ts_ms: now() }); }
      if (method === 'POST' && m[2]) {
        const yes = Math.round(Number(body.price) * 100), priceCents = order.side === 'yes' ? yes : 100 - yes, remaining = Math.round(Number(body.count)) - order.filled;
        if (body.client_order_id && body.client_order_id !== order.clientOrderId) return refuse(400, 'invalid_parameters', 'client order id mismatch');
        if (!(remaining >= 1) || !(priceCents >= 1 && priceCents <= 99)) return refuse(400, 'invalid_parameters', 'invalid amend');
        if (priceCents !== order.priceCents && crosses(order.ticker, order.side, priceCents)) return refuse(400, 'post_only_cross', 'post only cross');
        const more = priceCents * remaining - order.priceCents * order.remaining;
        if (more > account.cash - account.reserved) return refuse(400, 'insufficient_balance', 'insufficient balance');
        const back = priceCents !== order.priceCents || remaining > order.remaining;
        levelDelta(order, -order.remaining); account.reserved += more;
        if (back) { remove(order); order.priceCents = priceCents; order.remaining = remaining; insert(order); } else order.remaining = remaining;
        if (body.updated_client_order_id) order.clientOrderId = body.updated_client_order_id;
        levelDelta(order, order.remaining); userOrder(order, 'resting', 'Amend');
        return json(200, { order_id: order.id, client_order_id: order.clientOrderId, ts_ms: now() });
      }
    }
    return refuse(404, 'not_found', 'not found');
  }

  /** The REST API, for createKalshiClient({ fetchImpl }); every request is logged with its answer's status. */
  async function fetchImpl(input, init = {}) {
    const response = await answer(input, init);
    log.at(-1).status = response.status;
    return response;
  }
  async function answer(input, init) {
    expire();
    const url = new URL(String(input)), path = url.pathname.replace(/^\/trade-api\/v2/u, ''), method = (init.method ?? 'GET').toUpperCase();
    const body = init.body ? JSON.parse(init.body) : null, headers = new Headers(init.headers ?? {}), key = headers.get('KALSHI-ACCESS-KEY');
    log.push({ at: now(), method, path });
    if (!key) { const answer = await marketData({ method, path, query: url.searchParams }); return answer === null ? refuse(404, 'not_found', 'not found') : json(200, answer); }
    const account = accounts.get(key);
    if (!account) return refuse(401, 'unauthorized', 'unknown key');
    const lane = path === '/portfolio/balance' ? 'balance' : method === 'GET' ? 'read' : 'write';
    if (!spend(account.buckets[lane], lane === 'balance' ? 1 : 10)) return refuse(429, 'too_many_requests', 'too many requests');
    if (path.startsWith('/portfolio')) return route(account, method, path, url.searchParams, body);
    const answer = await marketData({ method, path, query: url.searchParams, account: account.id });
    return answer === null ? refuse(404, 'not_found', 'not found') : json(200, answer);
  }

  /** The WebSocket API, for openKalshiStream({ WebSocketImpl }). */
  class WebSocket {
    constructor(_url, { headers = {} } = {}) {
      this.account = accounts.get(headers['KALSHI-ACCESS-KEY'] ?? headers['kalshi-access-key']) ?? null;
      this.listeners = new Map(); this.market = new Map(); this.private = new Map(); this.closed = false;
      sockets.add(this);
      queueMicrotask(() => this.emit('open', {}));
    }
    addEventListener(type, f) { if (!this.listeners.has(type)) this.listeners.set(type, []); this.listeners.get(type).push(f); }
    emit(type, event) { for (const f of this.listeners.get(type) ?? []) f(event); }
    push(frame) { if (!this.closed) queueMicrotask(() => !this.closed && this.emit('message', { data: JSON.stringify(frame) })); }
    close() { this.closed = true; sockets.delete(this); }
    send(text) {
      const { id, cmd, params } = JSON.parse(text);
      if (cmd === 'subscribe') {
        for (const channel of params.channels) {
          const sid = (ids += 1);
          if (['orderbook_delta', 'trade', 'market_lifecycle_v2'].includes(channel)) {
            const sub = { sid, seq: 0, tickers: new Set(params.market_tickers ?? []) };
            this.market.set(channel, sub);
            this.push({ type: 'subscribed', id, msg: { channel, sid } });
            if (channel === 'orderbook_delta') for (const t of sub.tickers) this.snapshot(sub, t);
          } else { this.private.set(channel === 'user_orders' ? 'user_order' : channel === 'market_positions' ? 'market_position' : channel, sid); this.push({ type: 'subscribed', id, msg: { channel, sid } }); }
        }
      } else if (cmd === 'update_subscription') {
        for (const [channel, sub] of this.market) {
          if (!params.sids.includes(sub.sid)) continue;
          for (const t of params.market_tickers) { if (params.action === 'add_markets') sub.tickers.add(t); else sub.tickers.delete(t); }
          this.push({ type: 'ok', id, sid: sub.sid, seq: (sub.seq += 1), msg: {} });
          if (channel === 'orderbook_delta' && params.action === 'add_markets') for (const t of params.market_tickers) this.snapshot(sub, t);
        }
      } else if (cmd === 'unsubscribe') {
        for (const [channel, sub] of this.market) if (params.sids.includes(sub.sid)) { this.market.delete(channel); this.push({ type: 'unsubscribed', id, sid: sub.sid, msg: {} }); }
      }
    }
    snapshot(sub, ticker) {
      const book = bookOf(ticker), ladder = (side) => {
        const levels = new Map(); for (const o of book[side]) levels.set(o.priceCents, (levels.get(o.priceCents) ?? 0) + o.remaining);
        return [...levels].sort((a, b) => a[0] - b[0]).map(([p, q]) => [dollars(p), fp(q)]);
      };
      this.push({ type: 'orderbook_snapshot', sid: sub.sid, seq: (sub.seq += 1), msg: { market_ticker: ticker, yes_dollars_fp: ladder('yes'), no_dollars_fp: ladder('no') } });
    }
  }

  return Object.freeze({
    open, fetchImpl, WebSocket, log,
    /** Someone else's resting bid. */
    seed(ticker, side, priceCents, count) { const order = { id: `order-${(ids += 1)}`, account: null, ticker, side, priceCents, remaining: count, filled: 0 }; insert(order); levelDelta(order, count); return order.id; },
    /** Someone else's marketable order: buy `count` of `side` at up to `limitCents`; returns the contracts matched. */
    take(ticker, side, limitCents, count) { expire(); return match(ticker, side, limitCents, count); },
    /** Settle a market: every position is paid and every resting order on it cancelled. */
    settle(ticker, yes) {
      for (const side of ['yes', 'no']) for (const order of [...bookOf(ticker)[side]]) cancel(order, 'SettlementBoundsCancel');
      for (const account of accounts.values()) {
        const n = account.positions.get(ticker); if (!n) continue;
        if ((n > 0) === yes) account.cash += 100 * Math.abs(n);
        account.positions.delete(ticker); positionTold(account, ticker);
      }
    },
    expire,
    account: (apiKeyId) => accounts.get(apiKeyId),
    book: (ticker) => bookOf(ticker),
  });
}

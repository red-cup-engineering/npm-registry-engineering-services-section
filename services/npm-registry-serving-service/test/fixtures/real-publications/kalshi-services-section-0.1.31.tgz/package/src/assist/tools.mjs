import {assistOperation} from '@red-cup-engineering/personal-intelligence-systems-services-section/tools';
import {createPersonKalshiReader} from './account.mjs';
import {createAssistPersonWorkBroker} from '@red-cup-engineering/assist/person-work';

const empty={type:'object',additionalProperties:false,properties:{}};
const cursor={type:'object',additionalProperties:false,properties:{cursor:{type:'string',maxLength:2048},limit:{type:'integer',minimum:1,maximum:50}}};
const statement={type:'string',minLength:1,maxLength:400};
const requirement={type:'object',required:['says','class','priority'],additionalProperties:false,properties:{id:{type:'string',maxLength:128},says:statement,class:{enum:['functional','quality','constraint','interface']},priority:{enum:['must','should','could','wont']},rationale:statement}};
const condition={type:'object',required:['says','method'],additionalProperties:false,properties:{id:{type:'string',maxLength:128},says:statement,verifies:{type:'array',maxItems:16,items:{type:'string',maxLength:128}},method:{enum:['test','analysis','inspection','demonstration']}}};
export const workParameters={type:'object',required:['need'],additionalProperties:false,properties:{need:statement,requirements:{type:'array',maxItems:16,items:requirement},conditions:{type:'array',maxItems:16,items:condition},scope:{type:'array',minItems:1,maxItems:16,uniqueItems:true,items:{type:'string',maxLength:1024}}}};

async function observed(ctx,kind,args,data){
 // This is a Person-scoped derived observation, not a replacement for venue
 // bytes. Response receipts preserve original hashes and availability clocks.
 const bodyJson=JSON.stringify(data);
 if(new TextEncoder().encode(bodyJson).byteLength>49152)throw new RangeError('observation exceeds the private record allocation; request a smaller account page');
 await ctx.store.saveObservation({principalId:ctx.principal.id,kind,path:`kalshi:${kind}`,paramsJson:JSON.stringify(args),status:200,bodyJson,recordedAt:ctx.now(),expiresAt:ctx.now()+60000});
 return {data,observations:[{type:'KalshiPersonObservation',kind,recordedAt:new Date(ctx.now()).toISOString(),receipts:data.receipts??[],tradeAuthority:false}]};
}
const reader=async ctx=>createPersonKalshiReader({secret:await ctx.credential(),fetchImpl:ctx.fetchImpl,now:ctx.now});
export function createKalshiAssistTools(){return [
 assistOperation({id:'account_connection',description:'Read whether this Person has a sealed Kalshi connection, without opening the key or querying the venue. This does not claim current venue usability.',parameters:empty,effects:['private-data-read'],handler:async(ctx)=>{
  const row=await ctx.store.getCredential({principalId:ctx.principal.id,provider:'kalshi'});
  return {data:{connected:Boolean(row),connectionNotice:row?'A key is sealed to your identity. Account reads establish its current usability; replace or disconnect it here.':'No Kalshi key is sealed for your identity.'},observations:[]};
 }}),
 assistOperation({id:'account_overview',description:'Read this Person’s connected Kalshi cash, marks, first 25-row active-position and resting-order pages. It is not a historical or atomic account close.',parameters:empty,effects:['network-read','private-observation-write'],handler:async(ctx,args)=>observed(ctx,'account-overview',args,await(await reader(ctx)).overview())}),
 ...['positions','orders'].map(kind=>assistOperation({id:`account_${kind}`,description:`Read one bounded ${kind==='positions'?'active-position':'resting-order'} page for this Person’s sealed account. Follow the returned cursor explicitly; no historical coverage.`,parameters:cursor,effects:['network-read','private-observation-write'],handler:async(ctx,args)=>observed(ctx,`account-${kind}`,args,await(await reader(ctx)).page(kind,args.cursor,args.limit))})),
 assistOperation({id:'study_market',description:'Read exact public market/event rules, settlement sources, observed current fees and 25 bid levels per side. No forecast, profit, order authority or lasting quote validity is implied.',parameters:{type:'object',required:['ticker'],additionalProperties:false,properties:{ticker:{type:'string',pattern:'^[A-Z0-9][A-Z0-9_-]{0,119}$'}}},effects:['network-read','private-observation-write'],handler:async(ctx,args)=>observed(ctx,'market-study',args,await createPersonKalshiReader({secret:null,fetchImpl:ctx.fetchImpl,now:ctx.now}).market(args.ticker))}),
 assistOperation({id:'request_improvement_work',description:'Request a strategy or upstream improvement outcome through the installed native governed broker as this Person’s outside party. It enters the shared board: never include credentials, balances, positions or other private account facts. Native legality, staffing and progress determine the actual returned receipt.',parameters:workParameters,effects:['native-work-request','private-observation-write'],handler:async(ctx,args)=>{
  const broker=createAssistPersonWorkBroker({app:'kalshi-assist',principal:ctx.principal,secret:ctx.capabilities.SESSION_SECRET,allowedScopes:ctx.allowedWorkScopes,runAs:ctx.runAs});
  const data=await broker.submit(args);
  // Preserve the native reply for the caller. The private receipt references
  // only the request and native disposition; it never substitutes a queued claim.
  const receivedAt=new Date(ctx.now()).toISOString(),bytes=new TextEncoder().encode(JSON.stringify(data));
  const digest=await crypto.subtle.digest('SHA-256',bytes),nativeReplySha256='sha256:'+Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join('');
  const receipt={receivedAt,nativeReplySha256,nativeReplyBytes:bytes.byteLength,...(bytes.byteLength<=45056?{nativeReply:data}:{nativeReplyOmitted:'exceeds private receipt allocation; caller receives unchanged native reply'})};
  let privateReceiptRecorded=true;
  try{await ctx.store.saveObservation({principalId:ctx.principal.id,kind:'work-request',path:'native:work-open',paramsJson:JSON.stringify(args),status:200,bodyJson:JSON.stringify(receipt),recordedAt:ctx.now(),expiresAt:null});}
  catch{privateReceiptRecorded=false;} // Never hide an already-issued native reply behind a subsequent bookkeeping failure.
  return {data,observations:[{type:'NativePersonWorkReply',receivedAt,nativeReplySha256,privateReceiptRecorded,outsideParty:true,executionAuthority:false}]};
 }}),
 ];}

/** Person-bound read adapter over the canonical venue client. There is no
 * process credential fallback, venue write method, or account authority here. */
import {createKalshiClient} from '../client.mjs';
import {readBody} from '@red-cup-engineering/http-services-section/body/web';
import {defineType,admit} from '@red-cup-engineering/signcell/type-system';
import {readWeatherParticipationFees} from '@red-cup-engineering/forecasting/weather-participation';
import feed from '../../content/config/feed.json' with {type:'json'};

const credentialSchema={type:'object',required:['keyId','privateKeyPem','environment'],additionalProperties:false,properties:{keyId:{type:'string',minLength:1,maxLength:128,pattern:'^[A-Za-z0-9_-]+$'},privateKeyPem:{type:'string',minLength:64,maxLength:16384,pattern:'^-----BEGIN PRIVATE KEY-----'},environment:{enum:['production','demo']},subaccount:{type:'integer',minimum:0,maximum:63}}};
const definition=defineType({id:'kalshi.assist.credential',name:'kalshi.assist.credential',description:'One Person-owned venue key and exact environment; no household account fallback.',parents:[],schema:credentialSchema});
if(!definition.ok)throw new TypeError('cannot define Kalshi account credential');
export function admitKalshiCredential(input){const result=admit(definition.value,input);if(!result.ok)throw new TypeError('a bounded PKCS#8 key, key ID, production/demo environment and optional subaccount 0..63 are required');return result.value;}
const fixed=value=>typeof value==='string'&&/^-?\d+(?:\.\d{1,4})?$/u.test(value)&&Number.isFinite(Number(value))?value:null;
const numeric=value=>fixed(value)===null?null:Number(value);
const cents=value=>Number.isSafeInteger(value)?value/100:null;
const stamp=now=>new Date(now()).toISOString();
const tickerPattern=/^[A-Z0-9][A-Z0-9_-]{0,119}$/u;
export function admitTicker(value){if(typeof value!=='string'||!tickerPattern.test(value))throw new TypeError('one exact market ticker is required');return value;}
const cursorOf=value=>{if(value===undefined||value===null||value==='')return '';if(typeof value!=='string'||value.length>2048||/[\u0000-\u001f\u007f]/u.test(value))throw new TypeError('invalid venue cursor');return value;};

export function createPersonKalshiReader({secret=null,fetchImpl,now=Date.now}={}){
 const selected=secret===null?null:admitKalshiCredential(secret),receipts=[];
 if(typeof fetchImpl!=='function')throw new TypeError('request-owned budgeted fetch required');
 const client=createKalshiClient({credentials:selected?{apiKeyId:selected.keyId,privateKeyPem:selected.privateKeyPem}:null,baseUrl:selected?.environment==='demo'?feed.demo:feed.base,retries429:0,fetchImpl:async(url,options)=>{
  const response=await fetchImpl(url,options);
  // Fetch bodies are already decoded. The shared streaming receiver bounds
  // memory before buffering; retain the exact decoded response bytes.
  let bytes;try{bytes=await readBody({body:response.body,headers:response.headers,signal:options.signal},{maxBytes:32768,maxEncodedBytes:32768,contentEncoding:'identity'});}catch(error){if(error.code==='body-too-large')throw new Error('kalshi-response-byte-allocation-exceeded');throw error;}
  const receivedAt=stamp(now),digest=await crypto.subtle.digest('SHA-256',bytes);
  receipts.push({path:new URL(url).pathname,query:new URL(url).search,status:response.status,receivedAt,sourceSha256:'sha256:'+Array.from(new Uint8Array(digest),b=>b.toString(16).padStart(2,'0')).join(''),sourceBytes:bytes.byteLength});
  return new Response(bytes,{status:response.status,statusText:response.statusText,headers:{'content-type':'application/json'}});
 }});
 const query={...(selected?.subaccount===undefined?{}:{subaccount:selected.subaccount})};
 const get=async(path,params={},signed=true)=>{
  try{const body=await client.call('GET',path,{query:params,signed});if(!body||typeof body!=='object'||Array.isArray(body))throw new TypeError('invalid venue response');return body;}
  catch(error){if(error.detail==='kalshi-response-byte-allocation-exceeded')throw new Error('Kalshi response exceeds the 32 KiB allocation; request a smaller account page limit');throw new Error(error.status?`Kalshi read refused (${error.status}); check the connected key's read scopes and environment`:'Kalshi read failed; no venue write was attempted');}
 };
 async function page(kind,cursor='',limit=25){
  if(!Number.isSafeInteger(limit)||limit<1||limit>50)throw new TypeError('account page allocation is 1..50 rows');
  if(!selected)throw new Error('connect your own Kalshi read key first');
  const path=kind==='positions'?'/portfolio/positions':'/portfolio/orders',key=kind==='positions'?'market_positions':'orders',start=cursorOf(cursor);
  const packet=await get(path,{...query,limit,...(kind==='positions'?{settlement_status:'unsettled',count_filter:'position'}:{status:'resting'}),...(start?{cursor:start}:{})});
  if(!Array.isArray(packet[key])||packet[key].length>limit)throw new TypeError('bounded venue account page required');
  const next=cursorOf(packet.cursor);if(next&&next===start)throw new TypeError('nonadvancing venue cursor');
  const rows=packet[key].map(row=>kind==='positions'?{
   ticker:admitTicker(row.ticker),exchangeIndex:row.exchange_index??null,quantity:fixed(row.position_fp),exposureExactUsd:fixed(row.market_exposure_dollars),exposureUsd:numeric(row.market_exposure_dollars),realizedPnlExactUsd:fixed(row.realized_pnl_dollars),realizedPnlUsd:numeric(row.realized_pnl_dollars),feesExactUsd:fixed(row.fees_paid_dollars),feesUsd:numeric(row.fees_paid_dollars),updatedAt:row.last_updated_ts??null,
  }:{ticker:admitTicker(row.ticker),id:typeof row.order_id==='string'?row.order_id:null,side:row.outcome_side??row.side??null,bookSide:row.book_side??null,remaining:fixed(row.remaining_count_fp),priceExactUsd:fixed((row.outcome_side??row.side)==='no'?row.no_price_dollars:row.yes_price_dollars),priceUsd:numeric((row.outcome_side??row.side)==='no'?row.no_price_dollars:row.yes_price_dollars),status:row.status??null,venueUserId:typeof row.user_id==='string'?row.user_id:null});
  return {rows,cursor:next,coverage:{limit,fromStart:!start,complete:!start&&!next,atomicSnapshot:false,allExchangeShards:true,subaccount:selected.subaccount??0,historicalCoverage:false},receipts:receipts.slice()};
 }
 async function overview(){
  if(!selected)return {connected:false,positions:[],orders:[],notices:['Your private Person workspace has no connected Kalshi key. Public market study remains available.']};
  const balance=await get('/portfolio/balance',query),balanceAt=receipts.at(-1).receivedAt;
  if(balance.balance_dollars!==undefined&&fixed(balance.balance_dollars)===null)throw new TypeError('invalid fixed-point venue cash');
  if(cents(balance.portfolio_value)===null||(balance.balance_dollars===undefined&&cents(balance.balance)===null))throw new TypeError('valid venue cash and marked-value fields required');
  const positions=await page('positions'),orders=await page('orders');
  return {connected:true,environment:selected.environment,subaccount:selected.subaccount??0,cashExactUsd:fixed(balance.balance_dollars),cashUsd:numeric(balance.balance_dollars)??cents(balance.balance),portfolioValueUsd:cents(balance.portfolio_value),venueBalanceUpdatedAt:balance.updated_ts??null,observedAt:balanceAt,positions:positions.rows,orders:orders.rows,positionCursor:positions.cursor,orderCursor:orders.cursor,positionCoverage:positions.cursor?'First 25 active positions; more pages remain. Use account_positions with the returned cursor.':'Active positions only; no historical settled coverage. Reading is not an atomic account close.',orderCoverage:orders.cursor?'First 25 resting orders; more pages remain. Use account_orders with the returned cursor.':'Resting orders only; completed and historical orders are outside this reading.',receipts:receipts.slice(),notices:['Cash, position marks, active realized P&L and fees have separate meanings. This view does not establish lifetime account profit.','Response clocks and venue update clocks are separate. No automatic order placement or strategy admission is granted.']};
 }
 async function market(ticker){
  admitTicker(ticker);
  const packet=await get(`/markets/${ticker}`,{},false),market=packet.market;if(market?.ticker!==ticker)throw new TypeError('market source scope mismatch');
  const eventTicker=admitTicker(market.event_ticker),eventPacket=await get(`/events/${eventTicker}`,{},false),event=eventPacket.event;
  if(event?.event_ticker!==eventTicker)throw new TypeError('event source scope mismatch');const seriesTicker=admitTicker(event.series_ticker);
  const publicClient={getSeries:async id=>(await get(`/series/${admitTicker(id)}`,{},false)).series,call:async(method,path,options)=>{if(method!=='GET'||path!=='/events/fee_changes'||options?.signed!==false)throw new TypeError('public fee read only');return get(path,options.query,false);}};
  let fees,feeUnavailable=false;try{fees=await readWeatherParticipationFees(publicClient,{seriesTicker,event_ticker:eventTicker});}catch{feeUnavailable=true;}
  const bookPacket=await get(`/markets/${ticker}/orderbook`,{depth:25},false),book=bookPacket.orderbook_fp;
  if(!book||!Array.isArray(book.yes_dollars)||!Array.isArray(book.no_dollars))throw new TypeError('fixed-point orderbook evidence required');
  for(const side of ['yes_dollars','no_dollars'])if(book[side].length>25||book[side].some(row=>!Array.isArray(row)||row.length!==2||fixed(row[0])===null||fixed(row[1])===null||Number(row[0])<0||Number(row[0])>1||Number(row[1])<0))throw new TypeError('bounded valid depth required');
  const observedAt=receipts.at(-1).receivedAt,close=Date.parse(market.close_time),expires=Math.min(Date.parse(observedAt)+60000,Number.isFinite(close)?close:0,fees?.nextFeeChangeAt?Date.parse(fees.nextFeeChangeAt):Infinity);
  return {ticker,eventTicker,seriesTicker,title:market.title??ticker,yesSubtitle:market.yes_sub_title??null,noSubtitle:market.no_sub_title??null,status:market.status,marketType:market.market_type??null,notionalValueExactUsd:fixed(market.notional_value_dollars),closeTime:market.close_time??null,settlementTimerSeconds:market.settlement_timer_seconds??null,rulesPrimary:market.rules_primary??null,rulesSecondary:market.rules_secondary??null,settlementSources:event.settlement_sources??fees?.rawSeries.settlement_sources??[],feeTerms:fees?{available:true,type:fees.effective.fee_type,multiplier:fees.effective.fee_multiplier,nextChangeAt:fees.nextFeeChangeAt,seriesReceivedAt:fees.seriesReceivedAt}:{available:false,reason:'Current supported fee context could not be established; contract and depth evidence remain readable, price/alpha assessment is unavailable'},orderbook:book,observedAt,expiresAt:Number.isFinite(expires)?new Date(expires).toISOString():null,expired:feeUnavailable||market.status!=='active'||expires<=now(),receipts:receipts.slice(),notices:['Displayed bid depth can disappear before execution. Opposite-side bids imply offers only for the observed binary contract.','Fee terms are the observed series plus event override; charged fees depend on execution and current canonical rounding. Your account-specific fee rounding grid requires evidence; the house direct-member grid is not assumed for other Persons. No calibrated forecast or alpha is implied.'],tradeAuthority:false};
 }
 return Object.freeze({overview,page,market,receipts:()=>receipts.slice()});
}

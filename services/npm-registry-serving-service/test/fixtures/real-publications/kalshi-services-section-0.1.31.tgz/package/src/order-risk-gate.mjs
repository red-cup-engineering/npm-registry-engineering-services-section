/**
 * The order risk gate: the controls every venue write passes before the client sends it. They are the
 * erroneous-order and capital-threshold controls SEC Rule 15c3-5 requires of anyone with market access,
 * and FIA's per-order, per-instrument and loss-limit controls with a kill switch. The gate is independent
 * of every strategy: it reads the account from the venue, never from the desk that wants to trade, so a
 * desk whose model is wrong cannot argue its way past it.
 *
 * Contract.
 * - A cancel (any DELETE, a decrease, or an order group trigger) is always admitted: it only reduces risk.
 * - Nothing else is admitted while the latch is set. The latch is a file in the section's state. It
 *   survives restarts and binds every process and account on the host, because what trips it is the
 *   code, not one account. A latch that cannot be read counts as set.
 * - An order or amend (V2: `side` bid buys YES at `price`, ask sells YES, which is buying NO at 1 - price)
 *   is admitted only if
 *     1. the account's loss since this release first traded it, net of deposits and withdrawals, is at
 *        most `lossFraction` of the account value at that start;
 *     2. its worst-case loss (bid: price x count; ask: (1 - price) x count) is at most
 *        `orderLossFraction` of the account value;
 *     3. the event's position cost, plus its resting orders' worst-case loss, plus this order's, is at
 *        most `eventLossFraction` of the account value.
 *   Account value is the venue's cash plus its marked portfolio value.
 * - Before any of that, the account's books must agree with the venue: `venue.books()` is the double-entry
 *   ledger derived from the venue's own records (src/kalshi-ledger.mjs) reconciled against its balance and
 *   positions. A break refuses the order without tripping: it is a books fault, not a loss.
 * - Failing 1 or 2 trips the latch: the gate cancels every resting desk order on the account (client
 *   order ID prefix `kd-`; a person's own orders carry none and are never touched) and refuses
 *   everything but cancels until a repaired release clears the trip: a release other than the one that
 *   tripped, whose limits list the trip's `id` in `clears`. Failing 3 refuses the order without tripping:
 *   it is the ordinary bound on one event.
 * - Order-group writes are admitted while the latch is not set. A write the gate does not know is refused.
 * - Anything the gate cannot establish (an unreadable latch or baseline, a venue read that fails, a
 *   malformed order) refuses the write.
 */
import { join } from 'node:path';
import { readFileText } from '@red-cup-engineering/computer-file-engineering-services-section/read-file';
import { writeFileText } from '@red-cup-engineering/computer-file-engineering-services-section/write-file';

export const DESK_ORDER_PREFIX = 'kd-';
const ORDER = /^\/portfolio\/events\/orders(?:\/([^/]+)\/amend)?$/u;
const DECREASE = /^\/portfolio\/(?:events\/)?orders\/[^/]+\/decrease$/u;
const TRIGGER = /^\/portfolio\/order_groups\/[^/]+\/trigger$/u;
const ORDER_GROUP = /^\/portfolio\/order_groups\/(?:create|[^/]+\/(?:limit|reset))$/u;
const ADMIT = Object.freeze({ admit: true });

const number = (value, label) => {
  const n = Number(value);
  if (value === null || value === undefined || value === '' || !Number.isFinite(n)) throw new TypeError(`${label} is not a number`);
  return n;
};
/** A market ticker's event: the ticker without its last `-` segment. */
export const eventOf = (ticker) => (ticker.includes('-') ? ticker.slice(0, ticker.lastIndexOf('-')) : ticker);
/** The most an order can lose, in dollars: a bid pays its price, an ask (long NO) pays one minus it. */
export const worstCaseLoss = ({ side, price, count }) => (side === 'bid' ? price : 1 - price) * count;
/** A resting order row's worst-case loss; rows without `book_side` are read in the legacy action/side shape. */
function restingLoss(row) {
  const bookSide = row.book_side ?? (((row.action ?? 'buy') === 'buy') === (row.side === 'yes') ? 'bid' : 'ask');
  return worstCaseLoss({ side: bookSide, price: number(row.yes_price_dollars, 'resting yes_price_dollars'), count: number(row.remaining_count_fp ?? row.remaining_count, 'resting remaining count') });
}

/** The latch and the baseline of one account, under the section's state directory. */
export const orderRiskPaths = ({ hostStateDirectory, accountStateDirectory }) => ({
  latchPath: join(hostStateDirectory, 'latch.json'),
  baselinePath: join(accountStateDirectory, 'baseline.json'),
});

/**
 * @param {{latchPath: string, baselinePath: string, release: string, accountId: string,
 *   limits: {orderLossFraction: number, eventLossFraction: number, lossFraction: number,
 *            accountValueMaxAgeMs: number, transfersMaxAgeMs: number, clears?: string[]},
 *   venue: {books: () => Promise<{admit: boolean, code?: string, detail?: string}>, balance: () => Promise<object>, positions: (event: string) => Promise<object[]>,
 *           restingOrders: (event?: string) => Promise<object[]>, deposits: () => Promise<object[]>,
 *           withdrawals: () => Promise<object[]>, cancel: (orderId: string, ticker: string) => Promise<unknown>},
 *   clock?: () => number}} options
 */
export function createOrderRiskGate({ latchPath, baselinePath, release, accountId, limits, venue, clock = () => Date.now() }) {
  for (const key of ['orderLossFraction', 'eventLossFraction', 'lossFraction'])
    if (!(limits?.[key] > 0 && limits[key] <= 1)) throw new TypeError(`order risk limit ${key} must be in (0, 1]`);
  const cached = { value: null, transfers: null, books: null };
  const fresh = (entry, maxAgeMs) => entry && clock() - entry.at <= maxAgeMs;

  async function readJson(path) {
    try { return JSON.parse(await readFileText(path)); }
    catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  }
  const writeJson = (path, value) => writeFileText(path, `${JSON.stringify(value, null, 2)}\n`);

  async function openLatch() {
    let latch;
    try { latch = await readJson(latchPath); }
    catch (error) { return { id: 'latch-unreadable', trippedAt: null, reason: `the latch at ${latchPath} cannot be read (${error.message})` }; }
    if (!latch) return null;
    return latch.release !== release && (limits.clears ?? []).includes(latch.id) ? null : latch;
  }

  async function accountValue() {
    if (fresh(cached.value, limits.accountValueMaxAgeMs)) return cached.value.amount;
    const balance = await venue.balance();
    const cash = balance.balance_dollars !== undefined ? number(balance.balance_dollars, 'balance_dollars') : number(balance.balance, 'balance') / 100;
    const amount = cash + number(balance.portfolio_value, 'portfolio_value') / 100;
    cached.value = { at: clock(), amount };
    return amount;
  }
  async function netTransfers() {
    if (fresh(cached.transfers, limits.transfersMaxAgeMs)) return cached.transfers.amount;
    const applied = (rows) => rows.filter((row) => row.status === 'applied').reduce((sum, row) => sum + number(row.amount_cents, 'transfer amount_cents') / 100, 0);
    const [deposits, withdrawals] = await Promise.all([venue.deposits(), venue.withdrawals()]);
    const amount = applied(deposits) - applied(withdrawals);
    cached.transfers = { at: clock(), amount };
    return amount;
  }
  async function booksAgree() {
    if (fresh(cached.books, limits.booksMaxAgeMs ?? 0)) return cached.books.verdict;
    const verdict = await venue.books();
    cached.books = { at: clock(), verdict };
    return verdict;
  }
  /** The account's loss since this release first traded it, net of money moved in and out. */
  async function lossSinceBaseline(value) {
    const transfers = await netTransfers();
    let baseline = await readJson(baselinePath);
    if (!baseline || baseline.release !== release) {
      baseline = { release, accountId, at: new Date(clock()).toISOString(), accountValue: value, netTransfers: transfers };
      await writeJson(baselinePath, baseline);
    }
    return { loss: (baseline.accountValue - baseline.netTransfers) - (value - transfers), baseline };
  }

  async function trip(reason, detail) {
    const trippedAt = new Date(clock()).toISOString();
    const latch = { id: `${trippedAt.replace(/\D/gu, '').slice(0, 14)}-${reason}`, trippedAt, release, accountId, reason, detail };
    await writeJson(latchPath, latch);
    const cancelled = [], failed = [];
    try {
      for (const order of await venue.restingOrders()) {
        if (!String(order.client_order_id ?? '').startsWith(DESK_ORDER_PREFIX)) continue;
        try { await venue.cancel(order.order_id, order.ticker); cancelled.push(order.order_id); }
        catch (error) { failed.push({ orderId: order.order_id, error: error.message }); }
      }
    } catch (error) { failed.push({ orderId: null, error: `resting orders unreadable: ${error.message}` }); }
    await writeJson(latchPath, { ...latch, cancelled, failed });
    return { admit: false, code: 'risk-tripped', latch: latch.id,
      detail: `${detail}. Trading is latched (${latch.id}) until a repaired release clears it; ${cancelled.length} desk orders cancelled, ${failed.length} cancels failed` };
  }
  const refuse = (code, detail) => ({ admit: false, code, detail });

  async function check(method, apiPath, body) {
    if (method === 'DELETE' || (method === 'POST' && (DECREASE.test(apiPath) || TRIGGER.test(apiPath)))) return ADMIT;
    const latch = await openLatch();
    if (latch) return refuse('risk-latched', `trading is latched (${latch.id}, ${latch.trippedAt ?? 'unknown time'}): ${latch.reason}; a repaired release must clear it`);
    if (ORDER_GROUP.test(apiPath) && (method === 'POST' || method === 'PUT')) return ADMIT;
    const match = method === 'POST' ? ORDER.exec(apiPath) : null;
    if (!match) return refuse('risk-unknown-write', `${method} ${apiPath} is not a write the order risk gate knows`);
    const amendedOrderId = match[1] ?? null;
    const { ticker, side } = body ?? {};
    let price, count;
    try { price = number(body?.price, 'price'); count = number(body?.count, 'count'); } catch (error) { return refuse('risk-order-malformed', error.message); }
    if (typeof ticker !== 'string' || !ticker || (side !== 'bid' && side !== 'ask') || !(price > 0 && price < 1) || !(count > 0))
      return refuse('risk-order-malformed', 'an order needs a ticker, side bid or ask, a price strictly between 0 and 1 and a positive count');

    const books = await booksAgree();
    if (!books.admit) return refuse(books.code ?? 'ledger-break', books.detail ?? 'the books do not agree with the venue');
    const value = await accountValue();
    const { loss, baseline } = await lossSinceBaseline(value);
    if (loss > limits.lossFraction * baseline.accountValue)
      return trip('loss-limit', `account ${accountId} lost $${loss.toFixed(2)} since ${baseline.at}, over ${limits.lossFraction} of its $${baseline.accountValue.toFixed(2)} value then`);
    const orderLoss = worstCaseLoss({ side, price, count });
    if (orderLoss > limits.orderLossFraction * value)
      return trip('order-over-limit', `${ticker} ${side} ${count} at ${price} can lose $${orderLoss.toFixed(2)}, over ${limits.orderLossFraction} of account ${accountId}'s $${value.toFixed(2)} value`);
    const event = eventOf(ticker);
    const [positions, resting] = await Promise.all([venue.positions(event), venue.restingOrders(event)]);
    const positionCost = positions.reduce((sum, row) => sum + Math.abs(number(row.market_exposure_dollars ?? 0, 'market_exposure_dollars')), 0);
    const restingCost = resting.filter((row) => row.order_id !== amendedOrderId).reduce((sum, row) => sum + restingLoss(row), 0);
    if (positionCost + restingCost + orderLoss > limits.eventLossFraction * value)
      return refuse('risk-event-limit', `event ${event} would carry $${(positionCost + restingCost + orderLoss).toFixed(2)} at risk, over ${limits.eventLossFraction} of account ${accountId}'s $${value.toFixed(2)} value`);
    return ADMIT;
  }

  return Object.freeze({
    /** The gate's verdict on one venue write: `{admit: true}` or `{admit: false, code, detail}`. */
    async admit({ method, apiPath, body }) {
      try { return await check(method, apiPath, body); }
      catch (error) { return refuse('risk-unestablished', `the order risk gate could not establish the account (${error.message})`); }
    },
  });
}

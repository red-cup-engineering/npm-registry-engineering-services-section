/**
 * Settlement sources: what Kalshi settles on, which of those the firm can read, and how a reading enters
 * the firm as evidence. Pure.
 *
 * Every Kalshi series names its settlement sources in free text ("the Associated Press", "AP", "ESPN").
 * `normalizeSource` folds those spellings to one source id. A source is *read* by an adapter (the
 * registry below): a public, permitted feed or API, acquired by AOE communicating's newswire for RSS/Atom
 * or by a source-specific acquisition. A parser is a one-time cost and pays for as long as every series on
 * that source stays listed, so `coverage` ranks sources by the open volume that settles on them and marks
 * which are read.
 *
 * A reading is admitted the way the newswire admits a feed item: a SignCell utterance (the source, and
 * what was observed) projected through communicating's CloudEvents carrier, with a deduplication key that
 * two observations of the same item share, so a replayed acquisition admits nothing twice. These
 * arrivals are the arena's nature moves for the markets that settle on that source: the generators whose
 * admission time the generator-lag experiments measure against the market.
 */
import { mark, utterance } from '@red-cup-engineering/signcell/utterance';
import { cloudEventFromUtterance } from '@red-cup-engineering/communicating/messaging/cloudevents';
import { hashPosition } from '@red-cup-engineering/gaming/running/rules';

/** Spellings Kalshi uses for one source, after lowercasing and dropping a leading "the". */
const ALIASES = new Map(Object.entries({
  'kalshi weather index': 'kalshi-weather-index',
  ap: 'associated press', 'associated press': 'associated press',
  'wall street journal': 'wall street journal', wsj: 'wall street journal',
  'new york times': 'new york times', nyt: 'new york times',
  'washington post': 'washington post', abc: 'abc news', 'abc news': 'abc news', cbs: 'cbs news', 'cbs news': 'cbs news',
  'fox news': 'fox news', 'fox sports': 'fox sports', 'governing league': 'governing league',
}));
/** Fragments of Kalshi's rule text that are not sources (a list's lead-in captured as an item). */
const NOT_SOURCES = [/^source agencies are$/u, /^in hierarchical order/u];

/** One source id for a Kalshi settlement-source spelling, or null for a non-source fragment. */
export function normalizeSource(name) {
  const s = String(name ?? '').toLowerCase().normalize('NFKC').replace(/\s+/gu, ' ').trim().replace(/^the /u, '').replace(/[.,;:]+$/u, '');
  if (!s || NOT_SOURCES.some((re) => re.test(s))) return null;
  return ALIASES.get(s) ?? s;
}

/**
 * Adapters the firm runs, by source id. kind 'rss' feeds are acquired by communicating's newswire
 * (`admitSetOfFeedArrivals`); other kinds name the acquisition module that reads them.
 */
export const ADAPTERS = Object.freeze([
  { source: 'kalshi-weather-index', kind: 'weather-index', module: '@red-cup-engineering/forecasting/weather-index' },
  { source: 'espn', kind: 'espn-scoreboard', module: '@red-cup-engineering/forecasting/sport-feeds' },
  // RSS/Atom verified live 2026-10-04 (WSJ's public feeds stopped in Jan 2025; Axios 403; Reuters forbids
  // automated collection; AP and Politico block; White House has no feed)
  { source: 'new york times', kind: 'rss', feeds: [{ id: 'nyt-home', url: 'https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml' }, { id: 'nyt-politics', url: 'https://rss.nytimes.com/services/xml/rss/nyt/Politics.xml' }] },
  { source: 'washington post', kind: 'rss', feeds: [{ id: 'wapo-politics', url: 'https://feeds.washingtonpost.com/rss/politics' }, { id: 'wapo-world', url: 'https://feeds.washingtonpost.com/rss/world' }] },
  { source: 'cbs news', kind: 'rss', feeds: [{ id: 'cbs-main', url: 'https://www.cbsnews.com/latest/rss/main' }] },
  { source: 'msnbc', kind: 'rss', feeds: [{ id: 'msnbc', url: 'https://www.msnbc.com/feed' }] },
  { source: 'abc news', kind: 'rss', feeds: [{ id: 'abc-top', url: 'https://abcnews.go.com/abcnews/topstories' }] },
  { source: 'fox news', kind: 'rss', feeds: [{ id: 'fox-latest', url: 'https://moxie.foxnews.com/google-publisher/latest.xml' }, { id: 'fox-politics', url: 'https://moxie.foxnews.com/google-publisher/politics.xml' }] },
  { source: 'semafor', kind: 'rss', feeds: [{ id: 'semafor', url: 'https://www.semafor.com/rss.xml' }] },
  { source: 'information', kind: 'rss', feeds: [{ id: 'the-information', url: 'https://www.theinformation.com/feed', kind: 'atom' }] },
  { source: 'federal register', kind: 'rss', feeds: [{ id: 'federal-register', url: 'https://www.federalregister.gov/api/v1/documents.rss' }] },
]);

/** Every RSS/Atom feed of the registry, in the newswire's `{ id, url, kind }` form. */
export const rssFeeds = (adapters = ADAPTERS) => adapters.filter((a) => a.kind === 'rss').flatMap((a) => a.feeds.map((f) => ({ id: f.id, url: f.url, kind: f.kind ?? 'rss', source: a.source })));

export const adapterFor = (source) => ADAPTERS.find((a) => a.source === source) ?? null;

/**
 * Coverage of open volume by read sources. `index` is the catalog's settlementIndex:
 * [{ source, series, openMarkets, openVolume }] with raw Kalshi spellings.
 */
export function coverage(index, adapters = ADAPTERS) {
  const by = new Map();
  for (const row of index) {
    const id = normalizeSource(row.source); if (!id) continue;
    const s = by.get(id) ?? by.set(id, { source: id, spellings: new Set(), series: 0, openMarkets: 0, openVolume: 0 }).get(id);
    s.spellings.add(row.source); s.series += row.series; s.openMarkets += row.openMarkets; s.openVolume += row.openVolume;
  }
  const read = new Set(adapters.map((a) => a.source));
  const rows = [...by.values()].map((s) => ({ ...s, spellings: [...s.spellings], read: read.has(s.source) })).sort((a, b) => b.openVolume - a.openVolume);
  const total = rows.reduce((t, r) => t + r.openVolume, 0);
  const covered = rows.filter((r) => r.read).reduce((t, r) => t + r.openVolume, 0);
  return { rows, openVolume: total, coveredVolume: covered, coveredFraction: total ? covered / total : 0 };
}

/** The key two observations of one source item share, whenever they were made. */
export const observationKey = (source, externalId) => hashPosition({ source, externalId });

/**
 * A settlement-source reading as a CloudEvents arrival: the utterance (source url, {source, externalId,
 * value}) with its deduplication key. `value` is the adapter's typed reading (a score, a release value,
 * a headline).
 */
export function sourceObservation({ source, url, externalId, value, observedAt }) {
  const key = observationKey(source, externalId);
  return cloudEventFromUtterance(utterance(mark(url), mark({ source, externalId, value, deduplicationKey: key })), 'assertive', observedAt, { id: `${key}@${observedAt}` });
}

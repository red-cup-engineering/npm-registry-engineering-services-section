import { schemaFrom } from "@red-cup-engineering/json-schema-services-section/contracts";

const paging = {
  offset: { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
  limit: { type: "integer", minimum: 1, maximum: 100 },
  sourceRevision: { type: "string", minLength: 1, maxLength: 160 },
};

export const weatherStatusPageRequestContract = schemaFrom({
  $id: "kalshi/weather/status-page-request",
  type: "object", additionalProperties: false,
  properties: { ...paging, field: { enum: ["contracts", "forecasts", "grades", "errors", "opportunities", "research", "scoring"] } },
});

export const weatherStationSkillPageRequestContract = schemaFrom({
  $id: "kalshi/weather/station-skill-page-request",
  type: "object", additionalProperties: false,
  properties: { ...paging,
    field: { enum: ["metrics", "comparisons", "parameters"] },
    station: { type: "string", pattern: "^([A-Z0-9]{4}|index:(miami|nyc|chicago|la-coastal))$" },
  },
});

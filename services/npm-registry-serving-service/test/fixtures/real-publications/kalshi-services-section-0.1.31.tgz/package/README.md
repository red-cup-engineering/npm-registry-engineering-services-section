# Kalshi services section

This is the 561 Group's Kalshi services section: package
`@red-cup-engineering/kalshi-services-section`, repository
`red-cup-engineering/kalshi-services-section`. **It runs on MetroPlat like
every other section, and it is served as the ASSIST instance
`kalshi.assist.561.group`.** ASSIST (`@red-cup-engineering/assist`) is the
shared engine for every "… Assist" app. This section supplies Kalshi's
parameterization of it and Kalshi's domain runtime. There is no separate
Kalshi stack, engine, server or timer system.

## Where it runs

Everything here is loaded into a MetroPlat instance's FeltOS host process
(today Cold Red Gate's), through two exports:

- **`./assist`**: the Kalshi ASSIST hosted application
  (`createKalshiAssistHostedApplication`). It covers:
  - invited Google sign-in;
  - each Person's own sealed Kalshi key;
  - account reading and market study;
  - the analyst loop and governed improvement work.

  A person's account joins by that Person connecting their key here. It does
  not join by hand-placed credential files or new job records.
- **`./operations`**: the Kalshi MetroPlat operation family
  (`kalshiOperations`). It covers market reads, order intents, the desk, and
  the forecasting and hypotheses it trades on. These run as operations the
  instance executes and schedules.

Market making belongs inside the instance, as part of these two exports. It
holds its venue connections while the instance runs and reacts to the market
and the weather as they change. It is not a periodic job, a side process or a
new engine.

Today the desk still runs as one node job per account every 60 seconds,
outside the instance process. That is the defect being replaced.

## What it owns and what it takes from upstream

It owns Kalshi domain knowledge:
- the venue client and accounts;
- the desk's planning and execution (`services/kalshi-stake-path-service`);
- the weather forecasting it trades on (`services/forecasting-service`,
  published as `@red-cup-engineering/forecasting`).

It parameterizes upstream capabilities and does not rewrite them:
- **Sizing and allocation:** prediction-market engineering's
  `mandate-portfolio-allocation-service` and `position-sizing-service`.
- **Presentation, work and governance:** ASSIST.
- **Identity, sealing, sessions, MCP and the analyst loop:** the Assist
  application engine (`personal-intelligence-systems-services-section`).
- **Operations, scheduling and hosting:** MetroPlat on FeltOS.

An uncertain order stays in durable custody. The desk recovers it by its
original client order ID before it may place another order.

Shared prediction-market research and cross-venue strategy are maintained in
[prediction-market engineering](https://github.com/red-cup-engineering/prediction-market-engineering-services-section).
[Polymarket](https://github.com/red-cup-engineering/polymarket-services-section)
is a separate venue section.

## Test

The package installs its exact house-registry closure from `package-lock.json`:

```sh
npm ci
npm test   # the root suite and the desk suite
```

A repository commit is not a deployment. Production credentials are in the
custody of the MetroPlat instance that runs this section. A source checkout
or a positive research calculation never authorizes an order.

## Canonical Kalshi catalog knowledge

The operational catalog's persistent feed now stores complete native
**SignCells as SCA-addressed SEN/SEAVT observations** through the existing
`seavtOfSignCell` provider. Replay restores original support/refutation
witnesses instead of replacing them with generic "read from log" testimony.
SCA coincidence and SignCell knowledge join preserve new witnesses even when
a field value does not change. Historical flat pseudo-mark rows remain readable
through an explicit on-read conversion; their lost original witnesses cannot
be reconstructed or silently claimed authentic. This is the SAME SEAVT store,
not an additional log or record format.

The forecasting section's read-only gas research now includes a
source-aligned AAA participation adapter, one joint scenario-price
distribution for the entire strike ladder, and an offline research
entrypoint:

    node apps/aaa-gas-study.mjs participation /path/to/sourced-packet.json
    node apps/aaa-gas-study.mjs pooled-fuel-fill /path/to/fill-grid-gas.csv

The second path is RETROSPECTIVE and pooled between AAA gasoline and
diesel, with no per-row event/date identity. It must never be
submitted to the upstream real-receipt fill calibrator as a prospective
gas-only model. The first path requires independent preissued
forecast/score, source-population, market-receipt and fill-model
evidence. A real fill study can be supplied only as a frozen upstream
one-contract order fit together with a later heldout day-block evaluation;
the shared calibration service checks its own receipt/score consistency
before the Kalshi adapter receives research-only hazard bounds. It still
does not place an order. Exact Kalshi fee handling
currently requires whole-cent one-lot quote prices in this research
adapter; any unsupported subcent quote is withheld, not treated as
fee-free. Liquidity incentive revenue is never claimed from an
unverified pool or one instantaneous book snapshot. The central
research doctrine is in the upstream prediction-market engineering
participation-science specification. No new commercial AAA
collection is deployed; licensed data rights remain a gate.

The `kalshi-research-candidates-rank` office command exposes source-aligned
research ranking to the seated CFO. Missing calibration remains research input,
not permission to trade.


## Retrieve the actual history before settling its mathematics

`createKalshiClient().getAccountingHistory({ticker,subaccount,from,to})`
now reads the SAME signed Kalshi API client across both `/portfolio` and
`/historical` order/fill endpoints as dictated by the exchange's public
`/historical/cutoff`. It paginates every route to an explicit empty cursor,
requires the cutoff to remain stable across the read, preserves the entire
finite window, and refuses duplicated, contradictory, cross-account, or
out-of-window economic events. It also reads the settled portfolio population.
The actual signed HTTP response bytes for every accounting page are now
retained **in memory**, along with their SHA-256, original URL and exact query.
The parsed rows and cursor are checked against those same bytes, so an
independent Operations source reader can re-hash original source material
rather than serialize a lossy reconstructed JSON object. Retaining original
bytes is not itself source authentication; the true custodian must still
validate publisher authority, full activity coverage and account identity.
This fixes earlier blind spots where `getOrders` and `getFills` returned
only arrays and the time-bounded settlement calculation could not know which
archive it was missing. A Kalshi order's actual terminal timestamp is
`last_update_time`, which the cash reconciler now accepts.

The returned read is NOT itself an authenticated, atomic account close:
`atomicSnapshot:false`, `accountCashMovementsCovered:false`,
`originalSourceAuthenticated:false`. Independent Operations source
verification, complete cash-activity/transfer coverage, subaccount custody,
and full financial reconciliation remain necessary to score real outcomes.
No order execution or additional persistence is introduced.

## Exact fill-to-settlement-to-cash accounting

The existing `./settlement-accounting` export now also exposes
`reconcileIsolatedKalshiYesClose`, a **read-only** numerical reconciliation
of one isolated long-YES position from its genuine venue orders and individual
fills through finalized settlement and observed account cash.

It uses integer micro-USD throughout: each fill's `count_fp` (hundredths of
contracts) times `yes_price_dollars` (ten-thousandths of a dollar) is exactly
one micro-USD per product unit. It separately checks complete order-fill
quantity, settled position counts, cash payout, reconstructed cost basis,
actual fill fees, and the before/after cash difference. Settlement `revenue`
is cents, while fill prices, cost and fee fields are dollar strings.
Those units **must not** be interchanged.

This particular verified domain is deliberately narrow: one market and
subaccount, no opening or leftover holdings, long YES buys only, no closing
sells, no unrelated account activity, and fully received source coverage
through the account-close observation. Other strategies, missing pagination,
NO exposures, ambiguous inventory, transfers, void settlements, or unobserved
fees do not get a guessed profit. A reconciled mathematical result is still
`originalSourcesReceived:false` and `accountingAuthenticated:false` until
independent Operations verifies the ORIGINAL exchange and account source
material. Sub-cent amounts stay in micro-USD; an amount not divisible by one
whole cent has `netWholeCents:null` rather than being rounded into false
strategy P&L.

The pure equation tests run in
`.github/workflows/kalshi-settlement-close.yml`; the complete venue workspace,
independent source readers and operating account reconciliation remain
separate receiving obligations.

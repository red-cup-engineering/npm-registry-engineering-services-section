#!/usr/bin/env node
// Pure research transform: combines normalized Kalshi market observations,
// house forecasts, exact settlement-source bindings, calibration uncertainty,
// published fees, cash opportunity cost, and declared extra execution cost.
// It ranks research candidates without placing orders or inheriting venue
// credentials. Title similarity never establishes source equivalence.

const DEFAULT_FEE_RATE = 0.07;

function finite(value, name) {
  if (typeof value !== "number" || !Number.isFinite(value)) throw new TypeError(`${name} must be finite`);
  return value;
}
function unit(value, name) {
  const n = finite(value, name);
  if (n < 0 || n > 1) throw new TypeError(`${name} must lie in [0,1]`);
  return n;
}
function nonempty(value, name) {
  if (typeof value !== "string" || !value.length) throw new TypeError(`${name} must be non-empty`);
  return value;
}
function iso(value, name) {
  nonempty(value, name);
  const t = Date.parse(value);
  if (!Number.isFinite(t)) throw new TypeError(`${name} must be an ISO timestamp`);
  return t;
}
function roundCentUp(value) {
  return Math.ceil(value * 100 - 1e-12) / 100;
}

export function kalshiFeePerContract(price, feeRate = DEFAULT_FEE_RATE) {
  unit(price, "price");
  finite(feeRate, "feeRate");
  if (feeRate < 0) throw new TypeError("feeRate must be nonnegative");
  return roundCentUp(feeRate * price * (1 - price));
}

export function horizonCashCost({ annualRate, observedAt, settlementTime }) {
  const rate = finite(annualRate, "annualRate");
  if (rate < 0) throw new TypeError("annualRate must be nonnegative");
  const start = iso(observedAt, "observedAt");
  const end = iso(settlementTime, "settlementTime");
  if (end <= start) return 0;
  const years = (end - start) / (365.25 * 86400000);
  return Math.expm1(Math.log1p(rate) * years);
}

export function scoreKalshiResearchCandidate({
  market,
  forecast,
  sourceBinding,
  calibration,
  annualCashRate = 0,
  feeRate = DEFAULT_FEE_RATE,
  extraCostPerContract = 0,
  maxAgeSeconds = 900,
  now,
}) {
  if (!market || !forecast || !sourceBinding) throw new TypeError("market, forecast, and sourceBinding are required");
  const ticker = nonempty(market.ticker, "market.ticker");
  if (forecast.marketTicker !== ticker) throw new Error("forecast-market-ticker-mismatch");
  if (sourceBinding.marketTicker !== ticker) throw new Error("source-binding-ticker-mismatch");

  if (sourceBinding.aligned !== true) {
    return Object.freeze({
      ticker,
      state: "SOURCE_SEMANTICS_UNALIGNED",
      eligible: false,
      reason: sourceBinding.reason ?? null,
    });
  }

  if (market.status && market.status !== "open") {
    return Object.freeze({ ticker, state: "MARKET_NOT_OPEN", eligible: false });
  }

  const nowMs = iso(now, "now");
  const observedMs = iso(market.observedAt, "market.observedAt");
  const ageSeconds = (nowMs - observedMs) / 1000;
  if (ageSeconds > maxAgeSeconds) {
    return Object.freeze({ ticker, state: "MARKET_STALE", eligible: false, ageSeconds });
  }

  const probability = unit(forecast.probability, "forecast.probability");
  const yesAsk = unit(market.yesAsk, "market.yesAsk");
  const noAsk = market.noAsk == null
    ? unit(1 - unit(market.yesBid, "market.yesBid"), "derived.noAsk")
    : unit(market.noAsk, "market.noAsk");

  const uncertaintyKnown = calibration?.probabilityHalfWidth != null;
  const uncertainty = uncertaintyKnown
    ? Math.max(0, finite(calibration.probabilityHalfWidth, "calibration.probabilityHalfWidth"))
    : null;
  const cashCost = horizonCashCost({
    annualRate: annualCashRate,
    observedAt: market.observedAt,
    settlementTime: market.settlementTime,
  });

  const sides = [
    { side: "yes", winProbability: probability, price: yesAsk },
    { side: "no", winProbability: 1 - probability, price: noAsk },
  ].map((candidate) => {
    const feePerContract = kalshiFeePerContract(candidate.price, feeRate);
    const conservativeProbability = uncertaintyKnown
      ? Math.max(0, candidate.winProbability - uncertainty)
      : null;
    const grossEdgePerContract = candidate.winProbability - candidate.price;
    const netPerContractBeforeUncertainty =
      candidate.winProbability
      - candidate.price
      - feePerContract
      - extraCostPerContract
      - cashCost * candidate.price;
    const conservativeNetPerContract = uncertaintyKnown
      ? conservativeProbability
        - candidate.price
        - feePerContract
        - extraCostPerContract
        - cashCost * candidate.price
      : null;

    return Object.freeze({
      ...candidate,
      feePerContract,
      cashCost,
      uncertaintyKnown,
      uncertainty,
      conservativeProbability,
      grossEdgePerContract,
      netPerContractBeforeUncertainty,
      conservativeNetPerContract,
    });
  }).sort((a, b) =>
    (b.conservativeNetPerContract ?? b.netPerContractBeforeUncertainty)
    - (a.conservativeNetPerContract ?? a.netPerContractBeforeUncertainty));

  const best = sides[0];
  const resolvedForecastCount = Number(calibration?.resolvedForecastCount ?? 0);
  const brierScore = Number(calibration?.brierScore ?? NaN);
  const marketImpliedBrierScore = Number(calibration?.marketImpliedBrierScore ?? NaN);
  const calibrated =
    Number.isFinite(resolvedForecastCount)
    && resolvedForecastCount >= 30
    && Number.isFinite(brierScore)
    && Number.isFinite(marketImpliedBrierScore);
  const calibrationBeatsMarket = calibrated && brierScore < marketImpliedBrierScore;

  const hasRawNetEdge = best.netPerContractBeforeUncertainty > 0;
  const hasConservativeEdge =
    best.conservativeNetPerContract != null
    && best.conservativeNetPerContract > 0;
  const state = uncertaintyKnown
    ? hasConservativeEdge
      ? calibrated && calibrationBeatsMarket
        ? "CONSUMER_PROPOSABLE"
        : "RESEARCH_CANDIDATE"
      : "NO_CONSERVATIVE_EDGE"
    : hasRawNetEdge
      ? "RESEARCH_CANDIDATE"
      : "NO_EDGE_BEFORE_UNCERTAINTY";

  return Object.freeze({
    type: "KalshiResearchCandidate",
    version: 1,
    ticker,
    eligible: true,
    state,
    side: best.side,
    price: best.price,
    winProbability: best.winProbability,
    conservativeProbability: best.conservativeProbability,
    grossEdgePerContract: best.grossEdgePerContract,
    netPerContractBeforeUncertainty: best.netPerContractBeforeUncertainty,
    conservativeNetPerContract: best.conservativeNetPerContract,
    feePerContract: best.feePerContract,
    cashCostFraction: best.cashCost,
    probabilityHalfWidth: best.uncertainty,
    uncertaintyKnown: best.uncertaintyKnown,
    calibrationResolvedCount: resolvedForecastCount,
    calibrationBeatsMarket,
    settlementSource: sourceBinding.settlementSource ?? null,
    forecastSource: sourceBinding.forecastSource ?? null,
    observedAt: market.observedAt,
    settlementTime: market.settlementTime,
    venueWrite: false,
  });
}

export function rankKalshiResearchCandidates(request) {
  if (!request || !Array.isArray(request.markets) || !Array.isArray(request.forecasts)) {
    throw new TypeError("markets and forecasts arrays are required");
  }
  nonempty(request.now, "request.now");
  const forecasts = new Map(request.forecasts.map((row) => [row.marketTicker, row]));
  const bindings = new Map((request.sourceBindings ?? []).map((row) => [row.marketTicker, row]));
  const calibrations = new Map((request.calibrationRecords ?? []).map((row) => [row.marketTicker, row]));

  const rows = [];
  for (const market of request.markets) {
    const forecast = forecasts.get(market.ticker);
    const sourceBinding = bindings.get(market.ticker);
    if (!forecast || !sourceBinding) {
      rows.push(Object.freeze({
        ticker: market.ticker,
        state: "MISSING_RESEARCH_INPUT",
        eligible: false,
      }));
      continue;
    }
    rows.push(scoreKalshiResearchCandidate({
      market,
      forecast,
      sourceBinding,
      calibration: calibrations.get(market.ticker),
      annualCashRate: request.annualCashRate ?? 0,
      feeRate: request.feeRate ?? DEFAULT_FEE_RATE,
      extraCostPerContract: request.extraCostPerContract ?? 0,
      maxAgeSeconds: request.maxAgeSeconds ?? 900,
      now: request.now,
    }));
  }

  return Object.freeze(rows.sort(
    (a, b) => (b.conservativeNetPerContract ?? -Infinity) - (a.conservativeNetPerContract ?? -Infinity),
  ));
}

if (import.meta.main) {
  const { runJavascriptNodeOperation } = await import("@red-cup-engineering/javascript-node-services-section/operation");
  const result = await runJavascriptNodeOperation(
    {
      name: "rank-kalshi-research-candidates",
      description: "Ranks read-only Kalshi research candidates using exact settlement-source alignment, forecast probability, uncertainty, fees, cash opportunity cost, and declared execution friction. Never places an order.",
      operation: rankKalshiResearchCandidates,
    },
    {
      arguments: process.argv.slice(2),
      standardInput: process.stdin,
      standardOutput: process.stdout,
    },
  );
  process.exitCode = result.exitCode;
}

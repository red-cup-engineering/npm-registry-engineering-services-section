#!/usr/bin/env node
/**
 * The Kalshi game client: play the arena (src/arena.mjs) from the signed WebSocket. Read-only.
 *
 *   node scripts/kalshi-world.mjs live   --tickers T1,T2 | --events E1,E2  [--record play.jsonl] [--seconds 60]
 *   node scripts/kalshi-world.mjs replay --record play.jsonl     (a play record, one {seq,intent,ts} per line)
 *   node scripts/kalshi-world.mjs replay --frames frames.jsonl[.gz]   (raw {r,m} frames, e.g. the generator-lag journal)
 *
 * live admits every frame through `admitFrame`, extends the position by the arena's rules and appends each
 * admitted move to the play record. replay folds a record (or re-admits raw frames) one line at a time; a
 * move the rules refuse stops the replay, as the gaming faculty's `replayPlay` does. The report gives books,
 * stale books, moves by polarity, and the transport lag (receive clock minus the exchange's ts_ms), the
 * number that decides whether hosting nearer the exchange matters.
 */
import { appendFileSync, createReadStream } from 'node:fs';
import { createGunzip } from 'node:zlib';
import { createInterface } from 'node:readline';
import { createKalshiClient, kalshiCredentials, authHeaders } from '../src/client.mjs';
import { kalshiArena, admitFrame, top, marketsOf } from '../src/arena.mjs';

const args = process.argv.slice(2); const cmd = args[0];
const opt = (name, def) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : def; };
const WS = { host: 'wss://api.elections.kalshi.com', path: '/trade-api/ws/v2' };

function player() {
  let position = kalshiArena.initialPosition(); let seq = -1; const counts = {}; const lag = [];
  const play = (move, ts, onEntry) => {
    const { state, events } = kalshiArena.extend(position, move); position = state; seq += 1;
    for (const e of events) { counts[`${e.polarity}:${e.kind}`] = (counts[`${e.polarity}:${e.kind}`] ?? 0) + 1; if (e.t && ts) { lag.push(ts - e.t); if (lag.length > 20000) lag.shift(); } }
    onEntry?.({ seq, intent: move, ts });
  };
  const report = () => {
    const s = [...lag].sort((a, b) => a - b); const q = (p) => (s.length ? s[Math.min(s.length - 1, Math.floor(p * s.length))] : null);
    const books = marketsOf(position).filter(([, m]) => m.yes);
    return { moves: seq + 1, books: books.length, stale: books.filter(([, m]) => m.stale).length, byPolarity: counts, transportLagMs: { n: s.length, p10: q(0.1), p50: q(0.5), p90: q(0.9), p99: q(0.99) }, sample: books.slice(0, 3).map(([t]) => ({ ticker: t, ...top(position, t) })) };
  };
  return { play, report, get position() { return position; } };
}

async function tickersFrom(client) {
  if (opt('tickers')) return opt('tickers').split(',');
  const out = [];
  for (const ev of (opt('events') ?? '').split(',').filter(Boolean)) {
    const p = await client.call('GET', `/events/${ev}`, { query: { with_nested_markets: true }, signed: false });
    for (const m of p?.event?.markets ?? p?.markets ?? []) if (m.status === 'active') out.push(m.ticker);
  }
  return out;
}

async function live() {
  const tickers = await tickersFrom(createKalshiClient()); const file = opt('record'); const p = player();
  const h = await authHeaders({ ...kalshiCredentials(), method: 'GET', path: WS.path }); delete h.accept; delete h['content-type'];
  const ws = new WebSocket(WS.host + WS.path, { headers: h });
  ws.onopen = () => ws.send(JSON.stringify({ id: 1, cmd: 'subscribe', params: { channels: ['orderbook_delta', 'trade', 'market_lifecycle_v2'], market_tickers: tickers } }));
  ws.onmessage = (msg) => {
    const ts = Date.now();
    for (const move of admitFrame(p.position, JSON.parse(String(msg.data)))) p.play(move, ts, file && ((entry) => appendFileSync(file, `${JSON.stringify(entry)}\n`)));
  };
  ws.onerror = (e) => console.error('ws error', e.message ?? '');
  await new Promise((res) => setTimeout(res, Number(opt('seconds', 60)) * 1000));
  ws.close(); console.log(JSON.stringify({ tickers: tickers.length, ...p.report() }, null, 1));
}

async function replay() {
  const p = player(); const frames = opt('frames'); let refused = null;
  const file = frames ?? opt('record');
  const raw = createReadStream(file);
  const rl = createInterface({ input: file.endsWith('.gz') ? raw.pipe(createGunzip()) : raw, crlfDelay: Infinity });
  let pending = '';
  for await (const line of rl) {
    // a frame whose raw message carried its own newline spans two lines: join until it parses
    if (!line && !pending) continue; let row; try { row = JSON.parse(pending + line); pending = ''; } catch { pending += line; continue; }
    try {
      if (frames) for (const move of admitFrame(p.position, row.m)) p.play(move, row.r);
      else p.play(row.intent, row.ts);
    } catch (e) { refused = { line: p.report().moves, reason: e.message }; break; }
  }
  console.log(JSON.stringify({ valid: refused === null, refused, ...p.report() }, null, 1));
}

if (cmd === 'live') await live();
else if (cmd === 'replay') await replay();
else { console.error('usage: kalshi-world.mjs live|replay'); process.exit(2); }

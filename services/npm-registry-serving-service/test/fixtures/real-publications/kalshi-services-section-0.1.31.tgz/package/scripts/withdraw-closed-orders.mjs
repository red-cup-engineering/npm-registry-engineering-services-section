#!/usr/bin/env node
// Incident withdrawal is cancellation-only. Human orders and positions stay put.
import {createKalshiClient} from '../src/client.mjs';
import {KALSHI_ACCOUNTS} from '../src/accounts.mjs';
import {orderExecutionControl} from '../src/execution-control.mjs';
import {recordDirectory,settlementRoot} from '../src/data-layout.mjs';
import {mkdirSync,writeFileSync,renameSync} from 'node:fs';
import {join} from 'node:path';
const results=[];
for(const account of Object.keys(KALSHI_ACCOUNTS)) {
 if(!orderExecutionControl(account).closed)throw new Error('Close live execution before withdrawing incident orders');
 const env={...process.env,KALSHI_ACCOUNT_ID:account,KALSHI_CREDENTIAL_ACCOUNT_ID:account};
 if(account!=='emsenn'){delete env.KALSHI_API_KEY_ID;delete env.KALSHI_PRIVATE_KEY_PATH;env.KALSHI_ENV_FILE=process.env.KALSHI_ESTHER_DAVIS_ENV_FILE;}
 const at=new Date().toISOString(),receipt={account,at,cancelled:[],gone:[],errors:[],manualOrdersPreserved:null,remainingBotOrders:null};
 try {
  const client=createKalshiClient({env}),orders=await client.getOrders({status:'resting'});
  const ours=orders.filter(order=>String(order.client_order_id??'').startsWith('kd-'));
  receipt.manualOrdersPreserved=orders.length-ours.length;
  for(const order of ours) {
   try {await client.cancelOrder(order.order_id,order.ticker,{subaccount:order.subaccount??0});receipt.cancelled.push({orderId:order.order_id,ticker:order.ticker});}
   catch(error){if(error.status===404)receipt.gone.push(order.order_id);else receipt.errors.push({orderId:order.order_id,code:error.code??'error',message:error.message});}
  }
  receipt.remainingBotOrders=(await client.getOrders({status:'resting'})).filter(order=>String(order.client_order_id??'').startsWith('kd-')).map(order=>({orderId:order.order_id,ticker:order.ticker}));
 }catch(error){receipt.errors.push({code:error.code??'error',message:error.message});}
 receipt.complete=Array.isArray(receipt.remainingBotOrders)&&receipt.remainingBotOrders.length===0&&receipt.errors.length===0;
 const directory=recordDirectory(settlementRoot(env),'order-closure');mkdirSync(directory,{recursive:true,mode:0o700});
 const path=join(directory,at.replaceAll(':','-')+'.json');writeFileSync(path+'.tmp',JSON.stringify(receipt,null,2)+'\n',{mode:0o600});renameSync(path+'.tmp',path);
 results.push({...receipt,path});
}
console.log(JSON.stringify({closed:true,complete:results.every(receipt=>receipt.complete),results}));
if(results.some(receipt=>!receipt.complete))process.exitCode=1;

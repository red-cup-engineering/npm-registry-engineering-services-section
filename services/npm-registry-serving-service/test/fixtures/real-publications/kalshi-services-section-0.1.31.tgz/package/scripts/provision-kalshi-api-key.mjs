#!/usr/bin/env node
// Private key material is accepted from a file, never from a command argument.
import { resolve, join } from 'node:path';
import { provisionApiKey, prepareApiKey, importApiKey, connectApiKey, keyPath } from '../src/provisioning.mjs';
import { kalshiAccount } from '../src/accounts.mjs';
import { kalshiCredentials, kalshiEnvFile } from '../src/account-credentials.mjs';

const usage = `provision-kalshi-api-key [assist|prepare|connect|import|status] [--account emsenn|esther-davis]
  --directory /absolute/private/directory   caller-owned custody instead of the host store
  connect --key-id UUID                     register a prepared public key on Kalshi first
  import --key-id UUID --private-key-file /absolute/downloaded-key.txt
  prepare prints the public key only; status makes no network request.
  Connection verifies a signed balance read. It does not arm a trading desk.`;

try {
  const args = process.argv.slice(2);
  if (args.includes('--help')) { process.stdout.write(usage + '\n'); }
  else {
    const command = args[0] && !args[0].startsWith('--') ? args.shift() : 'assist';
    if (!['assist', 'prepare', 'connect', 'import', 'status'].includes(command)) throw new TypeError('unknown setup command');
    const options = {};
    while (args.length) {
      const flag = args.shift(), value = args.shift();
      if (!['--account', '--directory', '--key-id', '--private-key-file'].includes(flag) || !value || value.startsWith('--') || Object.hasOwn(options, flag)) throw new TypeError('one value per supported setup flag is required');
      options[flag] = value;
    }
    if ((options['--private-key-file'] && command !== 'import') || (options['--key-id'] && !['import', 'connect'].includes(command))) throw new TypeError('key input is only accepted by connect/import');
    const env = { ...process.env, ...(options['--account'] ? { KALSHI_ACCOUNT_ID: options['--account'] } : {}) };
    const account = kalshiAccount(env);
    if (options['--directory']) {
      const directory = resolve(options['--directory']);
      delete env.KALSHI_API_KEY_ID;
      Object.assign(env, { KALSHI_CREDENTIAL_ACCOUNT_ID: account.id, KALSHI_ENV_FILE: join(directory, 'credentials.env'), KALSHI_PRIVATE_KEY_PATH: join(directory, 'private-key.pem') });
    }
    const receipt = command === 'prepare' ? await prepareApiKey({ env }) :
      command === 'connect' ? await connectApiKey({ apiKeyId: options['--key-id'], env }) :
      command === 'import' ? await importApiKey({ apiKeyId: options['--key-id'], privateKeyFile: options['--private-key-file'], env }) :
      command === 'status' ? { type: 'KalshiAccountSetup', accountId: account.id, name: account.name, credentialed: Boolean(kalshiCredentials(env)), envFile: kalshiEnvFile(env), keyFile: keyPath(env), deskOrders: account.deskOrders, venueVerified: false } :
      await provisionApiKey({ env });
    process.stdout.write(JSON.stringify(receipt, null, 2) + '\n');
    process.exitCode = receipt.stoppedEarly ? 1 : 0;
  }
} catch (error) {
  // Never serialize arbitrary input, parsed keys or network response bodies.
  process.stderr.write(`Kalshi setup failed: ${error.message}\n${usage}\n`);
  process.exitCode = 1;
}

#!/usr/bin/env node
/** One-time receiving of meaningful legacy Kalshi custody into the current store.
 * Originals remain untouched. This is a deployment operation, never a pulse.
 * --dry-run reads and validates; --apply requires the caller's stopped-writer
 * deployment boundary. No credential, client or order operation is imported.
 * Requeryable catalog cursors, forecast presentation and guidance caches,
 * leases, diagnostics and obsolete state stay outside the active store.
 */
import fs from 'node:fs';
import {join,resolve,dirname,relative} from 'node:path';
import {tmpdir} from 'node:os';
import {createHash} from 'node:crypto';
import {gunzipSync} from 'node:zlib';
import {createInterface} from 'node:readline';
import {fileURLToPath} from 'node:url';
import {append,put,get,readLog} from '@red-cup-engineering/semiotic-eavt-services-section/store';
import {stateDirectory} from '../src/data-layout.mjs';
import {deskStatePath,ledgerFile,shadowFile,reviewDirectory} from '../services/kalshi-stake-path-service/src/desk-layout.mjs';

const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const clock=x=>typeof x==='string'&&Number.isFinite(Date.parse(x));
const sha=x=>createHash('sha256').update(x).digest('hex');
const HASH=/^[a-f0-9]{64}$/u;
const DAY=/^\d{4}-\d{2}-\d{2}\.jsonl$/u;
const ledgerKinds=new Set(['place','place-acknowledged','place-recovered','place-absent','cancel','amend','refused-size','arm','halt','authority-refusal']);
const finiteTree=x=>typeof x==='number'?Number.isFinite(x):Array.isArray(x)?x.every(finiteTree):object(x)?Object.values(x).every(finiteTree):true;
const requireThat=(condition,message)=>{if(!condition)throw new TypeError(message);};

export async function fileSettlementByTier({settlement,output=settlement,dryRun=true,writersStopped=false}={}){
 requireThat(typeof settlement==='string'&&settlement.length>0,'settlement root required');
 requireThat(dryRun||writersStopped,'apply requires the existing deployment boundary to stop every settlement writer');
 const root=resolve(settlement),destination=resolve(output);
 requireThat(!destination.startsWith(root+'/'),'destination cannot be nested in the source settlement');
 const stage=fs.mkdtempSync(join(tmpdir(),'kalshi-state-receiving-'));
 const summary={settlement:root,output:destination,dryRun,orderEffect:false,originalsPreserved:true,selected:{},excluded:{},incompleteOrigins:[],files:[],conflicts:[]};
 const stamps=new Map(),evidence=new Set();
 const count=(name,n=1)=>{summary.selected[name]=(summary.selected[name]??0)+n;};
 const exclude=(name,n=1)=>{summary.excluded[name]=(summary.excluded[name]??0)+n;};
 const present=p=>{try{const s=fs.lstatSync(p);requireThat(s.isFile(),'regular source file required: '+p);if(!stamps.has(p))stamps.set(p,[s.size,s.mtimeMs,s.ctimeMs]);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}};
 const read=p=>{if(!present(p))return undefined;return JSON.parse(fs.readFileSync(p,'utf8'));};
 const write=(p,v)=>{fs.mkdirSync(dirname(p),{recursive:true,mode:0o700});fs.writeFileSync(p,JSON.stringify(v)+'\n',{mode:0o600,flag:'wx'});};
 const emit=(p,row)=>{fs.mkdirSync(dirname(p),{recursive:true,mode:0o700});fs.appendFileSync(p,JSON.stringify(row)+'\n',{mode:0o600});};
 const names=p=>{try{return fs.readdirSync(p).sort();}catch(e){if(e.code==='ENOENT')return [];throw e;}};
 async function* rows(p){
  if(!present(p))return;
  const lines=createInterface({input:fs.createReadStream(p),crlfDelay:Infinity});
  let lineNumber=0;
  for await(const text of lines){lineNumber++;if(!text)continue;let row;
   try{row=JSON.parse(text);}catch{throw new TypeError('invalid JSON at '+p+':'+lineNumber);}
   requireThat(object(row)&&finiteTree(row),'finite object at '+p+':'+lineNumber);yield row;
  }
 }
 const verifiedEvidence=new Set();
 const qualify=(row,record)=>{
  const ids=[row.evidenceId,row.sourceEvidenceId].filter(x=>x!==undefined);
  if(ids.length===0){summary.incompleteOrigins.push({record,reason:'original record retains no immutable source packet address'});return false;}
  for(const id of ids){
   requireThat(HASH.test(id),'invalid weather evidence address');
   const source=join(root,'weather','evidence',id+'.json.gz');
   if(!present(source)){summary.incompleteOrigins.push({record,evidenceId:id,reason:'cited immutable source packet unavailable; original claim stays outside active calibration'});return false;}
   if(!verifiedEvidence.has(id)){requireThat(sha(gunzipSync(fs.readFileSync(source)))===id,'weather evidence does not hash to its original id: '+id);verifiedEvidence.add(id);}
  }
  for(const id of ids)evidence.add(id);return true;
 };
 const forecast=row=>object(row)&&clock(row.at)&&typeof row.ticker==='string'&&HASH.test(row.rulesHash)&&Array.isArray(row.models)&&row.models.every(m=>typeof m.id==='string'&&Number.isFinite(m.p)&&m.p>=0&&m.p<=1);
 try{
  requireThat(fs.existsSync(join(root,'weather-desk','arming.json')),'the original principal arming custody is required');
  // Principal authority and unresolved venue writes are retained without widening.
  for(const name of ['arming.json','pending-order-effect.json','rest-state.json','rest-state.paper.json']){
   const source=join(root,'weather-desk',name),value=read(source);if(value===undefined)continue;
   if(name==='arming.json')requireThat(object(value)&&typeof value.armed==='boolean'&&(!value.armed||clock(value.armedAt)&&typeof value.armedBy==='string'),'invalid principal arming');
   else if(name==='pending-order-effect.json')requireThat(value===null||value.type==='KalshiPendingOrderEffect'&&clock(value.at)&&typeof value.params?.clientOrderId==='string'&&typeof value.params?.ticker==='string','invalid pending order custody');
   else requireThat(object(value)&&finiteTree(value),'invalid desk rest state');
   write(deskStatePath(stage,name),value);count(name);
  }
  for(const name of names(join(root,'weather-desk','ledger')).filter(x=>DAY.test(x))){
   for await(const row of rows(join(root,'weather-desk','ledger',name))){
    requireThat(clock(row.at)&&row.at.slice(0,10)===name.slice(0,10),'ledger source instant disagrees with filing day');
    const useful=ledgerKinds.has(row.kind)||row.kind==='error'&&['place','amend','cancel','book-provenance'].includes(row.step);
    if(!useful){exclude('ledger:'+row.kind);continue;}
    if(row.kind==='place')requireThat(typeof row.orderId==='string'&&typeof row.ticker==='string','placement attribution requires original venue order id');
    emit(ledgerFile(stage,name.slice(0,10)),row);count('ledger:'+row.kind);
   }
  }
  for(const name of names(join(root,'weather-desk','shadow')).filter(x=>DAY.test(x)))for await(const row of rows(join(root,'weather-desk','shadow',name))){
   requireThat(clock(row.at)&&row.at.slice(0,10)===name.slice(0,10)&&typeof row.lane==='string'&&typeof row.ticker==='string'&&['ask','bid'].includes(row.bookSide),'invalid original shadow opportunity');
   emit(shadowFile(stage,name.slice(0,10)),row);count('shadow-opportunity');
  }
  exclude('derived-shadow-score-caches-recomputed-from-original-opportunities');
  const judgments=read(join(root,'weather-desk','reviews','judgments.json'));
  if(judgments!==undefined){requireThat(object(judgments.lanes)&&finiteTree(judgments),'invalid in-force lane judgments');for(const lane of Object.values(judgments.lanes))requireThat(Number.isFinite(lane.fraction)&&lane.fraction>=0&&lane.fraction<=1,'invalid in-force capital fraction');write(join(reviewDirectory(stage),'judgments.json'),judgments);count('in-force-judgments');}

  // Original source arrivals have a real availability clock and body. Admit
  // that same event through the canonical record store; never invent witnesses.
  for(const name of names(join(root,'sources')).filter(x=>DAY.test(x)))for await(const row of rows(join(root,'sources',name))){
   requireThat(row.specversion==='1.0'&&clock(row.time)&&row.time.slice(0,10)===name.slice(0,10)&&typeof row.source==='string'&&typeof row.id==='string'&&object(row.data)&&typeof row.settlementSource==='string','invalid original source arrival');
   const address=put(stage,'source-arrival',row);
   append(stage,'source-arrival',{at:row.time,of:address,settlementSource:row.settlementSource});
   requireThat(get(stage,'source-arrival',address)?.id===row.id,'canonical source record did not receive original event');count('source-arrival');
  }
  const cursor=read(join(root,'sources','cursor.json'));
  if(cursor!==undefined){requireThat(object(cursor),'invalid original source deduplication cursor');write(join(stateDirectory(stage,'source'),'cursor.json'),cursor);count('source-cursor');}

  // Forecasts cannot be re-created after their outcomes. Keep original rules,
  // availability, probabilities, venue settlement and immutable evidence ids.
  const weather=stateDirectory(stage,'weather'),pending=read(join(root,'weather','pending.json'));
  if(pending!==undefined){requireThat(object(pending),'invalid pending forecasts');const active={};for(const [id,row] of Object.entries(pending)){requireThat(HASH.test(id)&&forecast(row),'invalid pending forecast '+id);if(!qualify(row,'weather/pending.json#'+id)){exclude('incomplete-origin-pending-forecast');continue;}active[id]=row;count('pending-forecast');}write(join(weather,'pending.json'),active);}
  const held=new Map();
  async function retainResolved(row){
   requireThat(HASH.test(row.id),'resolved forecast requires original id');
   const text=JSON.stringify(row),seen=held.get(row.id);
   if(seen!==undefined){requireThat(seen===sha(text),'conflicting resolved forecast id '+row.id);exclude('duplicate-resolved');return;}
   if(!forecast(row)||row.settlementEvidenceVersion!==1||row.settlement?.status!=='finalized'||row.settlement.marketType!=='binary'||!clock(row.settlement.settledAt)||Date.parse(row.at)>=Date.parse(row.settlement.settledAt)||!['yes','no'].includes(row.settlement.result)||row.venueResult!==row.settlement.result||row.settlement.ticker!==row.ticker||row.outcome!==(row.settlement.result==='yes'?1:0)){
    exclude('unqualified-resolved-original-preserved');return;
   }
   held.set(row.id,sha(text));if(!qualify(row,'weather/resolved.jsonl#'+row.id)){exclude('incomplete-origin-resolved-forecast');return;}emit(join(weather,'resolved.jsonl'),row);count('pre-outcome-resolved-forecast');
  }
  for await(const row of rows(join(root,'weather','resolved.jsonl')))await retainResolved(row);
  for(const name of names(join(root,'weather','scores')).filter(x=>/^[a-f0-9]{64}\.json$/u.test(x))){const row=read(join(root,'weather','scores',name));requireThat(row.id===name.slice(0,64),'score id disagrees with source filename');await retainResolved(row);}
  const science=read(join(root,'weather','station-science','state.json'));
  if(science!==undefined){
   requireThat(object(science.pending)&&object(science.history)&&clock(science.at),'invalid station-science state');
   const pending={},history={},comparisons={};
   for(const [id,row] of Object.entries(science.pending)){requireThat(clock(row.availableAt)&&clock(row.validTime)&&Date.parse(row.availableAt)<Date.parse(row.validTime)&&typeof row.model==='string'&&Number.isFinite(row.meanF)&&Number.isFinite(row.scaleF)&&row.scaleF>0&&finiteTree(row),'invalid prequential station forecast');if(qualify(row,'weather/station-science/state.json#pending/'+id)){pending[id]=row;count('station-pending');}else exclude('incomplete-origin-station-pending');}
   // Aggregates do not preserve each forecast/outcome's original packet. A
   // single final sourceEvidenceId cannot qualify all observations in a sum.
   // Preserve those claims in original custody and refit from qualified pending
   // records/current observations instead of importing unverified admissions.
   for(const [id,row] of Object.entries(science.history)){requireThat(typeof row.date==='string'&&typeof row.key==='string'&&Number.isInteger(row.n)&&row.n>0&&finiteTree(row),'invalid station history aggregate');summary.incompleteOrigins.push({record:'weather/station-science/state.json#history/'+id,reason:'aggregate lacks per-observation immutable source lineage; original descriptive claim preserved'});exclude('unverified-station-history-aggregate');}
   for(const [id,row] of Object.entries(science.comparisons??{})){requireThat(typeof row.date==='string'&&Number.isInteger(row.n)&&row.n>0&&finiteTree(row),'invalid paired station history');summary.incompleteOrigins.push({record:'weather/station-science/state.json#comparisons/'+id,reason:'aggregate lacks per-observation paired source lineage; original descriptive claim preserved'});exclude('unverified-station-comparison-aggregate');}
   // Parameters are fitted again by the current scientific owner. Unsupported
   // measurement/publication stores remain in the untouched original custody.
   write(join(weather,'station-science','state.json'),{pending,history,comparisons,missingOutcomes:science.missingOutcomes??0,parameters:{},at:science.at});
   for(const k of Object.keys(science))if(!['pending','history','comparisons','missingOutcomes','parameters','at'].includes(k))exclude('obsolete-station-field:'+k);
  }
  for(const id of evidence){
   const source=join(root,'weather','evidence',id+'.json.gz');requireThat(present(source),'referenced weather evidence missing: '+id);
   const bytes=fs.readFileSync(source),raw=gunzipSync(bytes);requireThat(sha(raw)===id,'weather evidence does not hash to its original id: '+id);
   const to=join(weather,'evidence',id+'.json.gz');fs.mkdirSync(dirname(to),{recursive:true,mode:0o700});fs.writeFileSync(to,bytes,{mode:0o600,flag:'wx'});count('referenced-weather-evidence');
  }
  // Refuse nonempty old catalog history rather than blindly copying its flat
  // marks into the native SignCell feed. Its adjudication is a separate input.
  requireThat(names(join(root,'catalog','data','logs')).length===0,'legacy catalog history requires semantic adjudication; originals were preserved');
  exclude('requeryable-catalog-routes-and-watermark');exclude('requeryable-weather-presentation-guidance-and-derived-grades');exclude('leases-and-diagnostics');
  function walk(p){return names(p).flatMap(name=>{const f=join(p,name),s=fs.lstatSync(f);requireThat(!s.isSymbolicLink(),'staging symlink refused');return s.isDirectory()?walk(f):[f];});}
  const staged=walk(stage);
  for(const from of staged){const to=join(destination,relative(stage,from)),bytes=fs.readFileSync(from);summary.files.push({path:relative(stage,from),bytes:bytes.length,sha256:sha(bytes)});if(fs.existsSync(to)&&(!fs.lstatSync(to).isFile()||!fs.readFileSync(to).equals(bytes)))summary.conflicts.push(relative(stage,from));}
  requireThat(summary.conflicts.length===0,'destination collisions: '+summary.conflicts.join(', '));
  for(const [p,stamp] of stamps){const s=fs.lstatSync(p);requireThat(s.isFile()&&JSON.stringify([s.size,s.mtimeMs,s.ctimeMs])===JSON.stringify(stamp),'source changed during receiving: '+p);}
  // Source days are independently received as canonical references before any
  // active destination changes; every reference names the original record.
  for(const name of names(join(root,'sources')).filter(x=>DAY.test(x)))for(const {line} of readLog(stage,'source-arrival',name.slice(0,10)))requireThat(get(stage,'source-arrival',line.of)?.settlementSource===line.settlementSource,'source-arrival reference failed receiving');
  if(!dryRun){
   const installed=[];
   try{
    for(const from of staged){
     const to=join(destination,relative(stage,from));if(fs.existsSync(to))continue;
     fs.mkdirSync(dirname(to),{recursive:true,mode:0o700});fs.copyFileSync(from,to,fs.constants.COPYFILE_EXCL);installed.push(to);fs.chmodSync(to,0o600);
     const fd=fs.openSync(to,'r');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
     const directory=fs.openSync(dirname(to),'r');try{fs.fsyncSync(directory);}finally{fs.closeSync(directory);}
    }
    for(const file of summary.files)requireThat(sha(fs.readFileSync(join(destination,file.path)))===file.sha256,'destination receiving failed: '+file.path);
   }
   catch(error){for(const p of installed.reverse())fs.unlinkSync(p);throw error;}
  }
  summary.bytes=summary.files.reduce((n,f)=>n+f.bytes,0);return summary;
 }finally{fs.rmSync(stage,{recursive:true,force:true});}
}

if(process.argv[1]&&fs.realpathSync(process.argv[1])===fileURLToPath(import.meta.url)){
 const args=process.argv.slice(2),opt=name=>{const index=args.indexOf(name);return index<0?undefined:args[index+1];},apply=args.includes('--apply');
 try{const receipt=await fileSettlementByTier({settlement:opt('--settlement'),output:args.includes('--output')?opt('--output'):undefined,dryRun:!apply,writersStopped:args.includes('--writers-stopped')});console.log(JSON.stringify(receipt,null,2));}
 catch(error){console.error(JSON.stringify({orderEffect:false,originalsPreserved:true,error:error.message}));process.exitCode=1;}
}

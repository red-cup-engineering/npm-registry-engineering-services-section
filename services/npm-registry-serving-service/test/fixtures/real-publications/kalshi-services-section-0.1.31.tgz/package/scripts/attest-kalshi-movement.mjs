#!/usr/bin/env node
// Record a money movement Kalshi's API does not list (a promotional credit, or a deposit or withdrawal it omits),
// from attested evidence, so the books (src/kalshi-ledger.mjs) post it through the same derivation as a venue record.
// Idempotent by id: recording the same movement again changes nothing; a different movement under a used id refuses.
//   KALSHI_ACCOUNT_ID=<holder> node scripts/attest-kalshi-movement.mjs --kind credit|deposit|withdrawal --id ID
//     --amount-cents N --at ISO-8601 --evidence TEXT [--type Promotional]
import { join } from 'node:path';
import { parseArgs } from 'node:util';
import { isDeepStrictEqual } from 'node:util';
import { readFileText } from '@red-cup-engineering/computer-file-engineering-services-section/read-file';
import { writeFileText } from '@red-cup-engineering/computer-file-engineering-services-section/write-file';
import { recordDirectory, settlementRoot } from '../src/data-layout.mjs';

const KINDS = { credit: 'credits', deposit: 'deposits', withdrawal: 'withdrawals' };
const { values } = parseArgs({ options: Object.fromEntries(['kind', 'id', 'amount-cents', 'at', 'evidence', 'type'].map((name) => [name, { type: 'string' }])) });
const amount = Number(values['amount-cents']);
if (!KINDS[values.kind] || !values.id || !Number.isSafeInteger(amount) || amount <= 0 || Number.isNaN(Date.parse(values.at ?? '')) || !values.evidence?.trim())
  throw new TypeError('--kind credit|deposit|withdrawal, --id, a positive integer --amount-cents, an ISO --at and a non-empty --evidence are required');

const file = join(recordDirectory(settlementRoot(), 'kalshi-attested-movement'), 'movements.json');
let movements = {};
try { movements = JSON.parse(await readFileText(file)); } catch (error) { if (error.code !== 'ENOENT') throw error; }
const record = { id: values.id, amount_cents: amount, type: values.type ?? (values.kind === 'credit' ? 'Promotional' : 'attested'), status: 'applied', at: new Date(values.at).toISOString(), evidence: values.evidence.trim() };
const list = movements[KINDS[values.kind]] ?? [];
const same = list.find((entry) => entry.id === record.id);
if (same && !isDeepStrictEqual(same, record)) throw new Error(`${record.id} is already recorded as a different movement`);
if (!same) {
  movements[KINDS[values.kind]] = [...list, record];
  await writeFileText(file, `${JSON.stringify(movements, null, 2)}\n`);
}
process.stdout.write(`${JSON.stringify({ file, recorded: !same, record })}\n`);

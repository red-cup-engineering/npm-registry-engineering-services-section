#!/usr/bin/env node
import {hardCloseOrderExecution} from '../src/execution-control.mjs';
const reason=process.argv.slice(2).join(' ').trim();
if(!reason)throw new TypeError('usage: hard-close-kalshi.mjs <human closure reason>');
console.log(JSON.stringify(hardCloseOrderExecution(reason)));

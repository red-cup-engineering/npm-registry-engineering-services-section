#!/usr/bin/env node
/**
 * Read Kalshi's settlement sources.   Read-only: public feeds, no orders.
 *
 *   node scripts/kalshi-sources.mjs read [--dir D]      admit new items of every RSS/Atom adapter
 *   node scripts/kalshi-sources.mjs coverage --index index.json
 *
 * read runs communicating's newswire admission over the registry's feeds (src/sources.mjs) with a cursor,
 * so each item is admitted once, and appends the arrivals (CloudEvents) to the day's source-arrival log under
 * D/data/logs/source-arrival-logs/, the cursor to D/data/state/source-state/; D defaults to the settlement root,
 * ~/.local/state/561-group/settlements/kalshi-services-section. coverage reads a catalog
 * settlement index ([{source, series, openMarkets, openVolume}]) and prints what share of open volume
 * settles on a source the firm reads.
 */
import { mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { admitSetOfFeedArrivals, loadCursor, saveCursor } from '@red-cup-engineering/communicating/messaging/newswire/feed-arrivals';
import { append, put } from '@red-cup-engineering/semiotic-eavt-services-section/store';
import { rssFeeds, coverage, sourceObservation } from '../src/sources.mjs';
import { publishWeatherIndexSources, weatherRoot } from '@red-cup-engineering/forecasting/weather-engine';
import { settlementRoot, stateDirectory } from '../src/data-layout.mjs';

const args = process.argv.slice(2); const cmd = args[0];
const opt = (name, def) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : def; };
const dir = opt('dir', settlementRoot());

async function read() {
  mkdirSync(stateDirectory(dir, 'source'), { recursive: true });
  // The short-lived index path precedes RSS and all heavyweight station work.
  let indices;
  try{indices=await publishWeatherIndexSources({root:weatherRoot({...process.env,KALSHI_SETTLEMENT_DIR:dir})});}
  catch(error){indices={at:new Date().toISOString(),status:'refused',error:error.message,orderEffect:false};}
  const arrival=sourceObservation({source:'kalshi-weather-index',url:'https://api.elections.kalshi.com/trade-api/v2/live_data/weather',externalId:indices.evidenceId??'refusal@'+indices.at,value:indices,observedAt:indices.at});
  append(dir,'source-arrival',{at:indices.at,of:put(dir,'source-arrival',{settlementSource:'kalshi-weather-index',...arrival}),settlementSource:'kalshi-weather-index'});
  const feeds = rssFeeds(); const sourceOf = new Map(feeds.map((f) => [f.id, f.source]));
  const cursorPath = join(stateDirectory(dir, 'source'), 'cursor.json');
  const { events, cursor, obstructions } = await admitSetOfFeedArrivals({ feeds: feeds.map(({ id, url, kind }) => ({ id, url, kind })), cursor: loadCursor(cursorPath) });
  // Each arrival is a record of the `source-arrival` type; the day's log names it, with its settlement source, at the instant it was admitted.
  const at = new Date().toISOString();
  for (const e of events) {
    const settlementSource = sourceOf.get(e.data.feed.id);
    append(dir, 'source-arrival', { at, of: put(dir, 'source-arrival', { settlementSource, ...e }), settlementSource });
  }
  saveCursor(cursorPath, cursor);
  console.log(JSON.stringify({ indices, feeds: feeds.length, admitted: events.length, bySource: events.reduce((m, e) => ({ ...m, [sourceOf.get(e.data.feed.id)]: (m[sourceOf.get(e.data.feed.id)] ?? 0) + 1 }), {}), obstructions }));
}

function cover() {
  const c = coverage(JSON.parse(readFileSync(opt('index'), 'utf8')));
  console.log(`read sources settle ${(100 * c.coveredFraction).toFixed(1)}% of open volume (${Math.round(c.coveredVolume).toLocaleString()} of ${Math.round(c.openVolume).toLocaleString()})`);
  for (const r of c.rows.slice(0, Number(opt('top', 40)))) console.log(`${r.read ? 'READ' : '    '} ${r.source.padEnd(48).slice(0, 48)} ${String(r.series).padStart(5)} series ${String(Math.round(r.openVolume)).padStart(12)}`);
}

if (cmd === 'read') await read();
else if (cmd === 'coverage') cover();
else { console.error('usage: kalshi-sources.mjs read|coverage'); process.exit(2); }

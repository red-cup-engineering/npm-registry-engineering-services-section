#!/usr/bin/env node
// Read-only (GETs only, through createKalshiClient). Derives the selected account's books from its venue records,
// has Farolfi check them, reconciles every wallet with the venue, and answers questions as Farolfi queries over the
// journal. Prints JSON; `--journal` prints the Beancount instead. Account: KALSHI_ACCOUNT_ID (+ credential env).
import { readLedgerReport } from '@red-cup-engineering/farolfi/ledger/reports';
import { createKalshiClient } from '../src/client.mjs';
import { dollarsText, reconcileKalshiLedger, renderJournal } from '../src/kalshi-ledger.mjs';

const [ledger, venue] = await createKalshiClient().getLedgerInputs();
const text = renderJournal(ledger);
if (process.argv.includes('--journal')) { process.stdout.write(text); process.exit(0); }

const journal = { text, format: 'beancount' };
const holder = ledger.coa.cashPrefix.split(':')[2];
// A query is a Farolfi report over the journal: the report name and an account-name regular expression.
const queries = {
  'cash per wallet': { report: 'balance', account: `^Assets:Kalshi:${holder}:Cash` },
  'credits received': { report: 'balance', account: `^Income:Kalshi:${holder}:Credits` },
  'contributions per rail': { report: 'balance', account: `^Equity:Kalshi:${holder}:Contributions` },
  'withdrawn per rail': { report: 'balance', account: `^Equity:Kalshi:${holder}:Withdrawals` },
  'realized P&L by market': { report: 'balance', account: `^Income:Kalshi:${holder}:(Realized-PnL|Funding)` },
  'fees by kind': { report: 'balance', account: `^Expenses:Kalshi:${holder}:Fees` },
};
const leaves = (node, out = []) => {
  const usd = node.own?.USD?.value;
  if (usd) out.push([node.name, dollarsText((BigInt(usd.num) * 1_000_000n) / BigInt(usd.den))]);
  for (const child of Object.values(node.children ?? {})) leaves(child, out);
  return out;
};
const answers = {};
for (const [name, q] of Object.entries(queries)) {
  const rows = leaves((await readLedgerReport({ journal, ...q })).tree);
  answers[name] = { query: q, total: dollarsText(rows.reduce((s, [, v]) => s + BigInt(v.replace('.', '')), 0n)), rows: name === 'realized P&L by market' ? rows.filter(([, v]) => v !== '0.000000').length + ' non-zero accounts' : rows };
}
const check = await readLedgerReport({ journal, report: 'check' });
console.log(JSON.stringify({ accountId: ledger.accountId, entries: ledger.transactions.length, skipped: ledger.skipped, farolfiCheck: { ok: check.ok, contradictions: check.contradictions.length }, reconciliation: reconcileKalshiLedger(ledger, venue), queries: answers }, null, 2));

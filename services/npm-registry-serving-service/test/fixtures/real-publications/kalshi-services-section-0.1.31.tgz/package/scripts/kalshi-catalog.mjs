#!/usr/bin/env node
// The universal Kalshi catalog: sync, coverage, spec, stats. One SignCraft history per shard (see src/catalog.mjs).
//   kalshi-catalog sync [--limit N] [--settled-hours H]
//   kalshi-catalog coverage [--top N]
//   kalshi-catalog spec <ticker>
//   kalshi-catalog stats
// Public GETs only. Each shard is a SignCraft history held in memory one at a time; what persists is the shard's
// feed of SEAVT rows (src/seavt-log.mjs), one row per changed fact, in the settlement's data/logs/catalog-fact-logs/.
import { appendFileSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { cell } from '@red-cup-engineering/signcell/cell';
import { createHistory, historySize, observeHistory, queryHistory } from '@red-cup-engineering/signcraft/history';
import { appendLogRows, feedRows, logDays, logFile, unmark } from '../src/seavt-log.mjs';
import {seavtOfSignCell,signCellOfSeavt} from '@red-cup-engineering/semiotic-eavt-services-section/admit-seavt-row';
import { settlementRoot, stateDirectory } from '../src/data-layout.mjs';
import { createKalshiClient } from '../src/client.mjs';
import { FUNCTIONAL_PREDICATES, SHARDS, SOURCE, changedCells, contractSpec, eventPageCells, marketPageCells, predicate, seriesPageCells, seriesTickerOfTicker, settlementIndex, shardOf } from '../src/catalog.mjs';

/** The settlement root the catalog keeps its `data/` under (KALSHI_CATALOG_DIR overrides it). */
export const catalogDir = (env = process.env) => env.KALSHI_CATALOG_DIR ?? settlementRoot(env);
/** The one feed of the catalog's facts; its shards are a reading partition, not a filing one. */
const CATALOG_FEED = 'catalog-fact';
const catalogState = (dir) => stateDirectory(dir, 'catalog');
const spoolDirectory = (dir) => stateDirectory(dir, 'catalog-spool');
const spoolFile = (dir, shard) => join(spoolDirectory(dir), `${String(shard).padStart(2, '0')}.ndjson`);

/**
 * One shard's history, replayed from its feed: rows logged at one instant are one observation. `record`
 * appends changed cells to the feed as rows at `t`. Close it to release the reading.
 */
/** A native row retains the original SignCell witnesses. Legacy flat triple
 * rows did not retain them; the older synthetic replay witness remains clearly
 * limited to that legacy case. No invented issuer/source verification. */
const cellOfCatalogRow=row=>unmark(row.a)==='signcell:cell'
  ?signCellOfSeavt(row)
  :cell(unmark(row.e),unmark(row.a),unmark(row.v),{
    for:[{source:SOURCE,endpoint:'legacy-flat-catalog-log'}],
  });
const shardOfRow=(routes,row)=>shardOf(routeOf(routes,cellOfCatalogRow(row).subject));

export function openShard(dir, shard) {
  let history=createHistory(FUNCTIONAL_PREDICATES),batch=[],at=null;
  const flush=()=>{
    if(batch.length){
      history=observeHistory(history,batch,{source:SOURCE});
      batch=[];
    }
  };
  const routes=readRoutes(dir);
  for(const row of feedRows(dir,CATALOG_FEED)){
    const native=cellOfCatalogRow(row);
    if(shardOf(routeOf(routes,native.subject))!==shard)continue;
    if(row.t!==at){flush();at=row.t;}
    batch.push(native);
  }
  flush();
  return {
    shard,
    get history(){return history;},
    set history(next){history=next;},
    record(cells,t){
      // SCA address + original complete SignCell/FOUR evidence carried by
      // native SEN/SEAVT, with no shadow EAVT truth database.
      appendLogRows(dir,CATALOG_FEED,cells.map(c=>seavtOfSignCell(c,t)),
        row=>row.t.slice(0,10),{distinct:false});
    },
    close(){},
  };
}

/** Read every shard that already holds a catalog claim; native SEAVT's
 * subject is an SCA address, so shard by the recovered cell subject. */
const existingShards=dir=>{
  const shards=new Set(),routes=readRoutes(dir);
  for(const row of feedRows(dir,CATALOG_FEED))
    if(shards.add(shardOfRow(routes,row)).size===SHARDS)break;
  return [...shards].sort((a,b)=>a-b);
};
export function foldShards(dir,fold,initial){
  let acc=initial;
  for(const shard of existingShards(dir)){
    const open=openShard(dir,shard);
    try{acc=fold(acc,open);}
    finally{open.close();}
  }
  return acc;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** A client call paced ~200 ms apart, backing off exponentially on 429 and transient failure. */
export function politeCaller(client, { pace = 200, retries = 8, log = () => {} } = {}) {
  let last = 0;
  return async function get(path, query) {
    for (let attempt = 0; ; attempt += 1) {
      const wait = last + pace - Date.now();
      if (wait > 0) await sleep(wait);
      last = Date.now();
      try { return await client.call('GET', path, { query, signed: false }); } catch (error) {
        const transient = error.status === 429 || error.status >= 500 || error.code === 'network';
        if (!transient || attempt >= retries) throw error;
        const delay = Math.min(60000, 1000 * 2 ** attempt);
        log(`  ${error.code} on ${path}; backing off ${delay} ms`);
        await sleep(delay);
        last = Date.now();
      }
    }
  };
}

// Kalshi names a market SERIES-EVENT-STRIKE, except a few legacy events (EUCLIMATE under KXEUCLIMATE).
// The exceptions are routes learned from the events crawl and kept beside the shards.
const routesFile = (dir) => join(catalogState(dir), 'routes.json');
const readRoutes = (dir) => (existsSync(routesFile(dir)) ? JSON.parse(readFileSync(routesFile(dir), 'utf8')) : {});
const routeOf = (routes, ticker) => routes[seriesTickerOfTicker(ticker)] ?? seriesTickerOfTicker(ticker);

const triple = (c) => [c.subject, c.predicate, c.object];
/** Spool: one NDJSON line per (page, shard) of the page's cells as triples; a staging buffer drained into the shard's history. */
function spool(dir, byShard, endpoint) {
  for (const [shard, cells] of byShard) {
    mkdirSync(spoolDirectory(dir), { recursive: true });
    appendFileSync(spoolFile(dir, shard), `${JSON.stringify({ endpoint, cells: cells.map(triple) })}\n`);
  }
}
const group = (items, shardOfItem, cellsOfItem) => {
  const byShard = new Map();
  for (const item of items) { const shard = shardOf(shardOfItem(item)); const list = byShard.get(shard) ?? []; list.push(...cellsOfItem(item)); byShard.set(shard, list); }
  return byShard;
};

/** Drain one shard's spool into its history: each spooled page's cells that differ from the current reading become rows. */
function drain(dir, shard, stats) {
  const file = spoolFile(dir, shard);
  const open = openShard(dir, shard);
  try {
    for (const line of readFileSync(file, 'utf8').split('\n')) {
      if (!line) continue;
      const { endpoint, cells } = JSON.parse(line);
      const witness = { source: SOURCE, endpoint };
      const changed = changedCells(open.history, cells.map(([s, p, o]) => cell(s, p, o, { for: [witness] })));
      stats.cells += cells.length; stats.changed += changed.length;
      if (changed.length) { open.history = observeHistory(open.history, changed, { source: SOURCE }); open.record(changed, new Date().toISOString()); stats.revisions += 1; }
    }
  } finally { open.close(); }
  rmSync(file);
}

export async function sync({ client = createKalshiClient({ credentials: null }), dir = catalogDir(), limit = Infinity, settledHours = 6, pace = 200, log = (m) => process.stderr.write(`${m}\n`) } = {}) {
  const get = politeCaller(client, { pace, log });
  const t0 = Date.now();
  const routes = readRoutes(dir);
  const stats = { pages: 0, cells: 0, changed: 0, revisions: 0, series: 0, events: 0, markets: 0, prefixMismatches: 0 };
  const elapsed = () => `${((Date.now() - t0) / 1000).toFixed(0)} s`;
  mkdirSync(spoolDirectory(dir), { recursive: true }); mkdirSync(catalogState(dir), { recursive: true });
  // Spool left by an interrupted run is drained first; applying it again is idempotent.
  const leftover = existsSync(spoolDirectory(dir)) ? readdirSync(spoolDirectory(dir)).map((f) => Number(f.split('.')[0])) : [];
  const crawl = async (path, key, query, onRows) => {
    let cursor;
    for (let page = 0; page < limit; page += 1) {
      const payload = await get(path, { ...query, cursor });
      onRows(payload[key] ?? []);
      stats.pages += 1;
      log(`${path} page ${page + 1}: ${stats.series} series, ${stats.events} events, ${stats.markets} markets, ${elapsed()}, rss ${(process.memoryUsage.rss() / 1e6).toFixed(0)} MB`);
      cursor = payload.cursor;
      if (!cursor) return true;
    }
    return false;
  };
  const complete = {};
  complete.series = await crawl('/series', 'series', { limit: 1000 }, (rows) => { stats.series += rows.length; spool(dir, group(rows, (x) => x.ticker, (x) => seriesPageCells([x])), '/series'); });
  complete.events = await crawl('/events', 'events', { status: 'open', with_nested_markets: true, limit: 200 }, (rows) => {
    stats.events += rows.length; stats.markets += rows.reduce((n, e) => n + (e.markets?.length ?? 0), 0);
    for (const e of rows) if (seriesTickerOfTicker(e.event_ticker) !== e.series_ticker) { routes[seriesTickerOfTicker(e.event_ticker)] = e.series_ticker; stats.prefixMismatches += 1; }
    spool(dir, group(rows, (e) => e.series_ticker, (e) => eventPageCells([e])), '/events');
  });
  writeFileSync(routesFile(dir), `${JSON.stringify(routes, null, 1)}\n`);
  const control = join(catalogState(dir), 'settled-through');
  const since = existsSync(control) ? Number(readFileSync(control, 'utf8')) : Math.floor(Date.now() / 1000) - settledHours * 3600;
  const until = Math.floor(Date.now() / 1000);
  complete.settled = await crawl('/markets', 'markets', { status: 'settled', mve_filter: 'exclude', min_settled_ts: since, limit: 1000 }, (rows) => {
    stats.markets += rows.length; spool(dir, group(rows, (m) => routeOf(routes, m.ticker), (m) => marketPageCells([m])), '/markets');
  });
  const shards = [...new Set([...leftover, ...readdirSync(spoolDirectory(dir)).map((f) => Number(f.split('.')[0]))])].sort((a, b) => a - b);
  for (const shard of shards) {
    if (existsSync(spoolFile(dir, shard))) drain(dir, shard, stats);
    log(`shard ${shard} drained: ${stats.changed}/${stats.cells} cells changed, ${elapsed()}, rss ${(process.memoryUsage.rss() / 1e6).toFixed(0)} MB`);
  }
  if (complete.settled) writeFileSync(control, String(until));
  return { ...stats, complete, seconds: (Date.now() - t0) / 1000 };
}

const logBytes = (dir) => logDays(dir, CATALOG_FEED).reduce((n, day) => n + statSync(logFile(dir, CATALOG_FEED, day)).blocks * 512, 0);
export function catalogStats(dir = catalogDir()) {
  const total = foldShards(dir, (acc, { history }) => {
    acc.series += queryHistory(history, { predicate: predicate('series', 'title') }).length;
    acc.events += queryHistory(history, { predicate: predicate('event', 'series') }).length;
    acc.markets += queryHistory(history, { predicate: predicate('market', 'event') }).length;
    acc.openMarkets += queryHistory(history, { predicate: predicate('market', 'status'), object: 'active' }).length;
    acc.cells += historySize(history); return acc;
  }, { series: 0, events: 0, markets: 0, openMarkets: 0, cells: 0 });
  return { ...total, shards: existingShards(dir).length, logBytes: logBytes(dir) };
}

/** Settlement-source rows, merged across shards (series are shard-disjoint, so sums add), sorted by open volume. */
export function coverage(dir = catalogDir(), top = Infinity) {
  const merged = foldShards(dir, (acc, { history }) => {
    for (const [source, series] of Object.entries(settlementIndex(history))) {
      const row = (acc[source] ??= { source, series: 0, markets: 0, volume: 0 });
      for (const r of Object.values(series)) { row.series += 1; row.markets += r.markets; row.volume += r.volume; }
    }
    return acc;
  }, {});
  return Object.values(merged).sort((a, b) => b.volume - a.volume || a.source.localeCompare(b.source)).slice(0, top);
}

/** The contract spec of a ticker: its shard by series ticker, else a scan of every shard. */
export function specOf(dir, ticker) {
  const tried = new Set();
  const attempt = (shard) => { tried.add(shard); if (!existingShards(dir).includes(shard)) return null; const open = openShard(dir, shard); try { return contractSpec(open.history, ticker); } finally { open.close(); } };
  const direct = attempt(shardOf(routeOf(readRoutes(dir), ticker)));
  if (direct) return direct;
  for (const shard of existingShards(dir)) if (!tried.has(shard)) { const spec = attempt(shard); if (spec) return spec; }
  return null;
}

const arg = (argv, name, fallback) => { const i = argv.indexOf(`--${name}`); return i < 0 ? fallback : Number(argv[i + 1]); };

async function main(argv) {
  const [command, ...rest] = argv;
  const dir = catalogDir();
  if (command === 'sync') {
    const out = await sync({ dir, limit: arg(rest, 'limit', Infinity), settledHours: arg(rest, 'settled-hours', 6) });
    console.log(JSON.stringify({ ...out, ...catalogStats(dir) }, null, 2));
  } else if (command === 'coverage') {
    console.log(['source', 'series', 'open markets', 'open volume'].join('\t'));
    for (const r of coverage(dir, arg(rest, 'top', Infinity))) console.log([r.source, r.series, r.markets, Math.round(r.volume)].join('\t'));
  } else if (command === 'spec') {
    const spec = specOf(dir, rest[0]);
    if (!spec) { console.error(`unknown ticker ${rest[0]}`); process.exitCode = 1; } else console.log(JSON.stringify(spec, null, 2));
  } else if (command === 'stats') console.log(JSON.stringify(catalogStats(dir), null, 2));
  else { console.error('usage: kalshi-catalog sync [--limit N] | coverage [--top N] | spec <ticker> | stats'); process.exitCode = 2; }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) await main(process.argv.slice(2));

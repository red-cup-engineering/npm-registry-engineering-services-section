#!/usr/bin/env node
/**
 * Is the weather market maker ready to be armed? A deterministic, read-only check of its recorded shadow run against the
 * acceptance gates of content/text/documents/specifications/weather-market-making.md section 8, gate 5.
 *
 * It reads the settlement root's weather-market-making logs (every account's: the host root's and accounts/<id>/) and its
 * shadow-score state, and the order risk gate's loss limit. It writes nothing, places nothing and re-arms nothing: it
 * informs the Leader's decision, which is the Leader's. Exit status: 0 pass, 1 fail, 2 the logs could not be read.
 *
 *   node scripts/amm-readiness.mjs [--root <settlement root>] [--days 7] [--until <ISO instant>] [--json]
 *
 * The window is `--days` days ending at `--until`, by default the instant of the latest recorded row, so the same logs
 * always give the same verdict.
 */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { parseArgs } from 'node:util';
import { sectionRoot } from '../src/data-layout.mjs';
import { feedRows, unmark } from '../src/seavt-log.mjs';
import { assess, MIN_LADDERS, MIN_FILLS } from '../src/amm-readiness.mjs';

const FEED = 'weather-market-making';

/** The ledger rows of one settlement root, each as the JSON the desk wrote. Unreadable rows are counted, not guessed. */
export function ledgerRows(root) {
  const rows = []; let skipped = 0;
  try {
    for (const row of feedRows(root, FEED)) {
      try { const v = unmark(row.v); if (v && typeof v === 'object' && typeof v.kind === 'string' && typeof v.at === 'string') rows.push(v); else skipped += 1; } catch { skipped += 1; }
    }
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  return { rows, skipped };
}

/** The shadow-score state under a root (the older opportunity scoring), summarized; null when there is none. */
export function shadowScores(root) {
  const file = join(root, 'data', 'state', 'shadow-score-state', 'scores.json');
  if (!existsSync(file)) return null;
  const s = JSON.parse(readFileSync(file, 'utf8'));
  return { generatedAt: s.generatedAt, source: s.source, settled: s.settled, opportunities: s.opportunities, lanes: Object.keys(s.lanes ?? {}), note: 'opportunity scoring of the old desk lanes, not the weather market maker; informational' };
}

/** The roots whose logs hold the desk's rows: the host root, and each account's under accounts/. */
export const rootsOf = (root) => [root, ...(existsSync(join(root, 'accounts')) ? readdirSync(join(root, 'accounts')).sort().map((a) => join(root, 'accounts', a)) : [])];

export function readiness({ root, days, until }) {
  const limits = JSON.parse(readFileSync(new URL('../content/config/order-risk-limits.json', import.meta.url), 'utf8'));
  const rows = []; let skipped = 0; const roots = [];
  for (const r of rootsOf(root)) { const got = ledgerRows(r); if (got.rows.length || got.skipped) roots.push({ root: r, rows: got.rows.length, skipped: got.skipped }); rows.push(...got.rows); skipped += got.skipped; }
  const verdict = assess(rows, { days, until, lossFraction: limits.lossFraction });
  return { ...verdict, root, logs: roots, skippedRows: skipped, shadowScores: shadowScores(root), gatesAre: { source: 'content/text/documents/specifications/weather-market-making.md section 8, gate 5', minLadders: MIN_LADDERS, minFills: MIN_FILLS, lossFraction: limits.lossFraction } };
}

function text(r) {
  const out = [`AMM readiness: ${r.verdict.toUpperCase()}   (root ${r.root}; window ${r.window.days} days to ${r.window.until ?? 'n/a'})`];
  out.push(`ledger rows read: ${r.logs.map((l) => `${l.rows} in ${l.root}`).join(', ') || 'none'}${r.skippedRows ? ` (${r.skippedRows} unreadable, skipped)` : ''}`);
  for (const reason of r.reasons) out.push(`  fails: ${reason}`);
  for (const [account, a] of Object.entries(r.accounts)) {
    out.push(`account ${account}: ${a.pass ? 'pass' : 'fail'}; modes ${a.modes.join(',') || 'none'}; ${a.rows} rows in window`);
    for (const [g, v] of Object.entries(a.gates)) { const { pass, byCity, need, ...rest } = v; out.push(`  ${pass ? 'pass' : 'FAIL'} ${g}: ${JSON.stringify(rest)}${byCity ? ` byCity ${JSON.stringify(byCity)}` : ''}`); }
  }
  const s = r.shadowScores; out.push(s ? `shadow-score state: generated ${s.generatedAt}, ${s.settled} settled of ${s.opportunities} (${s.note})` : 'shadow-score state: none');
  return out.join('\n');
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const { values } = parseArgs({ options: { root: { type: 'string' }, days: { type: 'string', default: '7' }, until: { type: 'string' }, json: { type: 'boolean', default: false } } });
  try {
    const r = readiness({ root: values.root ?? sectionRoot(), days: Number(values.days), until: values.until });
    process.stdout.write((values.json ? JSON.stringify(r, null, 2) : text(r)) + '\n');
    process.exitCode = r.verdict === 'pass' ? 0 : 1;
  } catch (error) { process.stderr.write(`amm-readiness: ${error.message}\n`); process.exitCode = 2; }
}

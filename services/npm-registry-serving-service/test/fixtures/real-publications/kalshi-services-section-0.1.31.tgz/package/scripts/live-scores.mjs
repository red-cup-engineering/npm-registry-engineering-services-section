#!/usr/bin/env node
/**
 * The weather model scored live against the market (src/live-scores.mjs), read-only, from a settlement root's stored
 * belief-score rows (the host root's and each account's under accounts/).
 *   node scripts/live-scores.mjs [--root <settlement root>] [--json]
 */
import { readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { parseArgs } from 'node:util';
import { sectionRoot } from '../src/data-layout.mjs';
import { storedScores } from '../src/live-score-store.mjs';
import { liveStats, LIVE_MIN_EVENTS } from '../src/live-scores.mjs';

export const rootsOf = (root) => [root, ...(existsSync(join(root, 'accounts')) ? readdirSync(join(root, 'accounts')).sort().map((a) => join(root, 'accounts', a)) : [])];

if (import.meta.url === `file://${process.argv[1]}`) {
  const { values } = parseArgs({ options: { root: { type: 'string' }, json: { type: 'boolean', default: false } } });
  const root = values.root ?? sectionRoot();
  // one account's scores: every desk of the plan scores the same beliefs, so pooling accounts would count a ladder once per account
  const rows = rootsOf(root).map((r) => storedScores(r)).find((r) => r.length) ?? [];
  const stats = liveStats(rows);
  if (values.json) process.stdout.write(JSON.stringify(stats, null, 2) + '\n');
  else {
    const f = (c) => (c.events ? `${String(c.events).padStart(4)} ladders  dBrier ${c.dBrier.toFixed(4)} [${c.dBrierCI.map((x) => x.toFixed(4))}]  dLog ${c.dLogLoss.toFixed(4)} [${c.dLogLossCI.map((x) => x.toFixed(4))}]` : '   0 ladders');
    process.stdout.write(`pooled: ${f(stats.pooled)}\n(live statistics replace the replay's in a cell from ${LIVE_MIN_EVENTS} ladders)\n`);
    for (const [city, c] of Object.entries(stats.byCity)) { process.stdout.write(`${city}: ${f(c.pooled)}\n`); for (const [b, cell] of Object.entries(c.buckets)) if (cell.events) process.stdout.write(`  ${b.padEnd(4)} ${f(cell)}\n`); }
  }
}
